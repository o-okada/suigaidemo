###############################################################################
### ファイル名：P0300AreaUpload/views.py
### 水害区域図アップロード
###############################################################################

import os
import sys
from datetime import date, datetime, timedelta, timezone
from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic

from .forms import AreaUploadForm

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

from MessageQueue.views import get_message 
from MessageQueue.views import publish_message 
from MessageQueue.views import publish_consume_message 
from MessageQueue.views import consume_message 
from MessageQueue.views import delete_message 

_B01 = 'B01'
_B02 = 'B02'
_B03 = 'B03'
_B04 = 'B04'
_B05 = 'B05'
_B06 = 'B06'
_B07 = 'B07'
_B08 = 'B08'
_B09 = 'B09'
_B10 = 'B10'
_B99 = 'B99'

_WAITING = 'WAITING'
_RUNNING = 'RUNNING'
_SUCCESS = 'SUCCESS'
_FAILURE = 'FAILURE'
_CANCEL = 'CANCEL'

###############################################################################
### 関数名：index_view(request)
### urlpattern：path('', views.index_view, name='index_view')
### (1)GETの場合、水害区域図アップロード画面を表示する。
### (2)POSTの場合、アップロードされた水害区域図をチェックして、正常ケースの場合、DBに登録する。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0300AreaUpload.index_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 STEP 1/12.', 'DEBUG')
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 request={}'.format(request.method), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 STEP 2/12.', 'DEBUG')
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
    
        #######################################################################
        ### 条件分岐処理(0020)
        ### (1)GETの場合、水害区域図アップロード画面を表示して関数を抜ける。
        ### (2)POSTの場合、アップロードされた水害区域図をチェックする。
        ### ※ネストを浅くするため。
        #######################################################################
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 STEP 3/12.', 'DEBUG')
        if request.method == 'GET':
            form = AreaUploadForm()
            context = {
                'form': form, 
                'ken_list': ken_list, 
            }
            print_log('[INFO] P0300AreaUpload.index_view()関数が正常終了しました。', 'INFO')
            return render(request, 'P0300AreaUpload/index.html', context)
        
        elif request.method == 'POST':
            form = AreaUploadForm(request.POST, request.FILES)
            
        #######################################################################
        ### フォーム検証処理(0030)
        ### (1)フォームが正しい場合、処理を継続する。
        ### (2)フォームが正しくない場合、ERROR画面を表示して関数を抜ける。
        ### ※ネストを浅くするため。
        #######################################################################
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 STEP 4/12.', 'DEBUG')
        if form.is_valid() == False:
            print_log('[WARN] P0300AreaUpload.index_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0300IppanUpload/index.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))
    
        #######################################################################
        ### 水害区域図入出力処理(0040)
        ### (1)局所変数に値をセットする。
        ### (2)アップロードされた水害区域図ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 STEP 5/12.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_Ym = datetime.now(JST).strftime('%Y%m')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        
        upload_file_object = request.FILES['file']
        upload_file_name, upload_file_ext = os.path.splitext(request.FILES['file'].name)
        upload_file_name = upload_file_name + '_' + datetime_now_YmdHMS
        upload_file_path = 'static/repository/' + datetime_now_Ym + '/' + upload_file_name + '.pdf'
        
        with open(upload_file_path, 'wb+') as destination:
            for chunk in upload_file_object.chunks():
                destination.write(chunk)
        
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 upload_file_object={}'.format(upload_file_object), 'DEBUG')
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 upload_file_name={}'.format(upload_file_name), 'DEBUG')
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 upload_file_ext={}'.format(upload_file_ext), 'DEBUG')
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 upload_file_path={}'.format(upload_file_path), 'DEBUG')

        #######################################################################
        ### ポストデータ検証処理(0050)
        ### ポストされたデータをチェックして、局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 STEP 6/12.', 'DEBUG')
        area_id = request.POST.get('area_id')
        area_name = request.POST.get('area_name')
        ken_code = request.POST.get('ken_code')
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 area_id={}'.format(area_id), 'DEBUG')
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 area_name={}'.format(area_name), 'DEBUG')
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 ken_code={}'.format(ken_code), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0060)
        ### 水害区域テーブルのデータを削除済に更新する。
        ### 水害区域テーブルにデータを登録する。
        #######################################################################
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 STEP 7/12.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""");
            
            ###################################################################
            ### DBアクセス処理(0070)
            ### 水害区域テーブルのデータを削除済に更新する。
            ###################################################################
            print_log('[DEBUG] P0300AreaUpload.index_view()関数 STEP 8/12.', 'DEBUG')
            params = dict({
                'AREA_ID': int(area_id)
            })
            connection_cursor.execute("""
                DELETE 
                FROM AREA 
                WHERE 
                    area_id=%(AREA_ID)s""", params)
            
            ###################################################################
            ### DBアクセス処理(0080)
            ### 水害区域テーブルにデータを登録する。TODO TO-DO TO_DO
            ###################################################################
            print_log('[DEBUG] P0300AreaUpload.index_view()関数 STEP 9/12.', 'DEBUG')
            params = dict({
                'AREA_ID': int(area_id), 
                'AREA_NAME': area_name, 
                'KEN_CODE': ken_code, 
                'DELETED_AT': None, 
                'UPLOAD_FILE_PATH': upload_file_path, 
                'UPLOAD_FILE_NAME': upload_file_name 
            })
            connection_cursor.execute("""
                INSERT INTO AREA (
                    area_id, area_name, ken_code, committed_at, deleted_at, upload_file_path, upload_file_name
                ) VALUES (
                    %(AREA_ID)s, 
                    %(AREA_NAME)s, 
                    %(KEN_CODE)s, 
                    CURRENT_TIMESTAMP, 
                    %(DELETED_AT)s, 
                    %(UPLOAD_FILE_PATH)s, 
                    %(UPLOAD_FILE_NAME)s)""", params)
    
            ###################################################################
            ### DBアクセス処理(0090)
            ### トリガーテーブルにB01水害区域図アップロードトリガーを実行済、成功として登録する。TODO TO-DO TO_DO
            ###################################################################
            print_log('[DEBUG] P0300AreaUpload.index_view()関数 STEP 10/12.', 'DEBUG')
            metadata = dict({
                'connection_cursor': connection_cursor, 
                'header_id': None, 
                'ken_code': ken_code, 
                'city_code': None, 
                'action_code': _B01, 
                'status_code': _SUCCESS, 
                'info_count': 1, 
                'warn_count': 0, 
                'deleted_at': None, 
                'info_log': get_info_log(), 
                'warn_log': get_warn_log(), 
                'download_file_path': None, 
                'download_file_name': None, 
                'upload_file_path': upload_file_path, 
                'upload_file_name': upload_file_name
            })
            bool_return = publish_consume_message(metadata=metadata)
            if bool_return == False:
                print_log('[WARN] publish_message()関数が警告終了しました。', 'WARN')
                raise Exception
            
            ###################################################################
            ### DBアクセス処理(0100)
            ### トリガーテーブルにB02水害区域図貼付けトリガーを未実行＝次回実行対象として登録する。TODO TO-DO TO_DO
            ###################################################################
            print_log('[DEBUG] P0300AreaUpload.index_view()関数 STEP 11/12.', 'DEBUG')
            metadata = dict({
                'connection_cursor': connection_cursor, 
                'header_id': None, 
                'ken_code': ken_code, 
                'city_code': None, 
                'action_code': _B02, 
                'status_code': None, 
                'download_file_path': None, 
                'download_file_name': None, 
                'upload_file_path': upload_file_path, 
                'upload_file_name': upload_file_name
            })
            bool_return = publish_message(metadata=metadata)
            if bool_return == False:
                print_log('[WARN] publish_message()関数が警告終了しました。', 'WARN')
                raise Exception
                
            connection_cursor.execute("""COMMIT""");
            
        except:
            print_log('[ERROR] P0300AreaUpload.index_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0300AreaUpload.index_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0300AreaUpload.index_view()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            template = loader.get_template('P0300AreaUpload/index.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))
            
        finally:
            connection_cursor.close()
            
        #######################################################################
        ### レスポンスセット処理(0110)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0300AreaUpload.index_view()関数 STEP 12/12.', 'DEBUG')
        template = loader.get_template('P0300AreaUpload/success.html')
        context = {
        }
        print_log('[INFO] P0300AreaUpload.index_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0300AreaUpload.index_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0300AreaUpload.index_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0300AreaUpload.index_viwe()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0300AreaUpload/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
    