from django.urls import path
from . import views

app_name = 'P0800Reverse'
urlpatterns = [
    path('', views.input_view, name='input_view'), 
    
    path('input/', views.input_view, name='input_view'), 
    path('input/ken/<slug:ken_code>/city/<slug:city_code>/cat/<slug:cat_code>/', views.input_ken_city_cat_view, name='input_ken_city_cat_view'), 
    
    path('summary/', views.summary_view, name='summary_view'), 
    path('summary/ken/<slug:ken_code>/city/<slug:city_code>/cat/<slug:cat_code>/', views.summary_ken_city_cat_view, name='summary_ken_city_cat_view'), 
]
