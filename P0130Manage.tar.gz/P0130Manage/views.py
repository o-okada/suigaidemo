###############################################################################
### ファイル名：P0130Manage/views.py
### ファイル管理
###############################################################################

import json                                            ### ADD 2023/02/06
import os                                              ### ADD 2023/02/21
import sys

from datetime import date, datetime                    ### ADD 2023/02/21
from datetime import timedelta, timezone               ### ADD 2023/02/21

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import connection                       ### ADD 2023/02/21
from django.db import transaction                      ### ADD 2023/02/21
from django.db.models import Max                       ### ADD 2023/02/21
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.http import HttpResponseNotFound           ### ADD 2023/02/17
from django.http.response import JsonResponse          ### ADD 2023/02/06
from django.shortcuts import redirect                  ### ADD 2023/02/10
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic.base import TemplateView

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査員調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査員調査票_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査員調査票_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.models import KEN_BUCKET              ### 99999: バケットデータ_都道府県
from P0000Common.models import CITY_BUCKET             ### 99999: バケットデータ_市区町村

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from P0000Common.services import get_ippan_chosa_csv_excel     ### ADD 2023/03/09
from P0000Common.services import get_ippan_summary_csv_excel   ### ADD 2023/03/09
from P0000Common.services import get_area_kml_pdf              ### ADD 2023/03/09
from P0000Common.services import get_chitan_chosa_csv_excel    ### ADD 2023/03/09
from P0000Common.services import get_chitan_summary_csv_excel  ### ADD 2023/03/09
from P0000Common.services import get_hojo_chosa_csv_excel      ### ADD 2023/03/09
from P0000Common.services import get_koeki_chosa_csv_excel     ### ADD 2023/03/09
from P0000Common.services import get_koeki_summary_csv_excel   ### ADD 2023/03/09

from P0000Common.services import create_ippan_chosa_excel      ### ADD 2023/03/09
from P0000Common.services import create_chitan_chosa_excel     ### ADD 2023/03/09
from P0000Common.services import create_hojo_chosa_excel       ### ADD 2023/03/09
from P0000Common.services import create_koeki_chosa_excel      ### ADD 2023/03/09

_KEN01 = '01'
_KEN02 = '02'
_KEN03 = '03'
_KEN04 = '04'
_KEN05 = '05'
_KEN06 = '06'
_KEN07 = '07'
_KEN08 = '08'
_KEN09 = '09'
_KEN10 = '10'
_KEN11 = '11'
_KEN12 = '12'
_KEN13 = '13'
_KEN14 = '14'
_KEN15 = '15'
_KEN16 = '16'
_KEN17 = '17'
_KEN18 = '18'
_KEN19 = '19'
_KEN20 = '20'
_KEN21 = '21'
_KEN22 = '22'
_KEN23 = '23'
_KEN24 = '24'
_KEN25 = '25'
_KEN26 = '26'
_KEN27 = '27'
_KEN28 = '28'
_KEN29 = '29'
_KEN30 = '30'
_KEN31 = '31'
_KEN32 = '32'
_KEN33 = '33'
_KEN34 = '34'
_KEN35 = '35'
_KEN36 = '36'
_KEN37 = '37'
_KEN38 = '38'
_KEN39 = '39'
_KEN40 = '40'
_KEN41 = '41'
_KEN42 = '42'
_KEN43 = '43'
_KEN44 = '44'
_KEN45 = '45'
_KEN46 = '46'
_KEN47 = '47'

### USER_PROXYテーブル.ROLE_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_ROLE_CITY = 'ROLE_CITY'
_ROLE_KEN = 'ROLE_KEN'
_ROLE_MANAGE = 'ROLE_MANAGE'

### ACTIONテーブル.ACTION_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_IPP_ACT_01 = 'IPP_ACT_01'
_IPP_ACT_02 = 'IPP_ACT_02'
_IPP_ACT_03 = 'IPP_ACT_03'
_IPP_ACT_04 = 'IPP_ACT_04'
_IPP_ACT_05 = 'IPP_ACT_05'
_IPP_ACT_06 = 'IPP_ACT_06'
_IPP_ACT_07 = 'IPP_ACT_07'

_CHI_ACT_01 = 'CHI_ACT_01'
_CHI_ACT_02 = 'CHI_ACT_02'
_CHI_ACT_03 = 'CHI_ACT_03'
_CHI_ACT_04 = 'CHI_ACT_04'
_CHI_ACT_05 = 'CHI_ACT_05'
_CHI_ACT_06 = 'CHI_ACT_06'
_CHI_ACT_07 = 'CHI_ACT_07'

_HOJ_ACT_01 = 'HOJ_ACT_01'
_HOJ_ACT_02 = 'HOJ_ACT_02'
_HOJ_ACT_03 = 'HOJ_ACT_03'
_HOJ_ACT_04 = 'HOJ_ACT_04'
_HOJ_ACT_05 = 'HOJ_ACT_05'
_HOJ_ACT_06 = 'HOJ_ACT_06'
_HOJ_ACT_07 = 'HOJ_ACT_07'

_KOE_ACT_01 = 'KOE_ACT_01'
_KOE_ACT_02 = 'KOE_ACT_02'
_KOE_ACT_03 = 'KOE_ACT_03'
_KOE_ACT_04 = 'KOE_ACT_04'
_KOE_ACT_05 = 'KOE_ACT_05'
_KOE_ACT_06 = 'KOE_ACT_06'
_KOE_ACT_07 = 'KOE_ACT_07'

_ARE_ACT_01 = 'ARE_ACT_01'
_ARE_ACT_02 = 'ARE_ACT_02'
_ARE_ACT_03 = 'ARE_ACT_03'
_ARE_ACT_04 = 'ARE_ACT_04'
_ARE_ACT_05 = 'ARE_ACT_05'
_ARE_ACT_06 = 'ARE_ACT_06'
_ARE_ACT_07 = 'ARE_ACT_07'

### 局所定数 ※DELETE関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP = 'IPP'
_ARE = 'ARE'
_CHI = 'CHI'
_HOJ = 'HOJ'
_KOE = 'KOE'

### 局所定数 ※DOWNLOAD関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP_CHO_EXC = 'IPP_CHO_EXC'
_IPP_CHO_CSV = 'IPP_CHO_CSV'
_IPP_SUM_EXC = 'IPP_SUM_EXC'
_IPP_SUM_CSV = 'IPP_SUM_CSV'
_CHI_CHO_EXC = 'CHI_CHO_EXC'
_CHI_CHO_CSV = 'CHI_CHO_CSV'
_CHI_SUM_EXC = 'CHI_SUM_EXC'
_CHI_SUM_CSV = 'CHI_SUM_CSV'
_HOJ_CHO_EXC = 'HOJ_CHO_EXC'
_HOJ_CHO_CSV = 'HOJ_CHO_CSV'
_HOJ_SUM_EXC = 'HOJ_SUM_EXC'
_HOJ_SUM_CSV = 'HOJ_SUM_CSV'
_KOE_CHO_EXC = 'KOE_CHO_EXC'
_KOE_CHO_CSV = 'KOE_CHO_CSV'
_KOE_SUM_EXC = 'KOE_SUM_EXC'
_KOE_SUM_CSV = 'KOE_SUM_CSV'
_ARE_PDF = 'ARE_PDF'
_ARE_KML = 'ARE_KML'

###############################################################################
### /P0130Manage/ => /P0130Manage/bucket/ リダイレクト用【済】
### 関数名：index_view(request)
### urlpattern：path('', views.index_view, name='index_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_view(request):
    return redirect('bucket/')

###############################################################################
### 運用担当者用バケット都バケット【済】
### 関数名：bucket_view(request)
### urlpattern：path('bucket/', views.bucket_view, name='bucket_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def bucket_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.bucket_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.bucket_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.bucket_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0130Manage/bucket/bucket.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_view()関数 STEP 4/6.', 'DEBUG')
        params = dict({
        })
        ken_bucket_list = KEN_BUCKET.objects.raw("""
            SELECT 
                KEN_CODE, 
                KEN_NAME, 
                USAGE, 
                FILES 
            FROM KEN_BUCKET 
            ORDER BY 
                CAST(KEN_CODE AS INTEGER)""")

        print_log('{}'.format(ken_bucket_list), 'DEBUG')
        print_log('{}'.format(len(ken_bucket_list)), 'DEBUG')
        print_log('{}'.format(ken_bucket_list[0]), 'DEBUG')
        print_log('{}'.format(ken_bucket_list[0].ken_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_view()関数 STEP 5/6.', 'DEBUG')
        if ken_bucket_list == False:
            print_log('[WARN] P0130Manage.bucket_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0130Manage/bucket/bucket.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.bucket_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0130Manage/bucket/bucket.html')
        context = {
            'ken_bucket_list': ken_bucket_list, 
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0130Manage.bucket_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.bucket_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.bucket_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0130Manage/bucket/bucket.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 運用担当者用バケット市バケット【済】
### 関数名：bucket_ken_code_view(request, ken_code)
### urlpattern：path('bucket/ken/<slug:ken_code>/', views.bucket_ken_code_view, name='bucket_ken_code_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def bucket_ken_code_view(request, ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.bucket_ken_code_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 ken_code={}'.format(ken_code), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 STEP 2/8.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### レスポンスセット処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.bucket_ken_code_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0130Manage/bucket/bucket_ken_code.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'KEN_CODE': ken_code
        })
        ### HTMLタイトル部分表示用
        ken_bucket_list = KEN_BUCKET.objects.raw("""
            SELECT 
                KEN_CODE, 
                KEN_NAME, 
                USAGE, 
                FILES 
            FROM KEN_BUCKET 
            WHERE 
                KEN_CODE=%(KEN_CODE)s""", params)

        print_log('{}'.format(ken_bucket_list), 'DEBUG')
        print_log('{}'.format(len(ken_bucket_list)), 'DEBUG')
        print_log('{}'.format(ken_bucket_list[0]), 'DEBUG')
        print_log('{}'.format(ken_bucket_list[0].ken_code), 'DEBUG')

        ### HTML一覧部分表示用
        city_bucket_list = CITY_BUCKET.objects.raw("""
            SELECT 
                CITY_CODE, 
                CITY_NAME, 
                KEN_CODE, 
                USAGE, 
                FILES 
            FROM CITY_BUCKET 
            WHERE 
                KEN_CODE=%(KEN_CODE)s 
            ORDER BY 
                CAST(CITY_CODE AS INTEGER)""", params)
        
        print_log('{}'.format(city_bucket_list), 'DEBUG')
        print_log('{}'.format(len(city_bucket_list)), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0]), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0].city_code), 'DEBUG')

        ### HTML一覧部分表示用
        chitan_header_list = CHITAN_HEADER.objects.raw("""
            SELECT 
                CHITAN_HEADER_ID, 
                CHITAN_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM CHITAN_HEADER 
            WHERE 
                KEN_CODE=%(KEN_CODE)s AND 
                DELETED_AT IS NULL""", params)
        
        print_log('{}'.format(chitan_header_list), 'DEBUG')
        print_log('{}'.format(len(chitan_header_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_header_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_header_list[0].chitan_header_id), 'DEBUG')

        ### HTML一覧部分表示用
        hojo_header_list = HOJO_HEADER.objects.raw("""
            SELECT 
                HOJO_HEADER_ID, 
                HOJO_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM HOJO_HEADER 
            WHERE 
                KEN_CODE=%(KEN_CODE)s AND 
                DELETED_AT IS NULL""", params)
        
        print_log('{}'.format(hojo_header_list), 'DEBUG')
        print_log('{}'.format(len(hojo_header_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_header_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_header_list[0].hojo_header_id), 'DEBUG')

        ### HTML一覧部分表示用
        koeki_header_list = KOEKI_HEADER.objects.raw("""
            SELECT 
                KOEKI_HEADER_ID, 
                KOEKI_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM KOEKI_HEADER 
            WHERE 
                KEN_CODE=%(KEN_CODE)s AND 
                DELETED_AT IS NULL""", params)
        
        print_log('{}'.format(koeki_header_list), 'DEBUG')
        print_log('{}'.format(len(koeki_header_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_header_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_header_list[0].koeki_header_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### レスポンスセット処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 STEP 5/6.', 'DEBUG')
        if ken_bucket_list == False:
            print_log('[WARN] P0130Manage.bucket_ken_code_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0130Manage/bucket/bucket_ken_code.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        if city_bucket_list == False:
            print_log('[WARN] P0130Manage.bucket_ken_code_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0130Manage/bucket/bucket_ken_code.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        ### 地方単独事業調査票ファイルの0件は正常であるため、
        ### 補助事業事業調査票ファイルの0件は正常であるため、
        ### 公益事業調査票ファイルの0件は正常であるため、
        ### 下記の戻り値チェックはコメントアウトすること。

        ### if chitan_header_list == False:
        ###     print_log('[WARN] P0130Manage.bucket_ken_code_view()関数が警告終了しました。', 'WARN')
        ###     template = loader.get_template('P0130Manage/bucket/bucket_ken_code.html')
        ###     context = {
        ###         'alert_log': get_alert_log(), 
        ###     }
        ###     return HttpResponse(template.render(context, request))

        ### if hojo_header_list == False:
        ###     print_log('[WARN] P0130Manage.bucket_ken_code_view()関数が警告終了しました。', 'WARN')
        ###     template = loader.get_template('P0130Manage/bucket/bucket_ken_code.html')
        ###     context = {
        ###         'alert_log': get_alert_log(), 
        ###     }
        ###     return HttpResponse(template.render(context, request))

        ### if koeki_header_list == False:
        ###     print_log('[WARN] P0130Manage.bucket_ken_code_view()関数が警告終了しました。', 'WARN')
        ###     template = loader.get_template('P0130Manage/bucket/bucket_ken_code.html')
        ###     context = {
        ###         'alert_log': get_alert_log(), 
        ###     }
        ###     return HttpResponse(template.render(context, request))

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.bucket_ken_code_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.bucket_ken_code_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0130Manage/bucket/bucket_ken_code.html')
        context = {
            'ken_bucket_list': ken_bucket_list, 
            'city_bucket_list': city_bucket_list, 
            'chitan_header_list': chitan_header_list, 
            'hojo_header_list': hojo_header_list, 
            'koeki_header_list': koeki_header_list, 
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0130Manage.bucket_ken_code_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.bucket_ken_code_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.bucket_ken_code_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0130Manage/bucket/bucket_ken_code.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 運用担当者用ブラウザ都アップロードファイル
### 関数名：browser_ken_code_view(request, ken_code)
### urlpattern：path('browser/ken/<slug:ken_code>/', views.browser_ken_code_view, name='browser_ken_code_view')
###############################################################################

###############################################################################
### 運用担当者用ブラウザ市アップロードファイル【済】
### 関数名：browser_city_code_view(request, city_code)
### urlpattern：path('browser/city/<slug:city_code>/', views.browser_city_code_view, name='browser_city_code_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def browser_city_code_view(request, city_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.browser_city_code_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.browser_city_code_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.browser_city_code_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.browser_city_code_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.browser_city_code_view()関数 city_code={}'.format(city_code), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.browser_city_code_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### レスポンスセット処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.browser_city_code_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.browser_city_code_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0130Manage/browser/browser_city_code.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        ### ※コンテンツにアクセス可能なユーザは運用担当者のみとする。
        ### ※0020で運用担当者のみに絞っているため、ここではアクセス制御しない。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'CITY_CODE': city_code
        })
        ### HTMLタイトル部分表示用
        city_bucket_list = CITY_BUCKET.objects.raw("""
            SELECT 
                CITY_CODE, 
                CITY_NAME, 
                KEN_CODE, 
                USAGE, 
                FILES 
            FROM CITY_BUCKET 
            WHERE 
                CITY_CODE=%(CITY_CODE)s""", params)
        
        print_log('{}'.format(city_bucket_list), 'DEBUG')
        print_log('{}'.format(len(city_bucket_list)), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0]), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0].city_code), 'DEBUG')

        ### HTML一覧部分表示用
        ippan_header_list = IPPAN_HEADER.objects.raw("""
            SELECT 
                IPPAN_HEADER_ID, 
                IPPAN_HEADER_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM IPPAN_HEADER 
            WHERE 
                CITY_CODE=%(CITY_CODE)s AND 
                DELETED_AT IS NULL""", params)
        
        print_log('{}'.format(ippan_header_list), 'DEBUG')
        print_log('{}'.format(len(ippan_header_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_header_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_header_list[0].ippan_header_id), 'DEBUG')

        ### HTML一覧部分表示用
        area_list = AREA.objects.raw("""
            SELECT 
                AREA_ID, 
                AREA_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM AREA 
            WHERE 
                CITY_CODE=%(CITY_CODE)s AND 
                DELETED_AT IS NULL""", params)
        
        print_log('{}'.format(area_list), 'DEBUG')
        print_log('{}'.format(len(area_list)), 'DEBUG')
        ### print_log('{}'.format(area_list[0]), 'DEBUG')
        ### print_log('{}'.format(area_list[0].area_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### レスポンスセット処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.browser_city_code_view()関数 STEP 5/6.', 'DEBUG')
        if city_bucket_list == False:
            print_log('[WARN] P0130Manage.browser_city_code_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0130Manage/browser/browser_city_code.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        ### 一般資産調査員調査票ファイルの0件は正常であるため、
        ### 水害区域図ファイルの0件は正常であるため、
        ### 下記の戻り値チェックはコメントアウトすること。

        ### if ippan_header_list == False:
        ###     print_log('[WARN] P0130Manage.browser_city_code_view()関数が警告終了しました。', 'WARN')
        ###     template = loader.get_template('P0130Manage/browser/browser_city_code.html')
        ###     context = {
        ###         'alert_log': get_alert_log(), 
        ###     }
        ###     return HttpResponse(template.render(context, request))

        ### if area_list == False:
        ###     print_log('[WARN] P0130Manage.browser_city_code_view()関数が警告終了しました。', 'WARN')
        ###     template = loader.get_template('P0130Manage/browser/browser_city_code.html')
        ###     context = {
        ###         'alert_log': get_alert_log(), 
        ###     }
        ###     return HttpResponse(template.render(context, request))

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.browser_city_code_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.browser_city_code_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0130Manage/browser/browser_city_code.html')
        context = {
            'city_bucket_list': city_bucket_list, 
            'area_list': area_list,
            'ippan_header_list': ippan_header_list, 
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0130Manage.browser_city_code_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.browser_city_code_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.browser_city_code_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0130Manage/browser/browser_city_code.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 運用担当者用一般資産調査員調査票右スライドメニュー表示【済】
### 関数名：slide_ippan_header_id_view(request, header_id)
### urlpattern：path('slide/ippan/header/<slug:header_id>/', views.slideippan_header_id_view, name='slideippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def slide_ippan_header_id_view(request, header_id):
    bool_return, response = slide_ippan_header_id(request, header_id)
    ### if bool_return == False:
    ###     return JsonResponse(data)
    return response

###############################################################################
### 運用担当者用水害区域図右スライドメニュー表示【済】
### 関数名：slide_area_header_id_view(request, header_id)
### urlpattern：path('slide/area/header/<slug:header_id>/', views.slide_area_header_id_view, name='slide_area_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def slide_area_header_id_view(request, header_id):
    bool_return, response = slide_area_header_id(request, header_id)
    ### if bool_return == False:
    ###     return JsonResponse(data)
    return response

###############################################################################
### 運用担当者用地方単独事業調査票右スライドメニュー表示【済】
### 関数名：slide_chitan_header_id_view(request, header_id)
### urlpattern：path('slide/chitan/header/<slug:header_id>/', views.slide_chitan_header_id_view, name='slide_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def slide_chitan_header_id_view(request, header_id):
    bool_return, response = slide_chitan_header_id(request, header_id)
    ### if bool_return == False:
    ###     return JsonResponse(data)
    return response

###############################################################################
### 運用担当者用補助事業調査票右スライドメニュー表示【済】
### 関数名：slide_hojo_header_id_view(request, header_id)
### urlpattern：path('slide/hojo/header/<slug:header_id>/', views.slide_hojo_header_id_view, name='slide_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def slide_hojo_header_id_view(request, header_id):
    bool_return, response = slide_hojo_header_id(request, header_id)
    ### if bool_return == False:
    ###     return JsonResponse(data)
    return response

###############################################################################
### 運用担当者用公益事業調査票右スライドメニュー表示【済】
### 関数名：slide_koeki_header_id_view(request, header_id)
### urlpattern：path('slide/koeki/header/<slug:header_id>/', views.slide_koeki_header_id_view, name='slide_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def slide_koeki_header_id_view(request, header_id):
    bool_return, response = slide_koeki_header_id(request, header_id)
    ### if bool_return == False:
    ###     return JsonResponse(data)
    return response

###############################################################################
### 運用担当者用一般資産調査員調査票EXCELダウンロード【済】
### 関数名：download_ippan_chosa_excel_header_id_view(request, header_id)
### urlpattern：path('download/ippan/chosa/excel/header/<slug:header_id>/', views.download_ippan_chosa_excel_header_id_view, name='download_ippan_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_chosa_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _IPP_CHO_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用一般資産調査員調査票CSVダウンロード【済】
### 関数名：download_ippan_chosa_csv_header_id_view(request, header_id)
### urlpattern：path('download/ippan/chosa/csv/header/<slug:header_id>/', views.download_ippan_chosa_csv_header_id_view, name='download_ippan_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_chosa_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _IPP_CHO_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用一般資産集計結果EXCELダウンロード【済】
### 関数名：download_ippan_summary_excel_header_id_view(request, header_id)
### urlpattern：path('download/ippan/summary/excel/header/<slug:header_id>/', views.download_ippan_summary_excel_header_id_view, name='download_ippan_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_summary_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _IPP_SUM_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用一般資産集計結果CSVダウンロード【済】
### 関数名：download_ippan_summary_csv_header_id_view(request, header_id)
### urlpattern：path('download/ippan/summary/csv/header/<slug:header_id>/', views.download_ippan_summary_csv_header_id_view, name='download_ippan_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_summary_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _IPP_SUM_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用水害区域図PDFダウンロード【済】
### 関数名：download_area_pdf_header_id_view(request, header_id)
### urlpattern：path('download/area/pdf/header/<slug:header_id>/', views.download_area_pdf_header_id_view, name='download_area_pdf_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_area_pdf_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _ARE_PDF)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用水害区域図KMLダウンロード【済】
### 関数名：download_area_kml_header_id_view(request, header_id)
### urlpattern：path('download/area/kml/header/<slug:header_id>/', views.download_area_kml_header_id_view, name='download_area_kml_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_area_kml_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _ARE_KML)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用地方単独事業調査票EXCELダウンロード【済】
### 関数名：download_chitan_chosa_excel_header_id_view(request, header_id)
### urlpattern：path('download/chitan/chosa/excel/header/<slug:header_id>/', views.download_chitan_chosa_excel_header_id_view, name='download_chitan_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_chitan_chosa_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _CHI_CHO_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用地方単独事業調査票CSVダウンロード【済】
### 関数名：download_chitan_chosa_csv_header_id_view(request, header_id)
### urlpattern：path('download/chitan/chosa/csv/header/<slug:header_id>/', views.download_chitan_chosa_csv_header_id_view, name='download_chitan_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_chitan_chosa_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _CHI_CHO_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用地方単独事業集計結果EXCELダウンロード【済】
### 関数名：download_chitan_summary_excel_header_id_view(request, header_id)
### urlpattern：path('download/chitan/summary/excel/header/<slug:header_id>/', views.download_chitan_summary_excel_header_id_view, name='download_chitan_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_chitan_summary_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _CHI_SUM_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用地方単独事業集計結果CSVダウンロード【済】
### 関数名：download_chitan_summary_csv_header_id_view(request, header_id)
### urlpattern：path('download/chitan/summary/csv/header/<slug:header_id>/', views.download_chitan_summary_csv_header_id_view, name='download_chitan_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_chitan_summary_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _CHI_SUM_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用補助事業調査票EXCELダウンロード【済】
### 関数名：download_hojo_chosa_excel_header_id_view(request, header_id)
### urlpattern：path('download/hojo/chosa/excel/header/<slug:header_id>/', views.download_hojo_chosa_excel_header_id_view, name='download_hojo_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_hojo_chosa_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _HOJ_CHO_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用補助事業調査票CSVダウンロード【済】
### 関数名：download_hojo_chosa_csv_header_id_view(request, header_id)
### urlpattern：path('download/hojo/chosa/csv/header/<slug:header_id>/', views.download_hojo_chosa_csv_header_id_view, name='download_hojo_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_hojo_chosa_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _HOJ_CHO_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用補助事業集計結果EXCELダウンロード【済】
### 関数名：download_hojo_summary_excel_header_id_view(request, header_id)
### urlpattern：path('download/hojo/summary/excel/header/<slug:header_id>/', views.download_hojo_summary_excel_header_id_view, name='download_hojo_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_hojo_summary_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _HOJ_SUM_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用補助事業集計結果CSVダウンロード【済】
### 関数名：download_hojo_summary_csv_header_id_view(request, header_id)
### urlpattern：path('download/hojo/summary/csv/header/<slug:header_id>/', views.download_hojo_summary_csv_header_id_view, name='download_hojo_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_hojo_summary_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _HOJ_SUM_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用公益事業調査票EXCELダウンロード【済】
### 関数名：download_koeki_chosa_excel_header_id_view(request, header_id)
### urlpattern：path('download/koeki/chosa/excel/header/<slug:header_id>/', views.download_koeki_chosa_excel_header_id_view, name='download_koeki_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_koeki_chosa_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _KOE_CHO_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用公益事業調査票CSVダウンロード【済】
### 関数名：download_koeki_chosa_csv_header_id_view(request, header_id)
### urlpattern：path('download/koeki/chosa/csv/header/<slug:header_id>/', views.download_koeki_chosa_csv_header_id_view, name='download_koeki_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_koeki_chosa_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _KOE_CHO_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用公益事業集計結果EXCELダウンロード【済】
### 関数名：download_koeki_summary_excel_header_id_view(request, header_id)
### urlpattern：path('download/koeki/summary/excel/header/<slug:header_id>/', views.download_koeki_summary_excel_header_id_view, name='download_koeki_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_koeki_summary_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _KOE_SUM_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用公益事業集計結果CSVダウンロード【済】
### 関数名：download_koeki_summary_csv_header_id_view(request, header_id)
### urlpattern：path('download/koeki/summary/csv/header/<slug:header_id>/', views.download_koeki_summary_csv_header_id_view, name='download_koeki_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_koeki_summary_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _KOE_SUM_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 運用担当者用一般資産調査員調査票管理者承認
### 関数名：approve_ippan_header_id(request, header_id)
### urlpattern：path('approve/ippan/header/<slug:header_id>/', views.approve_ippan_header_id_view, name='approve_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def approve_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.approve_ippan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.approve_ippan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_ippan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_ippan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_ippan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_ippan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.approve_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_ippan_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_ippan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.approve_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.approve_ippan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_ippan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 運用担当者用地方単独事業調査票管理者承認
### 関数名：approve_chitan_header_id(request, header_id)
### urlpattern：path('approve/chitan/header/<slug:header_id>/', views.approve_chitan_header_id_view, name='approve_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def approve_chitan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.approve_chitan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.approve_chitan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_chitan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_chitan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_chitan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_chitan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_chitan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.approve_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_chitan_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_chitan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.approve_chitan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.approve_chitan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_chitan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 運用担当者用補助事業調査票管理者承認
### 関数名：approve_hojo_header_id(request, header_id)
### urlpattern：path('approve/hojo/header/<slug:header_id>/', views.approve_hojo_header_id_view, name='approve_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def approve_hojo_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.approve_hojo_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.approve_hojo_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_hojo_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_hojo_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_hojo_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_hojo_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_hojo_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.approve_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_hojo_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_hojo_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.approve_hojo_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.approve_hojo_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_hojo_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 運用担当者用公益事業調査票管理者承認
### 関数名：approve_koeki_header_id(request, header_id)
### urlpattern：path('approve/koeki/header/<slug:header_id>/', views.approve_koeki_header_id_view, name='approve_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def approve_koeki_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.approve_koeki_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.approve_koeki_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_koeki_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_koeki_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_koeki_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_koeki_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_koeki_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.approve_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_koeki_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_koeki_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.approve_koeki_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.approve_koeki_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_koeki_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 運用担当者用水害区域図管理者承認
### 関数名：approve_area_header_id(request, header_id)
### urlpattern：path('approve/area/header/<slug:header_id>/', views.approve_area_header_id_view, name='approve_area_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def approve_area_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.approve_area_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.approve_area_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_area_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_area_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.approve_area_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_area_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_area_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.approve_area_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_area_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.approve_area_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.approve_area_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.approve_area_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_area_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.approve_area_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 運用担当者用一般資産調査員調査票再チェック
### 関数名：check_ippan_header_id(request, header_id)
### urlpattern：path('check/ippan/header/<slug:header_id>/', views.check_ippan_header_id_view, name='check_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def check_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.check_ippan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.check_ippan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.check_ippan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.check_ippan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.check_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_ippan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_ippan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.check_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_ippan_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_ippan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.check_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.check_ippan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.check_ippan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.check_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 運用担当者用地方単独事業調査票再チェック
### 関数名：check_chitan_header_id(request, header_id)
### urlpattern：path('check/chitan/header/<slug:header_id>/', views.check_chitan_header_id_view, name='check_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def check_chitan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.check_chitan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.check_chitan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.check_chitan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.check_chitan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.check_chitan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_chitan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_chitan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.check_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_chitan_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_chitan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.check_chitan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.check_chitan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.check_chitan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.check_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 運用担当者用補助事業調査票再チェック
### 関数名：check_hojo_header_id(request, header_id)
### urlpattern：path('check/hojo/header/<slug:header_id>/', views.check_hojo_header_id_view, name='check_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def check_hojo_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.check_hojo_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.check_hojo_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.check_hojo_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.check_hojo_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.check_hojo_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_hojo_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_hojo_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.check_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_hojo_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_hojo_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.check_hojo_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.check_hojo_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.check_hojo_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.check_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 運用担当者用公益事業調査票再チェック
### 関数名：check_koeki_header_id(request, header_id)
### urlpattern：path('check/koeki/header/<slug:header_id>/', views.check_koeki_header_id_view, name='check_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def check_koeki_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.check_koeki_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.check_koeki_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.check_koeki_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.check_koeki_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.check_koeki_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_koeki_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_koeki_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.check_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_koeki_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.check_koeki_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.check_koeki_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.check_koeki_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.check_koeki_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.check_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 運用担当者用一般資産調査員調査票再集計
### 関数名：summarize_ippan_header_id(request, header_id)
### urlpattern：path('summarize/ippan/header/<slug:header_id>/', views.summarize_ippan_header_id_view, name='summarize_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def summarize_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.summarize_ippan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.summarize_ippan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.summarize_ippan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.summarize_ippan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.summarize_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_ippan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_ippan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.summarize_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_ippan_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_ippan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.summarize_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.summarize_ippan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.summarize_ippan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.summarize_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 運用担当者用地方単独事業調査票再集計
### 関数名：summarize_chitan_header_id(request, header_id)
### urlpattern：path('summarize/chitan/header/<slug:header_id>/', views.summarize_chitan_header_id_view, name='summarize_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def summarize_chitan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.summarize_chitan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.summarize_chitan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.summarize_chitan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.summarize_chitan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.summarize_chitan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_chitan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_chitan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.summarize_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_chitan_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_chitan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.summarize_chitan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.summarize_chitan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.summarize_chitan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.summarize_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 運用担当者用補助事業調査票再集計
### 関数名：summarize_hojo_header_id(request, header_id)
### urlpattern：path('summarize/hojo/header/<slug:header_id>/', views.summarize_hojo_header_id_view, name='summarize_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def summarize_hojo_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.summarize_hojo_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.summarize_hojo_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.summarize_hojo_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.summarize_hojo_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.summarize_hojo_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_hojo_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_hojo_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.summarize_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_hojo_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_hojo_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.summarize_hojo_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.summarize_hojo_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.summarize_hojo_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.summarize_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 運用担当者用公益事業調査票再集計
### 関数名：summarize_koeki_header_id(request, header_id)
### urlpattern：path('summarize/koeki/header/<slug:header_id>/', views.summarize_koeki_header_id_view, name='summarize_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def summarize_koeki_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.summarize_koeki_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.summarize_koeki_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.summarize_koeki_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.summarize_koeki_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.summarize_koeki_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_koeki_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_koeki_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.summarize_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_koeki_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.summarize_koeki_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.summarize_koeki_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0130Manage.summarize_koeki_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.summarize_koeki_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.summarize_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 運用担当者用一般資産調査員調査票ファイル削除
### 関数名：delete_ippan_header_id_view(request, header_id)
### urlpattern：path('delete/ippan/header/<slug:header_id>/', views.delete_ippan_header_id_view, name='delete_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def delete_ippan_header_id_view(request, header_id):
    bool_return, response = delete_header_id(request, header_id, _IPP)
    if bool_return == False:
        pass
    return response

###############################################################################
### 運用担当者用水害区域図ファイル削除
### 関数名：delete_area_header_id_view(request, header_id)
### urlpattern：path('delete/area/header/<slug:header_id>/', views.delete_area_header_id_view, name='delete_area_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def delete_area_header_id_view(request, header_id):
    bool_return, response = delete_header_id(request, header_id, _ARE)
    if bool_return == False:
        pass
    return response

###############################################################################
### 運用担当者用地方単独事業調査票ファイル削除
### 関数名：delete_chitan_header_id_view(request, header_id)
### urlpattern：path('delete/chitan/header/<slug:header_id>/', views.delete_chitan_header_id_view, name='delete_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def delete_chitan_header_id_view(request, header_id):
    bool_return, response = delete_header_id(request, header_id, _CHI)
    if bool_return == False:
        pass
    return response

###############################################################################
### 運用担当者用補助事業調査票ファイル削除
### 関数名：delete_hojo_header_id_view(request, header_id)
### urlpattern：path('delete/hojo/header/<slug:header_id>/', views.delete_hojo_header_id_view, name='delete_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def delete_hojo_header_id_view(request, header_id):
    bool_return, response = delete_header_id(request, header_id, _HOJ)
    if bool_return == False:
        pass
    return response

###############################################################################
### 運用担当者用公益事業調査票ファイル削除
### 関数名：delete_hojo_header_id_view(request, header_id)
### urlpattern：path('delete/koeki/header/<slug:header_id>/', views.delete_koeki_header_id_view, name='delete_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def delete_koeki_header_id_view(request, header_id):
    bool_return, response = delete_header_id(request, header_id, _KOE)
    if bool_return == False:
        pass
    return response

###############################################################################
### 運用担当者用一般資産調査員調査票右スライドメニュー表示
###############################################################################
def slide_ippan_header_id(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.slide_ippan_header_id()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### レスポンスセット処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.slide_ippan_header_id()関数が警告終了しました。', 'WARN')
            data = {
                'sample1': [1, 2, 3], 
                'sample2': [3, 6, 9],
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return False, response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        ### ※コンテンツにアクセス可能なユーザは運用担当者のみとする。
        ### ※0020で運用担当者のみに絞っているため、ここではアクセス制御しない。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'IPPAN_HEADER_ID': header_id, 
            'IPP_ACT_01': _IPP_ACT_01,
            'IPP_ACT_02': _IPP_ACT_02,
            'IPP_ACT_03': _IPP_ACT_03,
            'IPP_ACT_04': _IPP_ACT_04,
            'IPP_ACT_05': _IPP_ACT_05,
            'IPP_ACT_06': _IPP_ACT_06,
            'IPP_ACT_07': _IPP_ACT_07,
        })
        ippan_header_list = IPPAN_HEADER.objects.raw("""
            SELECT 
                IPPAN_HEADER_ID, 
                IPPAN_HEADER_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM IPPAN_HEADER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s""", params)
        
        print_log('{}'.format(ippan_header_list), 'DEBUG')
        print_log('{}'.format(len(ippan_header_list)), 'DEBUG')
        print_log('{}'.format(ippan_header_list[0]), 'DEBUG')
        print_log('{}'.format(ippan_header_list[0].ippan_header_id), 'DEBUG')

        ippan_trigger_act_01_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                ACTION_CODE=%(IPP_ACT_01)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        ippan_trigger_act_02_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                ACTION_CODE=%(IPP_ACT_02)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        ippan_trigger_act_03_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                ACTION_CODE=%(IPP_ACT_03)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        ippan_trigger_act_04_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                ACTION_CODE=%(IPP_ACT_04)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        ippan_trigger_act_05_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                ACTION_CODE=%(IPP_ACT_05)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        ippan_trigger_act_06_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                ACTION_CODE=%(IPP_ACT_06)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        ippan_trigger_act_07_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                ACTION_CODE=%(IPP_ACT_07)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        print_log('{}'.format(ippan_trigger_act_01_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_01_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_01_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_01_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_02_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_02_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_02_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_02_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_03_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_03_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_03_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_03_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_04_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_04_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_04_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_04_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_05_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_05_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_05_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_05_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_06_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_06_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_06_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_06_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_07_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_07_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_07_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_07_list[0].ippan_trigger_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### レスポンスセット処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id()関数 STEP 5/6.', 'DEBUG')
        if ippan_header_list == False:
            print_log('[WARN] P0130Manage.slide_ippan_header_id()関数が警告終了しました。', 'WARN')
            data = {
                'sample1': [1, 2, 3], 
                'sample2': [3, 6, 9],
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return False, response

        ### if ippan_trigger_act_01_list == False:
        ###     print_log('[WARN] P0130Manage.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_02_list == False:
        ###     print_log('[WARN] P0130Manage.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_03_list == False:
        ###     print_log('[WARN] P0130Manage.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_04_list == False:
        ###     print_log('[WARN] P0130Manage.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_05_list == False:
        ###     print_log('[WARN] P0130Manage.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_06_list == False:
        ###     print_log('[WARN] P0130Manage.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_07_list == False:
        ###     print_log('[WARN] P0130Manage.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_ippan_header_id()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.slide_ippan_header_id()関数が正常終了しました。', 'INFO')
        data = {
            'ippan_header_id': ippan_header_list[0].ippan_header_id, 
            'ippan_header_name': ippan_header_list[0].ippan_header_name, 
            'ken_code': ippan_header_list[0].ken_code, 
            'city_code': ippan_header_list[0].city_code, 
            'upload_file_path': ippan_header_list[0].upload_file_path, 
            'upload_file_name': ippan_header_list[0].upload_file_name, 
            'upload_file_size': ippan_header_list[0].upload_file_size, 
            'summary_file_path': ippan_header_list[0].summary_file_path, 
            'summary_file_name': ippan_header_list[0].summary_file_name, 
            'summary_file_size': ippan_header_list[0].summary_file_size, 
            'committed_at': ippan_header_list[0].committed_at, 
            'deleted_at': ippan_header_list[0].deleted_at, 
        }
        if ippan_trigger_act_01_list:
            data01 = {
                'act_01_status_code': ippan_trigger_act_01_list[0].status_code, 
                'act_01_published_at': ippan_trigger_act_01_list[0].published_at, 
                'act_01_consumed_at': ippan_trigger_act_01_list[0].consumed_at, 
                'act_01_deleted_at': ippan_trigger_act_01_list[0].deleted_at, 
            }
        else:
            data01 = {
                'act_01_status_code': None, 
                'act_01_published_at': None, 
                'act_01_consumed_at': None, 
                'act_01_deleted_at': None, 
            }
        if ippan_trigger_act_02_list:
            data02 = {
                'act_02_status_code': ippan_trigger_act_02_list[0].status_code, 
                'act_02_published_at': ippan_trigger_act_02_list[0].published_at, 
                'act_02_consumed_at': ippan_trigger_act_02_list[0].consumed_at, 
                'act_02_deleted_at': ippan_trigger_act_02_list[0].deleted_at, 
            }
        else:
            data02 = {
                'act_02_status_code': None, 
                'act_02_published_at': None, 
                'act_02_consumed_at': None, 
                'act_02_deleted_at': None, 
            }
        if ippan_trigger_act_03_list:
            data03 = {
                'act_03_status_code': ippan_trigger_act_03_list[0].status_code, 
                'act_03_published_at': ippan_trigger_act_03_list[0].published_at, 
                'act_03_consumed_at': ippan_trigger_act_03_list[0].consumed_at, 
                'act_03_deleted_at': ippan_trigger_act_03_list[0].deleted_at, 
            }
        else:
            data03 = {
                'act_03_status_code': None, 
                'act_03_published_at': None, 
                'act_03_consumed_at': None, 
                'act_03_deleted_at': None, 
            }
        if ippan_trigger_act_04_list:
            data04 = {
                'act_04_status_code': ippan_trigger_act_04_list[0].status_code, 
                'act_04_published_at': ippan_trigger_act_04_list[0].published_at, 
                'act_04_consumed_at': ippan_trigger_act_04_list[0].consumed_at, 
                'act_04_deleted_at': ippan_trigger_act_04_list[0].deleted_at, 
            }
        else:
            data04 = {
                'act_04_status_code': None, 
                'act_04_published_at': None, 
                'act_04_consumed_at': None, 
                'act_04_deleted_at': None, 
            }
        if ippan_trigger_act_05_list:
            data05 = {
                'act_05_status_code': ippan_trigger_act_05_list[0].status_code, 
                'act_05_published_at': ippan_trigger_act_05_list[0].published_at, 
                'act_05_consumed_at': ippan_trigger_act_05_list[0].consumed_at, 
                'act_05_deleted_at': ippan_trigger_act_05_list[0].deleted_at, 
            }
        else:
            data05 = {
                'act_05_status_code': None, 
                'act_05_published_at': None, 
                'act_05_consumed_at': None, 
                'act_05_deleted_at': None, 
            }
        if ippan_trigger_act_06_list:
            data06 = {
                'act_06_status_code': ippan_trigger_act_06_list[0].status_code, 
                'act_06_published_at': ippan_trigger_act_06_list[0].published_at, 
                'act_06_consumed_at': ippan_trigger_act_06_list[0].consumed_at, 
                'act_06_deleted_at': ippan_trigger_act_06_list[0].deleted_at, 
            }
        else:
            data06 = {
                'act_06_status_code': None, 
                'act_06_published_at': None, 
                'act_06_consumed_at': None, 
                'act_06_deleted_at': None, 
            }
        if ippan_trigger_act_07_list:
            data07 = {
                'act_07_status_code': ippan_trigger_act_07_list[0].status_code, 
                'act_07_published_at': ippan_trigger_act_07_list[0].published_at, 
                'act_07_consumed_at': ippan_trigger_act_07_list[0].consumed_at, 
                'act_07_deleted_at': ippan_trigger_act_07_list[0].deleted_at, 
            }
        else:
            data07 = {
                'act_07_status_code': None, 
                'act_07_published_at': None, 
                'act_07_consumed_at': None, 
                'act_07_deleted_at': None, 
            }
        data.update(data01)
        data.update(data02)
        data.update(data03)
        data.update(data04)
        data.update(data05)
        data.update(data06)
        data.update(data07)
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return True, response
    
    except:
        print_log('[ERROR] P0130Manage.slide_ippan_header_id()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_ippan_header_id()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_ippan_header_id()関数が異常終了しました。', 'ERROR')
        data = {
            'sample1': [1, 2, 3], 
            'sample2': [3, 6, 9],
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return False, response

###############################################################################
### 運用担当者用水害区域図右スライドメニュー表示
###############################################################################
def slide_area_header_id(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.slide_area_header_id()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.slide_area_header_id()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_area_header_id()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_area_header_id()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_area_header_id()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_area_header_id()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### レスポンスセット処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_area_header_id()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.slide_area_header_id()関数が警告終了しました。', 'WARN')
            data = {
                'sample1': [1, 2, 3], 
                'sample2': [3, 6, 9],
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return False, response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        ### ※コンテンツにアクセス可能なユーザは運用担当者のみとする。
        ### ※0020で運用担当者のみに絞っているため、ここではアクセス制御しない。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_area_header_id()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'AREA_ID': header_id, 
        })
        area_list = AREA.objects.raw("""
            SELECT 
                AREA_ID, 
                AREA_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM AREA 
            WHERE 
                AREA_ID=%(AREA_ID)s""", params)
        
        print_log('{}'.format(area_list), 'DEBUG')
        print_log('{}'.format(len(area_list)), 'DEBUG')
        print_log('{}'.format(area_list[0]), 'DEBUG')
        print_log('{}'.format(area_list[0].area_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### レスポンスセット処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_area_header_id()関数 STEP 5/6.', 'DEBUG')
        if area_list == False:
            print_log('[WARN] P0130Manage.slide_area_header_id()関数が警告終了しました。', 'WARN')
            data = {
                'sample1': [1, 2, 3], 
                'sample2': [3, 6, 9],
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return False, response

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_area_header_id()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.slide_area_header_id()関数が正常終了しました。', 'INFO')
        data = {
            'area_id': area_list[0].area_id, 
            'area_name': area_list[0].area_name,
            'ken_code': area_list[0].ken_code,
            'city_code': area_list[0].city_code,
            'upload_file_path': area_list[0].upload_file_path, 
            'upload_file_name': area_list[0].upload_file_name, 
            'upload_file_size': area_list[0].upload_file_size, 
            'committed_at': area_list[0].committed_at, 
            'deleted_at': area_list[0].deleted_at, 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return True, response
    
    except:
        print_log('[ERROR] P0130Manage.slide_area_header_id()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_area_header_id()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_area_header_id()関数が異常終了しました。', 'ERROR')
        data = {
            'sample1': [1, 2, 3], 
            'sample2': [3, 6, 9],
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return False, response

###############################################################################
### 運用担当者用地方単独事業調査票右スライドメニュー表示
###############################################################################
def slide_chitan_header_id(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.slide_chitan_header_id()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### レスポンスセット処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.slide_chitan_header_id()関数が警告終了しました。', 'WARN')
            data = {
                'sample1': [1, 2, 3], 
                'sample2': [3, 6, 9],
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return False, response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        ### ※コンテンツにアクセス可能なユーザは運用担当者のみとする。
        ### ※0020で運用担当者のみに絞っているため、ここではアクセス制御しない。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'CHITAN_HEADER_ID': header_id, 
            'CHI_ACT_01': _CHI_ACT_01,
            'CHI_ACT_02': _CHI_ACT_02,
            'CHI_ACT_03': _CHI_ACT_03,
            'CHI_ACT_04': _CHI_ACT_04,
            'CHI_ACT_05': _CHI_ACT_05,
            'CHI_ACT_06': _CHI_ACT_06,
            'CHI_ACT_07': _CHI_ACT_07,
        })
        chitan_header_list = CHITAN_HEADER.objects.raw("""
            SELECT 
                CHITAN_HEADER_ID, 
                CHITAN_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM CHITAN_HEADER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s""", params)
        
        print_log('{}'.format(chitan_header_list), 'DEBUG')
        print_log('{}'.format(len(chitan_header_list)), 'DEBUG')
        print_log('{}'.format(chitan_header_list[0]), 'DEBUG')
        print_log('{}'.format(chitan_header_list[0].chitan_header_id), 'DEBUG')

        chitan_trigger_act_01_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                ACTION_CODE=%(CHI_ACT_01)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        chitan_trigger_act_02_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                ACTION_CODE=%(CHI_ACT_02)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        chitan_trigger_act_03_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                ACTION_CODE=%(CHI_ACT_03)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        chitan_trigger_act_04_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                ACTION_CODE=%(CHI_ACT_04)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        chitan_trigger_act_05_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                ACTION_CODE=%(CHI_ACT_05)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        chitan_trigger_act_06_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                ACTION_CODE=%(CHI_ACT_06)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        chitan_trigger_act_07_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                ACTION_CODE=%(CHI_ACT_07)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        print_log('{}'.format(chitan_trigger_act_01_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_01_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_01_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_01_list[0].chitan_trigger_id), 'DEBUG')

        print_log('{}'.format(chitan_trigger_act_02_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_02_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_02_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_02_list[0].chitan_trigger_id), 'DEBUG')

        print_log('{}'.format(chitan_trigger_act_03_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_03_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_03_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_03_list[0].chitan_trigger_id), 'DEBUG')

        print_log('{}'.format(chitan_trigger_act_04_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_04_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_04_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_04_list[0].chitan_trigger_id), 'DEBUG')

        print_log('{}'.format(chitan_trigger_act_05_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_05_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_05_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_05_list[0].chitan_trigger_id), 'DEBUG')

        print_log('{}'.format(chitan_trigger_act_06_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_06_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_06_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_06_list[0].chitan_trigger_id), 'DEBUG')

        print_log('{}'.format(chitan_trigger_act_07_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_07_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_07_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_07_list[0].chitan_trigger_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### レスポンスセット処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id()関数 STEP 5/6.', 'DEBUG')
        if chitan_header_list == False:
            print_log('[WARN] P0130Manage.slide_chitan_header_id()関数が警告終了しました。', 'WARN')
            data = {
                'sample1': [1, 2, 3], 
                'sample2': [3, 6, 9],
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return False, response

        ### if chitan_trigger_act_01_list == False:
        ###     print_log('[WARN] P0130Manage.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        ### if chitan_trigger_act_02_list == False:
        ###     print_log('[WARN] P0130Manage.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        ### if chitan_trigger_act_03_list == False:
        ###     print_log('[WARN] P0130Manage.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        ### if chitan_trigger_act_04_list == False:
        ###     print_log('[WARN] P0130Manage.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        ### if chitan_trigger_act_05_list == False:
        ###     print_log('[WARN] P0130Manage.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        ### if chitan_trigger_act_06_list == False:
        ###     print_log('[WARN] P0130Manage.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        ### if chitan_trigger_act_07_list == False:
        ###     print_log('[WARN] P0130Manage.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_chitan_header_id()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.slide_chitan_header_id()関数が正常終了しました。', 'INFO')
        data = {
            'chitan_header_id': chitan_header_list[0].chitan_header_id, 
            'chitan_header_name': chitan_header_list[0].chitan_header_name, 
            'ken_code': chitan_header_list[0].ken_code, 
            'upload_file_path': chitan_header_list[0].upload_file_path, 
            'upload_file_name': chitan_header_list[0].upload_file_name, 
            'upload_file_size': chitan_header_list[0].upload_file_size, 
            'summary_file_path': chitan_header_list[0].summary_file_path, 
            'summary_file_name': chitan_header_list[0].summary_file_name, 
            'summary_file_size': chitan_header_list[0].summary_file_size, 
            'committed_at': chitan_header_list[0].committed_at, 
            'deleted_at': chitan_header_list[0].deleted_at, 
        }
        if chitan_trigger_act_01_list:
            data01 = {
                'act_01_status_code': chitan_trigger_act_01_list[0].status_code, 
                'act_01_published_at': chitan_trigger_act_01_list[0].published_at, 
                'act_01_consumed_at': chitan_trigger_act_01_list[0].consumed_at, 
                'act_01_deleted_at': chitan_trigger_act_01_list[0].deleted_at, 
            }
        else:
            data01 = {
                'act_01_status_code': None, 
                'act_01_published_at': None, 
                'act_01_consumed_at': None, 
                'act_01_deleted_at': None, 
            }
        if chitan_trigger_act_02_list:
            data02 = {
                'act_02_status_code': chitan_trigger_act_02_list[0].status_code, 
                'act_02_published_at': chitan_trigger_act_02_list[0].published_at, 
                'act_02_consumed_at': chitan_trigger_act_02_list[0].consumed_at, 
                'act_02_deleted_at': chitan_trigger_act_02_list[0].deleted_at, 
            }
        else:
            data02 = {
                'act_02_status_code': None, 
                'act_02_published_at': None, 
                'act_02_consumed_at': None, 
                'act_02_deleted_at': None, 
            }
        if chitan_trigger_act_03_list:
            data03 = {
                'act_03_status_code': chitan_trigger_act_03_list[0].status_code, 
                'act_03_published_at': chitan_trigger_act_03_list[0].published_at, 
                'act_03_consumed_at': chitan_trigger_act_03_list[0].consumed_at, 
                'act_03_deleted_at': chitan_trigger_act_03_list[0].deleted_at, 
            }
        else:
            data03 = {
                'act_03_status_code': None, 
                'act_03_published_at': None, 
                'act_03_consumed_at': None, 
                'act_03_deleted_at': None, 
            }
        if chitan_trigger_act_04_list:
            data04 = {
                'act_04_status_code': chitan_trigger_act_04_list[0].status_code, 
                'act_04_published_at': chitan_trigger_act_04_list[0].published_at, 
                'act_04_consumed_at': chitan_trigger_act_04_list[0].consumed_at, 
                'act_04_deleted_at': chitan_trigger_act_04_list[0].deleted_at, 
            }
        else:
            data04 = {
                'act_04_status_code': None, 
                'act_04_published_at': None, 
                'act_04_consumed_at': None, 
                'act_04_deleted_at': None, 
            }
        if chitan_trigger_act_05_list:
            data05 = {
                'act_05_status_code': chitan_trigger_act_05_list[0].status_code, 
                'act_05_published_at': chitan_trigger_act_05_list[0].published_at, 
                'act_05_consumed_at': chitan_trigger_act_05_list[0].consumed_at, 
                'act_05_deleted_at': chitan_trigger_act_05_list[0].deleted_at, 
            }
        else:
            data05 = {
                'act_05_status_code': None, 
                'act_05_published_at': None, 
                'act_05_consumed_at': None, 
                'act_05_deleted_at': None, 
            }
        if chitan_trigger_act_06_list:
            data06 = {
                'act_06_status_code': chitan_trigger_act_06_list[0].status_code, 
                'act_06_published_at': chitan_trigger_act_06_list[0].published_at, 
                'act_06_consumed_at': chitan_trigger_act_06_list[0].consumed_at, 
                'act_06_deleted_at': chitan_trigger_act_06_list[0].deleted_at, 
            }
        else:
            data06 = {
                'act_06_status_code': None, 
                'act_06_published_at': None, 
                'act_06_consumed_at': None, 
                'act_06_deleted_at': None, 
            }
        if chitan_trigger_act_07_list:
            data07 = {
                'act_07_status_code': chitan_trigger_act_07_list[0].status_code, 
                'act_07_published_at': chitan_trigger_act_07_list[0].published_at, 
                'act_07_consumed_at': chitan_trigger_act_07_list[0].consumed_at, 
                'act_07_deleted_at': chitan_trigger_act_07_list[0].deleted_at, 
            }
        else:
            data07 = {
                'act_07_status_code': None, 
                'act_07_published_at': None, 
                'act_07_consumed_at': None, 
                'act_07_deleted_at': None, 
            }
        data.update(data01)
        data.update(data02)
        data.update(data03)
        data.update(data04)
        data.update(data05)
        data.update(data06)
        data.update(data07)
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return True, response
    
    except:
        print_log('[ERROR] P0130Manage.slide_chitan_header_id()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_chitan_header_id()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_chitan_header_id()関数が異常終了しました。', 'ERROR')
        data = {
            'sample1': [1, 2, 3], 
            'sample2': [3, 6, 9],
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return False, response

###############################################################################
### 運用担当者用補助事業調査票右スライドメニュー表示
###############################################################################
def slide_hojo_header_id(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.slide_hojo_header_id()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### レスポンスセット処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.slide_hojo_header_id()関数が警告終了しました。', 'WARN')
            data = {
                'sample1': [1, 2, 3], 
                'sample2': [3, 6, 9],
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return False, response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        ### ※コンテンツにアクセス可能なユーザは運用担当者のみとする。
        ### ※0020で運用担当者のみに絞っているため、ここではアクセス制御しない。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'HOJO_HEADER_ID': header_id, 
            'HOJ_ACT_01': _HOJ_ACT_01,
            'HOJ_ACT_02': _HOJ_ACT_02,
            'HOJ_ACT_03': _HOJ_ACT_03,
            'HOJ_ACT_04': _HOJ_ACT_04,
            'HOJ_ACT_05': _HOJ_ACT_05,
            'HOJ_ACT_06': _HOJ_ACT_06,
            'HOJ_ACT_07': _HOJ_ACT_07,
        })
        hojo_header_list = HOJO_HEADER.objects.raw("""
            SELECT 
                HOJO_HEADER_ID, 
                HOJO_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM HOJO_HEADER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s""", params)
        
        print_log('{}'.format(hojo_header_list), 'DEBUG')
        print_log('{}'.format(len(hojo_header_list)), 'DEBUG')
        print_log('{}'.format(hojo_header_list[0]), 'DEBUG')
        print_log('{}'.format(hojo_header_list[0].hojo_header_id), 'DEBUG')

        hojo_trigger_act_01_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                ACTION_CODE=%(HOJ_ACT_01)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        hojo_trigger_act_02_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                ACTION_CODE=%(HOJ_ACT_02)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        hojo_trigger_act_03_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                ACTION_CODE=%(HOJ_ACT_03)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        hojo_trigger_act_04_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                ACTION_CODE=%(HOJ_ACT_04)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        hojo_trigger_act_05_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                ACTION_CODE=%(HOJ_ACT_05)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        hojo_trigger_act_06_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                ACTION_CODE=%(HOJ_ACT_06)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        hojo_trigger_act_07_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                ACTION_CODE=%(HOJ_ACT_07)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        print_log('{}'.format(hojo_trigger_act_01_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_01_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_01_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_01_list[0].hojo_trigger_id), 'DEBUG')

        print_log('{}'.format(hojo_trigger_act_02_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_02_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_02_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_02_list[0].hojo_trigger_id), 'DEBUG')

        print_log('{}'.format(hojo_trigger_act_03_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_03_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_03_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_03_list[0].hojo_trigger_id), 'DEBUG')

        print_log('{}'.format(hojo_trigger_act_04_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_04_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_04_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_04_list[0].hojo_trigger_id), 'DEBUG')

        print_log('{}'.format(hojo_trigger_act_05_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_05_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_05_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_05_list[0].hojo_trigger_id), 'DEBUG')

        print_log('{}'.format(hojo_trigger_act_06_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_06_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_06_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_06_list[0].hojo_trigger_id), 'DEBUG')

        print_log('{}'.format(hojo_trigger_act_07_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_07_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_07_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_07_list[0].hojo_trigger_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### レスポンスセット処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id()関数 STEP 5/6.', 'DEBUG')
        if hojo_header_list == False:
            print_log('[WARN] P0130Manage.slide_hojo_header_id()関数が警告終了しました。', 'WARN')
            data = {
                'sample1': [1, 2, 3], 
                'sample2': [3, 6, 9],
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return False, response

        ### if hojo_trigger_act_01_list == False:
        ###     print_log('[WARN] P0130Manage.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        ### if hojo_trigger_act_02_list == False:
        ###     print_log('[WARN] P0130Manage.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        ### if hojo_trigger_act_03_list == False:
        ###     print_log('[WARN] P0130Manage.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        ### if hojo_trigger_act_04_list == False:
        ###     print_log('[WARN] P0130Manage.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        ### if hojo_trigger_act_05_list == False:
        ###     print_log('[WARN] P0130Manage.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        ### if hojo_trigger_act_06_list == False:
        ###     print_log('[WARN] P0130Manage.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        ### if hojo_trigger_act_07_list == False:
        ###     print_log('[WARN] P0130Manage.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_hojo_header_id()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.slide_hojo_header_id()関数が正常終了しました。', 'INFO')
        data = {
            'hojo_header_id': hojo_header_list[0].hojo_header_id, 
            'hojo_header_name': hojo_header_list[0].hojo_header_name, 
            'ken_code': hojo_header_list[0].ken_code, 
            'upload_file_path': hojo_header_list[0].upload_file_path, 
            'upload_file_name': hojo_header_list[0].upload_file_name, 
            'upload_file_size': hojo_header_list[0].upload_file_size, 
            'summary_file_path': hojo_header_list[0].summary_file_path, 
            'summary_file_name': hojo_header_list[0].summary_file_name, 
            'summary_file_size': hojo_header_list[0].summary_file_size, 
            'committed_at': hojo_header_list[0].committed_at, 
            'deleted_at': hojo_header_list[0].deleted_at, 
        }
        if hojo_trigger_act_01_list:
            data01 = {
                'act_01_status_code': hojo_trigger_act_01_list[0].status_code, 
                'act_01_published_at': hojo_trigger_act_01_list[0].published_at, 
                'act_01_consumed_at': hojo_trigger_act_01_list[0].consumed_at, 
                'act_01_deleted_at': hojo_trigger_act_01_list[0].deleted_at, 
            }
        else:
            data01 = {
                'act_01_status_code': None, 
                'act_01_published_at': None, 
                'act_01_consumed_at': None, 
                'act_01_deleted_at': None, 
            }
        if hojo_trigger_act_02_list:
            data02 = {
                'act_02_status_code': hojo_trigger_act_02_list[0].status_code, 
                'act_02_published_at': hojo_trigger_act_02_list[0].published_at, 
                'act_02_consumed_at': hojo_trigger_act_02_list[0].consumed_at, 
                'act_02_deleted_at': hojo_trigger_act_02_list[0].deleted_at, 
            }
        else:
            data02 = {
                'act_02_status_code': None, 
                'act_02_published_at': None, 
                'act_02_consumed_at': None, 
                'act_02_deleted_at': None, 
            }
        if hojo_trigger_act_03_list:
            data03 = {
                'act_03_status_code': hojo_trigger_act_03_list[0].status_code, 
                'act_03_published_at': hojo_trigger_act_03_list[0].published_at, 
                'act_03_consumed_at': hojo_trigger_act_03_list[0].consumed_at, 
                'act_03_deleted_at': hojo_trigger_act_03_list[0].deleted_at, 
            }
        else:
            data03 = {
                'act_03_status_code': None, 
                'act_03_published_at': None, 
                'act_03_consumed_at': None, 
                'act_03_deleted_at': None, 
            }
        if hojo_trigger_act_04_list:
            data04 = {
                'act_04_status_code': hojo_trigger_act_04_list[0].status_code, 
                'act_04_published_at': hojo_trigger_act_04_list[0].published_at, 
                'act_04_consumed_at': hojo_trigger_act_04_list[0].consumed_at, 
                'act_04_deleted_at': hojo_trigger_act_04_list[0].deleted_at, 
            }
        else:
            data04 = {
                'act_04_status_code': None, 
                'act_04_published_at': None, 
                'act_04_consumed_at': None, 
                'act_04_deleted_at': None, 
            }
        if hojo_trigger_act_05_list:
            data05 = {
                'act_05_status_code': hojo_trigger_act_05_list[0].status_code, 
                'act_05_published_at': hojo_trigger_act_05_list[0].published_at, 
                'act_05_consumed_at': hojo_trigger_act_05_list[0].consumed_at, 
                'act_05_deleted_at': hojo_trigger_act_05_list[0].deleted_at, 
            }
        else:
            data05 = {
                'act_05_status_code': None, 
                'act_05_published_at': None, 
                'act_05_consumed_at': None, 
                'act_05_deleted_at': None, 
            }
        if hojo_trigger_act_06_list:
            data06 = {
                'act_06_status_code': hojo_trigger_act_06_list[0].status_code, 
                'act_06_published_at': hojo_trigger_act_06_list[0].published_at, 
                'act_06_consumed_at': hojo_trigger_act_06_list[0].consumed_at, 
                'act_06_deleted_at': hojo_trigger_act_06_list[0].deleted_at, 
            }
        else:
            data06 = {
                'act_06_status_code': None, 
                'act_06_published_at': None, 
                'act_06_consumed_at': None, 
                'act_06_deleted_at': None, 
            }
        if hojo_trigger_act_07_list:
            data07 = {
                'act_07_status_code': hojo_trigger_act_07_list[0].status_code, 
                'act_07_published_at': hojo_trigger_act_07_list[0].published_at, 
                'act_07_consumed_at': hojo_trigger_act_07_list[0].consumed_at, 
                'act_07_deleted_at': hojo_trigger_act_07_list[0].deleted_at, 
            }
        else:
            data07 = {
                'act_07_status_code': None, 
                'act_07_published_at': None, 
                'act_07_consumed_at': None, 
                'act_07_deleted_at': None, 
            }
        data.update(data01)
        data.update(data02)
        data.update(data03)
        data.update(data04)
        data.update(data05)
        data.update(data06)
        data.update(data07)
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return True, response
    
    except:
        print_log('[ERROR] P0130Manage.slide_hojo_header_id()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_hojo_header_id()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_hojo_header_id()関数が異常終了しました。', 'ERROR')
        data = {
            'sample1': [1, 2, 3], 
            'sample2': [3, 6, 9],
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return False, response

###############################################################################
### 運用担当者用公益事業調査票右スライドメニュー表示
###############################################################################
def slide_koeki_header_id(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.slide_koeki_header_id()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### レスポンスセット処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.slide_koeki_header_id()関数が警告終了しました。', 'WARN')
            data = {
                'sample1': [1, 2, 3], 
                'sample2': [3, 6, 9],
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return False, response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        ### ※コンテンツにアクセス可能なユーザは運用担当者のみとする。
        ### ※0020で運用担当者のみに絞っているため、ここではアクセス制御しない。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'KOEKI_HEADER_ID': header_id, 
            'KOE_ACT_01': _KOE_ACT_01,
            'KOE_ACT_02': _KOE_ACT_02,
            'KOE_ACT_03': _KOE_ACT_03,
            'KOE_ACT_04': _KOE_ACT_04,
            'KOE_ACT_05': _KOE_ACT_05,
            'KOE_ACT_06': _KOE_ACT_06,
            'KOE_ACT_07': _KOE_ACT_07,
        })
        koeki_header_list = KOEKI_HEADER.objects.raw("""
            SELECT 
                KOEKI_HEADER_ID, 
                KOEKI_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM KOEKI_HEADER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s""", params)
        
        print_log('{}'.format(koeki_header_list), 'DEBUG')
        print_log('{}'.format(len(koeki_header_list)), 'DEBUG')
        print_log('{}'.format(koeki_header_list[0]), 'DEBUG')
        print_log('{}'.format(koeki_header_list[0].koeki_header_id), 'DEBUG')

        koeki_trigger_act_01_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                ACTION_CODE=%(KOE_ACT_01)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        koeki_trigger_act_02_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                ACTION_CODE=%(KOE_ACT_02)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        koeki_trigger_act_03_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                ACTION_CODE=%(KOE_ACT_03)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        koeki_trigger_act_04_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                ACTION_CODE=%(KOE_ACT_04)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        koeki_trigger_act_05_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                ACTION_CODE=%(KOE_ACT_05)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        koeki_trigger_act_06_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                ACTION_CODE=%(KOE_ACT_06)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        koeki_trigger_act_07_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                ACTION_CODE=%(KOE_ACT_07)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        print_log('{}'.format(koeki_trigger_act_01_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_01_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_01_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_01_list[0].koeki_trigger_id), 'DEBUG')

        print_log('{}'.format(koeki_trigger_act_02_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_02_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_02_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_02_list[0].koeki_trigger_id), 'DEBUG')

        print_log('{}'.format(koeki_trigger_act_03_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_03_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_03_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_03_list[0].koeki_trigger_id), 'DEBUG')

        print_log('{}'.format(koeki_trigger_act_04_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_04_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_04_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_04_list[0].koeki_trigger_id), 'DEBUG')

        print_log('{}'.format(koeki_trigger_act_05_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_05_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_05_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_05_list[0].koeki_trigger_id), 'DEBUG')

        print_log('{}'.format(koeki_trigger_act_06_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_06_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_06_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_06_list[0].koeki_trigger_id), 'DEBUG')

        print_log('{}'.format(koeki_trigger_act_07_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_07_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_07_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_07_list[0].koeki_trigger_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### レスポンスセット処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id()関数 STEP 5/6.', 'DEBUG')
        if koeki_header_list == False:
            print_log('[WARN] P0130Manage.slide_koeki_header_id()関数が警告終了しました。', 'WARN')
            data = {
                'sample1': [1, 2, 3], 
                'sample2': [3, 6, 9],
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return False, response

        ### if koeki_trigger_act_01_list == False:
        ###     print_log('[WARN] P0130Manage.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        ### if koeki_trigger_act_02_list == False:
        ###     print_log('[WARN] P0130Manage.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        ### if koeki_trigger_act_03_list == False:
        ###     print_log('[WARN] P0130Manage.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        ### if koeki_trigger_act_04_list == False:
        ###     print_log('[WARN] P0130Manage.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        ### if koeki_trigger_act_05_list == False:
        ###     print_log('[WARN] P0130Manage.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        ### if koeki_trigger_act_06_list == False:
        ###     print_log('[WARN] P0130Manage.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        ### if koeki_trigger_act_07_list == False:
        ###     print_log('[WARN] P0130Manage.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.slide_koeki_header_id()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.slide_koeki_header_id()関数が正常終了しました。', 'INFO')
        data = {
            'koeki_header_id': koeki_header_list[0].koeki_header_id, 
            'koeki_header_name': koeki_header_list[0].koeki_header_name, 
            'ken_code': koeki_header_list[0].ken_code, 
            'upload_file_path': koeki_header_list[0].upload_file_path, 
            'upload_file_name': koeki_header_list[0].upload_file_name, 
            'upload_file_size': koeki_header_list[0].upload_file_size, 
            'summary_file_path': koeki_header_list[0].summary_file_path, 
            'summary_file_name': koeki_header_list[0].summary_file_name, 
            'summary_file_size': koeki_header_list[0].summary_file_size, 
            'committed_at': koeki_header_list[0].committed_at, 
            'deleted_at': koeki_header_list[0].deleted_at, 
        }
        if koeki_trigger_act_01_list:
            data01 = {
                'act_01_status_code': koeki_trigger_act_01_list[0].status_code, 
                'act_01_published_at': koeki_trigger_act_01_list[0].published_at, 
                'act_01_consumed_at': koeki_trigger_act_01_list[0].consumed_at, 
                'act_01_deleted_at': koeki_trigger_act_01_list[0].deleted_at, 
            }
        else:
            data01 = {
                'act_01_status_code': None, 
                'act_01_published_at': None, 
                'act_01_consumed_at': None, 
                'act_01_deleted_at': None, 
            }
        if koeki_trigger_act_02_list:
            data02 = {
                'act_02_status_code': koeki_trigger_act_02_list[0].status_code, 
                'act_02_published_at': koeki_trigger_act_02_list[0].published_at, 
                'act_02_consumed_at': koeki_trigger_act_02_list[0].consumed_at, 
                'act_02_deleted_at': koeki_trigger_act_02_list[0].deleted_at, 
            }
        else:
            data02 = {
                'act_02_status_code': None, 
                'act_02_published_at': None, 
                'act_02_consumed_at': None, 
                'act_02_deleted_at': None, 
            }
        if koeki_trigger_act_03_list:
            data03 = {
                'act_03_status_code': koeki_trigger_act_03_list[0].status_code, 
                'act_03_published_at': koeki_trigger_act_03_list[0].published_at, 
                'act_03_consumed_at': koeki_trigger_act_03_list[0].consumed_at, 
                'act_03_deleted_at': koeki_trigger_act_03_list[0].deleted_at, 
            }
        else:
            data03 = {
                'act_03_status_code': None, 
                'act_03_published_at': None, 
                'act_03_consumed_at': None, 
                'act_03_deleted_at': None, 
            }
        if koeki_trigger_act_04_list:
            data04 = {
                'act_04_status_code': koeki_trigger_act_04_list[0].status_code, 
                'act_04_published_at': koeki_trigger_act_04_list[0].published_at, 
                'act_04_consumed_at': koeki_trigger_act_04_list[0].consumed_at, 
                'act_04_deleted_at': koeki_trigger_act_04_list[0].deleted_at, 
            }
        else:
            data04 = {
                'act_04_status_code': None, 
                'act_04_published_at': None, 
                'act_04_consumed_at': None, 
                'act_04_deleted_at': None, 
            }
        if koeki_trigger_act_05_list:
            data05 = {
                'act_05_status_code': koeki_trigger_act_05_list[0].status_code, 
                'act_05_published_at': koeki_trigger_act_05_list[0].published_at, 
                'act_05_consumed_at': koeki_trigger_act_05_list[0].consumed_at, 
                'act_05_deleted_at': koeki_trigger_act_05_list[0].deleted_at, 
            }
        else:
            data05 = {
                'act_05_status_code': None, 
                'act_05_published_at': None, 
                'act_05_consumed_at': None, 
                'act_05_deleted_at': None, 
            }
        if koeki_trigger_act_06_list:
            data06 = {
                'act_06_status_code': koeki_trigger_act_06_list[0].status_code, 
                'act_06_published_at': koeki_trigger_act_06_list[0].published_at, 
                'act_06_consumed_at': koeki_trigger_act_06_list[0].consumed_at, 
                'act_06_deleted_at': koeki_trigger_act_06_list[0].deleted_at, 
            }
        else:
            data06 = {
                'act_06_status_code': None, 
                'act_06_published_at': None, 
                'act_06_consumed_at': None, 
                'act_06_deleted_at': None, 
            }
        if koeki_trigger_act_07_list:
            data07 = {
                'act_07_status_code': koeki_trigger_act_07_list[0].status_code, 
                'act_07_published_at': koeki_trigger_act_07_list[0].published_at, 
                'act_07_consumed_at': koeki_trigger_act_07_list[0].consumed_at, 
                'act_07_deleted_at': koeki_trigger_act_07_list[0].deleted_at, 
            }
        else:
            data07 = {
                'act_07_status_code': None, 
                'act_07_published_at': None, 
                'act_07_consumed_at': None, 
                'act_07_deleted_at': None, 
            }
        data.update(data01)
        data.update(data02)
        data.update(data03)
        data.update(data04)
        data.update(data05)
        data.update(data06)
        data.update(data07)
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return True, response
    
    except:
        print_log('[ERROR] P0130Manage.slide_koeki_header_id()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_koeki_header_id()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.slide_koeki_header_id()関数が異常終了しました。', 'ERROR')
        data = {
            'sample1': [1, 2, 3], 
            'sample2': [3, 6, 9],
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return False, response

###############################################################################
### 運用担当者用一般資産調査員調査票EXCELダウンロード
### 運用担当者用一般資産調査員調査票CSVダウンロード
### 運用担当者用一般資産集計結果EXCELダウンロード
### 運用担当者用一般資産集計結果CSVダウンロード
### 運用担当者用水害区域図PDFダウンロード
### 運用担当者用水害区域図KMLダウンロード
### 運用担当者用地方単独事業調査票EXCELダウンロード
### 運用担当者用地方単独事業調査票CSVダウンロード
### 運用担当者用地方単独事業集計結果EXCELダウンロード
### 運用担当者用地方単独事業集計結果CSVダウンロード
### 運用担当者用補助事業調査票EXCELダウンロード
### 運用担当者用補助事業調査票CSVダウンロード
### 運用担当者用補助事業集計結果EXCELダウンロード
### 運用担当者用補助事業集計結果CSVダウンロード
### 運用担当者用公益事業調査票EXCELダウンロード
### 運用担当者用公益事業調査票CSVダウンロード
### 運用担当者用公益事業集計結果EXCELダウンロード
### 運用担当者用公益事業集計結果CSVダウンロード
###############################################################################
def download_header_id(request, header_id, file_type):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.download_header_id()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.download_header_id()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.download_header_id()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.download_header_id()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.download_header_id()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.download_header_id()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.download_header_id()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.download_header_id()関数が警告終了しました。', 'WARN')
            response = HttpResponseNotFound("")
            return False, response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.download_header_id()関数 STEP 4/6.', 'DEBUG')
        func_params = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'AREA_ID': header_id, 
            'FILE_TYPE': file_type
        })
        if file_type == _IPP_CHO_EXC:
            bool_return, file_path = get_ippan_chosa_csv_excel(request, func_params)
        elif file_type == _IPP_CHO_CSV:
            bool_return, file_path = get_ippan_chosa_csv_excel(request, func_params)
        elif file_type == _IPP_SUM_EXC:
            bool_return, file_path = get_ippan_summary_csv_excel(request, func_params)
        elif file_type == _IPP_SUM_CSV:
            bool_return, file_path = get_ippan_summary_csv_excel(request, func_params)
        elif file_type == _CHI_CHO_EXC:
            bool_return, file_path = get_chitan_chosa_csv_excel(request, func_params)
        elif file_type == _CHI_CHO_CSV:
            bool_return, file_path = get_chitan_chosa_csv_excel(request, func_params)
        elif file_type == _CHI_SUM_EXC:
            bool_return, file_path = get_chitan_summary_csv_excel(request, func_params)
        elif file_type == _CHI_SUM_CSV:
            bool_return, file_path = get_chitan_summary_csv_excel(request, func_params)
        elif file_type == _HOJ_CHO_EXC:
            bool_return, file_path = get_hojo_chosa_csv_excel(request, func_params)
        elif file_type == _HOJ_CHO_CSV:
            bool_return, file_path = get_hojo_chosa_csv_excel(request, func_params)
        elif file_type == _HOJ_SUM_EXC:
            bool_return, file_path = get_hojo_summary_csv_excel(request, func_params)
        elif file_type == _HOJ_SUM_CSV:
            bool_return, file_path = get_hojo_summary_csv_excel(request, func_params)
        elif file_type == _KOE_CHO_EXC:
            bool_return, file_path = get_koeki_chosa_csv_excel(request, func_params)
        elif file_type == _KOE_CHO_CSV:
            bool_return, file_path = get_koeki_chosa_csv_excel(request, func_params)
        elif file_type == _KOE_SUM_EXC:
            bool_return, file_path = get_koeki_summary_csv_excel(request, func_params)
        elif file_type == _KOE_SUM_CSV:
            bool_return, file_path = get_koeki_summary_csv_excel(request, func_params)
        elif file_type == _ARE_PDF:
            bool_return, file_path = get_area_kml_pdf(request, func_params)
        elif file_type == _ARE_KML:
            bool_return, file_path = get_area_kml_pdf(request, func_params)
            
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.download_header_id()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0130Manage.download_header_id()関数が正常終了しました。', 'INFO')
        if file_type == _IPP_CHO_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _IPP_CHO_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _IPP_SUM_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _IPP_SUM_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _ARE_PDF:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/pdf')
            response['Content-Disposition'] = 'attachment; filename="test.pdf"'
        elif file_type == _ARE_KML:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/kml') ### OK
            response['Content-Disposition'] = 'attachment; filename="test.kml"'
        elif file_type == _CHI_CHO_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _CHI_CHO_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _CHI_SUM_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _CHI_SUM_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _HOJ_CHO_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _HOJ_CHO_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _HOJ_SUM_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _HOJ_SUM_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _KOE_CHO_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _KOE_CHO_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _KOE_SUM_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _KOE_SUM_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'

        return True, response
    
    except:
        print_log('[ERROR] P0130Manage.download_header_id()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_header_id()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.download_header_id()関数が異常終了しました。', 'ERROR')
        response = HttpResponseNotFound("")
        return False, response

###############################################################################
### 運用担当者用一般資産調査員調査票ファイル削除
### 運用担当者用水害区域図ファイル削除
### 運用担当者用地方単独事業調査票ファイル削除
### 運用担当者用補助事業調査票ファイル削除
### 運用担当者用公益事業調査票ファイル削除
###############################################################################
def delete_header_id(request, header_id, file_type):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0130Manage.delete_header_id()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0130Manage.delete_header_id()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0130Manage.delete_header_id()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.delete_header_id()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0130Manage.delete_header_id()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0130Manage.delete_header_id()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_MANAGE
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### レスポンスセット処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.delete_header_id()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0130Manage.delete_header_id()関数が警告終了しました。', 'WARN')
            data = {
                'sample1': [1, 2, 3], 
                'sample2': [3, 6, 9],
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return False, response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        ### 下記の処理でアクセス制御を行う。
        ### ※コンテンツにアクセス可能なユーザは市のみとする。
        ### ※Query Stringのheader_idとrequest.userのcity_codeの組み合わせで市区町村がアップロードしたコンテンツにアクセス可能とする。
        ### ※Query Stringのheader_idのみで市区町村がアップロードしたコンテンツにアクセスできてはならない。
        #######################################################################
        print_log('[DEBUG] P0130Manage.delete_header_id()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### レスポンスセット処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.delete_header_id()関数 STEP 5/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0130Manage.delete_header_id()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0130Manage.delete_header_id()関数が正常終了しました。', 'INFO')
        data = {
            'sample1': [1, 2, 3], 
            'sample2': [3, 6, 9],
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return True, response
    
    except:
        print_log('[ERROR] P0130Manage.delete_header_id()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0130Manage.delete_header_id()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0130Manage.delete_header_id()関数が異常終了しました。', 'ERROR')
        data = {
            'sample1': [1, 2, 3], 
            'sample2': [3, 6, 9],
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return False, response
