from django.db import models
from django.contrib.auth.models import User

### データベース設計で絶対役に立つ命名規則
### https://katalog.tokyo/?p=5403
### ID、CODEはテーブル名にあわせる。OK：SUIKEI_CODE、NG：CODE、OK:HEADER_ID、NG:ID
### 項目名が同じになるようにするとER図も自動作成できる。

###############################################################################
### 0000: マスタデータ_ユーザプロキシ
### ログイン用コード
###############################################################################
class USER_PROXY(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)                   ### ユーザ
    ### user.username                                                          ### デフォルトユーザのフィールド
    ### user.first_name                                                        ### デフォルトユーザのフィールド
    ### user.last_name                                                         ### デフォルトユーザのフィールド
    ### user.email                                                             ### デフォルトユーザのフィールド
    ### user.is_staff                                                          ### デフォルトユーザのフィールド
    ### user.is_active                                                         ### デフォルトユーザのフィールド
    ### user.date_joined                                                       ### デフォルトユーザのフィールド
    role_code = models.CharField(max_length=20)                                ### 役割コード（ROLE_CITY:市区町村、ROLE_KEN:都道府県、ROLE_MANAGE:運用担当者）
    ken_code = models.CharField(max_length=10, null=True)                      ### 都道府県コード
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード

    class Meta:
        db_table = 'user_proxy'
    
    def __str__(self):
        return '<USER_PROXY: ' + self.role_code + '>'

### INSERT INTO USER_PROXY (ROLE_CODE, KEN_CODE, CITY_CODE, USER_ID) VALUES ('1', '01', '011011', 1);
### INSERT INTO USER_PROXY (ROLE_CODE, KEN_CODE, USER_ID) VALUES ('2', '01', 2);
### INSERT INTO USER_PROXY (ROLE_CODE, USER_ID) VALUES ('3', 3);

###############################################################################
### 1000: マスタデータ_建物区分
### 入力用コード、集計用コード
###############################################################################
class BUILDING(models.Model):
    building_code = models.CharField(max_length=10, primary_key=True)          ### 建物区分コード
    building_name = models.CharField(max_length=128)                           ### 建物区分名

    class Meta:
        db_table = 'building'
    
    def __str__(self):
        return '<BUILDING: ' + self.building_code + '>'

###############################################################################
### 1010: マスタデータ_都道府県
### 入力用コード、集計用コード
###############################################################################
class KEN(models.Model):
    ken_code = models.CharField(max_length=10, primary_key=True)               ### 都道府県コード
    ken_name = models.CharField(max_length=128)                                ### 都道府県名

    class Meta:
        db_table = 'ken'
    
    def __str__(self):
        return '<KEN: ' + self.ken_code + '>'

###############################################################################
### 1020: マスタデータ_市区町村
### 入力用コード、集計用コード
###############################################################################
class CITY(models.Model):
    city_code = models.CharField(max_length=10, primary_key=True)              ### 市区町村コード
    city_name = models.CharField(max_length=128)                               ### 市区町村名
    ken_code = models.CharField(max_length=10)                                 ### 都道府県コード
    city_population = models.IntegerField()                                    ### 市区町村人口
    city_area = models.IntegerField()                                          ### 市区町村面積
    ### city_population = models.DecimalField(max_digits=15, decimal_places=2) ### 市区町村人口
    ### city_area = models.DecimalField(max_digits=15, decimal_places=2)       ### 市区町村面積

    class Meta:
        db_table = 'city'
    
    def __str__(self):
        return '<CITY: ' + self.city_code + '>'

###############################################################################
### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
### 入力用コード、集計用コード
###############################################################################
class KASEN_KAIGAN(models.Model):
    kasen_kaigan_code = models.CharField(max_length=10, primary_key=True)      ### 河川海岸区分コード
    kasen_kaigan_name = models.CharField(max_length=128)                       ### 河川海岸区分名

    class Meta:
        db_table = 'kasen_kaigan'
 
    def __str__(self):
        return '<KASEN_KAIGAN: ' + self.kasen_kaigan_code + '>'

###############################################################################
### 1030: マスタデータ_災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
### 入力用コード、集計用コード
###############################################################################
class KASEN_SETUBI(models.Model):
    kasen_setubi_code = models.CharField(max_length=10, primary_key=True)     ### 河川海岸砂防設備地すべり防止施設区分コード
    kasen_setubi_name = models.CharField(max_length=128)                      ### 河川海岸砂防設備地すべり防止施設区分名

    class Meta:
        db_table = 'kasen_setubi'
 
    def __str__(self):
        return '<KASEN_SETUBI: ' + self.kasen_setubi_code + '>'

###############################################################################
### 1040: マスタデータ_水系（水系・沿岸）
### 入力用コード、集計用コード
###############################################################################
class SUIKEI(models.Model):
    suikei_code = models.CharField(max_length=10, primary_key=True)            ### 水系コード
    suikei_name = models.CharField(max_length=128)                             ### 水系名
    suikei_type_code = models.CharField(max_length=10)                         ### 水系種別コード

    class Meta:
        db_table = 'suikei'

    def __str__(self):
        return '<SUIKEI: ' + self.suikei_code + '>'

###############################################################################
### 1050: マスタデータ_水系種別（水系・沿岸種別）
### 入力用コード、集計用コード
###############################################################################
class SUIKEI_TYPE(models.Model):
    suikei_type_code = models.CharField(max_length=10, primary_key=True)       ### 水系種別コード
    suikei_type_name = models.CharField(max_length=128)                        ### 水系種別名

    class Meta:
        db_table = 'suikei_type'

    def __str__(self):
        return '<SUIKEI_TYPE: ' + self.suikei_type_code + '>'

###############################################################################
### 1060: マスタデータ_河川（河川・海岸）
### 入力用コード、集計用コード
###############################################################################
class KASEN(models.Model):
    kasen_code = models.CharField(max_length=10, primary_key=True)             ### 河川コード
    kasen_name = models.CharField(max_length=128)                              ### 河川名
    kasen_type_code = models.CharField(max_length=10)                          ### 河川種別コード
    suikei_code = models.CharField(max_length=10)                              ### 水系コード

    class Meta:
        db_table = 'kasen'

    def __str__(self):
        return '<KASEN: ' + self.kasen_code + '>'

###############################################################################
### 1070: マスタデータ_河川種別（河川・海岸種別）
### 入力用コード、集計用コード
###############################################################################
class KASEN_TYPE(models.Model):
    kasen_type_code = models.CharField(max_length=10, primary_key=True)        ### 河川種別コード
    kasen_type_name = models.CharField(max_length=128)                         ### 河川種別名

    class Meta:
        db_table = 'kasen_type'

    def __str__(self):
        return '<KASEN_TYPE: ' + self.kasen_type_code + '>'

###############################################################################
### 1080: マスタデータ_水害原因
### 入力用コード、集計用コード
###############################################################################
class CAUSE(models.Model):    
    cause_code = models.CharField(max_length=10, primary_key=True)             ### 水害原因コード
    cause_name = models.CharField(max_length=128)                              ### 水害原因名

    class Meta:
        db_table = 'cause'
    
    def __str__(self):
        return '<CAUSE: ' + self.cause_code + '>'

###############################################################################
### 1090: マスタデータ_地上地下区分
### 入力用コード、集計用コード
###############################################################################
class UNDERGROUND(models.Model):
    underground_code = models.CharField(max_length=10, primary_key=True)       ### 地上地下区分コード
    underground_name = models.CharField(max_length=128)                        ### 地上地下区分名

    class Meta:
        db_table = 'underground'

    def __str__(self):
        return '<UNDERGROUND: ' + self.underground_code + '>'

###############################################################################
### 1100: マスタデータ_地下空間の利用形態
### 入力用コード、集計用コード
###############################################################################
class USAGE(models.Model):
    usage_code = models.CharField(max_length=10, primary_key=True)             ### 地下空間の利用形態コード
    usage_name = models.CharField(max_length=128)                              ### 地下空間の利用形態名

    class Meta:
        db_table = 'usage'

    def __str__(self):
        return '<USAGE: ' + self.usage_code + '>'

###############################################################################
### 1110: マスタデータ_浸水土砂区分
### 入力用コード、集計用コード
###############################################################################
class FLOOD_SEDIMENT(models.Model):
    flood_sediment_code = models.CharField(max_length=10, primary_key=True)    ### 浸水土砂区分コード
    flood_sediment_name = models.CharField(max_length=128)                     ### 浸水土砂区分名

    class Meta:
        db_table = 'flood_sediment'

    def __str__(self):
        return '<FLOOD_SEDIMENT: ' + self.flood_sediment_code + '>'
    
###############################################################################
### 1120: マスタデータ_地盤勾配区分
### 入力用コード、集計用コード
###############################################################################
class GRADIENT(models.Model):
    gradient_code = models.CharField(max_length=10, primary_key=True)          ### 地盤勾配区分コード
    gradient_name = models.CharField(max_length=128)                           ### 地盤勾配区分名

    class Meta:
        db_table = 'gradient'

    def __str__(self):
        return '<GRADIENT: ' + self.gradient_code + '>'

###############################################################################
### 1130: マスタデータ_産業分類
### 入力用コード、集計用コード
###############################################################################
class INDUSTRY(models.Model):
    industry_code = models.CharField(max_length=10, primary_key=True)          ### 産業分類コード
    industry_name = models.CharField(max_length=128)                           ### 産業分類名

    class Meta:
        db_table = 'industry'

    def __str__(self):
        return '<INDUSTRY: ' + self.industry_code + '>'

###############################################################################
### 1140: マスタデータ_公益事業分類
### 入力用コード、集計用コード
###############################################################################
class BUSINESS(models.Model):
    business_code = models.CharField(max_length=10, primary_key=True)          ### 公益事業分類コード
    business_name = models.CharField(max_length=128)                           ### 公益事業分類名

    class Meta:
        db_table = 'business'

    def __str__(self):
        return '<BUSINESS: ' + self.business_code + '>'

###############################################################################
### 2000: マスタデータ_家屋評価額
### 集計用資産額、集計用被害率
###############################################################################
class HOUSE_ASSET(models.Model):
    house_asset_code = models.CharField(max_length=10, primary_key=True)       ### 家屋評価額コード
    ken_code = models.CharField(max_length=10)                                 ### 都道府県コード
    house_asset = models.FloatField(null=True)                                 ### 家屋評価額

    class Meta:
        db_table = 'house_asset'

    def __str__(self):
        return '<HOUSE_ASSET: ' + self.house_asset_code + '>'

###############################################################################
### 2010: マスタデータ_家屋被害率
### 集計用資産額、集計用被害率
###############################################################################
class HOUSE_RATE(models.Model):
    house_rate_code = models.CharField(max_length=10, primary_key=True)        ### 家屋被害率コード
    flood_sediment_code = models.CharField(max_length=10)                      ### 浸水土砂区分コード
    gradient_code = models.CharField(max_length=10)                            ### 地盤勾配区分コード
    house_rate_lv00 = models.FloatField()                                      ### 家屋被害率_床下
    house_rate_lv00_50 = models.FloatField()                                   ### 家屋被害率_0から50cm未満
    house_rate_lv50_100 = models.FloatField()                                  ### 家屋被害率_50から100cm未満
    house_rate_lv100_200 = models.FloatField()                                 ### 家屋被害率_100から200cm未満
    house_rate_lv200_300 = models.FloatField()                                 ### 家屋被害率_200から300cm未満
    house_rate_lv300 = models.FloatField()                                     ### 家屋被害率_300cm以上

    class Meta:
        db_table = 'house_rate'

    def __str__(self):
        return '<HOUSE_RATE: ' + self.house_rate_code + '>'
    
###############################################################################
### 2020: マスタデータ_家庭応急対策費_代替活動費
### 集計用資産額、集計用被害率
###############################################################################
class HOUSE_ALT(models.Model):
    house_alt_code = models.CharField(max_length=10, primary_key=True)         ### 家庭応急対策費_代替活動費コード
    house_alt_lv00 = models.FloatField()                                       ### 家庭応急対策費_代替活動費_床下
    house_alt_lv00_50 = models.FloatField()                                    ### 家庭応急対策費_代替活動費_0から50cm未満
    house_alt_lv50_100 = models.FloatField()                                   ### 家庭応急対策費_代替活動費_50から100cm未満
    house_alt_lv100_200 = models.FloatField()                                  ### 家庭応急対策費_代替活動費_100から200cm未満
    house_alt_lv200_300 = models.FloatField()                                  ### 家庭応急対策費_代替活動費_200から300cm未満
    house_alt_lv300 = models.FloatField()                                      ### 家庭応急対策費_代替活動費_300cm以上
    
    class Meta:
        db_table = 'house_alt'
    
    def __str__(self):
        return '<HOUSE_ALT: ' + self.house_alt_code + '>'

###############################################################################
### 2030: マスタデータ_家庭応急対策費_清掃日数
### 集計用資産額、集計用被害率
###############################################################################
class HOUSE_CLEAN(models.Model):
    house_clean_code = models.CharField(max_length=10, primary_key=True)       ### 家庭応急対策費_清掃日数コード
    house_clean_days_lv00 = models.FloatField()                                ### 家庭応急対策費_清掃日数_床下
    house_clean_days_lv00_50 = models.FloatField()                             ### 家庭応急対策費_清掃日数_0から50cm未満
    house_clean_days_lv50_100 = models.FloatField()                            ### 家庭応急対策費_清掃日数_50から100cm未満
    house_clean_days_lv100_200 = models.FloatField()                           ### 家庭応急対策費_清掃日数_100から200cm未満
    house_clean_days_lv200_300 = models.FloatField()                           ### 家庭応急対策費_清掃日数_200から300cm未満
    house_clean_days_lv300 = models.FloatField()                               ### 家庭応急対策費_清掃日数_300cm以上
    house_clean_unit_cost = models.FloatField()                                ### 家庭応急対策費_清掃労働単価
    
    class Meta:
        db_table = 'house_clean'
    
    def __str__(self):
        return '<HOUSE_CLEAN: ' + self.house_clean_code + '>'

###############################################################################
### 3000: マスタデータ_家庭用品自動車以外所有額
### 集計用資産額、集計用被害率
###############################################################################
class HOUSEHOLD_ASSET(models.Model):
    household_asset_code = models.CharField(max_length=10, primary_key=True)   ### 家庭用品自動車以外所有額コード
    household_asset = models.FloatField()                                      ### 家庭用品自動車以外所有額

    class Meta:
        db_table = 'household_asset'

    def __str__(self):
        return '<HOUSEHOLD_ASSET: ' + self.household_asset_code + '>'

###############################################################################
### 3010: マスタデータ_家庭用品自動車以外被害率
### 集計用資産額、集計用被害率
###############################################################################
class HOUSEHOLD_RATE(models.Model):
    household_rate_code = models.CharField(max_length=10, primary_key=True)    ### 家庭用品自動車以外被害率コード
    flood_sediment_code = models.CharField(max_length=10)                      ### 浸水土砂区分コード
    ### gradient_code = models.CharField(max_length=10)                        ### 地盤勾配区分コード
    household_rate_lv00 = models.FloatField()                                  ### 家庭用品自動車以外被害率_床下
    household_rate_lv00_50 = models.FloatField()                               ### 家庭用品自動車以外被害率_0から50cm未満
    household_rate_lv50_100 = models.FloatField()                              ### 家庭用品自動車以外被害率_50から100cm未満
    household_rate_lv100_200 = models.FloatField()                             ### 家庭用品自動車以外被害率_100から200cm未満
    household_rate_lv200_300 = models.FloatField()                             ### 家庭用品自動車以外被害率_200から300cm未満
    household_rate_lv300 = models.FloatField()                                 ### 家庭用品自動車以外被害率_300cm以上

    class Meta:
        db_table = 'household_rate'

    def __str__(self):
        return '<HOUSEHOLD_RATE: ' + self.household_rate_code + '>'

###############################################################################
### 4000: マスタデータ_家庭用品自動車所有額
### 集計用資産額、集計用被害率
###############################################################################
class CAR_ASSET(models.Model):
    car_asset_code = models.CharField(max_length=10, primary_key=True)         ### 家庭用品自動車所有額コード
    car_asset = models.FloatField()                                            ### 家庭用品自動車所有額

    class Meta:
        db_table = 'car_asset'

    def __str__(self):
        return '<CAR_ASSET: ' + self.car_asset_code + '>'

###############################################################################
### 4010: マスタデータ_家庭用品自動車被害率
### 集計用資産額、集計用被害率
###############################################################################
class CAR_RATE(models.Model):
    car_rate_code = models.CharField(max_length=10, primary_key=True)          ### 家庭用品自動車被害率コード
    ### flood_sediment_code = models.CharField(max_length=10)                  ### 浸水土砂区分コード
    ### gradient_code = models.CharField(max_length=10)                        ### 地盤勾配区分コード
    car_rate_lv00 = models.FloatField()                                        ### 家庭用品自動車被害率_床下
    car_rate_lv00_50 = models.FloatField()                                     ### 家庭用品自動車被害率_0から50cm未満
    car_rate_lv50_100 = models.FloatField()                                    ### 家庭用品自動車被害率_50から100cm未満
    car_rate_lv100_200 = models.FloatField()                                   ### 家庭用品自動車被害率_100から200cm未満
    car_rate_lv200_300 = models.FloatField()                                   ### 家庭用品自動車被害率_200から300cm未満
    car_rate_lv300 = models.FloatField()                                       ### 家庭用品自動車被害率_300cm以上

    class Meta:
        db_table = 'car_rate'

    def __str__(self):
        return '<CAR_RATE: ' + self.car_rate_code + '>'

###############################################################################
### 5000: マスタデータ_事業所資産額
### 集計用資産額、集計用被害率
###############################################################################
class OFFICE_ASSET(models.Model):
    office_asset_code = models.CharField(max_length=10, primary_key=True)      ### 事業所資産額コード
    industry_code = models.CharField(max_length=10)                            ### 産業分類コード
    office_dep_asset = models.FloatField(null=True)                            ### 事業所資産額_償却資産額
    office_inv_asset = models.FloatField(null=True)                            ### 事業所資産額_在庫資産額
    office_va_asset = models.FloatField(null=True)                             ### 事業所資産額_付加価値額

    class Meta:
        db_table = 'office_asset'

    def __str__(self):
        return '<OFFICE_ASSET: ' + self.office_asset_code + '>'

###############################################################################
### 5010: マスタデータ_事業所被害率
### 集計用資産額、集計用被害率
###############################################################################
class OFFICE_RATE(models.Model):
    office_rate_code = models.CharField(max_length=10, primary_key=True)       ### 事業所被害率コード
    flood_sediment_code = models.CharField(max_length=10)                      ### 浸水土砂区分コード
    ### gradient_code = models.CharField(max_length=10)                        ### 地盤勾配区分コード
    office_dep_rate_lv00 = models.FloatField()                                 ### 事業所被害率_償却資産被害率_床下
    office_dep_rate_lv00_50 = models.FloatField()                              ### 事業所被害率_償却資産被害率_0から50cm未満
    office_dep_rate_lv50_100 = models.FloatField()                             ### 事業所被害率_償却資産被害率_50から100cm未満
    office_dep_rate_lv100_200 = models.FloatField()                            ### 事業所被害率_償却資産被害率_100から200cm未満
    office_dep_rate_lv200_300 = models.FloatField()                            ### 事業所被害率_償却資産被害率_200から300cm未満
    office_dep_rate_lv300 = models.FloatField()                                ### 事業所被害率_償却資産被害率_300cm以上
    office_inv_rate_lv00 = models.FloatField()                                 ### 事業所被害率_在庫資産被害率_床下
    office_inv_rate_lv00_50 = models.FloatField()                              ### 事業所被害率_在庫資産被害率_0から50cm未満
    office_inv_rate_lv50_100 = models.FloatField()                             ### 事業所被害率_在庫資産被害率_50から100cm未満
    office_inv_rate_lv100_200 = models.FloatField()                            ### 事業所被害率_在庫資産被害率_100から200cm未満
    office_inv_rate_lv200_300 = models.FloatField()                            ### 事業所被害率_在庫資産被害率_200から300cm未満
    office_inv_rate_lv300 = models.FloatField()                                ### 事業所被害率_在庫資産被害率_300cm以上

    class Meta:
        db_table = 'office_rate'

    def __str__(self):
        return '<OFFICE_RATE: ' + self.office_rate_code + '>'

###############################################################################
### 5020: マスタデータ_事業所営業停止日数
### 集計用資産額、集計用被害率
###############################################################################
class OFFICE_SUSPEND(models.Model):
    office_sus_code = models.CharField(max_length=10, primary_key=True)        ### 事業所営業停止日数コード
    office_sus_days_lv00 = models.FloatField(null=True)                        ### 事業所営業停止日数_床下
    office_sus_days_lv00_50 = models.FloatField(null=True)                     ### 事業所営業停止日数_0から50cm未満
    office_sus_days_lv50_100 = models.FloatField(null=True)                    ### 事業所営業停止日数_50から100cm未満
    office_sus_days_lv100_200 = models.FloatField(null=True)                   ### 事業所営業停止日数_100から200cm未満
    office_sus_days_lv200_300 = models.FloatField(null=True)                   ### 事業所営業停止日数_200から300cm未満
    office_sus_days_lv300 = models.FloatField(null=True)                       ### 事業所営業停止日数_300cm以上
    
    class Meta:
        db_table = 'office_suspend'
        
    def __str__(self):
        return '<OFFICE_SUSPEND: ' + self.office_sus_code + '>'

###############################################################################
### 5030: マスタデータ_事業所営業停滞日数
### 集計用資産額、集計用被害率
###############################################################################
class OFFICE_STAGNATE(models.Model):
    office_stg_code = models.CharField(max_length=10, primary_key=True)        ### 事業所営業停滞日数コード
    office_stg_days_lv00 = models.FloatField(null=True)                        ### 事業所営業停滞日数_床下
    office_stg_days_lv00_50 = models.FloatField(null=True)                     ### 事業所営業停滞日数_0から50cm未満
    office_stg_days_lv50_100 = models.FloatField(null=True)                    ### 事業所営業停滞日数_50から100cm未満
    office_stg_days_lv100_200 = models.FloatField(null=True)                   ### 事業所営業停滞日数_100から200cm未満
    office_stg_days_lv200_300 = models.FloatField(null=True)                   ### 事業所営業停滞日数_200から300cm未満
    office_stg_days_lv300 = models.FloatField(null=True)                       ### 事業所営業停滞日数_300cm以上

    class Meta:
        db_table = 'office_stagnate'
        
    def __str__(self):
        return '<OFFICE_STAGNATE: ' + self.office_stg_code + '>'

###############################################################################
### 5040: マスタデータ_事業所応急対策費_代替活動費
### 集計用資産額、集計用被害率
###############################################################################
class OFFICE_ALT(models.Model):
    office_alt_code = models.CharField(max_length=10, primary_key=True)        ### 事業所応急対策費_代替活動費コード
    office_alt_lv00 = models.FloatField(null=True)                             ### 事業所応急対策費_代替活動費_床下
    office_alt_lv00_50 = models.FloatField(null=True)                          ### 事業所応急対策費_代替活動費_0から50cm未満
    office_alt_lv50_100 = models.FloatField(null=True)                         ### 事業所応急対策費_代替活動費_50から100cm未満
    office_alt_lv100_200 = models.FloatField(null=True)                        ### 事業所応急対策費_代替活動費_100から200cm未満
    office_alt_lv200_300 = models.FloatField(null=True)                        ### 事業所応急対策費_代替活動費_200から300cm未満
    office_alt_lv300 = models.FloatField(null=True)                            ### 事業所応急対策費_代替活動費_300cm以上

    class Meta:
        db_table = 'office_alt'
        
    def __str__(self):
        return '<OFFICE_ALT: ' + self.office_alt_code + '>'

###############################################################################
### 6000: マスタデータ_農漁家資産額
### 集計用資産額、集計用被害率
###############################################################################
class FARMER_FISHER_ASSET(models.Model):
    farmer_fisher_asset_code = models.CharField(max_length=10, primary_key=True)    ### 農漁家資産額コード
    farmer_fisher_dep_asset = models.FloatField(null=True)                          ### 農漁家資産額_償却資産額
    farmer_fisher_inv_asset = models.FloatField(null=True)                          ### 農漁家資産額_在庫資産額

    class Meta:
        db_table = 'farmer_fisher_asset'

    def __str__(self):
        return '<FARMER_FISHER_ASSET: ' + self.farmer_fisher_asset_code + '>'

###############################################################################
### 6010: マスタデータ_農漁家被害率
### 集計用資産額、集計用被害率
###############################################################################
class FARMER_FISHER_RATE(models.Model):
    farmer_fisher_rate_code = models.CharField(max_length=10, primary_key=True)     ### 農漁家被害率コード
    flood_sediment_code = models.CharField(max_length=10)                           ### 浸水土砂区分コード
    ### gradient_code = models.CharField(max_length=10)                             ### 地盤勾配区分コード
    farmer_fisher_dep_rate_lv00 = models.FloatField()                               ### 農漁家被害率_償却資産被害率_床下
    farmer_fisher_dep_rate_lv00_50 = models.FloatField()                            ### 農漁家被害率_償却資産被害率_0から50cm未満
    farmer_fisher_dep_rate_lv50_100 = models.FloatField()                           ### 農漁家被害率_償却資産被害率_50から100cm未満
    farmer_fisher_dep_rate_lv100_200 = models.FloatField()                          ### 農漁家被害率_償却資産被害率_100から200cm未満
    farmer_fisher_dep_rate_lv200_300 = models.FloatField()                          ### 農漁家被害率_償却資産被害率_200から300cm未満
    farmer_fisher_dep_rate_lv300 = models.FloatField()                              ### 農漁家被害率_償却資産被害率_300cm以上
    farmer_fisher_inv_rate_lv00 = models.FloatField()                               ### 農漁家被害率_在庫資産被害率_床下
    farmer_fisher_inv_rate_lv00_50 = models.FloatField()                            ### 農漁家被害率_在庫資産被害率_0から50cm未満
    farmer_fisher_inv_rate_lv50_100 = models.FloatField()                           ### 農漁家被害率_在庫資産被害率_50から100cm未満
    farmer_fisher_inv_rate_lv100_200 = models.FloatField()                          ### 農漁家被害率_在庫資産被害率_100から200cm未満
    farmer_fisher_inv_rate_lv200_300 = models.FloatField()                          ### 農漁家被害率_在庫資産被害率_200から300cm未満
    farmer_fisher_inv_rate_lv300 = models.FloatField()                              ### 農漁家被害率_在庫資産被害率_300cm以上

    class Meta:
        db_table = 'farmer_fisher_rate'

    def __str__(self):
        return '<FARMER_FISHER_RATE: ' + self.farmer_fisher_rate_code + '>'

###############################################################################
### 7000: アップロードデータ_水害区域
### トランザクション系テーブル（更新テーブル）
### 主に入力用（アップロードダウンロード）
###############################################################################
class AREA(models.Model):
    area_id = models.IntegerField(primary_key=True)                            ### 水害区域ID
    area_name = models.CharField(max_length=128)                               ### 水害区域名
    ken_code = models.CharField(max_length=10, null=True)                      ### 都道府県コード
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード ADD 2023/02/08

    upload_file_path = models.CharField(max_length=256, null=True)             ### アップロードファイルパス ※2022/08/03 追加
    upload_file_name = models.CharField(max_length=256, null=True)             ### アップロードファイル名 ※2022/08/03 追加
    upload_file_size = models.FloatField(null=True)                            ### ディスク使用量 ※2023/02/10 追加

    ### upload_pdf_path = models.CharField(max_length=256, null=True)              ### アップロードPDFパス ※2023/03/XX 追加予定 TODO
    ### upload_pdf_name = models.CharField(max_length=256, null=True)              ### アップロードPDF名 ※2023/03/XX 追加予定 TODO
    ### upload_pdf_size = models.FloatField(null=True)                             ### ディスク使用量 ※2023/03/XX 追加予定 TODO

    ### upload_kml_path = models.CharField(max_length=256, null=True)              ### アップロードKMLパス ※2023/03/XX 追加予定 TODO
    ### upload_kml_name = models.CharField(max_length=256, null=True)              ### アップロードKML名 ※2023/03/XX 追加予定 TODO
    ### upload_kml_size = models.FloatField(null=True)                             ### ディスク使用量 ※2023/03/XX 追加予定 TODO

    ### action_code = models.CharField(max_length=10, null=True)               ### 最新のアクションコード ※2022/07/12 追加
    ### status_code = models.CharField(max_length=10, null=True)               ### 最新の状態コード ※2022/07/12 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/07/12 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※2022/07/12 追加

    class Meta:
        db_table = 'area'

    def __str__(self):
        return '<AREA: ' + str(self.area_id) + '>'

###############################################################################
### 7010: アップロードデータ_異常気象
### トランザクション系テーブル（更新テーブル）
### 主に入力用（アップロードダウンロード）
###############################################################################
class WEATHER(models.Model):
    weather_id = models.IntegerField(primary_key=True)                         ### 異常気象ID
    weather_name = models.CharField(max_length=128)                            ### 異常気象名
    begin_date = models.DateField()                                            ### 開始日
    end_date = models.DateField()                                              ### 終了日
    ken_code = models.CharField(max_length=10, null=True)                      ### 都道府県コード

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/07/27 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※2022/07/27 追加

    class Meta:
        db_table = 'weather'
    
    def __str__(self):
        return '<WEATHER: ' + str(self.weather_id) + '>'

###############################################################################
### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
### トランザクション系テーブル（更新テーブル）
### 主に入力用（アップロードダウンロード）
### ※テーブルの1レコード=EXCELの1シートに対応する。
### ※複数シート可とする。
###############################################################################
class IPPAN_HEADER(models.Model):
    ippan_header_id = models.IntegerField(primary_key=True)                    ### シートID
    ippan_header_name = models.CharField(max_length=128, null=True)            ### シート名

    ### 帳票のヘッダ部分 行7
    ### 第2正規形の考え方からはヘッダ部分は別テーブルに分割する。
    ken_code = models.CharField(max_length=10, null=True)                      ### 都道府県コード ### FOR GROUP BY
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード ### FOR GROUP BY
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ### FOR GROUP BY
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ### FOR GROUP BY
    cause_1_code = models.CharField(max_length=10, null=True)                  ### 水害原因_1_コード ### FOR GROUP BY
    cause_2_code = models.CharField(max_length=10, null=True)                  ### 水害原因_2_コード ### FOR GROUP BY
    cause_3_code = models.CharField(max_length=10, null=True)                  ### 水害原因_3_コード ### FOR GROUP BY
    area_id = models.IntegerField(null=True)                                   ### 水害区域ID ### FOR GROUP BY

    ### 帳票のヘッダ部分 行10
    suikei_code = models.CharField(max_length=10, null=True)                   ### 水系コード ### FOR GROUP BY
    suikei_type_code = models.CharField(max_length=10, null=True)              ### 水系種別コード
    kasen_code = models.CharField(max_length=10, null=True)                    ### 河川コード ### FOR GROUP BY
    kasen_type_code = models.CharField(max_length=10, null=True)               ### 河川種別コード
    gradient_code = models.CharField(max_length=10, null=True)                 ### 地盤勾配区分コード FOR PARAM ### FOR GROUP BY

    ### 帳票のヘッダ部分 行14
    residential_area = models.FloatField(null=True)                            ### 宅地面積（単位m2）
    agricultural_area = models.FloatField(null=True)                           ### 農地面積（単位m2）
    underground_area = models.FloatField(null=True)                            ### 地下面積（単位m2）
    kasen_kaigan_code = models.CharField(max_length=10, null=True)             ### 河川海岸（工種）コード ### FOR GROUP BY
    crop_damage = models.FloatField(null=True)                                 ### 農作物被害額（単位千円）
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ### FOR GROUP BY

    ### 制御用データ
    upload_file_path = models.CharField(max_length=256, null=True)             ### アップロードファイルパス ※2022/08/01 追加
    upload_file_name = models.CharField(max_length=256, null=True)             ### アップロードファイル名 ※2022/08/01 追加
    summary_file_path = models.CharField(max_length=256, null=True)            ### 集計結果ファイルパス ※2022/08/01 追加
    summary_file_name = models.CharField(max_length=256, null=True)            ### 集計結果ファイル名 ※2022/08/01 追加

    upload_file_size = models.FloatField(null=True)                            ### ディスク使用量 ※2023/02/10 追加
    summary_file_size = models.FloatField(null=True)                           ### ディスク使用量 ※2023/02/10 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/07/11 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※2022/07/11 追加

    class Meta:
        db_table = 'ippan_header'
        ### constraints = [
        ###     models.UniqueConstraint(
        ###         fields=['ken_code', 'city_code', 'begin_date', 'cause_1_code', 'area_id', 'suikei_code', 'kasen_code', 'gradient_code'],
        ###         name='ippan_header_unique'
        ###     ),
        ### ]
    def __str__(self):
        return '<IPPAN_HEADER: ' + str(self.ippan_header_id) + '>'

###############################################################################
### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
### トランザクション系テーブル（更新テーブル）
### 主に入力用（アップロードダウンロード）
### ※テーブルの1レコード=EXCELの1ファイル=1都道府県に対応する。
### ※CHITAN_HEADER、CHITAN、CHITAN_SUMMARY、CHITAN_TRIGGERの更新単位=EXCELの1ファイル=1都道府県とする。
### ※複数シート不可とする。
###############################################################################
class CHITAN_HEADER(models.Model):
    chitan_header_id = models.IntegerField(primary_key=True)                   ### シートID ※2022/08/05 追加
    chitan_header_name = models.CharField(max_length=128, null=True)           ### シート名 ※2022/08/05 追加
    
    ken_code = models.CharField(max_length=10, null=True)                      ### 都道府県コード ※2022/08/05 追加
    
    ### 制御用データ
    upload_file_path = models.CharField(max_length=256, null=True)             ### アップロードファイルパス ※2022/08/01 追加
    upload_file_name = models.CharField(max_length=256, null=True)             ### アップロードファイル名 ※2022/08/01 追加
    summary_file_path = models.CharField(max_length=256, null=True)            ### 集計結果ファイルパス ※2022/08/01 追加
    summary_file_name = models.CharField(max_length=256, null=True)            ### 集計結果ファイル名 ※2022/08/01 追加

    upload_file_size = models.FloatField(null=True)                            ### ディスク使用量 ※2023/02/10 追加
    summary_file_size = models.FloatField(null=True)                           ### ディスク使用量 ※2023/02/10 追加
    
    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/08/05 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※2022/08/05 追加

    class Meta:
        db_table = 'chitan_header'

    def __str__(self):
        return '<CHITAN_HEADER: ' + str(self.chitan_header_id) + '>'

###############################################################################
### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
### トランザクション系テーブル（更新テーブル）
### 主に入力用（アップロードダウンロード）
### ※テーブルの1レコード=EXCELの1ファイル=1都道府県に対応する。
### ※HOJO_HEADER、HOJO、HOJO_SUMMARY、HOJO_TRIGGERの更新単位=EXCELの1ファイル=1都道府県とする。
### ※複数シート不可とする。
###############################################################################
class HOJO_HEADER(models.Model):
    hojo_header_id = models.IntegerField(primary_key=True)                     ### シートID ※2022/08/05 追加
    hojo_header_name = models.CharField(max_length=128, null=True)             ### シート名 ※2022/08/05 追加
    
    ken_code = models.CharField(max_length=10, null=True)                      ### 都道府県コード ※2022/08/05 追加
    
    ### 制御用データ
    upload_file_path = models.CharField(max_length=256, null=True)             ### アップロードファイルパス ※2022/08/01 追加
    upload_file_name = models.CharField(max_length=256, null=True)             ### アップロードファイル名 ※2022/08/01 追加
    summary_file_path = models.CharField(max_length=256, null=True)            ### 集計結果ファイルパス ※2022/08/01 追加
    summary_file_name = models.CharField(max_length=256, null=True)            ### 集計結果ファイル名 ※2022/08/01 追加

    upload_file_size = models.FloatField(null=True)                            ### ディスク使用量 ※2023/02/10 追加
    summary_file_size = models.FloatField(null=True)                           ### ディスク使用量 ※2023/02/10 追加
    
    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/08/05 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※2022/08/05 追加

    class Meta:
        db_table = 'hojo_header'

    def __str__(self):
        return '<HOJO_HEADER: ' + str(self.hojo_header_id) + '>'

###############################################################################
### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
### トランザクション系テーブル（更新テーブル）
### 主に入力用（アップロードダウンロード）
### ※テーブルの1レコード=EXCELの1ファイル=1都道府県に対応する。
### ※KOEKI_HEADER、KOEKI、KOEKI_SUMMARY、KOEKI_TRIGGERの更新単位=EXCELの1ファイル=1都道府県とする。
### ※複数シート不可とする。
###############################################################################
class KOEKI_HEADER(models.Model):
    koeki_header_id = models.IntegerField(primary_key=True)                    ### シートID ※2022/08/05 追加
    koeki_header_name = models.CharField(max_length=128, null=True)            ### シート名 ※2022/08/05 追加

    ken_code = models.CharField(max_length=10, null=True)                      ### 都道府県コード ※2022/08/05 追加

    ### 制御用データ
    upload_file_path = models.CharField(max_length=256, null=True)             ### アップロードファイルパス ※2022/08/01 追加
    upload_file_name = models.CharField(max_length=256, null=True)             ### アップロードファイル名 ※2022/08/01 追加
    summary_file_path = models.CharField(max_length=256, null=True)            ### 集計結果ファイルパス ※2022/08/01 追加
    summary_file_name = models.CharField(max_length=256, null=True)            ### 集計結果ファイル名 ※2022/08/01 追加

    upload_file_size = models.FloatField(null=True)                            ### ディスク使用量 ※2023/02/10 追加
    summary_file_size = models.FloatField(null=True)                           ### ディスク使用量 ※2023/02/10 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/08/05 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※2022/08/05 追加

    class Meta:
        db_table = 'koeki_header'

    def __str__(self):
        return '<KOEKI_HEADER: ' + str(self.koeki_header_id) + '>'

###############################################################################
### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
### トランザクション系テーブル（更新テーブル）
### 主に入力用（アップロードダウンロード）
### ※テーブルの1レコード=EXCELの1行に対応する。
### ※IPPAN_HEADER、IPPAN、IPPAN_SUMMARY、IPPAN_TRIGGERの更新単位=EXCELの1ファイル=1市区町村とする。
### ※複数シート可とする。
###############################################################################
class IPPAN(models.Model):
    ### ユーザ入力データ
    ippan_id = models.IntegerField(primary_key=True)                           ### 行ID
    ippan_name = models.CharField(max_length=128, null=True)                   ### 町丁名、大字名

    ### ユーザ入力データ
    ippan_header_id = models.IntegerField(null=True)                           ### シートID ### 2022/10/04 追加

    ### ユーザ入力データ
    building_code = models.CharField(max_length=10, null=True)                 ### 建物区分コード
    underground_code = models.CharField(max_length=10, null=True)              ### 地上地下区分コード
    flood_sediment_code = models.CharField(max_length=10, null=True)           ### 浸水土砂区分コード ### FOR SUM PARAM

    ### ユーザ入力データ
    industry_code = models.CharField(max_length=10, null=True)                 ### 産業分類コード ### FOR SUM PARAM
    usage_code = models.CharField(max_length=10, null=True)                    ### 地下空間の利用形態コード
    comment = models.CharField(max_length=512, null=True)                      ### 備考
    
    ### ユーザ入力データ
    building_lv00 = models.FloatField(null=True)                               ### 被害建物棟数_床下
    building_lv01_49 = models.FloatField(null=True)                            ### 被害建物棟数_01から49cm
    building_lv50_99 = models.FloatField(null=True)                            ### 被害建物棟数_50から99cm
    building_lv100 = models.FloatField(null=True)                              ### 被害建物棟数_100cm以上
    building_half = models.FloatField(null=True)                               ### 被害建物棟数_半壊
    building_full = models.FloatField(null=True)                               ### 被害建物棟数_全壊
    
    ### ユーザ入力データ
    floor_area = models.FloatField(null=True)                                  ### 延床面積
    family = models.FloatField(null=True)                                      ### 被災世帯数
    office = models.FloatField(null=True)                                      ### 被災事業所数

    ### ユーザ入力データ
    farmer_fisher_lv00 = models.FloatField(null=True)                          ### 農漁家戸数_床下
    farmer_fisher_lv01_49 = models.FloatField(null=True)                       ### 農漁家戸数_01から49cm
    farmer_fisher_lv50_99 = models.FloatField(null=True)                       ### 農漁家戸数_50から99cm
    farmer_fisher_lv100 = models.FloatField(null=True)                         ### 農漁家戸数_100cm以上
    ### farmer_fisher_half = models.FloatField(null=True)
    farmer_fisher_full = models.FloatField(null=True)                          ### 農漁家戸数_全壊

    ### ユーザ入力データ
    employee_lv00 = models.FloatField(null=True)                               ### 被災従業者数_床下
    employee_lv01_49 = models.FloatField(null=True)                            ### 被災従業者数_01から49cm
    employee_lv50_99 = models.FloatField(null=True)                            ### 被災従業者数_50から99cm
    employee_lv100 = models.FloatField(null=True)                              ### 被災従業者数_100cm以上
    ### employee_half = models.FloatField(null=True)
    employee_full = models.FloatField(null=True)                               ### 被災従業者数_全壊
    
    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/07/11 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※2022/07/11 追加
    
    ### 導出データ ### TODO TO-DO TO_DO 削除する
    floor_area_lv00 = models.FloatField(null=True)                             ### 延床面積_床下
    floor_area_lv01_49 = models.FloatField(null=True)                          ### 延床面積_01から49cm
    floor_area_lv50_99 = models.FloatField(null=True)                          ### 延床面積_50から99cm
    floor_area_lv100 = models.FloatField(null=True)                            ### 延床面積_100cm以上
    floor_area_half = models.FloatField(null=True)                             ### 延床面積_半壊
    floor_area_full = models.FloatField(null=True)                             ### 延床面積_全壊
    
    ### 導出データ ### TODO TO-DO TO_DO 削除する
    family_lv00 = models.FloatField(null=True)                                 ### 被災世帯数_床下
    family_lv01_49 = models.FloatField(null=True)                              ### 被災世帯数_01から49cm
    family_lv50_99 = models.FloatField(null=True)                              ### 被災世帯数_50から99cm
    family_lv100 = models.FloatField(null=True)                                ### 被災世帯数_100cm以上
    family_half = models.FloatField(null=True)                                 ### 被災世帯数_半壊
    family_full = models.FloatField(null=True)                                 ### 被災世帯数_全壊
    
    ### 導出データ ### TODO TO-DO TO_DO 削除する
    office_lv00 = models.FloatField(null=True)                                 ### 被災事業所数_床下
    office_lv01_49 = models.FloatField(null=True)                              ### 被災事業所数_01から49cm
    office_lv50_99 = models.FloatField(null=True)                              ### 被災事業所数_50から99cm
    office_lv100 = models.FloatField(null=True)                                ### 被災事業所数_100cm以上
    office_half = models.FloatField(null=True)                                 ### 被災事業所数_半壊
    office_full = models.FloatField(null=True)                                 ### 被災事業所数_全壊

    class Meta:
        db_table = 'ippan'

    def __str__(self):
        return '<IPPAN: ' + str(self.ippan_id) + '>'


###############################################################################
### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
### トランザクション系テーブル（更新テーブル）
### 主に入力用（アップロードダウンロード）
### ※テーブルの1レコード=EXCELの1行に対応する。
### ※CHITAN_HEADER、CHITAN、CHITAN_SUMMARY、CHITAN_TRIGGERの更新単位=EXCELの1ファイル=1都道府県とする。
### ※複数シート不可とする。
###############################################################################
class CHITAN(models.Model):
    ### ユーザ入力データ
    chitan_id = models.IntegerField(primary_key=True)                          ### 行ID ※2022/08/05 追加
    chitan_name = models.CharField(max_length=128, null=True)                  ### 代表被災地区名 ※2022/08/05 追加

    ### ユーザ入力データ
    chitan_header_id = models.IntegerField(null=True)                          ### シートID ※2022/10/03 追加
    
    ### ユーザ入力データ
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード ※2022/08/05 追加
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※2022/08/05 追加
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※2022/08/05 追加

    ### ユーザ入力データ
    suikei_code = models.CharField(max_length=10, null=True)                   ### 水系コード ※2022/08/05 追加
    suikei_type_code = models.CharField(max_length=10, null=True)              ### 水系水系種別コード ※2022/10/25 追加
    kasen_code = models.CharField(max_length=10, null=True)                    ### 河川コード ※2022/08/05 追加
    kasen_type_code = models.CharField(max_length=10, null=True)               ### 河川種別コード ※2022/08/05 追加
    kasen_setubi_code = models.CharField(max_length=10, null=True)             ### 河川海岸砂防設備地すべり防止施設（工種）コード ※2022/10/26 追加
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※2022/08/05 追加

    ### ユーザ入力データ
    disaster_point = models.CharField(max_length=128, null=True)               ### 災害復旧箇所 ※2022/10/19 追加
    estimated_cost = models.FloatField(null=True)                              ### 災害復旧査定額（千円） ※2022/10/19 追加
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※2022/08/05 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/08/05 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※2022/08/05 追加

    class Meta:
        db_table = 'chitan'

    def __str__(self):
        return '<CHITAN: ' + str(self.chitan_id) + '>'


###############################################################################
### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
### トランザクション系テーブル（更新テーブル）
### 主に入力用（アップロードダウンロード）
### ※テーブルの1レコード=EXCELの1行に対応する。
### ※HOJO_HEADER、HOJO、HOJO_SUMMARY、HOJO_TRIGGERの更新単位=EXCELの1ファイル=1都道府県とする。
### ※複数シート不可とする。
###############################################################################
class HOJO(models.Model):
    ### ユーザ入力データ
    hojo_id = models.IntegerField(primary_key=True)                            ### 行ID ※2022/08/05 追加
    hojo_name = models.CharField(max_length=128, null=True)                    ### ※2022/08/05 追加

    ### ユーザ入力データ
    hojo_header_id = models.IntegerField(null=True)                            ### シートID ※2022/10/03 追加
    
    ### ユーザ入力データ
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード ※2022/08/05 追加
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※2022/08/05 追加
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※2022/08/05 追加

    ### ユーザ入力データ
    suikei_code = models.CharField(max_length=10, null=True)                   ### 水系コード ※2022/08/05 追加
    suikei_type_code = models.CharField(max_length=10, null=True)              ### 水系水系種別コード ※2022/10/25 追加
    kasen_code = models.CharField(max_length=10, null=True)                    ### 河川コード ※2022/08/05 追加
    kasen_type_code = models.CharField(max_length=10, null=True)               ### 河川種別コード ※2022/08/05 追加
    kasen_setubi_code = models.CharField(max_length=10, null=True)             ### 河川海岸砂防設備地すべり防止施設（工種）コード ※2022/10/26 追加
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※2022/08/05 追加

    ### ユーザ入力データ
    koji_code = models.CharField(max_length=10, null=True)                     ### 工事番号 ※2022/08/05 追加
    branch_code = models.CharField(max_length=10, null=True)                   ### 枝番 ※2022/08/05 追加
    koji_type_code = models.CharField(max_length=10, null=True)                ### 工事区分 ※2022/08/05 追加
    kosh_type_code = models.CharField(max_length=10, null=True)                ### 工種区分 ※2022/08/05 追加

    ### ユーザ入力データ
    determined_cost = models.FloatField(null=True)                             ### 決定額（千円） ※2022/08/05 追加
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※2022/08/05 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/08/05 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※2022/08/05 追加

    class Meta:
        db_table = 'hojo'

    def __str__(self):
        return '<HOJO: ' + str(self.hojo_id) + '>'

###############################################################################
### 7100: アップロードデータ_公益事業等調査票_一覧表部分
### トランザクション系テーブル（更新テーブル）
### 主に入力用（アップロードダウンロード）
### ※テーブルの1レコード=EXCELの1行に対応する。
### ※KOEKI_HEADER、KOEKI、KOEKI_SUMMARY、KOEKI_TRIGGERの更新単位=EXCELの1ファイル=1都道府県とする。
### ※複数シート不可とする。
###############################################################################
class KOEKI(models.Model):
    ### ユーザ入力データ
    koeki_id = models.IntegerField(primary_key=True)                           ### 行ID ※2022/08/05 追加
    koeki_name = models.CharField(max_length=128, null=True)                   ### 町丁名、大字名 ※2022/08/05 追加

    ### ユーザ入力データ
    koeki_header_id = models.IntegerField(null=True)                           ### シートID ※2022/10/03 追加
    
    ### ユーザ入力データ
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード ※2022/08/05 追加
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※2022/08/05 追加
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※2022/08/05 追加

    ### ユーザ入力データ
    suikei_code = models.CharField(max_length=10, null=True)                   ### 水系コード ※2022/08/05 追加
    suikei_type_code = models.CharField(max_length=10, null=True)              ### 水系水系種別コード ※2022/10/25 追加
    kasen_code = models.CharField(max_length=10, null=True)                    ### 河川コード ※2022/08/05 追加
    kasen_type_code = models.CharField(max_length=10, null=True)               ### 河川種別コード ※2022/08/05 追加
    kasen_setubi_code = models.CharField(max_length=10, null=True)             ### 河川海岸砂防設備地すべり防止施設（工種）コード ※2022/10/26 追加
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※2022/08/05 追加

    ### ユーザ入力データ
    cause_1_code = models.CharField(max_length=10, null=True)                  ### 水害原因_1_コード ※2022/08/05 追加
    cause_2_code = models.CharField(max_length=10, null=True)                  ### 水害原因_2_コード ※2022/08/05 追加
    cause_3_code = models.CharField(max_length=10, null=True)                  ### 水害原因_3_コード ※2022/08/05 追加
    business_code = models.CharField(max_length=10, null=True)                 ### 事業コード ※2022/08/05 追加
    organization_name = models.CharField(max_length=128, null=True)            ### 調査対象機関名称 ※2022/08/05 追加
    
    ### ユーザ入力データ
    physical_damage = models.FloatField(null=True)                             ### 被害金額_物的被害額（千円）
    sales_damage = models.FloatField(null=True)                                ### 被害金額_営業停止に伴う売上減少額
    alt_damage = models.FloatField(null=True)                                  ### 被害金額_代替活動費（外注費）
    other_damage = models.FloatField(null=True)                                ### 被害金額_その他
    sales_alt_other_damage = models.FloatField(null=True)                      ### 被害金額_営業停止損失額合計（千円）
    
    ### ユーザ入力データ
    suspended_days = models.IntegerField(null=True)                            ### 営業停止期間等_停止期間_日
    suspended_hours = models.IntegerField(null=True)                           ### 営業停止期間等_停止期間_時間
    suspended_amounts = models.IntegerField(null=True)                         ### 営業停止期間等_停止数量
    
    ### ユーザ入力データ
    department_name = models.CharField(max_length=128, null=True)              ### 照会先_調査担当課名
    employee_name = models.CharField(max_length=128, null=True)                ### 照会先_調査担当者名
    telephone = models.CharField(max_length=128, null=True)                    ### 照会先_電話番号
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※2022/08/05 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/08/05 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※2022/08/05 追加

    class Meta:
        db_table = 'koeki'

    def __str__(self):
        return '<KOEKI: ' + str(self.koeki_id) + '>'


###############################################################################
### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
###############################################################################
class IPPAN_SUMMARY(models.Model):
    ### ippan_summary_id = models.IntegerField(primary_key=True)               ### postgresの自動インクリメントを使用する。 ※一般資産調査票の複数行の集計計算を１個のSQLで行うため ※MAX(*_ID+1)の場合、FORループが必要となる。

    ### ユーザ入力データ
    ippan_id = models.IntegerField(null=True)                                  ### 行ID
    ippan_name = models.CharField(max_length=128, null=True)                   ### 町丁名、大字名

    ### ユーザ入力データ
    ippan_header_id = models.IntegerField(null=True)                           ### シートID

    ### ユーザ入力データ
    building_code = models.CharField(max_length=10, null=True)                 ### 建物区分コード
    underground_code = models.CharField(max_length=10, null=True)              ### 地上地下区分コード
    flood_sediment_code = models.CharField(max_length=10, null=True)           ### 浸水土砂区分コード ### FOR SUM PARAM

    ### ユーザ入力データ
    industry_code = models.CharField(max_length=10, null=True)                 ### 産業分類コード ### FOR SUM PARAM
    usage_code = models.CharField(max_length=10, null=True)                    ### 地下空間の利用形態コード
    comment = models.CharField(max_length=512, null=True)                      ### 備考

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/07/11 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時

    ### 導出データ
    house_summary_lv00 = models.FloatField(null=True)                          ### 家屋被害額_床下（延床面積×家屋評価額×浸水または土砂ごとの勾配差による被害率）
    house_summary_lv01_49 = models.FloatField(null=True)                       ### 家屋被害額_01から49cm（延床面積×家屋評価額×浸水または土砂ごとの勾配差による被害率）
    house_summary_lv50_99 = models.FloatField(null=True)                       ### 家屋被害額_50から99cm（延床面積×家屋評価額×浸水または土砂ごとの勾配差による被害率）
    house_summary_lv100 = models.FloatField(null=True)                         ### 家屋被害額_100cm以上（延床面積×家屋評価額×浸水または土砂ごとの勾配差による被害率）
    house_summary_half = models.FloatField(null=True)                          ### 家屋被害額_半壊（延床面積×家屋評価額×浸水または土砂ごとの勾配差による被害率）
    house_summary_full = models.FloatField(null=True)                          ### 家屋被害額_全壊（延床面積×家屋評価額×浸水または土砂ごとの勾配差による被害率）

    ### 導出データ
    household_summary_lv00 = models.FloatField(null=True)                      ### 家庭用品自動車以外被害額_床下（被災世帯数×家庭用品所有額×浸水または土砂による被害率）
    household_summary_lv01_49 = models.FloatField(null=True)                   ### 家庭用品自動車以外被害額_01から49cm（被災世帯数×家庭用品所有額×浸水または土砂による被害率）
    household_summary_lv50_99 = models.FloatField(null=True)                   ### 家庭用品自動車以外被害額_50から99cm（被災世帯数×家庭用品所有額×浸水または土砂による被害率）
    household_summary_lv100 = models.FloatField(null=True)                     ### 家庭用品自動車以外被害額_100cm以上（被災世帯数×家庭用品所有額×浸水または土砂による被害率）
    household_summary_half = models.FloatField(null=True)                      ### 家庭用品自動車以外被害額_半壊（被災世帯数×家庭用品所有額×浸水または土砂による被害率）
    household_summary_full = models.FloatField(null=True)                      ### 家庭用品自動車以外被害額_全壊（被災世帯数×家庭用品所有額×浸水または土砂による被害率）

    ### 導出データ
    car_summary_lv00 = models.FloatField(null=True)                            ### 家庭用品自動車被害額_床下（被災世帯数×家庭用品自動車所有額×浸水または土砂による被害率）
    car_summary_lv01_49 = models.FloatField(null=True)                         ### 家庭用品自動車被害額_01から49cm（被災世帯数×家庭用品自動車所有額×浸水または土砂による被害率）
    car_summary_lv50_99 = models.FloatField(null=True)                         ### 家庭用品自動車被害額_50から99cm（被災世帯数×家庭用品自動車所有額×浸水または土砂による被害率）
    car_summary_lv100 = models.FloatField(null=True)                           ### 家庭用品自動車被害額_100cm以上（被災世帯数×家庭用品自動車所有額×浸水または土砂による被害率）
    car_summary_half = models.FloatField(null=True)                            ### 家庭用品自動車被害額_半壊（被災世帯数×家庭用品自動車所有額×浸水または土砂による被害率）
    car_summary_full = models.FloatField(null=True)                            ### 家庭用品自動車被害額_全壊（被災世帯数×家庭用品自動車所有額×浸水または土砂による被害率）

    ### 導出データ
    house_alt_summary_lv00 = models.FloatField(null=True)                      ### 家庭応急対策費_代替活動費_床下（被災世帯数×代替活動費）
    house_alt_summary_lv01_49 = models.FloatField(null=True)                   ### 家庭応急対策費_代替活動費_01から49cm（被災世帯数×代替活動費）
    house_alt_summary_lv50_99 = models.FloatField(null=True)                   ### 家庭応急対策費_代替活動費_50から99cm（被災世帯数×代替活動費）
    house_alt_summary_lv100 = models.FloatField(null=True)                     ### 家庭応急対策費_代替活動費_100cm以上（被災世帯数×代替活動費）
    house_alt_summary_half = models.FloatField(null=True)                      ### 家庭応急対策費_代替活動費_半壊（被災世帯数×代替活動費）
    house_alt_summary_full = models.FloatField(null=True)                      ### 家庭応急対策費_代替活動費_全壊（被災世帯数×代替活動費）

    ### 導出データ
    house_clean_summary_lv00 = models.FloatField(null=True)                    ### 家庭応急対策費_清掃費_床下（被災世帯数×清掃日数×清掃労働単価）
    house_clean_summary_lv01_49 = models.FloatField(null=True)                 ### 家庭応急対策費_清掃費_01から49cm（被災世帯数×清掃日数×清掃労働単価）
    house_clean_summary_lv50_99 = models.FloatField(null=True)                 ### 家庭応急対策費_清掃費_50から99cm（被災世帯数×清掃日数×清掃労働単価）
    house_clean_summary_lv100 = models.FloatField(null=True)                   ### 家庭応急対策費_清掃費_100cm以上（被災世帯数×清掃日数×清掃労働単価）
    house_clean_summary_half = models.FloatField(null=True)                    ### 家庭応急対策費_清掃費_半壊（被災世帯数×清掃日数×清掃労働単価）
    house_clean_summary_full = models.FloatField(null=True)                    ### 家庭応急対策費_清掃費_全壊（被災世帯数×清掃日数×清掃労働単価）

    ### 導出データ
    office_dep_summary_lv00 = models.FloatField(null=True)                     ### 事業所被害額_償却資産被害額_床下（従業者数×産業分類ごとの償却資産×浸水または土砂による被害率）
    office_dep_summary_lv01_49 = models.FloatField(null=True)                  ### 事業所被害額_償却資産被害額_01から49cm（従業者数×産業分類ごとの償却資産×浸水または土砂による被害率）
    office_dep_summary_lv50_99 = models.FloatField(null=True)                  ### 事業所被害額_償却資産被害額_50から99cm（従業者数×産業分類ごとの償却資産×浸水または土砂による被害率）
    office_dep_summary_lv100 = models.FloatField(null=True)                    ### 事業所被害額_償却資産被害額_100cm以上（従業者数×産業分類ごとの償却資産×浸水または土砂による被害率）
    ### office_dep_summary_half = models.FloatField(null=True)                 ### 事業所被害額_償却資産被害額_半壊（従業者数×産業分類ごとの償却資産×浸水または土砂による被害率）
    office_dep_summary_full = models.FloatField(null=True)                     ### 事業所被害額_償却資産被害額_全壊（従業者数×産業分類ごとの償却資産×浸水または土砂による被害率）

    ### 導出データ
    office_inv_summary_lv00 = models.FloatField(null=True)                     ### 事業所被害額_在庫資産被害額_床下（従業者数×産業分類ごとの在庫資産×浸水または土砂による被害率）
    office_inv_summary_lv01_49 = models.FloatField(null=True)                  ### 事業所被害額_在庫資産被害額_01から49cm（従業者数×産業分類ごとの在庫資産×浸水または土砂による被害率）
    office_inv_summary_lv50_99 = models.FloatField(null=True)                  ### 事業所被害額_在庫資産被害額_50から99cm（従業者数×産業分類ごとの在庫資産×浸水または土砂による被害率）
    office_inv_summary_lv100 = models.FloatField(null=True)                    ### 事業所被害額_在庫資産被害額_100cm以上（従業者数×産業分類ごとの在庫資産×浸水または土砂による被害率）
    ### office_inv_summary_half = models.FloatField(null=True)                 ### 事業所被害額_在庫資産被害額_半壊（従業者数×産業分類ごとの在庫資産×浸水または土砂による被害率）
    office_inv_summary_full = models.FloatField(null=True)                     ### 事業所被害額_在庫資産被害額_全壊（従業者数×産業分類ごとの在庫資産×浸水または土砂による被害率）

    ### 導出データ
    office_sus_summary_lv00 = models.FloatField(null=True)                     ### 事業所被害額_営業停止に伴う被害額_床下（従業者数×営業停止日数×付加価値額）
    office_sus_summary_lv01_49 = models.FloatField(null=True)                  ### 事業所被害額_営業停止に伴う被害額_01から49cm（従業者数×営業停止日数×付加価値額）
    office_sus_summary_lv50_99 = models.FloatField(null=True)                  ### 事業所被害額_営業停止に伴う被害額_50から99cm（従業者数×営業停止日数×付加価値額）
    office_sus_summary_lv100 = models.FloatField(null=True)                    ### 事業所被害額_営業停止に伴う被害額_100cm以上（従業者数×営業停止日数×付加価値額）
    ### office_sus_summary_half = models.FloatField(null=True)                 ### 事業所被害額_営業停止に伴う被害額_半壊（従業者数×営業停止日数×付加価値額）
    office_sus_summary_full = models.FloatField(null=True)                     ### 事業所被害額_営業停止に伴う被害額_全壊（従業者数×営業停止日数×付加価値額）

    ### 導出データ
    office_stg_summary_lv00 = models.FloatField(null=True)                     ### 事業所被害額_営業停滞に伴う被害額_床下（従業者数×（営業停滞日数/2）×付加価値額）
    office_stg_summary_lv01_49 = models.FloatField(null=True)                  ### 事業所被害額_営業停滞に伴う被害額_01から49cm（従業者数×（営業停滞日数/2）×付加価値額）
    office_stg_summary_lv50_99 = models.FloatField(null=True)                  ### 事業所被害額_営業停滞に伴う被害額_50から99cm（従業者数×（営業停滞日数/2）×付加価値額）
    office_stg_summary_lv100 = models.FloatField(null=True)                    ### 事業所被害額_営業停滞に伴う被害額_100cm以上（従業者数×（営業停滞日数/2）×付加価値額）
    ### office_stg_summary_half = models.FloatField(null=True)                 ### 事業所被害額_営業停滞に伴う被害額_半壊（従業者数×（営業停滞日数/2）×付加価値額）
    office_stg_summary_full = models.FloatField(null=True)                     ### 事業所被害額_営業停滞に伴う被害額_全壊（従業者数×（営業停滞日数/2）×付加価値額）

    ### 導出データ
    farmer_fisher_dep_summary_lv00 = models.FloatField(null=True)              ### 農漁家被害額_償却資産被害額_床下（農漁家戸数×農漁家の償却資産×浸水または土砂による被害率）
    farmer_fisher_dep_summary_lv01_49 = models.FloatField(null=True)           ### 農漁家被害額_償却資産被害額_01から49cm（農漁家戸数×農漁家の償却資産×浸水または土砂による被害率）
    farmer_fisher_dep_summary_lv50_99 = models.FloatField(null=True)           ### 農漁家被害額_償却資産被害額_50から99cm（農漁家戸数×農漁家の償却資産×浸水または土砂による被害率）
    farmer_fisher_dep_summary_lv100 = models.FloatField(null=True)             ### 農漁家被害額_償却資産被害額_100cm以上（農漁家戸数×農漁家の償却資産×浸水または土砂による被害率）
    ### farmer_fisher_dep_summary_half = models.FloatField(null=True)          ### 農漁家被害額_償却資産被害額_半壊（農漁家戸数×農漁家の償却資産×浸水または土砂による被害率）
    farmer_fisher_dep_summary_full = models.FloatField(null=True)              ### 農漁家被害額_償却資産被害額_全壊（農漁家戸数×農漁家の償却資産×浸水または土砂による被害率）

    ### 導出データ
    farmer_fisher_inv_summary_lv00 = models.FloatField(null=True)              ### 農漁家被害額_在庫資産被害額_床下（農漁家戸数×農漁家の在庫資産×浸水または土砂による被害率）
    farmer_fisher_inv_summary_lv01_49 = models.FloatField(null=True)           ### 農漁家被害額_在庫資産被害額_01から49cm（農漁家戸数×農漁家の在庫資産×浸水または土砂による被害率）
    farmer_fisher_inv_summary_lv50_99 = models.FloatField(null=True)           ### 農漁家被害額_在庫資産被害額_50から99cm（農漁家戸数×農漁家の在庫資産×浸水または土砂による被害率）
    farmer_fisher_inv_summary_lv100 = models.FloatField(null=True)             ### 農漁家被害額_在庫資産被害額_100cm以上（農漁家戸数×農漁家の在庫資産×浸水または土砂による被害率）
    ### farmer_fisher_inv_summary_half = models.FloatField(null=True)          ### 農漁家被害額_在庫資産被害額_半壊（農漁家戸数×農漁家の在庫資産×浸水または土砂による被害率）
    farmer_fisher_inv_summary_full = models.FloatField(null=True)              ### 農漁家被害額_在庫資産被害額_全壊（農漁家戸数×農漁家の在庫資産×浸水または土砂による被害率）

    ### 導出データ
    office_alt_summary_lv00 = models.FloatField(null=True)                     ### 事業所応急対策費_代替活動費_床下（事業所数×代替活動費）
    office_alt_summary_lv01_49 = models.FloatField(null=True)                  ### 事業所応急対策費_代替活動費_01から49cm（事業所数×代替活動費）
    office_alt_summary_lv50_99 = models.FloatField(null=True)                  ### 事業所応急対策費_代替活動費_50から99cm（事業所数×代替活動費）
    office_alt_summary_lv100 = models.FloatField(null=True)                    ### 事業所応急対策費_代替活動費_100cm以上（事業所数×代替活動費）
    office_alt_summary_half = models.FloatField(null=True)                     ### 事業所応急対策費_代替活動費_半壊（事業所数×代替活動費）
    office_alt_summary_full = models.FloatField(null=True)                     ### 事業所応急対策費_代替活動費_全壊（事業所数×代替活動費）

    class Meta:
        db_table = 'ippan_summary'

    def __str__(self):
        return '<IPPAN_SUMMARY: ' + str(self.ippan_summary_id) + '>'


###############################################################################
### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
###############################################################################
class CHITAN_SUMMARY(models.Model):
    ### chitan_summary_id = models.IntegerField(primary_key=True)              ### postgresの自動インクリメントを使用する。 ※公共土木施設調査票_地方単独事業の複数行の集計計算を１個のSQLで行うため ※MAX(*_ID+1)の場合、FORループが必要となる。

    ### ユーザ入力データ
    chitan_id = models.IntegerField(null=True)                                 ### 行ID

    ### ユーザ入力データ
    chitan_header_id = models.IntegerField(null=True)                          ### シートID

    ### ユーザ入力データ
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード ※2022/08/05 追加
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※2022/08/05 追加
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※2022/08/05 追加

    ### ユーザ入力データ
    suikei_code = models.CharField(max_length=10, null=True)                   ### 水系コード ※2022/08/05 追加
    suikei_type_code = models.CharField(max_length=10, null=True)              ### 水系水系種別コード ※2022/10/25 追加
    kasen_code = models.CharField(max_length=10, null=True)                    ### 河川コード ※2022/08/05 追加
    kasen_type_code = models.CharField(max_length=10, null=True)               ### 河川種別コード ※2022/08/05 追加
    kasen_setubi_code = models.CharField(max_length=10, null=True)             ### 河川海岸砂防設備地すべり防止施設（工種）コード ※2022/10/26 追加
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※2022/08/05 追加

    ### ユーザ入力データ
    disaster_point = models.CharField(max_length=128, null=True)               ### 災害復旧箇所 ※2022/10/19 追加
    estimated_cost = models.FloatField(null=True)                              ### 災害復旧査定額（千円） ※2022/10/19 追加
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※2022/08/05 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/08/05 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※2022/08/05 追加

    class Meta:
        db_table = 'chitan_summary'
        
    def __str__(self):
        return '<CHITAN_SUMMARY: ' + str(self.chitan_summary_id) + '>'


###############################################################################
### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
###############################################################################
class HOJO_SUMMARY(models.Model):
    ### hojo_summary_id = models.IntegerField(primary_key=True)                ### postgresの自動インクリメントを使用する。 ※公共土木施設調査票_補助事業の複数行の集計計算を１個のSQLで行うため ※MAX(*_ID+1)の場合、FORループが必要となる。

    ### ユーザ入力データ
    hojo_id = models.IntegerField(null=True)                                   ### 行ID

    ### ユーザ入力データ
    hojo_header_id = models.IntegerField(null=True)                            ### シートID

    ### ユーザ入力データ
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード ※2022/08/05 追加
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※2022/08/05 追加
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※2022/08/05 追加

    ### ユーザ入力データ
    suikei_code = models.CharField(max_length=10, null=True)                   ### 水系コード ※2022/08/05 追加
    suikei_type_code = models.CharField(max_length=10, null=True)              ### 水系水系種別コード ※2022/10/25 追加
    kasen_code = models.CharField(max_length=10, null=True)                    ### 河川コード ※2022/08/05 追加
    kasen_type_code = models.CharField(max_length=10, null=True)               ### 河川種別コード ※2022/08/05 追加
    kasen_setubi_code = models.CharField(max_length=10, null=True)             ### 河川海岸砂防設備地すべり防止施設（工種）コード ※2022/10/26 追加
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※2022/08/05 追加

    ### ユーザ入力データ
    koji_code = models.CharField(max_length=10, null=True)                     ### 工事番号 ※2022/08/05 追加
    branch_code = models.CharField(max_length=10, null=True)                   ### 枝番 ※2022/08/05 追加
    koji_type_code = models.CharField(max_length=10, null=True)                ### 工事区分 ※2022/08/05 追加
    kosh_type_code = models.CharField(max_length=10, null=True)                ### 工種区分 ※2022/08/05 追加

    ### ユーザ入力データ
    determined_cost = models.FloatField(null=True)                             ### 決定額（千円） ※2022/08/05 追加
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※2022/08/05 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/08/05 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※2022/08/05 追加

    class Meta:
        db_table = 'hojo_summary'
        
    def __str__(self):
        return '<HOJO_SUMMARY: ' + str(self.hojo_summary_id) + '>'


###############################################################################
### 8030: 集計データ_公益事業等調査票_一覧表部分
###############################################################################
class KOEKI_SUMMARY(models.Model):
    ### koeki_summary_id = models.IntegerField(primary_key=True)               ### postgresの自動インクリメントを使用する。 ※公益事業等調査票の複数行の集計計算を１個のSQLで行うため ※MAX(*_ID+1)の場合、FORループが必要となる。

    ### ユーザ入力データ
    koeki_id = models.IntegerField(null=True)                                  ### 行ID

    ### ユーザ入力データ
    koeki_header_id = models.IntegerField(null=True)                           ### シートID

    ### ユーザ入力データ
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード ※2022/08/05 追加
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※2022/08/05 追加
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※2022/08/05 追加

    ### ユーザ入力データ
    suikei_code = models.CharField(max_length=10, null=True)                   ### 水系コード ※2022/08/05 追加
    suikei_type_code = models.CharField(max_length=10, null=True)              ### 水系水系種別コード ※2022/10/25 追加
    kasen_code = models.CharField(max_length=10, null=True)                    ### 河川コード ※2022/08/05 追加
    kasen_type_code = models.CharField(max_length=10, null=True)               ### 河川種別コード ※2022/08/05 追加
    kasen_setubi_code = models.CharField(max_length=10, null=True)             ### 河川海岸砂防設備地すべり防止施設（工種）コード ※2022/10/26 追加
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※2022/08/05 追加

    ### ユーザ入力データ
    cause_1_code = models.CharField(max_length=10, null=True)                  ### 水害原因_1_コード ※2022/08/05 追加
    cause_2_code = models.CharField(max_length=10, null=True)                  ### 水害原因_2_コード ※2022/08/05 追加
    cause_3_code = models.CharField(max_length=10, null=True)                  ### 水害原因_3_コード ※2022/08/05 追加
    business_code = models.CharField(max_length=10, null=True)                 ### 事業コード ※2022/08/05 追加
    organization_name = models.CharField(max_length=128, null=True)            ### 調査対象機関名称 ※2022/08/05 追加
    
    ### ユーザ入力データ
    physical_damage = models.FloatField(null=True)                             ### 被害金額_物的被害額（千円）
    sales_damage = models.FloatField(null=True)                                ### 被害金額_営業停止に伴う売上減少額
    alt_damage = models.FloatField(null=True)                                  ### 被害金額_代替活動費（外注費）
    other_damage = models.FloatField(null=True)                                ### 被害金額_その他
    sales_alt_other_damage = models.FloatField(null=True)                      ### 被害金額_営業停止損失額合計（千円）
    
    ### ユーザ入力データ
    suspended_days = models.IntegerField(null=True)                            ### 営業停止期間等_停止期間_日
    suspended_hours = models.IntegerField(null=True)                           ### 営業停止期間等_停止期間_時間
    suspended_amounts = models.IntegerField(null=True)                         ### 営業停止期間等_停止数量
    
    ### ユーザ入力データ
    department_name = models.CharField(max_length=128, null=True)              ### 照会先_調査担当課名
    employee_name = models.CharField(max_length=128, null=True)                ### 照会先_調査担当者名
    telephone = models.CharField(max_length=128, null=True)                    ### 照会先_電話番号
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※2022/08/05 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※2022/08/05 追加
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※2022/08/05 追加

    class Meta:
        db_table = 'koeki_summary'
        
    def __str__(self):
        return '<KOEKI_SUMMARY: ' + str(self.koeki_summary_id) + '>'

###############################################################################
### 0000: ビューデータ_一般資産調査票_調査員用_一覧表部分
### ※シンプルにするため、ビューテーブルでは、名前を取得するための外部結合を行わない。
### ※名前が必要な場合は、別途外部結合することとする。
### ※このアプリでは、AAAテーブルとAAA_HEADERテーブルを結合するために、ビューテーブルを使用する。
### ※このアプリでは、按分データを自動計算するために、ビューテーブルを使用する。
###############################################################################
class IPPAN_VIEW(models.Model):
    ### ユーザ入力データ
    ippan_id = models.IntegerField(primary_key=True)                           ### 行ID ※IPPAN_LINEテーブル
    ippan_name = models.CharField(max_length=128, null=True)                   ### 町丁名、大字名 ※IPPAN_LINEテーブル

    ### ユーザ入力データ
    ippan_header_id = models.IntegerField(null=True)                           ### シートID ※IPPAN_LINEテーブル

    ### ユーザ入力データ
    building_code = models.CharField(max_length=10, null=True)                 ### 建物区分コード ※IPPAN_LINEテーブル
    underground_code = models.CharField(max_length=10, null=True)              ### 地上地下区分コード ※IPPAN_LINEテーブル
    flood_sediment_code = models.CharField(max_length=10, null=True)           ### 浸水土砂区分コード ※IPPAN_LINEテーブル

    ### ユーザ入力データ
    industry_code = models.CharField(max_length=10, null=True)                 ### 産業分類コード ※IPPAN_LINEテーブル
    usage_code = models.CharField(max_length=10, null=True)                    ### 地下空間の利用形態コード ※IPPAN_LINEテーブル
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※IPPAN_LINEテーブル

    ### ユーザ入力データ
    building_lv00 = models.FloatField(null=True)                               ### 被害建物棟数_床下 ※IPPAN_LINEテーブル
    building_lv01_49 = models.FloatField(null=True)                            ### 被害建物棟数_01から49cm ※IPPAN_LINEテーブル
    building_lv50_99 = models.FloatField(null=True)                            ### 被害建物棟数_50から99cm ※IPPAN_LINEテーブル
    building_lv100 = models.FloatField(null=True)                              ### 被害建物棟数_100cm以上 ※IPPAN_LINEテーブル
    building_half = models.FloatField(null=True)                               ### 被害建物棟数_半壊 ※IPPAN_LINEテーブル
    building_full = models.FloatField(null=True)                               ### 被害建物棟数_全壊 ※IPPAN_LINEテーブル

    ### ユーザ入力データ
    floor_area = models.FloatField(null=True)                                  ### 延床面積 ※IPPAN_LINEテーブル
    family = models.IntegerField(null=True)                                    ### 被災世帯数 ※IPPAN_LINEテーブル
    office = models.IntegerField(null=True)                                    ### 被災事業所数 ※IPPAN_LINEテーブル

    ### ユーザ入力データ
    farmer_fisher_lv00 = models.FloatField(null=True)                          ### 農漁家戸数_床下 ※IPPAN_LINEテーブル
    farmer_fisher_lv01_49 = models.FloatField(null=True)                       ### 農漁家戸数_01から49cm ※IPPAN_LINEテーブル
    farmer_fisher_lv50_99 = models.FloatField(null=True)                       ### 農漁家戸数_50から99cm ※IPPAN_LINEテーブル
    farmer_fisher_lv100 = models.FloatField(null=True)                         ### 農漁家戸数_100cm以上 ※IPPAN_LINEテーブル
    ### farmer_fisher_half = models.FloatField(null=True)
    farmer_fisher_full = models.FloatField(null=True)                          ### 農漁家戸数_全壊 ※IPPAN_LINEテーブル

    ### ユーザ入力データ
    employee_lv00 = models.FloatField(null=True)                               ### 被災従業者数_床下 ※IPPAN_LINEテーブル
    employee_lv01_49 = models.FloatField(null=True)                            ### 被災従業者数_01から49cm ※IPPAN_LINEテーブル
    employee_lv50_99 = models.FloatField(null=True)                            ### 被災従業者数_50から99cm ※IPPAN_LINEテーブル
    employee_lv100 = models.FloatField(null=True)                              ### 被災従業者数_100cm以上 ※IPPAN_LINEテーブル
    ### employee_half = models.FloatField(null=True)
    employee_full = models.FloatField(null=True)                               ### 被災従業者数_全壊 ※IPPAN_LINEテーブル

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※IPPAN_LINEテーブル
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※IPPAN_LINEテーブル

    ### 外部結合データ
    ippan_header_name = models.CharField(max_length=128, null=True)            ### シート名 ※IPPAN_HEADERテーブル

    ### 外部結合データ
    ken_code = models.CharField(max_length=10)                                 ### 都道府県コード ※IPPAN_HEADERテーブル
    city_code = models.CharField(max_length=10)                                ### 市区町村コード ※IPPAN_HEADERテーブル
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※IPPAN_HEADERテーブル
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※IPPAN_HEADERテーブル
    cause_1_code = models.CharField(max_length=10)                             ### 水害原因コード1 ※IPPAN_HEADERテーブル
    cause_2_code = models.CharField(max_length=10)                             ### 水害原因コード2 ※IPPAN_HEADERテーブル
    cause_3_code = models.CharField(max_length=10)                             ### 水害原因コード3 ※IPPAN_HEADERテーブル
    area_id = models.IntegerField()                                            ### 水害区域ID ※IPPAN_HEADERテーブル

    ### 外部結合データ
    suikei_code = models.CharField(max_length=10)                              ### 水系コード ※IPPAN_HEADERテーブル
    suikei_type_code = models.CharField(max_length=10)                         ### 水系種別コード ※SUIKEIテーブル
    kasen_code = models.CharField(max_length=10)                               ### 河川コード ※IPPAN_HEADERテーブル
    kasen_type_code = models.CharField(max_length=10)                          ### 河川種別コード ※KASENテーブル
    gradient_code = models.CharField(max_length=10)                            ### 地盤勾配区分コード ※IPPAN_HEADERテーブル

    ### 外部結合データ
    residential_area = models.FloatField(null=True)                            ### 宅地面積（単位m2） ※IPPAN_HEADERテーブル
    agricultural_area = models.FloatField(null=True)                           ### 農地面積（単位m2） ※IPPAN_HEADERテーブル
    underground_area = models.FloatField(null=True)                            ### 地下面積（単位m2） ※IPPAN_HEADERテーブル
    kasen_kaigan_code = models.CharField(max_length=10, null=True)             ### 河川海岸（工種）コード ※IPPAN_HEADERテーブル
    crop_damage = models.FloatField(null=True)                                 ### 農作物被害額（単位千円） ※IPPAN_HEADERテーブル
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※IPPAN_HEADERテーブル

    ### このビューで導出したデータ
    floor_area_lv00 = models.FloatField(null=True)                             ### 延床面積_床下 ※IPPAN_LINEテーブル
    floor_area_lv01_49 = models.FloatField(null=True)                          ### 延床面積_01から49cm ※IPPAN_LINEテーブル
    floor_area_lv50_99 = models.FloatField(null=True)                          ### 延床面積_50から99cm ※IPPAN_LINEテーブル
    floor_area_lv100 = models.FloatField(null=True)                            ### 延床面積_100cm以上 ※IPPAN_LINEテーブル
    floor_area_half = models.FloatField(null=True)                             ### 延床面積_半壊 ※IPPAN_LINEテーブル
    floor_area_full = models.FloatField(null=True)                             ### 延床面積_全壊 ※IPPAN_LINEテーブル

    ### このビューで導出したデータ
    family_lv00 = models.FloatField(null=True)                                 ### 被災世帯数_床下 ※IPPAN_LINEテーブル
    family_lv01_49 = models.FloatField(null=True)                              ### 被災世帯数_01から49cm ※IPPAN_LINEテーブル
    family_lv50_99 = models.FloatField(null=True)                              ### 被災世帯数_50から99cm ※IPPAN_LINEテーブル
    family_lv100 = models.FloatField(null=True)                                ### 被災世帯数_100cm以上 ※IPPAN_LINEテーブル
    family_half = models.FloatField(null=True)                                 ### 被災世帯数_半壊 ※IPPAN_LINEテーブル
    family_full = models.FloatField(null=True)                                 ### 被災世帯数_全壊 ※IPPAN_LINEテーブル

    ### このビューで導出したデータ
    office_lv00 = models.FloatField(null=True)                                 ### 被災事業所数_床下 ※IPPAN_LINEテーブル
    office_lv01_49 = models.FloatField(null=True)                              ### 被災事業所数_01から49cm ※IPPAN_LINEテーブル
    office_lv50_99 = models.FloatField(null=True)                              ### 被災事業所数_50から99cm ※IPPAN_LINEテーブル
    office_lv100 = models.FloatField(null=True)                                ### 被災事業所数_100cm以上 ※IPPAN_LINEテーブル
    office_half = models.FloatField(null=True)                                 ### 被災事業所数_半壊 ※IPPAN_LINEテーブル
    office_full = models.FloatField(null=True)                                 ### 被災事業所数_全壊 ※IPPAN_LINEテーブル

    ### このビューで導出したデータ
    building_total = models.FloatField(null=True)                              ### 被害建物棟数_合計 ※IPPAN_LINEテーブル
    floor_area_total = models.FloatField(null=True)                            ### 延床面積_合計 ※IPPAN_LINEテーブル
    family_total = models.FloatField(null=True)                                ### 被災世帯数_合計 ※IPPAN_LINEテーブル
    office_total = models.FloatField(null=True)                                ### 被災事業所数_合計 ※IPPAN_LINEテーブル
    farmer_fisher_total = models.FloatField(null=True)                         ### 農漁家戸数_合計 ※IPPAN_LINEテーブル
    employee_total = models.FloatField(null=True)                              ### 被災従業者数_合計 ※IPPAN_LINEテーブル

    class Meta:
        db_table = 'ippan_view'
        managed = False                                                        ### マイグレーションの対象外とする。

    def __str__(self):
        return '<IPPAN_VIEW: ' + str(self.ippan_id) + '>'

###############################################################################
### 0000: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
### ※シンプルにするため、ビューテーブルでは、名前を取得するための外部結合を行わない。
### ※名前が必要な場合は、別途外部結合することとする。
### ※このアプリでは、AAAテーブルとAAA_HEADERテーブルを結合するために、ビューテーブルを使用する。
###############################################################################
class CHITAN_VIEW(models.Model):
    ### ユーザ入力データ
    chitan_id = models.IntegerField(primary_key=True)                          ### 行ID ※CHITAN_LINEテーブル
    chitan_name = models.CharField(max_length=128, null=True)                  ### 代表被災地区名 ※2022/08/05 追加

    ### ユーザ入力データ
    chitan_header_id = models.IntegerField(null=True)                          ### シートID ※CHITAN_LINEテーブル

    ### ユーザ入力データ
    city_code = models.CharField(max_length=10)                                ### 市区町村コード ※CHITAN_LINEテーブル
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※CHITAN_LINEテーブル
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※CHITAN_LINEテーブル

    ### ユーザ入力データ
    suikei_code = models.CharField(max_length=10, null=True)                   ### 水系コード ※CHITAN_LINEテーブル
    suikei_type_code = models.CharField(max_length=10, null=True)              ### 水系水系種別コード ※2022/10/25 追加
    kasen_code = models.CharField(max_length=10, null=True)                    ### 河川コード ※CHITAN_LINEテーブル
    kasen_type_code = models.CharField(max_length=10, null=True)               ### 河川種別コード ※2022/08/05 追加
    kasen_setubi_code = models.CharField(max_length=10, null=True)             ### 河川海岸砂防設備地すべり防止施設（工種）コード ※2022/10/26 追加
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※CHITAN_LINEテーブル

    ### ユーザ入力データ
    disaster_point = models.CharField(max_length=128, null=True)               ### 災害復旧箇所 ※CHITAN_LINEテーブル
    estimated_cost = models.FloatField(null=True)                              ### 災害復旧査定額（千円） ※CHITAN_LINEテーブル
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※CHITANテーブル

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※CHITAN_LINEテーブル
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※CHITAN_LINEテーブル

    ### 外部結合データ
    chitan_header_name = models.CharField(max_length=128, null=True)           ### シート名 ※2022/08/05 追加

    ### 外部結合データ
    ken_code = models.CharField(max_length=10)                                 ### 都道府県コード ※CHITAN_HEADERテーブル

    class Meta:
        db_table = 'chitan_view'
        managed = False                                                        ### マイグレーションの対象外とする。

    def __str__(self):
        return '<CHITAN_VIEW: ' + str(self.chitan_id) + '>'

###############################################################################
### 0000: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
### ※シンプルにするため、ビューテーブルでは、名前を取得するための外部結合を行わない。
### ※名前が必要な場合は、別途外部結合することとする。
### ※このアプリでは、AAAテーブルとAAA_HEADERテーブルを結合するために、ビューテーブルを使用する。
###############################################################################
class HOJO_VIEW(models.Model):
    ### ユーザ入力データ
    hojo_id = models.IntegerField(primary_key=True)                            ### 行ID ※HOJOテーブル
    hojo_name = models.CharField(max_length=128, null=True)                    ### ※2022/08/05 追加

    ### ユーザ入力データ
    hojo_header_id = models.IntegerField(null=True)                            ### シートID ※HOJOテーブル

    ### ユーザ入力データ
    city_code = models.CharField(max_length=10)                                ### 市区町村コード ※HOJOテーブル
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※2022/08/05 追加
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※2022/08/05 追加

    ### ユーザ入力データ
    suikei_code = models.CharField(max_length=10, null=True)                   ### 水系コード ※2022/08/05 追加
    suikei_type_code = models.CharField(max_length=10, null=True)              ### 水系水系種別コード ※2022/10/25 追加
    kasen_code = models.CharField(max_length=10, null=True)                    ### 河川コード ※2022/08/05 追加
    kasen_type_code = models.CharField(max_length=10, null=True)               ### 河川種別コード ※2022/08/05 追加
    kasen_setubi_code = models.CharField(max_length=10, null=True)             ### 河川海岸砂防設備地すべり防止施設（工種）コード ※2022/10/26 追加
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※2022/08/05 追加

    ### ユーザ入力データ
    koji_code = models.CharField(max_length=10, null=True)                     ### 工事番号 ※2022/08/05 追加
    branch_code = models.CharField(max_length=10, null=True)                   ### 枝番 ※2022/08/05 追加
    koji_type_code = models.CharField(max_length=10, null=True)                ### 工事区分 ※2022/08/05 追加
    kosh_type_code = models.CharField(max_length=10, null=True)                ### 工種区分 ※2022/08/05 追加

    ### ユーザ入力データ
    determined_cost = models.FloatField(null=True)                             ### 決定額（千円） ※2022/08/05 追加
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※2022/08/05 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※HOJOテーブル
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※HOJOテーブル

    ### 外部結合データ
    hojo_header_name = models.CharField(max_length=128, null=True)             ### シート名 ※2022/08/05 追加

    ### 外部結合データ
    ken_code = models.CharField(max_length=10)                                 ### 都道府県コード ※HOJO_HEADERテーブル

    class Meta:
        db_table = 'hojo_view'
        managed = False                                                        ### マイグレーションの対象外とする。

    def __str__(self):
        return '<HOJO_VIEW: ' + str(self.hojo_id) + '>'

###############################################################################
### 0000: ビューデータ_公益事業等調査票_一覧表部分
### ※シンプルにするため、ビューテーブルでは、名前を取得するための外部結合を行わない。
### ※名前が必要な場合は、別途外部結合することとする。
### ※このアプリでは、AAAテーブルとAAA_HEADERテーブルを結合するために、ビューテーブルを使用する。
###############################################################################
class KOEKI_VIEW(models.Model):
    ### ユーザ入力データ
    koeki_id = models.IntegerField(primary_key=True)                           ### 行ID ※KOEKIテーブル
    koeki_name = models.CharField(max_length=128, null=True)                   ### 町丁名、大字名 ※2022/08/05 追加

    ### ユーザ入力データ
    koeki_header_id = models.IntegerField(null=True)                           ### シートID ※KOEKIテーブル

    ### ユーザ入力データ
    city_code = models.CharField(max_length=10)                                ### 市区町村コード ※KOEKIテーブル
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※2022/08/05 追加
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※2022/08/05 追加

    ### ユーザ入力データ
    suikei_code = models.CharField(max_length=10, null=True)                   ### 水系コード ※2022/08/05 追加
    suikei_type_code = models.CharField(max_length=10, null=True)              ### 水系水系種別コード ※2022/10/25 追加
    kasen_code = models.CharField(max_length=10, null=True)                    ### 河川コード ※2022/08/05 追加
    kasen_type_code = models.CharField(max_length=10, null=True)               ### 河川種別コード ※2022/08/05 追加
    kasen_setubi_code = models.CharField(max_length=10, null=True)             ### 河川海岸砂防設備地すべり防止施設（工種）コード ※2022/10/26 追加
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※2022/08/05 追加

    ### ユーザ入力データ
    cause_1_code = models.CharField(max_length=10, null=True)                  ### 水害原因_1_コード ※2022/08/05 追加
    cause_2_code = models.CharField(max_length=10, null=True)                  ### 水害原因_2_コード ※2022/08/05 追加
    cause_3_code = models.CharField(max_length=10, null=True)                  ### 水害原因_3_コード ※2022/08/05 追加
    business_code = models.CharField(max_length=10, null=True)                 ### 事業コード ※2022/08/05 追加
    organization_name = models.CharField(max_length=128, null=True)            ### 調査対象機関名称 ※2022/08/05 追加
    
    ### ユーザ入力データ
    physical_damage = models.FloatField(null=True)                             ### 被害金額_物的被害額（千円）
    sales_damage = models.FloatField(null=True)                                ### 被害金額_営業停止に伴う売上減少額
    alt_damage = models.FloatField(null=True)                                  ### 被害金額_代替活動費（外注費）
    other_damage = models.FloatField(null=True)                                ### 被害金額_その他
    sales_alt_other_damage = models.FloatField(null=True)                      ### 被害金額_営業停止損失額合計（千円）
    
    ### ユーザ入力データ
    suspended_days = models.IntegerField(null=True)                            ### 営業停止期間等_停止期間_日
    suspended_hours = models.IntegerField(null=True)                           ### 営業停止期間等_停止期間_時間
    suspended_amounts = models.IntegerField(null=True)                         ### 営業停止期間等_停止数量
    
    ### ユーザ入力データ
    department_name = models.CharField(max_length=128, null=True)              ### 照会先_調査担当課名
    employee_name = models.CharField(max_length=128, null=True)                ### 照会先_調査担当者名
    telephone = models.CharField(max_length=128, null=True)                    ### 照会先_電話番号
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※2022/08/05 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※KOEKIテーブル
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※KOEKIテーブル

    ### 外部結合データ
    koeki_header_name = models.CharField(max_length=128, null=True)            ### シート名 ※2022/08/05 追加

    ### 外部結合データ
    ken_code = models.CharField(max_length=10)                                 ### 都道府県コード ※KOEKI_HEADERテーブル

    class Meta:
        db_table = 'koeki_view'
        managed = False                                                        ### マイグレーションの対象外とする。

    def __str__(self):
        return '<KOEKI_VIEW: ' + str(self.koeki_id) + '>'

###############################################################################
### 0000: ビューデータ_一般資産調査票_調査員用_一覧表部分
### ※シンプルにするため、ビューテーブルでは、名前を取得するための外部結合を行わない。
### ※名前が必要な場合は、別途外部結合することとする。
### ※このアプリでは、AAAテーブルとAAA_HEADERテーブルを結合するために、ビューテーブルを使用する。
###############################################################################
class IPPAN_SUMMARY_VIEW(models.Model):
    ### ippan_summary_id = models.IntegerField(primary_key=True)               ### postgresの自動インクリメントを使用する。 ※一般資産調査票の複数行の集計計算を１個のSQLで行うため ※MAX(*_ID+1)の場合、FORループが必要となる。

    ### ユーザ入力データ
    ippan_id = models.IntegerField(null=True)                                  ### 行ID ※IPPAN_SUMMARYビュー項目
    ippan_name = models.CharField(max_length=128, null=True)                   ### 町丁名、大字名
    
    ### ユーザ入力データ
    ippan_header_id = models.IntegerField(null=True)                           ### シートID ※IPPAN_SUMMARYビュー項目

    ### ユーザ入力データ
    building_code = models.CharField(max_length=10, null=True)                 ### 建物区分コード ※IPPANテーブル
    underground_code = models.CharField(max_length=10, null=True)              ### 地上地下区分コード ※IPPANテーブル
    flood_sediment_code = models.CharField(max_length=10, null=True)           ### 浸水土砂区分コード ※IPPANテーブル

    ### ユーザ入力データ
    industry_code = models.CharField(max_length=10, null=True)                 ### 産業分類コード ※IPPANテーブル
    usage_code = models.CharField(max_length=10, null=True)                    ### 地下空間の利用形態コード ※IPPANテーブル
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※IPPANテーブル

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※IPPAN_SUMMARYビュー項目
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※IPPAN_SUMMARYビュー項目

    ### 外部結合データ
    ken_code = models.CharField(max_length=10)                                 ### 都道府県コード ※IPPAN_HEADERビュー項目
    city_code = models.CharField(max_length=10)                                ### 市区町村コード ※IPPAN_HEADERビュー項目
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※IPPAN_HEADERテーブル
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※IPPAN_HEADERテーブル
    cause_1_code = models.CharField(max_length=10)                             ### 水害原因コード1 ※IPPAN_HEADERテーブル
    cause_2_code = models.CharField(max_length=10)                             ### 水害原因コード2 ※IPPAN_HEADERテーブル
    cause_3_code = models.CharField(max_length=10)                             ### 水害原因コード3 ※IPPAN_HEADERテーブル
    area_id = models.IntegerField()                                            ### 水害区域ID ※IPPAN_HEADERテーブル

    ### 外部結合データ
    suikei_code = models.CharField(max_length=10)                              ### 水系コード ※IPPAN_HEADERビュー項目
    suikei_type_code = models.CharField(max_length=10)                         ### 水系種別コード ※SUIKEIテーブル
    kasen_code = models.CharField(max_length=10)                               ### 河川コード ※IPPAN_HEADERビュー項目
    kasen_type_code = models.CharField(max_length=10)                          ### 河川種別コード ※KASENテーブル
    gradient_code = models.CharField(max_length=10)                            ### 地盤勾配区分コード ※IPPAN_HEADERテーブル

    ### 外部結合データ
    residential_area = models.FloatField(null=True)                            ### 宅地面積（単位m2） ※IPPAN_HEADERテーブル
    agricultural_area = models.FloatField(null=True)                           ### 農地面積（単位m2） ※IPPAN_HEADERテーブル
    underground_area = models.FloatField(null=True)                            ### 地下面積（単位m2） ※IPPAN_HEADERテーブル
    kasen_kaigan_code = models.CharField(max_length=10, null=True)             ### 河川海岸（工種）コード ※IPPAN_HEADERテーブル
    crop_damage = models.FloatField(null=True)                                 ### 農作物被害額（単位千円） ※IPPAN_SUMMARYビュー項目
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※IPPAN_HEADERテーブル

    ### 導出データ
    house_summary_lv00 = models.FloatField(null=True)                          ### 家屋被害額_床下（延床面積×家屋評価額×浸水または土砂ごとの勾配差による被害率） ※IPPAN_SUMMARYビュー項目
    house_summary_lv01_49 = models.FloatField(null=True)                       ### 家屋被害額_01から49cm（延床面積×家屋評価額×浸水または土砂ごとの勾配差による被害率） ※IPPAN_SUMMARYビュー項目
    house_summary_lv50_99 = models.FloatField(null=True)                       ### 家屋被害額_50から99cm（延床面積×家屋評価額×浸水または土砂ごとの勾配差による被害率） ※IPPAN_SUMMARYビュー項目
    house_summary_lv100 = models.FloatField(null=True)                         ### 家屋被害額_100cm以上（延床面積×家屋評価額×浸水または土砂ごとの勾配差による被害率） ※IPPAN_SUMMARYビュー項目
    house_summary_half = models.FloatField(null=True)                          ### 家屋被害額_半壊（延床面積×家屋評価額×浸水または土砂ごとの勾配差による被害率） ※IPPAN_SUMMARYビュー項目
    house_summary_full = models.FloatField(null=True)                          ### 家屋被害額_全壊（延床面積×家屋評価額×浸水または土砂ごとの勾配差による被害率） ※IPPAN_SUMMARYビュー項目

    ### 導出データ
    household_summary_lv00 = models.FloatField(null=True)                      ### 家庭用品自動車以外被害額_床下（被災世帯数×家庭用品所有額×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    household_summary_lv01_49 = models.FloatField(null=True)                   ### 家庭用品自動車以外被害額_01から49cm（被災世帯数×家庭用品所有額×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    household_summary_lv50_99 = models.FloatField(null=True)                   ### 家庭用品自動車以外被害額_50から99cm（被災世帯数×家庭用品所有額×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    household_summary_lv100 = models.FloatField(null=True)                     ### 家庭用品自動車以外被害額_100cm以上（被災世帯数×家庭用品所有額×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    household_summary_half = models.FloatField(null=True)                      ### 家庭用品自動車以外被害額_半壊（被災世帯数×家庭用品所有額×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    household_summary_full = models.FloatField(null=True)                      ### 家庭用品自動車以外被害額_全壊（被災世帯数×家庭用品所有額×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目

    ### 導出データ 
    car_summary_lv00 = models.FloatField(null=True)                            ### 家庭用品自動車被害額_床下（被災世帯数×家庭用品自動車所有額×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    car_summary_lv01_49 = models.FloatField(null=True)                         ### 家庭用品自動車被害額_01から49cm（被災世帯数×家庭用品自動車所有額×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    car_summary_lv50_99 = models.FloatField(null=True)                         ### 家庭用品自動車被害額_50から99cm（被災世帯数×家庭用品自動車所有額×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    car_summary_lv100 = models.FloatField(null=True)                           ### 家庭用品自動車被害額_100cm以上（被災世帯数×家庭用品自動車所有額×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    car_summary_half = models.FloatField(null=True)                            ### 家庭用品自動車被害額_半壊（被災世帯数×家庭用品自動車所有額×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    car_summary_full = models.FloatField(null=True)                            ### 家庭用品自動車被害額_全壊（被災世帯数×家庭用品自動車所有額×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目

    ### 導出データ 
    house_alt_summary_lv00 = models.FloatField(null=True)                      ### 家庭応急対策費_代替活動費_床下（被災世帯数×代替活動費） ※IPPAN_SUMMARYビュー項目
    house_alt_summary_lv01_49 = models.FloatField(null=True)                   ### 家庭応急対策費_代替活動費_01から49cm（被災世帯数×代替活動費） ※IPPAN_SUMMARYビュー項目
    house_alt_summary_lv50_99 = models.FloatField(null=True)                   ### 家庭応急対策費_代替活動費_50から99cm（被災世帯数×代替活動費） ※IPPAN_SUMMARYビュー項目
    house_alt_summary_lv100 = models.FloatField(null=True)                     ### 家庭応急対策費_代替活動費_100cm以上（被災世帯数×代替活動費） ※IPPAN_SUMMARYビュー項目
    house_alt_summary_half = models.FloatField(null=True)                      ### 家庭応急対策費_代替活動費_半壊（被災世帯数×代替活動費） ※IPPAN_SUMMARYビュー項目
    house_alt_summary_full = models.FloatField(null=True)                      ### 家庭応急対策費_代替活動費_全壊（被災世帯数×代替活動費） ※IPPAN_SUMMARYビュー項目

    ### 導出データ 
    house_clean_summary_lv00 = models.FloatField(null=True)                    ### 家庭応急対策費_清掃費_床下（被災世帯数×清掃日数×清掃労働単価） ※IPPAN_SUMMARYビュー項目
    house_clean_summary_lv01_49 = models.FloatField(null=True)                 ### 家庭応急対策費_清掃費_01から49cm（被災世帯数×清掃日数×清掃労働単価） ※IPPAN_SUMMARYビュー項目
    house_clean_summary_lv50_99 = models.FloatField(null=True)                 ### 家庭応急対策費_清掃費_50から99cm（被災世帯数×清掃日数×清掃労働単価） ※IPPAN_SUMMARYビュー項目
    house_clean_summary_lv100 = models.FloatField(null=True)                   ### 家庭応急対策費_清掃費_100cm以上（被災世帯数×清掃日数×清掃労働単価） ※IPPAN_SUMMARYビュー項目
    house_clean_summary_half = models.FloatField(null=True)                    ### 家庭応急対策費_清掃費_半壊（被災世帯数×清掃日数×清掃労働単価） ※IPPAN_SUMMARYビュー項目
    house_clean_summary_full = models.FloatField(null=True)                    ### 家庭応急対策費_清掃費_全壊（被災世帯数×清掃日数×清掃労働単価） ※IPPAN_SUMMARYビュー項目

    ### 導出データ 
    office_dep_summary_lv00 = models.FloatField(null=True)                     ### 事業所被害額_償却資産被害額_床下（従業者数×産業分類ごとの償却資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    office_dep_summary_lv01_49 = models.FloatField(null=True)                  ### 事業所被害額_償却資産被害額_01から49cm（従業者数×産業分類ごとの償却資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    office_dep_summary_lv50_99 = models.FloatField(null=True)                  ### 事業所被害額_償却資産被害額_50から99cm（従業者数×産業分類ごとの償却資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    office_dep_summary_lv100 = models.FloatField(null=True)                    ### 事業所被害額_償却資産被害額_100cm以上（従業者数×産業分類ごとの償却資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    ### office_dep_summary_half = models.FloatField(null=True)                 ### 事業所被害額_償却資産被害額_半壊（従業者数×産業分類ごとの償却資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    office_dep_summary_full = models.FloatField(null=True)                     ### 事業所被害額_償却資産被害額_全壊（従業者数×産業分類ごとの償却資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目

    ### 導出データ 
    office_inv_summary_lv00 = models.FloatField(null=True)                     ### 事業所被害額_在庫資産被害額_床下（従業者数×産業分類ごとの在庫資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    office_inv_summary_lv01_49 = models.FloatField(null=True)                  ### 事業所被害額_在庫資産被害額_01から49cm（従業者数×産業分類ごとの在庫資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    office_inv_summary_lv50_99 = models.FloatField(null=True)                  ### 事業所被害額_在庫資産被害額_50から99cm（従業者数×産業分類ごとの在庫資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    office_inv_summary_lv100 = models.FloatField(null=True)                    ### 事業所被害額_在庫資産被害額_100cm以上（従業者数×産業分類ごとの在庫資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    ### office_inv_summary_half = models.FloatField(null=True)                 ### 事業所被害額_在庫資産被害額_半壊（従業者数×産業分類ごとの在庫資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    office_inv_summary_full = models.FloatField(null=True)                     ### 事業所被害額_在庫資産被害額_全壊（従業者数×産業分類ごとの在庫資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目

    ### 導出データ 
    office_sus_summary_lv00 = models.FloatField(null=True)                     ### 事業所被害額_営業停止に伴う被害額_床下（従業者数×営業停止日数×付加価値額） ※IPPAN_SUMMARYビュー項目
    office_sus_summary_lv01_49 = models.FloatField(null=True)                  ### 事業所被害額_営業停止に伴う被害額_01から49cm（従業者数×営業停止日数×付加価値額） ※IPPAN_SUMMARYビュー項目
    office_sus_summary_lv50_99 = models.FloatField(null=True)                  ### 事業所被害額_営業停止に伴う被害額_50から99cm（従業者数×営業停止日数×付加価値額） ※IPPAN_SUMMARYビュー項目
    office_sus_summary_lv100 = models.FloatField(null=True)                    ### 事業所被害額_営業停止に伴う被害額_100cm以上（従業者数×営業停止日数×付加価値額） ※IPPAN_SUMMARYビュー項目
    ### office_sus_summary_half = models.FloatField(null=True)                 ### 事業所被害額_営業停止に伴う被害額_半壊（従業者数×営業停止日数×付加価値額） ※IPPAN_SUMMARYビュー項目
    office_sus_summary_full = models.FloatField(null=True)                     ### 事業所被害額_営業停止に伴う被害額_全壊（従業者数×営業停止日数×付加価値額） ※IPPAN_SUMMARYビュー項目

    ### 導出データ 
    office_stg_summary_lv00 = models.FloatField(null=True)                     ### 事業所被害額_営業停滞に伴う被害額_床下（従業者数×（営業停滞日数/2）×付加価値額） ※IPPAN_SUMMARYビュー項目
    office_stg_summary_lv01_49 = models.FloatField(null=True)                  ### 事業所被害額_営業停滞に伴う被害額_01から49cm（従業者数×（営業停滞日数/2）×付加価値額） ※IPPAN_SUMMARYビュー項目
    office_stg_summary_lv50_99 = models.FloatField(null=True)                  ### 事業所被害額_営業停滞に伴う被害額_50から99cm（従業者数×（営業停滞日数/2）×付加価値額） ※IPPAN_SUMMARYビュー項目
    office_stg_summary_lv100 = models.FloatField(null=True)                    ### 事業所被害額_営業停滞に伴う被害額_100cm以上（従業者数×（営業停滞日数/2）×付加価値額） ※IPPAN_SUMMARYビュー項目
    ### office_stg_summary_half = models.FloatField(null=True)                 ### 事業所被害額_営業停滞に伴う被害額_半壊（従業者数×（営業停滞日数/2）×付加価値額） ※IPPAN_SUMMARYビュー項目
    office_stg_summary_full = models.FloatField(null=True)                     ### 事業所被害額_営業停滞に伴う被害額_全壊（従業者数×（営業停滞日数/2）×付加価値額） ※IPPAN_SUMMARYビュー項目

    ### 導出データ
    farmer_fisher_dep_summary_lv00 = models.FloatField(null=True)              ### 農漁家被害額_償却資産被害額_床下（農漁家戸数×農漁家の償却資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    farmer_fisher_dep_summary_lv01_49 = models.FloatField(null=True)           ### 農漁家被害額_償却資産被害額_01から49cm（農漁家戸数×農漁家の償却資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    farmer_fisher_dep_summary_lv50_99 = models.FloatField(null=True)           ### 農漁家被害額_償却資産被害額_50から99cm（農漁家戸数×農漁家の償却資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    farmer_fisher_dep_summary_lv100 = models.FloatField(null=True)             ### 農漁家被害額_償却資産被害額_100cm以上（農漁家戸数×農漁家の償却資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    ### farmer_fisher_dep_summary_half = models.FloatField(null=True)          ### 農漁家被害額_償却資産被害額_半壊（農漁家戸数×農漁家の償却資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    farmer_fisher_dep_summary_full = models.FloatField(null=True)              ### 農漁家被害額_償却資産被害額_全壊（農漁家戸数×農漁家の償却資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目

    ### 導出データ 
    farmer_fisher_inv_summary_lv00 = models.FloatField(null=True)              ### 農漁家被害額_在庫資産被害額_床下（農漁家戸数×農漁家の在庫資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    farmer_fisher_inv_summary_lv01_49 = models.FloatField(null=True)           ### 農漁家被害額_在庫資産被害額_01から49cm（農漁家戸数×農漁家の在庫資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    farmer_fisher_inv_summary_lv50_99 = models.FloatField(null=True)           ### 農漁家被害額_在庫資産被害額_50から99cm（農漁家戸数×農漁家の在庫資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    farmer_fisher_inv_summary_lv100 = models.FloatField(null=True)             ### 農漁家被害額_在庫資産被害額_100cm以上（農漁家戸数×農漁家の在庫資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    ### farmer_fisher_inv_summary_half = models.FloatField(null=True)          ### 農漁家被害額_在庫資産被害額_半壊（農漁家戸数×農漁家の在庫資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目
    farmer_fisher_inv_summary_full = models.FloatField(null=True)              ### 農漁家被害額_在庫資産被害額_全壊（農漁家戸数×農漁家の在庫資産×浸水または土砂による被害率） ※IPPAN_SUMMARYビュー項目

    ### 導出データ 
    office_alt_summary_lv00 = models.FloatField(null=True)                     ### 事業所応急対策費_代替活動費_床下（事業所数×代替活動費） ※IPPAN_SUMMARYビュー項目
    office_alt_summary_lv01_49 = models.FloatField(null=True)                  ### 事業所応急対策費_代替活動費_01から49cm（事業所数×代替活動費） ※IPPAN_SUMMARYビュー項目
    office_alt_summary_lv50_99 = models.FloatField(null=True)                  ### 事業所応急対策費_代替活動費_50から99cm（事業所数×代替活動費） ※IPPAN_SUMMARYビュー項目
    office_alt_summary_lv100 = models.FloatField(null=True)                    ### 事業所応急対策費_代替活動費_100cm以上（事業所数×代替活動費） ※IPPAN_SUMMARYビュー項目
    office_alt_summary_half = models.FloatField(null=True)                     ### 事業所応急対策費_代替活動費_半壊（事業所数×代替活動費） ※IPPAN_SUMMARYビュー項目
    office_alt_summary_full = models.FloatField(null=True)                     ### 事業所応急対策費_代替活動費_全壊（事業所数×代替活動費） ※IPPAN_SUMMARYビュー項目

    ### 導出データ 
    asset_sales_damage = models.FloatField(null=True)                          ### 一般資産・営業停止損失額 ※IPPAN_SUMMARYビュー項目 2022/11/15 追加
    asset_sales_crop_damage = models.FloatField(null=True)                     ### 一般資産・営業停止損失額・農作物 ※IPPAN_SUMMARYビュー項目 2022/11/15 追加

    class Meta:
        db_table = 'ippan_summary_view'
        managed = False                                                        ### マイグレーションの対象外とする。

    def __str__(self):
        return '<IPPAN_SUMMARY_VIEW: ' + str(self.ippan_summary_id) + '>'

###############################################################################
### 0000: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
### ※シンプルにするため、ビューテーブルでは、名前を取得するための外部結合を行わない。
### ※名前が必要な場合は、別途外部結合することとする。
### ※このアプリでは、AAAテーブルとAAA_HEADERテーブルを結合するために、ビューテーブルを使用する。
###############################################################################
class CHITAN_SUMMARY_VIEW(models.Model):
    ### chitan_summary_id = models.IntegerField(primary_key=True)              ### postgresの自動インクリメントを使用する。 ※公共土木施設調査票_地方単独事業の複数行の集計計算を１個のSQLで行うため ※MAX(*_ID+1)の場合、FORループが必要となる。

    ### ユーザ入力データ
    chitan_id = models.IntegerField(null=True)                                 ### 行ID ※CHITAN_SUMMARYビュー項目

    ### ユーザ入力データ
    chitan_header_id = models.IntegerField(null=True)                          ### シートID ※CHITAN_SUMMARYビュー項目

    ### ユーザ入力データ
    city_code = models.CharField(max_length=10)                                ### 市区町村コード ※CHITAN_HEADERビュー項目
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※2022/08/05 追加
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※2022/08/05 追加

    ### ユーザ入力データ
    suikei_code = models.CharField(max_length=10, null=True)                   ### 水系コード ※2022/08/05 追加
    suikei_type_code = models.CharField(max_length=10, null=True)              ### 水系水系種別コード ※2022/10/25 追加
    kasen_code = models.CharField(max_length=10, null=True)                    ### 河川コード ※2022/08/05 追加
    kasen_type_code = models.CharField(max_length=10, null=True)               ### 河川種別コード ※2022/08/05 追加
    kasen_setubi_code = models.CharField(max_length=10, null=True)             ### 河川海岸砂防設備地すべり防止施設（工種）コード ※2022/10/26 追加
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※2022/08/05 追加

    ### ユーザ入力データ
    disaster_point = models.CharField(max_length=128, null=True)               ### 災害復旧箇所 ※2022/10/19 追加
    estimated_cost = models.FloatField(null=True)                              ### 災害復旧査定額（千円） ※2022/10/19 追加
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※2022/08/05 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※CHITAN_SUMMARYビュー項目
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※CHITAN_SUMMARYビュー項目

    ### 外部結合データ
    ken_code = models.CharField(max_length=10)                                 ### 都道府県コード ※CHITAN_HEADERビュー項目

    class Meta:
        db_table = 'chitan_summary_view'
        managed = False                                                        ### マイグレーションの対象外とする。

    def __str__(self):
        return '<CHITAN_SUMMARY_VIEW: ' + str(self.chitan_summary_id) + '>'

###############################################################################
### 0000: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
### ※シンプルにするため、ビューテーブルでは、名前を取得するための外部結合を行わない。
### ※名前が必要な場合は、別途外部結合することとする。
### ※このアプリでは、AAAテーブルとAAA_HEADERテーブルを結合するために、ビューテーブルを使用する。
###############################################################################
class HOJO_SUMMARY_VIEW(models.Model):
    ### hojo_summary_id = models.IntegerField(primary_key=True)                ### postgresの自動インクリメントを使用する。 ※公共土木施設調査票_補助事業の複数行の集計計算を１個のSQLで行うため ※MAX(*_ID+1)の場合、FORループが必要となる。

    ### ユーザ入力データ
    hojo_id = models.IntegerField(null=True)                                   ### 行ID ※HOJO_SUMMARYビュー項目

    ### ユーザ入力データ
    hojo_header_id = models.IntegerField(null=True)                            ### シートID ※HOJO_SUMMARYビュー項目

    ### ユーザ入力データ
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード ※2022/08/05 追加
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※2022/08/05 追加
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※2022/08/05 追加

    ### ユーザ入力データ
    suikei_code = models.CharField(max_length=10, null=True)                   ### 水系コード ※2022/08/05 追加
    suikei_type_code = models.CharField(max_length=10, null=True)              ### 水系水系種別コード ※2022/10/25 追加
    kasen_code = models.CharField(max_length=10, null=True)                    ### 河川コード ※2022/08/05 追加
    kasen_type_code = models.CharField(max_length=10, null=True)               ### 河川種別コード ※2022/08/05 追加
    kasen_setubi_code = models.CharField(max_length=10, null=True)             ### 河川海岸砂防設備地すべり防止施設（工種）コード ※2022/10/26 追加
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※2022/08/05 追加

    ### ユーザ入力データ
    koji_code = models.CharField(max_length=10, null=True)                     ### 工事番号 ※2022/08/05 追加
    branch_code = models.CharField(max_length=10, null=True)                   ### 枝番 ※2022/08/05 追加
    koji_type_code = models.CharField(max_length=10, null=True)                ### 工事区分 ※2022/08/05 追加
    kosh_type_code = models.CharField(max_length=10, null=True)                ### 工種区分 ※2022/08/05 追加

    ### ユーザ入力データ
    determined_cost = models.FloatField(null=True)                             ### 決定額（千円） ※2022/08/05 追加
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※2022/08/05 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※HOJO_SUMMARYビュー項目
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※HOJO_SUMMARYビュー項目

    ### 外部結合データ
    ken_code = models.CharField(max_length=10)                                 ### 都道府県コード ※HOJO_HEADERビュー項目

    class Meta:
        db_table = 'hojo_summary_view'
        managed = False                                                        ### マイグレーションの対象外とする。

    def __str__(self):
        return '<HOJO_SUMMARY_VIEW: ' + str(self.hojo_summary_id) + '>'

###############################################################################
### 0000: ビューデータ_公益事業等調査票_一覧表部分
### ※シンプルにするため、ビューテーブルでは、名前を取得するための外部結合を行わない。
### ※名前が必要な場合は、別途外部結合することとする。
### ※このアプリでは、AAAテーブルとAAA_HEADERテーブルを結合するために、ビューテーブルを使用する。
###############################################################################
class KOEKI_SUMMARY_VIEW(models.Model):
    ### koeki_summary_id = models.IntegerField(primary_key=True)               ### postgresの自動インクリメントを使用する。 ※公益事業等調査票の複数行の集計計算を１個のSQLで行うため ※MAX(*_ID+1)の場合、FORループが必要となる。

    ### ユーザ入力データ
    koeki_id = models.IntegerField(null=True)                                  ### 行ID ※KOEKI_SUMMARYビュー項目

    ### ユーザ入力データ
    koeki_header_id = models.IntegerField(null=True)                           ### シートID ※KOEKI_SUMMARYビュー項目

    ### ユーザ入力データ
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード ※2022/08/05 追加
    begin_date = models.DateField(null=True)                                   ### 水害発生年月日 ※2022/08/05 追加
    end_date = models.DateField(null=True)                                     ### 水害終了年月日 ※2022/08/05 追加

    ### ユーザ入力データ
    suikei_code = models.CharField(max_length=10, null=True)                   ### 水系コード ※2022/08/05 追加
    suikei_type_code = models.CharField(max_length=10, null=True)              ### 水系水系種別コード ※2022/10/25 追加
    kasen_code = models.CharField(max_length=10, null=True)                    ### 河川コード ※2022/08/05 追加
    kasen_type_code = models.CharField(max_length=10, null=True)               ### 河川種別コード ※2022/08/05 追加
    kasen_setubi_code = models.CharField(max_length=10, null=True)             ### 河川海岸砂防設備地すべり防止施設（工種）コード ※2022/10/26 追加
    weather_id = models.IntegerField(null=True)                                ### 異常気象ID ※2022/08/05 追加

    ### ユーザ入力データ
    cause_1_code = models.CharField(max_length=10, null=True)                  ### 水害原因_1_コード ※2022/08/05 追加
    cause_2_code = models.CharField(max_length=10, null=True)                  ### 水害原因_2_コード ※2022/08/05 追加
    cause_3_code = models.CharField(max_length=10, null=True)                  ### 水害原因_3_コード ※2022/08/05 追加
    business_code = models.CharField(max_length=10, null=True)                 ### 事業コード ※2022/08/05 追加
    organization_name = models.CharField(max_length=128, null=True)            ### 調査対象機関名称 ※2022/08/05 追加
    
    ### ユーザ入力データ
    physical_damage = models.FloatField(null=True)                             ### 被害金額_物的被害額（千円）
    sales_damage = models.FloatField(null=True)                                ### 被害金額_営業停止に伴う売上減少額
    alt_damage = models.FloatField(null=True)                                  ### 被害金額_代替活動費（外注費）
    other_damage = models.FloatField(null=True)                                ### 被害金額_その他
    sales_alt_other_damage = models.FloatField(null=True)                      ### 被害金額_営業停止損失額合計（千円）
    
    ### ユーザ入力データ
    suspended_days = models.IntegerField(null=True)                            ### 営業停止期間等_停止期間_日
    suspended_hours = models.IntegerField(null=True)                           ### 営業停止期間等_停止期間_時間
    suspended_amounts = models.IntegerField(null=True)                         ### 営業停止期間等_停止数量
    
    ### ユーザ入力データ
    department_name = models.CharField(max_length=128, null=True)              ### 照会先_調査担当課名
    employee_name = models.CharField(max_length=128, null=True)                ### 照会先_調査担当者名
    telephone = models.CharField(max_length=128, null=True)                    ### 照会先_電話番号
    comment = models.CharField(max_length=512, null=True)                      ### 備考 ※2022/08/05 追加

    ### 制御用データ
    committed_at = models.DateTimeField(null=True)                             ### コミット日時 ※KOEKI_SUMMARYビュー項目
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時 ※KOEKI_SUMMARYビュー項目

    ### 外部結合データ
    ken_code = models.CharField(max_length=10)                                 ### 都道府県コード ※KOEKI_HEADERビュー項目

    class Meta:
        db_table = 'koeki_summary_view'
        managed = False                                                        ### マイグレーションの対象外とする。

    def __str__(self):
        return '<KOEKI_SUMMARY_VIEW: ' + str(self.koeki_summary_id) + '>'

###############################################################################
### 10000: マスタデータ_アクション
###############################################################################
class ACTION(models.Model):
    action_code = models.CharField(max_length=10, primary_key=True)            ### アクションコード
    action_name = models.CharField(max_length=128, null=True)                  ### アクション名_日本語
    action_name_en = models.CharField(max_length=128, null=True)               ### アクション名_英語
    
    class Meta:
        db_table = 'action'
    
    def __str__(self):
        return '<ACTION: ' + self.action_code + '>'

###############################################################################
### 10010: マスタデータ_状態
###############################################################################
class STATUS(models.Model):
    status_code = models.CharField(max_length=10, primary_key=True)            ### 状態コード
    status_name = models.CharField(max_length=128, null=True)                  ### 状態名
    
    class Meta:
        db_table = 'status'
    
    def __str__(self):
        return '<STATUS: ' + self.status_code + '>'

###############################################################################
### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
###############################################################################
class IPPAN_TRIGGER(models.Model):
    ippan_trigger_id = models.IntegerField(primary_key=True)                   ### トリガーID
    ippan_header_id = models.IntegerField(null=True)                           ### シートID
    
    ken_code = models.CharField(max_length=10, null=True)                      ### 都道府県コード
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード

    action_code = models.CharField(max_length=20, null=True)                   ### アクションコード
    status_code = models.CharField(max_length=10, null=True)                   ### 状態コード
    
    info_count = models.IntegerField(null=True)                                ### 成功数
    warn_count = models.IntegerField(null=True)                                ### 失敗数
    info_log = models.TextField(null=True)                                     ### データ整合性 Row, Col, left, right, verified result, 
    warn_log = models.TextField(null=True)                                     ### データ整合性 Row, Col, left, right, verified result, 

    download_file_path = models.CharField(max_length=256, null=True)           ### ダウンロードファイルパス ※2022/07/14 追加
    download_file_name = models.CharField(max_length=256, null=True)           ### ダウンロードファイル名 ※2022/07/14 追加
    upload_file_path = models.CharField(max_length=256, null=True)             ### アップロードファイルパス ※2022/07/14 追加
    upload_file_name = models.CharField(max_length=256, null=True)             ### アップロードファイル名 ※2022/07/14 追加

    published_at = models.DateTimeField(null=True)                             ### 発行日時
    consumed_at = models.DateTimeField(null=True)                              ### 消費日時
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時
    
    class Meta:
        db_table = 'ippan_trigger'
    
    def __str__(self):
        return '<IPPAN_TRIGGER: ' + str(self.ippan_trigger_id) + '>'

###############################################################################
### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
###############################################################################
class CHITAN_TRIGGER(models.Model):
    chitan_trigger_id = models.IntegerField(primary_key=True)                  ### トリガーID
    chitan_header_id = models.IntegerField(null=True)                          ### シートID
    
    ken_code = models.CharField(max_length=10, null=True)                      ### 都道府県コード
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード

    action_code = models.CharField(max_length=20, null=True)                   ### アクションコード
    status_code = models.CharField(max_length=10, null=True)                   ### 状態コード
    
    info_count = models.IntegerField(null=True)                                ### 成功数
    warn_count = models.IntegerField(null=True)                                ### 失敗数

    download_file_path = models.CharField(max_length=256, null=True)           ### ダウンロードファイルパス ※2022/07/14 追加
    download_file_name = models.CharField(max_length=256, null=True)           ### ダウンロードファイル名 ※2022/07/14 追加
    upload_file_path = models.CharField(max_length=256, null=True)             ### アップロードファイルパス ※2022/07/14 追加
    upload_file_name = models.CharField(max_length=256, null=True)             ### アップロードファイル名 ※2022/07/14 追加

    info_log = models.TextField(null=True)                                     ### データ整合性 Row, Col, left, right, verified result, 
    warn_log = models.TextField(null=True)                                     ### データ整合性 Row, Col, left, right, verified result, 

    published_at = models.DateTimeField(null=True)                             ### 発行日時
    consumed_at = models.DateTimeField(null=True)                              ### 消費日時
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時
    
    class Meta:
        db_table = 'chitan_trigger'
    
    def __str__(self):
        return '<CHITAN_TRIGGER: ' + str(self.chitan_trigger_id) + '>'

###############################################################################
### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
###############################################################################
class HOJO_TRIGGER(models.Model):
    hojo_trigger_id = models.IntegerField(primary_key=True)                    ### トリガーID
    hojo_header_id = models.IntegerField(null=True)                            ### シートID
    
    ken_code = models.CharField(max_length=10, null=True)                      ### 都道府県コード
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード

    action_code = models.CharField(max_length=20, null=True)                   ### アクションコード
    status_code = models.CharField(max_length=10, null=True)                   ### 状態コード
    
    info_count = models.IntegerField(null=True)                                ### 成功数
    warn_count = models.IntegerField(null=True)                                ### 失敗数

    download_file_path = models.CharField(max_length=256, null=True)           ### ダウンロードファイルパス ※2022/07/14 追加
    download_file_name = models.CharField(max_length=256, null=True)           ### ダウンロードファイル名 ※2022/07/14 追加
    upload_file_path = models.CharField(max_length=256, null=True)             ### アップロードファイルパス ※2022/07/14 追加
    upload_file_name = models.CharField(max_length=256, null=True)             ### アップロードファイル名 ※2022/07/14 追加

    info_log = models.TextField(null=True)                                     ### データ整合性 Row, Col, left, right, verified result, 
    warn_log = models.TextField(null=True)                                     ### データ整合性 Row, Col, left, right, verified result, 

    published_at = models.DateTimeField(null=True)                             ### 発行日時
    consumed_at = models.DateTimeField(null=True)                              ### 消費日時
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時
    
    class Meta:
        db_table = 'hojo_trigger'
    
    def __str__(self):
        return '<HOJO_TRIGGER: ' + str(self.hojo_trigger_id) + '>'

###############################################################################
### 10050: キューデータ_公益事業等調査票_トリガーメッセージ
###############################################################################
class KOEKI_TRIGGER(models.Model):
    koeki_trigger_id = models.IntegerField(primary_key=True)                   ### トリガーID
    koeki_header_id = models.IntegerField(null=True)                           ### シートID
    
    ken_code = models.CharField(max_length=10, null=True)                      ### 都道府県コード
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード

    action_code = models.CharField(max_length=20, null=True)                   ### アクションコード
    status_code = models.CharField(max_length=10, null=True)                   ### 状態コード
    
    info_count = models.IntegerField(null=True)                                ### 成功数
    warn_count = models.IntegerField(null=True)                                ### 失敗数

    download_file_path = models.CharField(max_length=256, null=True)           ### ダウンロードファイルパス ※2022/07/14 追加
    download_file_name = models.CharField(max_length=256, null=True)           ### ダウンロードファイル名 ※2022/07/14 追加
    upload_file_path = models.CharField(max_length=256, null=True)             ### アップロードファイルパス ※2022/07/14 追加
    upload_file_name = models.CharField(max_length=256, null=True)             ### アップロードファイル名 ※2022/07/14 追加

    info_log = models.TextField(null=True)                                     ### データ整合性 Row, Col, left, right, verified result, 
    warn_log = models.TextField(null=True)                                     ### データ整合性 Row, Col, left, right, verified result, 

    published_at = models.DateTimeField(null=True)                             ### 発行日時
    consumed_at = models.DateTimeField(null=True)                              ### 消費日時
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時
    
    class Meta:
        db_table = 'koeki_trigger'
    
    def __str__(self):
        return '<KOEKI_TRIGGER: ' + str(self.koeki_trigger_id) + '>'

###############################################################################
### 10060: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
###############################################################################
class AREA_TRIGGER(models.Model):
    area_trigger_id = models.IntegerField(primary_key=True)                    ### トリガーID
    area_header_id = models.IntegerField(null=True)                            ### シートID
    
    ken_code = models.CharField(max_length=10, null=True)                      ### 都道府県コード
    city_code = models.CharField(max_length=10, null=True)                     ### 市区町村コード

    action_code = models.CharField(max_length=10, null=True)                   ### アクションコード
    status_code = models.CharField(max_length=10, null=True)                   ### 状態コード
    
    info_count = models.IntegerField(null=True)                                ### 成功数
    warn_count = models.IntegerField(null=True)                                ### 失敗数

    download_file_path = models.CharField(max_length=256, null=True)           ### ダウンロードファイルパス ※2022/07/14 追加
    download_file_name = models.CharField(max_length=256, null=True)           ### ダウンロードファイル名 ※2022/07/14 追加
    upload_file_path = models.CharField(max_length=256, null=True)             ### アップロードファイルパス ※2022/07/14 追加
    upload_file_name = models.CharField(max_length=256, null=True)             ### アップロードファイル名 ※2022/07/14 追加

    info_log = models.TextField(null=True)                                     ### データ整合性 Row, Col, left, right, verified result, 
    warn_log = models.TextField(null=True)                                     ### データ整合性 Row, Col, left, right, verified result, 

    published_at = models.DateTimeField(null=True)                             ### 発行日時
    consumed_at = models.DateTimeField(null=True)                              ### 消費日時
    deleted_at = models.DateTimeField(null=True)                               ### 削除日時
    
    class Meta:
        db_table = 'area_trigger'
    
    def __str__(self):
        return '<AREA_TRIGGER: ' + str(self.area_trigger_id) + '>'

###############################################################################
### 99999: バケットデータ_都道府県
###############################################################################
class KEN_BUCKET(models.Model):
    ken_code = models.CharField(max_length=10, primary_key=True)               ### 都道府県コード
    ken_name = models.CharField(max_length=128)                                ### 都道府県名
    usage = models.FloatField()                                                ### ディスク使用量
    files = models.IntegerField()                                              ### ファイル格納数

    class Meta:
        db_table = 'ken_bucket'
    
    def __str__(self):
        return '<KEN_BUCKET: ' + self.ken_code + '>'

###############################################################################
### 99999: バケットデータ_市区町村
###############################################################################
class CITY_BUCKET(models.Model):
    city_code = models.CharField(max_length=10, primary_key=True)              ### 市区町村コード
    city_name = models.CharField(max_length=128)                               ### 市区町村名
    ken_code = models.CharField(max_length=10)                                 ### 都道府県コード
    usage = models.FloatField()                                                ### ディスク使用量
    files = models.IntegerField()                                              ### ファイル格納数

    class Meta:
        db_table = 'city_bucket'
    
    def __str__(self):
        return '<CITY_BUCKET: ' + self.city_code + '>'
