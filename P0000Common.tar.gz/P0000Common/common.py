import logging
import sys
from datetime import date, datetime, timedelta, timezone

logger = logging.getLogger('suigai_website')
alert_log = []
all_log = []
info_log = []
warn_log = []
error_log = []
debug_log = []

###############################################################################
### 関数名：print_log(log_message, log_type)
###############################################################################
def print_log(log_message, log_type):
    JST = timezone(timedelta(hours=9), 'JST')
    datetime_now_YmdHMS = datetime.now(JST).strftime('%Y/%m/%d %H:%M:%S')

    print('[' + str(datetime_now_YmdHMS) + '] ' + str(log_message))
    
    if log_type == 'INFO':
        logger.info('[' + str(datetime_now_YmdHMS) + '] ' + str(log_message))
    elif log_type == 'WARN':
        logger.warn('[' + str(datetime_now_YmdHMS) + '] ' + str(log_message))
    elif log_type == 'ERROR':
        logger.error('[' + str(datetime_now_YmdHMS) + '] ' + str(log_message))
    elif log_type == 'DEBUG':
        pass
    else:
        pass
        
    ### if log_type == 'INFO':
    ###     info_log.append('[' + datetime_now_YmdHMS + '] ' + log_message)
    ### elif log_type == 'WARN':
    ###     warn_log.append('[' + datetime_now_YmdHMS + '] ' + log_message)
    ### elif log_type == 'ERROR':
    ###     error_log.append('[' + datetime_now_YmdHMS + '] ' + log_message)
    ### elif log_type == 'DEBUG':
    ###     debug_log.append('[' + datetime_now_YmdHMS + '] ' + log_message)

    alert_log.append(log_message)
    all_log.append(log_message)
    if log_type == 'INFO':
        info_log.append(log_message)
    elif log_type == 'WARN':
        warn_log.append(log_message)
    elif log_type == 'ERROR':
        error_log.append(log_message)
    elif log_type == 'DEBUG':
        debug_log.append(log_message)

###############################################################################
### 関数名：reset_log()
###############################################################################
def reset_log():
    global alert_log
    global all_log
    global info_log
    global warn_log
    global error_log
    global debug_log
    
    alert_log = []
    all_log = []
    info_log = []
    warn_log = []
    error_log = []
    debug_log = []

###############################################################################
### 関数名：get_alert_log()
###############################################################################
def get_alert_log():
    return alert_log

###############################################################################
### 関数名：get_all_log()
###############################################################################
def get_all_log():
    return all_log

###############################################################################
### 関数名：get_info_log()
###############################################################################
def get_info_log():
    return info_log

###############################################################################
### 関数名：get_warn_log()
###############################################################################
def get_warn_log():
    return warn_log

###############################################################################
### 関数名：get_error_log()
###############################################################################
def get_error_log():
    return error_log

###############################################################################
### 関数名：get_debug_log()
###############################################################################
def get_debug_log():
    return debug_log

###############################################################################
### 関数名：split_name_code(data_text)
### (1) 引数がname:codeの場合、[name,code]を返す。
### (2) 引数がnameの場合、[name,'']を返す。
### (3) 引数がcodeの場合、['', code]を返す。
###############################################################################
def split_name_code(data_text):
    try:
        name_code = ['', '']
        if data_text is not None:
            if len(data_text.split(':')) == 0:
                name_code = ['', '']
            elif len(data_text.split(':')) == 1:
                if data_text.isdecimal():
                    name_code = ['', str(data_text)]
                else:
                    name_code = [str(data_text), '']
            elif len(data_text.split(':')) == 2:
                name_code = data_text.split(':')
            else:
                name_code = ['', '']
    except:
        return ['', '']
    
    return name_code

###############################################################################
### 関数名：isdate(data_text)
### (1) 引数がYYYY-MM-DD形式の場合、Trueを返す。
### (2) 引数がYYYY/MM/DD形式の場合、Trueを返す。
### (3) 引数が上記以外の場合、Falseを返す。
###############################################################################
def isdate(data_text):
    try:
        try:
            datetime.strptime(data_text, '%Y/%m/%d')
            return True
        except ValueError:
            print_log('Incorrect data format, should be YYYY/MM/DD.', 'INFO')
            
        try:
            datetime.strptime(data_text, '%Y-%m-%d')
            return True
        except ValueError:
            print_log('Incorrect data format, should be YYYY-MM-DD', 'INFO')
            
        try:
            datetime.strptime(data_text, '%m/%d')
            return True
        except ValueError:
            print_log('Incorrect data format, should be MM/DD', 'INFO')
            
        try:
            datetime.strptime(data_text, '%m-%d')
            return True
        except ValueError:
            print_log('Incorrect data format, should be MM-DD', 'INFO')
            
        return False
    except:
        return False

###############################################################################
### 関数名：convert_empty_to_none(arg)
### (1) 引数がNoneの場合、Noneを返す。
### (2) 引数が''の場合、Noneを返す。
### (3) 引数が上記以外の場合、引数を返す。
###############################################################################
def convert_empty_to_none(arg):
    if arg is None or arg == None:
        return None
    elif arg == '' or arg == "":
        return None
    else:
        return arg

###############################################################################
### 関数名：add_comment
### 背景をセルにセットする。
### コメントをセルにセットする。
###############################################################################
def add_comment(ws, ws_result, row, column, fill, comment_index):
    print_log('[DEBUG] P0000Common.add_comment()関数 STEP 1/10.', 'DEBUG')
    ws.cell(row=row, column=column).fill = fill
    print_log('[DEBUG] P0000Common.add_comment()関数 STEP 2/10.', 'DEBUG')
    ws_result.cell(row=row, column=column).fill = fill
    
    print_log('[DEBUG] P0000Common.add_comment()関数 STEP 3/10.', 'DEBUG')
    local_message = MESSAGE[comment_index][3] + MESSAGE[comment_index][4]

    print_log('[DEBUG] P0000Common.add_comment()関数 STEP 4/10.', 'DEBUG')
    if ws.cell(row=row, column=column).comment is None:
        print_log('[DEBUG] P0000Common.add_comment()関数 STEP 5/10.', 'DEBUG')
        ws.cell(row=row, column=column).comment = Comment(local_message, '')
    else:
        print_log('[DEBUG] P0000Common.add_comment()関数 STEP 6/10.', 'DEBUG')
        ws.cell(row=row, column=column).comment = Comment(str(ws_chitan.cell(row=row, column=column).comment.text) + local_message, '')
    print_log('[DEBUG] P0000Common.add_comment()関数 STEP 7/10.', 'DEBUG')
    if ws_result.cell(row=row, column=column).comment is None:
        print_log('[DEBUG] P0000Common.add_comment()関数 STEP 8/10.', 'DEBUG')
        ws_result.cell(row=row, column=column).comment = Comment(local_message, '')
    else:
        print_log('[DEBUG] P0000Common.add_comment()関数 STEP 9/10.', 'DEBUG')
        ws_result.cell(row=row, column=column).comment = Comment(str(ws_result.cell(row=row, column=column).comment.text) + local_message, '')
    print_log('[DEBUG] P0000Common.add_comment()関数 STEP 10/10.', 'DEBUG')
    return True    
