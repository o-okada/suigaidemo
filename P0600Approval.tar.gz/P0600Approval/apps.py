from django.apps import AppConfig

class P0600ApprovalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'P0600Approval'
