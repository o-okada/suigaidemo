from django.urls import path
from . import views

app_name = 'P0600Approval'
urlpatterns = [
    path('', views.index_view, name='index_view'), 
    path('approve/', views.approve_view, name='approve_view'), 
    path('history/', views.history_view, name='history_view'), 
]
