from django.urls import path
from . import views

app_name = 'P0110City'
urlpatterns = [
    path('', views.index_view, name='index_view'),                                                                        ### /P0110City/ => /P0110City/bucket/ redirect用
    path('bucket/', views.bucket_view, name='bucket_view'),                                                               ### 市区町村用バケット Add 2023/01/27
    
    path('browser/', views.browser_view, name='browser_view'),                                                            ### 市区町村用オブジェクトブラウザ Add 2023/01/27
    
    path('slide/ippan/header/<slug:header_id>/', views.slide_ippan_header_id_view, name='slide_ippan_header_id_view'),    ### 市区町村用アクション情報表示 Add 2023/01/27
    path('slide/area/header/<slug:header_id>/', views.slide_area_header_id_view, name='slide_area_header_id_view'),       ### 市区町村用アクション情報表示 Add 2023/01/27

    path('delete/ippan/header/<slug:header_id>/', views.delete_ippan_header_id_view, name='delete_ippan_header_id_view'), ### 市区町村用一般資産調査票ファイル削除 Add 2023/02/16
    path('delete/area/header/<slug:header_id>/', views.delete_area_header_id_view, name='delete_area_header_id_view'),    ### 市区町村用水害区域図ファイル削除 Add 2023/02/16

    path('download/ippan/chosa/excel/header/<slug:header_id>/', views.download_ippan_chosa_excel_header_id_view, name='download_ippan_chosa_excel_header_id_view'), 
    path('download/ippan/chosa/csv/header/<slug:header_id>/', views.download_ippan_chosa_csv_header_id_view, name='download_ippan_chosa_csv_header_id_view'), 
    path('download/ippan/summary/excel/header/<slug:header_id>/', views.download_ippan_summary_excel_header_id_view, name='download_ippan_summary_excel_header_id_view'), 
    path('download/ippan/summary/csv/header/<slug:header_id>/', views.download_ippan_summary_csv_header_id_view, name='download_ippan_summary_csv_header_id_view'), 
    path('download/area/pdf/header/<slug:header_id>/', views.download_area_pdf_header_id_view, name='download_area_pdf_header_id_view'), 
    path('download/area/kml/header/<slug:header_id>/', views.download_area_kml_header_id_view, name='download_area_kml_header_id_view'), 

    ### path('link/ippan/area/header/<slug:header_id>/', views.link_ippan_area_header_id_view, name='link_ippan_area_header_id_view'), 
    ### path('link/ippan/weather/header/<slug:header_id>/', views.link_ippan_weather_header_id_view, name='link_ippan_weather_header_id_view'), 
    ### path('check/ippan/header/<slug:header_id>/', views.check_ippan_header_id_view, name='check_ippan_header_id_view'), 
    ### path('summarize/ippan/header/<slug:header_id>/', views.summarize_ippan_header_id_view, name='summarize_ippan_header_id_view'), 
]
