from django import forms

class UploadIppanForm(forms.Form):
    file = forms.FileField(widget=forms.FileInput(attrs={'accept':'application/xlsx'}))
    
class UploadAreaForm(forms.Form):
    file = forms.FileField(widget=forms.FileInput(attrs={'accept':'application/pdf'}))
