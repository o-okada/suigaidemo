###############################################################################
### ファイル名：P0000Common/services.py
### 共通サービス
###############################################################################

import csv                                             ### ADD 2023/03/13
import glob                                            ### ADD 2023/03/09
import hashlib                                         ### ADD 2023/03/09
import json                                            ### ADD 2023/02/06
import os                                              ### ADD 2023/02/21
import sys                                             ### ADD 2023/03/09
import time                                            ### ADD 2023/03/09
import shutil

from datetime import date, datetime, timedelta, timezone ### ADD 2023/02/21

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import connection                       ### ADD 2023/02/21
from django.db import transaction                      ### ADD 2023/02/21
from django.db.models import Max                       ### ADD 2023/02/21
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.http import HttpResponseNotFound           ### ADD 2023/02/17
from django.http.response import JsonResponse          ### ADD 2023/02/06
from django.shortcuts import redirect                  ### ADD 2023/02/10
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views import View                          ### ADD 2023/03/09
from django.views.generic.base import TemplateView

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import KASEN_SETUBI            ### 1030: マスタデータ_災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査員調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査員調査票_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査員調査票_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.models import KEN_BUCKET              ### 99999: バケットデータ_都道府県
from P0000Common.models import CITY_BUCKET             ### 99999: バケットデータ_市区町村

from P0000Common.common import get_alert_log
from P0000Common.common import get_info_log
from P0000Common.common import get_warn_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

### from P0000Common.common import split_name_code
### from P0000Common.common import isdate
### from P0000Common.common import convert_empty_to_none
### ### from P0000Common.common import add_comment ### DELETE 2023/02/24

### from . import constants

### from MessageQueue.views import get_message 
### from MessageQueue.views import publish_message 
### from MessageQueue.views import publish_consume_message 
### from MessageQueue.views import consume_message 
### from MessageQueue.views import delete_message 

### USER_PROXYテーブル.ROLE_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
### _ROLE_CITY = 'ROLE_CITY'
### _ROLE_KEN = 'ROLE_KEN'
### _ROLE_MANAGE = 'ROLE_MANAGE'

### ACTIONテーブル.ACTION_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
### _IPP_ACT_01 = 'IPP_ACT_01'
### _IPP_ACT_02 = 'IPP_ACT_02'
### _IPP_ACT_03 = 'IPP_ACT_03'
### _IPP_ACT_04 = 'IPP_ACT_04'
### _IPP_ACT_05 = 'IPP_ACT_05'
### _IPP_ACT_06 = 'IPP_ACT_06'
### _IPP_ACT_07 = 'IPP_ACT_07'

### _CHI_ACT_01 = 'CHI_ACT_01'
### _CHI_ACT_02 = 'CHI_ACT_02'
### _CHI_ACT_03 = 'CHI_ACT_03'
### _CHI_ACT_04 = 'CHI_ACT_04'
### _CHI_ACT_05 = 'CHI_ACT_05'
### _CHI_ACT_06 = 'CHI_ACT_06'
### _CHI_ACT_07 = 'CHI_ACT_07'

### _HOJ_ACT_01 = 'HOJ_ACT_01'
### _HOJ_ACT_02 = 'HOJ_ACT_02'
### _HOJ_ACT_03 = 'HOJ_ACT_03'
### _HOJ_ACT_04 = 'HOJ_ACT_04'
### _HOJ_ACT_05 = 'HOJ_ACT_05'
### _HOJ_ACT_06 = 'HOJ_ACT_06'
### _HOJ_ACT_07 = 'HOJ_ACT_07'

### _KOE_ACT_01 = 'KOE_ACT_01'
### _KOE_ACT_02 = 'KOE_ACT_02'
### _KOE_ACT_03 = 'KOE_ACT_03'
### _KOE_ACT_04 = 'KOE_ACT_04'
### _KOE_ACT_05 = 'KOE_ACT_05'
### _KOE_ACT_06 = 'KOE_ACT_06'
### _KOE_ACT_07 = 'KOE_ACT_07'

### _ARE_ACT_01 = 'ARE_ACT_01'
### _ARE_ACT_02 = 'ARE_ACT_02'
### _ARE_ACT_03 = 'ARE_ACT_03'
### _ARE_ACT_04 = 'ARE_ACT_04'
### _ARE_ACT_05 = 'ARE_ACT_05'
### _ARE_ACT_06 = 'ARE_ACT_06'
### _ARE_ACT_07 = 'ARE_ACT_07'

### STATUSテーブル.STATUS_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
### _WAITING = 'WAITING'
### _RUNNING = 'RUNNING'
### _SUCCESS = 'SUCCESS'
### _FAILURE = 'FAILURE'
### _CANCEL = 'CANCEL'

### 局所定数 ※DELETE関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
### _IPP = 'IPP'
### _ARE = 'ARE'
### _CHI = 'CHI'
### _HOJ = 'HOJ'
### _KOE = 'KOE'

### 局所定数 ※DOWNLOAD関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP_CHO_EXC = 'IPP_CHO_EXC'
_IPP_CHO_CSV = 'IPP_CHO_CSV'
_IPP_SUM_EXC = 'IPP_SUM_EXC'
_IPP_SUM_CSV = 'IPP_SUM_CSV'
_CHI_CHO_EXC = 'CHI_CHO_EXC'
_CHI_CHO_CSV = 'CHI_CHO_CSV'
_CHI_SUM_EXC = 'CHI_SUM_EXC'
_CHI_SUM_CSV = 'CHI_SUM_CSV'
_HOJ_CHO_EXC = 'HOJ_CHO_EXC'
_HOJ_CHO_CSV = 'HOJ_CHO_CSV'
_HOJ_SUM_EXC = 'HOJ_SUM_EXC'
_HOJ_SUM_CSV = 'HOJ_SUM_CSV'
_KOE_CHO_EXC = 'KOE_CHO_EXC'
_KOE_CHO_CSV = 'KOE_CHO_CSV'
_KOE_SUM_EXC = 'KOE_SUM_EXC'
_KOE_SUM_CSV = 'KOE_SUM_CSV'
_ARE_PDF = 'ARE_PDF'
_ARE_KML = 'ARE_KML'

### 局所定数 ※エクセルの列用
VLOOK_VALUE = [
    'B', 'G', 'L', 'Q', 'V', 'AA', 'AF', 'AK', 'AP', 'AU', 
    'AZ', 'BE', 'BJ', 'BO', 'BT', 'BY', 'CD', 'CI', 'CN', 'CS', 
    'CX', 'DC', 'DH', 'DM', 'DR', 'DW', 'EB', 'EG', 'EL', 'EQ', 
    'EV', 'FA', 'FF', 'FK', 'FP', 'FU', 'FZ', 'GE', 'GJ', 'GO', 
    'GT', 'GY', 'HD', 'HI', 'HN', 'HS', 'HX', 'IC', 'IH', 'IM', 
    'IR', 'IW', 'JB', 'JG', 'JL', 'JQ', 'JV', 'KA', 'KF', 'KK', 
    'KP', 'KU', 'KZ', 'LE', 'LJ', 'LO', 'LT', 'LY', 'MD', 'MI', 
    'MN', 'MS', 'MX', 'NC', 'NH', 'NM', 'NR', 'NW', 'OB', 'OG', 
    'OL', 'OQ', 'OV', 'PA', 'PF', 'PK', 'PP', 'PU', 'PZ', 'QE', 
    'QJ', 'QO', 'QT', 'QY', 'RD', 'RI', 'RN', 'RS', 'RX', 'SC', 
    'SH', 'SM', 'SR', 'SW', 'TB', 'TG', 'TL', 'TQ', 'TV', 'UA', 
    'UF', 'UK', 'UP', 'UU', 'UZ', 'VE', 'VJ', 'VO', 'VT', 'VY', 
    'WD', 'WI', 'WN', 'WS', 'WX', 'XC', 'XH', 'XM', 'XR', 'XW', 
    'YB', 'YG', 'YL', 'YQ', 'YV', 'ZA', 'ZF', 'ZK', 'ZP', 'ZU', 
    'ZZ', 'AAE', 'AAJ', 'AAO', 'AAT', 'AAY', 'ABD', 'ABI', 'ABN', 'ABS', 
    'ABX', 'ACC', 'ACH', 'ACM', 'ACR', 'ACW', 'ADB', 'ADG', 'ADL', 'ADQ', 
    'ADV', 'AEA', 'AEF', 'AEK', 'AEP', 'AEU', 'AEZ', 'AFE', 'AFJ', 'AFO', 
    'AFT', 'AFY', 'AGD', 'AGI', 'AGN', 'AGS', 'AGX', 'AHC', 'AHH', 'AHM', 
    'AHR', 'AHW', 'AIB', 'AIG', 'AIL', 'AIQ', 'AIV', 'AJA', 'AJF', 'AJK', 
    'AJP', 'AJU', 'AJZ', 'AKE', 'AKJ', 'AKO', 'AKT', 'AKY', 'ALD', 'ALI', 
    'ALN', 'ALS', 'ALX', 'AMC', 'AMH', 'AMM', 'AMR', 'AMW', 'ANB', 'ANG', 
    'ANL', 'ANQ', 'ANV', 'AOA', 'AOF', 'AOK', 'AOP', 'AOU', 'AOZ', 'APE', 
    'APJ', 'APO', 'APT', 'APY', 'AQD', 'AQI', 'AQN', 'AQS', 'AQX', 'ARC', 
    'ARH', 'ARM', 'ARR', 'ARW', 'ASB', 'ASG', 'ASL', 'ASQ', 'ASV', 'ATA', 
    'ATF', 'ATK', 'ATP', 'ATU', 'ATZ', 'AUE', 'AUJ', 'AUO', 'AUT', 'AUY', 
    'AVD', 'AVI', 'AVN', 'AVS', 'AVX', 'AWC', 'AWH', 'AWM', 'AWR', 'AWW', 
    'AXB', 'AXG', 'AXL', 'AXQ', 'AXV', 'AYA', 'AYF', 'AYK', 'AYP', 'AYU', 
    'AYZ', 'AZE', 'AZJ', 'AZO', 'AZT', 'AZY'
    ]

###############################################################################
### 一般資産調査員調査票ファイル生成処理
### func_params["IPPAN_HEADER_ID"]
### func_params["FILE_TYPE"]
###############################################################################
def get_ippan_chosa_csv_excel(request, func_params):
    
    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、複数EXCELシート対応版
    ###########################################################################
    def create_ippan_chosa_workbook():
        try:
            ### nonlocal building_list
            ### nonlocal ken_list
            ### nonlocal kasen_kaigan_list
            ### nonlocal suikei_list
            ### nonlocal suikei_type_list
            ### nonlocal kasen_type_list
            ### nonlocal cause_list
            ### nonlocal underground_list
            ### nonlocal usage_list
            ### nonlocal flood_sediment_list
            ### nonlocal gradient_list
            ### nonlocal industry_list
            ### nonlocal area_list
            ### nonlocal weather_list
            ### nonlocal ippan_header_list
            ### nonlocal ippan_header_count
            ### nonlocal template_file_path
            
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0000)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_ippan_chosa_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 1/11.', 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 2/11.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_ippan = []
            ws_ippan.append(workbook["IPPAN"])
            for i in range(ippan_header_count + 10):
                ws_ippan.append(workbook.copy_worksheet(workbook["IPPAN"]))
                ws_ippan[i+1].title = 'IPPAN' + str(i+1)
            ws_ippan_header = workbook["IPPAN_HEADER"]
            
            ws_building = workbook["BUILDING"]
            ws_ken = workbook["KEN"]
            ws_city = workbook["CITY"]
            ws_kasen_kaigan = workbook["KASEN_KAIGAN"]
            ws_suikei = workbook["SUIKEI"]
            ws_suikei_type = workbook["SUIKEI_TYPE"]
            ws_kasen = workbook["KASEN"]
            ws_kasen_type = workbook["KASEN_TYPE"]
            ws_cause = workbook["CAUSE"]
            ws_underground = workbook["UNDERGROUND"]
            ws_usage = workbook["USAGE"]
            ws_flood_sediment = workbook["FLOOD_SEDIMENT"]
            ws_gradient = workbook["GRADIENT"]
            ws_industry = workbook["INDUSTRY"]
            ws_area = workbook["AREA"]
            ws_weather = workbook["WEATHER"]
            
            ws_city_vlook = workbook["CITY_VLOOK"]
            ws_kasen_vlook = workbook["KASEN_VLOOK"]
            ws_suikei_type_vlook = workbook["SUIKEI_TYPE_VLOOK"]
            ws_kasen_type_vlook = workbook["KASEN_TYPE_VLOOK"]

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 3/11.', 'DEBUG')
            for i in range(ippan_header_count + 10 + 1):
                ws_ippan[i].sheet_view.showGridLines = False
            ws_ippan_header.sheet_view.showGridLines = False

            ws_building.sheet_view.showGridLines = False
            ws_ken.sheet_view.showGridLines = False
            ws_city.sheet_view.showGridLines = False
            ws_kasen_kaigan.sheet_view.showGridLines = False
            ws_suikei.sheet_view.showGridLines = False
            ws_suikei_type.sheet_view.showGridLines = False
            ws_kasen.sheet_view.showGridLines = False
            ws_kasen_type.sheet_view.showGridLines = False
            ws_cause.sheet_view.showGridLines = False
            ws_underground.sheet_view.showGridLines = False
            ws_usage.sheet_view.showGridLines = False
            ws_flood_sediment.sheet_view.showGridLines = False
            ws_gradient.sheet_view.showGridLines = False
            ws_industry.sheet_view.showGridLines = False
            ws_area.sheet_view.showGridLines = False
            ws_weather.sheet_view.showGridLines = False
            
            ws_city_vlook.sheet_view.showGridLines = False
            ws_kasen_vlook.sheet_view.showGridLines = False
            ws_suikei_type_vlook.sheet_view.showGridLines = False
            ws_kasen_type_vlook.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### マスタ用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 4/11.', 'DEBUG')
            ### 1000: 建物区分シート
            print("create_ippan_chosa_workbook_4_1", flush=True)
            if bool(building_list) == True:
                for i, building in enumerate(building_list):
                    ws_building.cell(row=i+1, column=1).value = building.building_code
                    ws_building.cell(row=i+1, column=2).value = str(building.building_name) + ":" + str(building.building_code)
    
            ### 1010: 都道府県シート
            print("create_ippan_chosa_workbook_4_2", flush=True)
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_ken.cell(row=i+1, column=1).value = ken.ken_code
                    ws_ken.cell(row=i+1, column=2).value = str(ken.ken_name) + ":" + str(ken.ken_code)
    
            ### 1020: 市区町村シート
            print("create_ippan_chosa_workbook_4_3", flush=True)
            cities_list = []
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    db_params = dict({
                        'KEN_CODE': ken.ken_code
                    })
                    cities_list.append(CITY.objects.raw("""
                        SELECT 
                            * 
                        FROM CITY 
                        WHERE 
                            ken_code=%(KEN_CODE)s 
                        ORDER BY 
                            CAST(CITY_CODE AS INTEGER)""", db_params))
    
            print("create_ippan_chosa_workbook_4_4", flush=True)
            if bool(cities_list) == True:
                for i, cities in enumerate(cities_list):
                    if cities:
                        for j, city in enumerate(cities):
                            ws_city.cell(row=j+1, column=i*5+1).value = city.city_code
                            ws_city.cell(row=j+1, column=i*5+2).value = str(city.city_name) + ":" + str(city.city_code)
                            ws_city.cell(row=j+1, column=i*5+3).value = city.ken_code
                            ws_city.cell(row=j+1, column=i*5+4).value = city.city_population
                            ws_city.cell(row=j+1, column=i*5+5).value = city.city_area
    
            ### 1030: 水害発生地点工種（河川海岸区分）
            print("create_ippan_chosa_workbook_4_5", flush=True)
            if bool(kasen_kaigan_list) == True:
                for i, kasen_kaigan in enumerate(kasen_kaigan_list):
                    ws_kasen_kaigan.cell(row=i+1, column=1).value = kasen_kaigan.kasen_kaigan_code
                    ws_kasen_kaigan.cell(row=i+1, column=2).value = str(kasen_kaigan.kasen_kaigan_name) + ":" + str(kasen_kaigan.kasen_kaigan_code)
    
            ### 1040: 水系（水系・沿岸）
            print("create_ippan_chosa_workbook_4_6", flush=True)
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_suikei.cell(row=i+1, column=1).value = suikei.suikei_code
                    ws_suikei.cell(row=i+1, column=2).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
                    ws_suikei.cell(row=i+1, column=3).value = suikei.suikei_type_code
    
            ### 1050: 水系種別（水系・沿岸種別）
            print("create_ippan_chosa_workbook_4_7", flush=True)
            if bool(suikei_type_list) == True:
                for i, suikei_type in enumerate(suikei_type_list):
                    ws_suikei_type.cell(row=i+1, column=1).value = suikei_type.suikei_type_code
                    ws_suikei_type.cell(row=i+1, column=2).value = str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code)
    
            ### 1060: 河川（河川・海岸）、連動プルダウン用
            print("create_ippan_chosa_workbook_4_8", flush=True)
            kasens_list = []
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    db_params = dict({
                        'SUIKEI_CODE': suikei.suikei_code
                    })
                    kasens_list.append(KASEN.objects.raw("""
                        SELECT 
                            * 
                        FROM KASEN 
                        WHERE 
                            suikei_code=%(SUIKEI_CODE)s 
                        ORDER BY 
                            CAST(kasen_code AS INTEGER)""", db_params))
    
            print("create_ippan_chosa_workbook_4_9", flush=True)
            if bool(kasens_list) == True:
                for i, kasens in enumerate(kasens_list):
                    if kasens:
                        for j, kasen in enumerate(kasens):
                            ws_kasen.cell(row=j+1, column=i*5+1).value = kasen.kasen_code
                            ws_kasen.cell(row=j+1, column=i*5+2).value = str(kasen.kasen_name) + ":" + str(kasen.kasen_code)
                            ws_kasen.cell(row=j+1, column=i*5+3).value = kasen.kasen_type_code
                            ws_kasen.cell(row=j+1, column=i*5+4).value = kasen.suikei_code
    
            ### 1070: 河川種別（河川・海岸種別）
            print("create_ippan_chosa_workbook_4_10", flush=True)
            if bool(kasen_type_list) == True:
                for i, kasen_type in enumerate(kasen_type_list):
                    ws_kasen_type.cell(row=i+1, column=1).value = kasen_type.kasen_type_code
                    ws_kasen_type.cell(row=i+1, column=2).value = str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code)
    
            ### 1080: 水害原因
            print("create_ippan_chosa_workbook_4_11", flush=True)
            if bool(cause_list) == True:
                for i, cause in enumerate(cause_list):
                    ws_cause.cell(row=i+1, column=1).value = cause.cause_code
                    ws_cause.cell(row=i+1, column=2).value = str(cause.cause_name) + ":" + str(cause.cause_code)
            
            ### 1090: 地上地下区分
            print("create_ippan_chosa_workbook_4_12", flush=True)
            if bool(underground_list) == True:
                for i, underground in enumerate(underground_list):
                    ws_underground.cell(row=i+1, column=1).value = underground.underground_code
                    ws_underground.cell(row=i+1, column=2).value = str(underground.underground_name) + ":" + str(underground.underground_code)
    
            ### 1100: 地下空間の利用形態
            print("create_ippan_chosa_workbook_4_13", flush=True)
            if bool(usage_list) == True:
                for i, usage in enumerate(usage_list):
                    ws_usage.cell(row=i+1, column=1).value = usage.usage_code
                    ws_usage.cell(row=i+1, column=2).value = str(usage.usage_name) + ":" + str(usage.usage_code)
    
            ### 1110: 浸水土砂区分
            print("create_ippan_chosa_workbook_4_14", flush=True)
            if bool(flood_sediment_list) == True:
                for i, flood_sediment in enumerate(flood_sediment_list):
                    ws_flood_sediment.cell(row=i+1, column=1).value = flood_sediment.flood_sediment_code
                    ws_flood_sediment.cell(row=i+1, column=2).value = str(flood_sediment.flood_sediment_name) + ":" + str(flood_sediment.flood_sediment_code)
    
            ### 1120: 地盤勾配区分
            print("create_ippan_chosa_workbook_4_15", flush=True)
            if bool(gradient_list) == True:
                for i, gradient in enumerate(gradient_list):
                    ws_gradient.cell(row=i+1, column=1).value = gradient.gradient_code
                    ws_gradient.cell(row=i+1, column=2).value = str(gradient.gradient_name) + ":" + str(gradient.gradient_code)
    
            ### 1130: 産業分類
            print("create_ippan_chosa_workbook_4_16", flush=True)
            if bool(industry_list) == True:
                for i, industry in enumerate(industry_list):
                    ws_industry.cell(row=i+1, column=1).value = industry.industry_code
                    ws_industry.cell(row=i+1, column=2).value = str(industry.industry_name) + ":" + str(industry.industry_code)
    
            ### 7000: 入力データ_水害区域
            print("create_ippan_chosa_workbook_4_17", flush=True)
            if bool(area_list) == True:
                for i, area in enumerate(area_list):
                    ws_area.cell(row=i+1, column=1).value = area.area_id
                    ws_area.cell(row=i+1, column=2).value = str(area.area_name) + ":" + str(area.area_id)
    
            ### 7010: 入力データ_異常気象
            print("create_ippan_chosa_workbook_4_18", flush=True)
            if bool(weather_list) == True:
                for i, weather in enumerate(weather_list):
                    ws_weather.cell(row=i+1, column=1).value = weather.weather_id
                    ws_weather.cell(row=i+1, column=2).value = str(weather.weather_name) + ":" + str(weather.weather_id)
    
            ### 7020: 入力データ_ヘッダ部分、水害
            print("create_ippan_chosa_workbook_4_19", flush=True)
            if bool(ippan_header_list) == True:
                for i, ippan_header in enumerate(ippan_header_list):
                    ws_ippan_header.cell(row=i+1, column=1).value = ippan_header.ippan_header_id
                    ws_ippan_header.cell(row=i+1, column=2).value = str(ippan_header.ippan_header_name) + ":" + str(ippan_header.ippan_header_id)
                    ws_ippan_header.cell(row=i+1, column=3).value = ippan_header.ken_code
                    ws_ippan_header.cell(row=i+1, column=4).value = ippan_header.city_code
                    ws_ippan_header.cell(row=i+1, column=5).value = ippan_header.begin_date
                    ws_ippan_header.cell(row=i+1, column=6).value = ippan_header.end_date
                    ws_ippan_header.cell(row=i+1, column=7).value = ippan_header.cause_1_code
                    ws_ippan_header.cell(row=i+1, column=8).value = ippan_header.cause_2_code
                    ws_ippan_header.cell(row=i+1, column=9).value = ippan_header.cause_3_code
                    ws_ippan_header.cell(row=i+1, column=10).value = ippan_header.area_id
                    ws_ippan_header.cell(row=i+1, column=11).value = ippan_header.suikei_code
                    ws_ippan_header.cell(row=i+1, column=12).value = ippan_header.kasen_code
                    ws_ippan_header.cell(row=i+1, column=13).value = ippan_header.gradient_code
                    ws_ippan_header.cell(row=i+1, column=14).value = ippan_header.residential_area
                    ws_ippan_header.cell(row=i+1, column=15).value = ippan_header.agricultural_area
                    ws_ippan_header.cell(row=i+1, column=16).value = ippan_header.underground_area
                    ws_ippan_header.cell(row=i+1, column=17).value = ippan_header.kasen_kaigan_code
                    ws_ippan_header.cell(row=i+1, column=18).value = ippan_header.crop_damage
                    ws_ippan_header.cell(row=i+1, column=19).value = ippan_header.weather_id

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### VLOOKUP用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 5/11.', 'DEBUG')
            ### 1020: 市区町村VLOOKUP
            print("create_ippan_chosa_workbook_5_1", flush=True)
            if bool(ken_list) == True and bool(cities_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_city_vlook.cell(row=i+1, column=1).value = str(ken.ken_name) + ":" + str(ken.ken_code)
        
                for i, cities in enumerate(cities_list):
                    ws_city_vlook.cell(row=i+1, column=2).value = 'CITY!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(cities)
    
            ### 1060: 河川（河川・海岸）VLOOKUP
            print("create_ippan_chosa_workbook_5_2", flush=True)
            if bool(suikei_list) == True and bool(kasens_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_kasen_vlook.cell(row=i+1, column=1).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
    
                for i, kasens in enumerate(kasens_list):
                    ws_kasen_vlook.cell(row=i+1, column=2).value = 'KASEN!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(kasens)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 6/11.', 'DEBUG')
            for i in range(ippan_header_count + 10 + 1):
                ws_ippan[i].cell(row=5, column=2).value = '都道府県'
                ws_ippan[i].cell(row=5, column=3).value = '市区町村'
                ws_ippan[i].cell(row=5, column=4).value = '水害発生年月日'
                ws_ippan[i].cell(row=5, column=5).value = '水害終了年月日'
                ws_ippan[i].cell(row=5, column=6).value = '水害原因'
                ws_ippan[i].cell(row=5, column=9).value = '水害区域番号'
                ws_ippan[i].cell(row=6, column=6).value = '1'
                ws_ippan[i].cell(row=6, column=7).value = '2'
                ws_ippan[i].cell(row=6, column=8).value = '3'
                ws_ippan[i].cell(row=9, column=2).value = '水系・沿岸名'
                ws_ippan[i].cell(row=9, column=3).value = '水系種別'
                ws_ippan[i].cell(row=9, column=4).value = '河川・海岸名'
                ws_ippan[i].cell(row=9, column=5).value = '河川種別'
                ws_ippan[i].cell(row=9, column=6).value = '地盤勾配区分※1'
                ws_ippan[i].cell(row=12, column=2).value = '水害区域面積（m2）'
                ws_ippan[i].cell(row=12, column=6).value = '工種'
                ws_ippan[i].cell(row=12, column=8).value = '農作物被害額（千円）'
                ws_ippan[i].cell(row=12, column=10).value = '異常気象コード'
                ws_ippan[i].cell(row=16, column=2).value = '町丁名・大字名'
                ws_ippan[i].cell(row=16, column=3).value = '名称'
                ws_ippan[i].cell(row=16, column=4).value = '地上・地下被害の区分※2'
                ws_ippan[i].cell(row=16, column=5).value = '浸水土砂被害の区分※3'
                ws_ippan[i].cell(row=16, column=6).value = '被害建物棟数'
                ws_ippan[i].cell(row=16, column=12).value = '被害建物の延床面積（m2）'
                ws_ippan[i].cell(row=16, column=13).value = '被災世帯数'
                ws_ippan[i].cell(row=16, column=14).value = '被災事業所数'
                ws_ippan[i].cell(row=16, column=15).value = '被害建物内での農業家又は事業所活動'
                ws_ippan[i].cell(row=16, column=25).value = '事業所の産業区分※7'
                ws_ippan[i].cell(row=16, column=26).value = '地下空間の利用形態※8'
                ws_ippan[i].cell(row=16, column=27).value = '備考'
                ws_ippan[i].cell(row=17, column=7).value = '床上浸水・土砂堆積・地下浸水'
                ws_ippan[i].cell(row=17, column=15).value = '農家・漁家戸数※5'
                ws_ippan[i].cell(row=17, column=20).value = '事業所従業者数※6'
                ws_ippan[i].cell(row=18, column=16).value = '床上浸水'
                ws_ippan[i].cell(row=18, column=21).value = '床上浸水'
                ws_ippan[i].cell(row=20, column=7).value = '1cm〜49cm'
                ws_ippan[i].cell(row=20, column=8).value = '50cm〜99cm'
                ws_ippan[i].cell(row=20, column=9).value = '1m以上'
                ws_ippan[i].cell(row=20, column=10).value = '半壊※4'
                ws_ippan[i].cell(row=20, column=11).value = '全壊・流失※4'
                ws_ippan[i].cell(row=20, column=16).value = '1cm〜49cm'
                ws_ippan[i].cell(row=20, column=17).value = '50cm〜99cm'
                ws_ippan[i].cell(row=20, column=18).value = '1m以上半壊'
                ws_ippan[i].cell(row=20, column=19).value = '全壊・流失'
                ws_ippan[i].cell(row=20, column=21).value = '1cm〜49cm'
                ws_ippan[i].cell(row=20, column=22).value = '50cm〜99cm'
                ws_ippan[i].cell(row=20, column=23).value = '1m以上半壊'
                ws_ippan[i].cell(row=20, column=24).value = '全壊・流失'
                ws_ippan[i].cell(row=7, column=2).value = ""
                ws_ippan[i].cell(row=7, column=3).value = ""
                ws_ippan[i].cell(row=7, column=4).value = ""
                ws_ippan[i].cell(row=7, column=5).value = ""
                ws_ippan[i].cell(row=7, column=6).value = ""
                ws_ippan[i].cell(row=7, column=7).value = ""
                ws_ippan[i].cell(row=7, column=8).value = ""
                ws_ippan[i].cell(row=7, column=9).value = ""
                ws_ippan[i].cell(row=10, column=2).value = ""
                ws_ippan[i].cell(row=10, column=3).value = ""
                ws_ippan[i].cell(row=10, column=4).value = ""
                ws_ippan[i].cell(row=10, column=5).value = ""
                ws_ippan[i].cell(row=10, column=6).value = ""
                ws_ippan[i].cell(row=14, column=2).value = ""
                ws_ippan[i].cell(row=14, column=3).value = ""
                ws_ippan[i].cell(row=14, column=4).value = ""
                ws_ippan[i].cell(row=14, column=6).value = ""
                ws_ippan[i].cell(row=14, column=8).value = ""
                ws_ippan[i].cell(row=14, column=10).value = ""
                ws_ippan[i].cell(row=20, column=2).value = ""
                ws_ippan[i].cell(row=20, column=3).value = ""
                ws_ippan[i].cell(row=20, column=4).value = ""
                ws_ippan[i].cell(row=20, column=5).value = ""
                ws_ippan[i].cell(row=20, column=6).value = ""
                ws_ippan[i].cell(row=20, column=7).value = ""
                ws_ippan[i].cell(row=20, column=8).value = ""
                ws_ippan[i].cell(row=20, column=9).value = ""
                ws_ippan[i].cell(row=20, column=10).value = ""
                ws_ippan[i].cell(row=20, column=11).value = ""
                ws_ippan[i].cell(row=20, column=12).value = ""
                ws_ippan[i].cell(row=20, column=13).value = ""
                ws_ippan[i].cell(row=20, column=14).value = ""
                ws_ippan[i].cell(row=20, column=15).value = ""
                ws_ippan[i].cell(row=20, column=16).value = ""
                ws_ippan[i].cell(row=20, column=17).value = ""
                ws_ippan[i].cell(row=20, column=18).value = ""
                ws_ippan[i].cell(row=20, column=19).value = ""
                ws_ippan[i].cell(row=20, column=20).value = ""
                ws_ippan[i].cell(row=20, column=21).value = ""
                ws_ippan[i].cell(row=20, column=22).value = ""
                ws_ippan[i].cell(row=20, column=23).value = ""
                ws_ippan[i].cell(row=20, column=24).value = ""
                ws_ippan[i].cell(row=20, column=25).value = ""
                ws_ippan[i].cell(row=20, column=26).value = ""
                ws_ippan[i].cell(row=20, column=27).value = ""

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0060)
            ### 入力データ用のEXCELシートの背景をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 7/11.', 'DEBUG')
            gray_fill = PatternFill(bgColor='C0C0C0', fill_type='solid')
            white_fill = PatternFill(bgColor='FFFFFF', fill_type='solid')
    
            for i in range(ippan_header_count + 10 + 1):
                ws_ippan[i].conditional_formatting.add('N20:Y1000', FormulaRule(formula=['$C20="戸建住宅:1"'], fill=gray_fill))
                ws_ippan[i].conditional_formatting.add('N20:Y1000', FormulaRule(formula=['$C20="共同住宅:2"'], fill=gray_fill))
                ws_ippan[i].conditional_formatting.add('N20:Y1000', FormulaRule(formula=['$C20="事業所併用住宅:3"'], fill=white_fill))
                ws_ippan[i].conditional_formatting.add('M20:M1000', FormulaRule(formula=['$C20="事業所:4"'], fill=gray_fill))
                ws_ippan[i].conditional_formatting.add('M20:N1000', FormulaRule(formula=['$C20="その他建物:5"'], fill=gray_fill))
                ws_ippan[i].conditional_formatting.add('T20:Y1000', FormulaRule(formula=['$C20="その他建物:5"'], fill=gray_fill))
                ws_ippan[i].conditional_formatting.add('F20:Z1000', FormulaRule(formula=['$C20="建物以外:6"'], fill=gray_fill))

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0070)
            ### 入力データ用のEXCELシートのプルダウンリストをセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 8/11.', 'DEBUG')
            for i in range(ippan_header_count + 10 + 1):
                ### 1000: 建物区分
                if len(building_list) > 0:
                    dv_building = DataValidation(type="list", formula1="BUILDING!$B$1:$B$%d" % len(building_list))
                    dv_building.ranges = 'C20:C1000'
                    ws_ippan[i].add_data_validation(dv_building)
        
                ### 1010: 都道府県
                if len(ken_list) > 0:
                    dv_ken = DataValidation(type="list", formula1="KEN!$B$1:$B$%d" % len(ken_list))
                    dv_ken.ranges = 'B7:B7'
                    ws_ippan[i].add_data_validation(dv_ken)
                
                ### 1020: 市区町村
                dv_city = DataValidation(type="list", formula1="=INDIRECT(AD3)")
                dv_city.ranges = 'C7:C7'
                ws_ippan[i].add_data_validation(dv_city)
                ### ws_ippan.cell(row=3, column=30).value = "=VLOOKUP(B7,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
                ws_ippan[i].cell(row=3, column=30).value = "=VLOOKUP(B7,CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS
                
                ### 1030: 水害発生地点工種（河川海岸区分）
                if len(kasen_kaigan_list) > 0:
                    dv_kasen_kaigan = DataValidation(type="list", formula1="KASEN_KAIGAN!$B$1:$B$%d" % len(kasen_kaigan_list))
                    dv_kasen_kaigan.ranges = 'F14:F14'
                    ws_ippan[i].add_data_validation(dv_kasen_kaigan)
                
                ### 1040: 水系（水系・沿岸）
                if len(suikei_list) > 0:
                    dv_suikei = DataValidation(type="list", formula1="SUIKEI!$B$1:$B$%d" % len(suikei_list))
                    dv_suikei.ranges = 'B10:B10'
                    ws_ippan[i].add_data_validation(dv_suikei)
                
                ### 1050: 水系種別（水系・沿岸種別）
                if len(suikei_type_list) > 0:
                    dv_suikei_type = DataValidation(type="list", formula1="SUIKEI_TYPE!$B$1:$B$%d" % len(suikei_type_list))
                    dv_suikei_type.ranges = 'C10:C10'
                    ws_ippan[i].add_data_validation(dv_suikei_type)
                
                ### 1060: 河川（河川・海岸）
                dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AD4)")
                dv_kasen.ranges = 'D10:D10'
                ws_ippan[i].add_data_validation(dv_kasen)
                ### ws_ippan.cell(row=4, column=30).value = "=VLOOKUP(B10,KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
                ws_ippan[i].cell(row=4, column=30).value = "=VLOOKUP(B10,KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS
                
                ### 1070: 河川種別（河川・海岸種別）
                if len(kasen_type_list) > 0:
                    dv_kasen_type = DataValidation(type="list", formula1="KASEN_TYPE!$B$1:$B$%d" % len(kasen_type_list))
                    dv_kasen_type.ranges = 'E10:E10'
                    ws_ippan[i].add_data_validation(dv_kasen_type)
                
                ### 1080: 水害原因
                if len(cause_list) > 0:
                    dv_cause = DataValidation(type="list", formula1="CAUSE!$B$1:$B$%d" % len(cause_list))
                    dv_cause.ranges = 'F7:H7'
                    ws_ippan[i].add_data_validation(dv_cause)
                
                ### 1090: 地上地下区分
                if len(underground_list) > 0:
                    dv_underground = DataValidation(type="list", formula1="UNDERGROUND!$B$1:$B$%d" % len(underground_list))
                    dv_underground.ranges = 'D20:D1000'
                    ws_ippan[i].add_data_validation(dv_underground)
                
                ### 1100: 地下空間の利用形態
                if len(usage_list) > 0:
                    dv_usage = DataValidation(type="list", formula1="USAGE!$B$1:$B$%d" % len(usage_list))
                    dv_usage.ranges = 'Z20:Z1000'
                    ws_ippan[i].add_data_validation(dv_usage)
                
                ### 1110: 浸水土砂区分
                if len(flood_sediment_list) > 0:
                    dv_flood_sediment = DataValidation(type="list", formula1="FLOOD_SEDIMENT!$B$1:$B$%d" % len(flood_sediment_list))
                    dv_flood_sediment.ranges = 'E20:E1000'
                    ws_ippan[i].add_data_validation(dv_flood_sediment)
                
                ### 1120: 地盤勾配区分
                if len(gradient_list) > 0:
                    dv_gradient = DataValidation(type="list", formula1="GRADIENT!$B$1:$B$%d" % len(gradient_list))
                    dv_gradient.ranges = 'F10:F10'
                    ws_ippan[i].add_data_validation(dv_gradient)
                
                ### 1130: 産業分類
                if len(industry_list) > 0:
                    dv_industry = DataValidation(type="list", formula1="INDUSTRY!$B$1:$B$%d" % len(industry_list))
                    dv_industry.ranges = 'Y20:Y1000'
                    ws_ippan[i].add_data_validation(dv_industry)
    
                ### 7000: 入力データ_水害区域
                if len(area_list) > 0:
                    dv_area = DataValidation(type="list", formula1="AREA!$B$1:$B$%d" % len(area_list))
                    dv_area.ranges = 'I7:I7'
                    ws_ippan[i].add_data_validation(dv_area)
                
                ### 7010: 入力データ_異常気象
                if len(weather_list) > 0:
                    dv_weather = DataValidation(type="list", formula1="WEATHER!$B$1:$B$%d" % len(weather_list))
                    dv_weather.ranges = 'J14:J14'
                    ws_ippan[i].add_data_validation(dv_weather)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0080)
            ### 入力データ用のEXCELシートに値をセットする。
            ### ※IPPANシート数分＝IPPAN_HEADER_COUNT+10+1分＝IPPAN_HEADER_ID_LIST、IPPAN_HEADER_NAME_LISTの数+10+1分ループする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 9/11.', 'DEBUG')
            ### 7020: 入力データ_ヘッダ部分、水害 TODO TO-DO TO_DO
            ### for i in range(ippan_header_count + 10 + 1):
            ###     if len(str(ken_name)) > 0 and len(str(ken_code)) > 0:
            ###         ws_ippan[i].cell(row=7, column=2).value = str(ken_name) + ":" + str(ken_code)
            ###     else:
            ###         ws_ippan[i].cell(row=7, column=2).value = ""
                    
            ###     if len(str(city_name)) > 0 and len(str(city_code)) > 0:
            ###         ws_ippan[i].cell(row=7, column=3).value = str(city_name) + ":" + str(city_code)
            ###     else:
            ###         ws_ippan[i].cell(row=7, column=3).value = ""
      
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0090)
            ### 入力データ用のEXCELシートに値をセットする。
            ### ※IPPANシート数分＝IPPAN_HEADER_COUNT+10+1分＝IPPAN_HEADER_ID_LIST、IPPAN_HEADER_NAME_LISTの数+10+1分ループする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 10/11.', 'DEBUG')
            ### 7020: 入力データ_ヘッダ部分、水害
            for i, ippan_header in enumerate(ippan_header_list):
                #==============================================================
                # 入力データ_ヘッダ部分のデータを取得する。
                #==============================================================
                print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 10_1/11.', 'DEBUG')
                db_params = dict({
                    'IPPAN_HEADER_ID': ippan_header.ippan_header_id
                })
                local_ippan_header_list = IPPAN_HEADER.objects.raw("""
                    SELECT 
                        IPP1.IPPAN_HEADER_ID AS IPPAN_HEADER_ID,
                        IPP1.IPPAN_HEADER_NAME AS IPPAN_HEADER_NAME,
                        IPP1.KEN_CODE AS KEN_CODE, 
                        KEN1.KEN_NAME AS KEN_NAME,
                        IPP1.CITY_CODE AS CITY_CODE,
                        CIT1.CITY_NAME AS CITY_NAME,
                        TO_CHAR(TIMEZONE('JST', IPP1.BEGIN_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS BEGIN_DATE,
                        TO_CHAR(TIMEZONE('JST', IPP1.END_DATE::TIMESTAMPTZ), 'YYYY/MM/DD') AS END_DATE,
                        IPP1.CAUSE_1_CODE AS CAUSE_1_CODE,
                        CAU1.CAUSE_NAME AS CAUSE_1_NAME,
                        IPP1.CAUSE_2_CODE AS CAUSE_2_CODE,
                        CAU2.CAUSE_NAME AS CAUSE_2_NAME,
                        IPP1.CAUSE_3_CODE AS CAUSE_3_CODE,
                        CAU3.CAUSE_NAME AS CAUSE_3_NAME,
                        IPP1.AREA_ID AS AREA_ID,
                        ARE1.AREA_NAME AS AREA_NAME,
                        IPP1.SUIKEI_CODE AS SUIKEI_CODE,
                        SUI1.SUIKEI_NAME AS SUIKEI_NAME,
                        SUT1.SUIKEI_TYPE_CODE AS SUIKEI_TYPE_CODE,
                        SUT1.SUIKEI_TYPE_NAME AS SUIKEI_TYPE_NAME,
                        IPP1.KASEN_CODE AS KASEN_CODE,
                        KAS1.KASEN_NAME AS KASEN_NAME,
                        KAT1.KASEN_TYPE_CODE AS KASEN_TYPE_CODE,
                        KAT1.KASEN_TYPE_NAME AS KASEN_TYPE_NAME,
                        IPP1.GRADIENT_CODE AS GRADIENT_CODE,
                        GRA1.GRADIENT_NAME AS GRADIENT_NAME,
                        CASE WHEN (IPP1.RESIDENTIAL_AREA) IS NULL THEN NULL ELSE CAST(IPP1.RESIDENTIAL_AREA AS NUMERIC(20,10)) END AS RESIDENTIAL_AREA,
                        CASE WHEN (IPP1.AGRICULTURAL_AREA) IS NULL THEN NULL ELSE CAST(IPP1.AGRICULTURAL_AREA AS NUMERIC(20,10)) END AS AGRICULTURAL_AREA,
                        CASE WHEN (IPP1.UNDERGROUND_AREA) IS NULL THEN NULL ELSE CAST(IPP1.UNDERGROUND_AREA AS NUMERIC(20,10)) END AS UNDERGROUND_AREA,
                        IPP1.KASEN_KAIGAN_CODE AS KASEN_KAIGAN_CODE,
                        KAK1.KASEN_KAIGAN_NAME AS KASEN_KAIGAN_NAME,
                        CASE WHEN (IPP1.CROP_DAMAGE) IS NULL THEN NULL ELSE CAST(IPP1.CROP_DAMAGE AS NUMERIC(20,10)) END AS CROP_DAMAGE,
                        IPP1.WEATHER_ID AS WEATHER_ID,
                        WEA1.WEATHER_NAME AS WEATHER_NAME
                    FROM IPPAN_HEADER IPP1 
                    LEFT JOIN KEN KEN1 ON IPP1.KEN_CODE=KEN1.KEN_CODE 
                    LEFT JOIN CITY CIT1 ON IPP1.CITY_CODE=CIT1.CITY_CODE 
                    LEFT JOIN CAUSE CAU1 ON IPP1.CAUSE_1_CODE=CAU1.CAUSE_CODE 
                    LEFT JOIN CAUSE CAU2 ON IPP1.CAUSE_2_CODE=CAU2.CAUSE_CODE 
                    LEFT JOIN CAUSE CAU3 ON IPP1.CAUSE_3_CODE=CAU3.CAUSE_CODE 
                    LEFT JOIN AREA ARE1 ON IPP1.AREA_ID=ARE1.AREA_ID 
                    LEFT JOIN SUIKEI SUI1 ON IPP1.SUIKEI_CODE=SUI1.SUIKEI_CODE 
                    LEFT JOIN SUIKEI_TYPE SUT1 ON SUI1.SUIKEI_TYPE_CODE=SUT1.SUIKEI_TYPE_CODE 
                    LEFT JOIN KASEN KAS1 ON IPP1.KASEN_CODE=KAS1.KASEN_CODE 
                    LEFT JOIN KASEN_TYPE KAT1 ON KAS1.KASEN_TYPE_CODE=KAT1.KASEN_TYPE_CODE 
                    LEFT JOIN GRADIENT GRA1 ON IPP1.GRADIENT_CODE=GRA1.GRADIENT_CODE 
                    LEFT JOIN KASEN_KAIGAN KAK1 ON IPP1.KASEN_KAIGAN_CODE=KAK1.KASEN_KAIGAN_CODE 
                    LEFT JOIN WEATHER WEA1 ON IPP1.WEATHER_ID=WEA1.WEATHER_ID 
                    WHERE 
                        IPP1.IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s LIMIT 1""", db_params)

                #==============================================================
                # 入力データ_一覧表部分のデータを取得する。
                #==============================================================
                print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 10_2/11.', 'DEBUG')
                db_params = dict({
                    'IPPAN_HEADER_ID': ippan_header.ippan_header_id
                })
                ippan_list = IPPAN.objects.raw("""
                    SELECT 
                        IPP1.IPPAN_ID AS IPPAN_ID,
                        IPP1.IPPAN_NAME AS IPPAN_NAME,
                        IPP1.BUILDING_CODE AS BUILDING_CODE,
                        BUI1.BUILDING_NAME AS BUILDING_NAME,
                        IPP1.UNDERGROUND_CODE AS UNDERGROUND_CODE,
                        UND1.UNDERGROUND_NAME AS UNDERGROUND_NAME,
                        IPP1.FLOOD_SEDIMENT_CODE AS FLOOD_SEDIMENT_CODE,
                        FLO1.FLOOD_SEDIMENT_NAME AS FLOOD_SEDIMENT_NAME,
                        CASE WHEN (IPP1.BUILDING_LV00) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_LV00 AS NUMERIC(20,10)) END AS BUILDING_LV00,
                        CASE WHEN (IPP1.BUILDING_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_LV01_49 AS NUMERIC(20,10)) END AS BUILDING_LV01_49,
                        CASE WHEN (IPP1.BUILDING_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_LV50_99 AS NUMERIC(20,10)) END AS BUILDING_LV50_99,
                        CASE WHEN (IPP1.BUILDING_LV100) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_LV100 AS NUMERIC(20,10)) END AS BUILDING_LV100,
                        CASE WHEN (IPP1.BUILDING_HALF) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_HALF AS NUMERIC(20,10)) END AS BUILDING_HALF,
                        CASE WHEN (IPP1.BUILDING_FULL) IS NULL THEN NULL ELSE CAST(IPP1.BUILDING_FULL AS NUMERIC(20,10)) END AS BUILDING_FULL,
                        CASE WHEN (IPP1.FLOOR_AREA) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA AS NUMERIC(20,10)) END AS FLOOR_AREA,
                        CASE WHEN (IPP1.FAMILY) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY AS NUMERIC(20,10)) END AS FAMILY,
                        CASE WHEN (IPP1.OFFICE) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE AS NUMERIC(20,10)) END AS OFFICE,
                        CASE WHEN (IPP1.FLOOR_AREA_LV00) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_LV00 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV00,
                        CASE WHEN (IPP1.FLOOR_AREA_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_LV01_49 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV01_49,
                        CASE WHEN (IPP1.FLOOR_AREA_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_LV50_99 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV50_99,
                        CASE WHEN (IPP1.FLOOR_AREA_LV100) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_LV100 AS NUMERIC(20,10)) END AS FLOOR_AREA_LV100,
                        CASE WHEN (IPP1.FLOOR_AREA_HALF) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_HALF AS NUMERIC(20,10)) END AS FLOOR_AREA_HALF,
                        CASE WHEN (IPP1.FLOOR_AREA_FULL) IS NULL THEN NULL ELSE CAST(IPP1.FLOOR_AREA_FULL AS NUMERIC(20,10)) END AS FLOOR_AREA_FULL,
                        CASE WHEN (IPP1.FAMILY_LV00) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_LV00 AS NUMERIC(20,10)) END AS FAMILY_LV00,
                        CASE WHEN (IPP1.FAMILY_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_LV01_49 AS NUMERIC(20,10)) END AS FAMILY_LV01_49,
                        CASE WHEN (IPP1.FAMILY_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_LV50_99 AS NUMERIC(20,10)) END AS FAMILY_LV50_99,
                        CASE WHEN (IPP1.FAMILY_LV100) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_LV100 AS NUMERIC(20,10)) END AS FAMILY_LV100,
                        CASE WHEN (IPP1.FAMILY_HALF) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_HALF AS NUMERIC(20,10)) END AS FAMILY_HALF,
                        CASE WHEN (IPP1.FAMILY_FULL) IS NULL THEN NULL ELSE CAST(IPP1.FAMILY_FULL AS NUMERIC(20,10)) END AS FAMILY_FULL,
                        CASE WHEN (IPP1.OFFICE_LV00) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_LV00 AS NUMERIC(20,10)) END AS OFFICE_LV00,
                        CASE WHEN (IPP1.OFFICE_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_LV01_49 AS NUMERIC(20,10)) END AS OFFICE_LV01_49,
                        CASE WHEN (IPP1.OFFICE_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_LV50_99 AS NUMERIC(20,10)) END AS OFFICE_LV50_99,
                        CASE WHEN (IPP1.OFFICE_LV100) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_LV100 AS NUMERIC(20,10)) END AS OFFICE_LV100,
                        CASE WHEN (IPP1.OFFICE_HALF) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_HALF AS NUMERIC(20,10)) END AS OFFICE_HALF,
                        CASE WHEN (IPP1.OFFICE_FULL) IS NULL THEN NULL ELSE CAST(IPP1.OFFICE_FULL AS NUMERIC(20,10)) END AS OFFICE_FULL,
                        CASE WHEN (IPP1.FARMER_FISHER_LV00) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_LV00 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV00,
                        CASE WHEN (IPP1.FARMER_FISHER_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_LV01_49 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV01_49,
                        CASE WHEN (IPP1.FARMER_FISHER_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_LV50_99 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV50_99,
                        CASE WHEN (IPP1.FARMER_FISHER_LV100) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_LV100 AS NUMERIC(20,10)) END AS FARMER_FISHER_LV100,
                        CASE WHEN (IPP1.FARMER_FISHER_FULL) IS NULL THEN NULL ELSE CAST(IPP1.FARMER_FISHER_FULL AS NUMERIC(20,10)) END AS FARMER_FISHER_FULL,
                        CASE WHEN (IPP1.EMPLOYEE_LV00) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_LV00 AS NUMERIC(20,10)) END AS EMPLOYEE_LV00,
                        CASE WHEN (IPP1.EMPLOYEE_LV01_49) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_LV01_49 AS NUMERIC(20,10)) END AS EMPLOYEE_LV01_49,
                        CASE WHEN (IPP1.EMPLOYEE_LV50_99) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_LV50_99 AS NUMERIC(20,10)) END AS EMPLOYEE_LV50_99,
                        CASE WHEN (IPP1.EMPLOYEE_LV100) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_LV100 AS NUMERIC(20,10)) END AS EMPLOYEE_LV100,
                        CASE WHEN (IPP1.EMPLOYEE_FULL) IS NULL THEN NULL ELSE CAST(IPP1.EMPLOYEE_FULL AS NUMERIC(20,10)) END AS EMPLOYEE_FULL,
                        IPP1.INDUSTRY_CODE AS INDUSTRY_CODE,
                        IND1.INDUSTRY_NAME AS INDUSTRY_NAME,
                        IPP1.USAGE_CODE AS USAGE_CODE,
                        USA1.USAGE_NAME AS USAGE_NAME,
                        IPP1.COMMENT AS COMMENT 
                    FROM IPPAN_VIEW IPP1 
                    LEFT JOIN BUILDING BUI1 ON IPP1.BUILDING_CODE=BUI1.BUILDING_CODE 
                    LEFT JOIN UNDERGROUND UND1 ON IPP1.UNDERGROUND_CODE=UND1.UNDERGROUND_CODE 
                    LEFT JOIN FLOOD_SEDIMENT FLO1 ON IPP1.FLOOD_SEDIMENT_CODE=FLO1.FLOOD_SEDIMENT_CODE 
                    LEFT JOIN INDUSTRY IND1 ON IPP1.INDUSTRY_CODE=IND1.INDUSTRY_CODE 
                    LEFT JOIN USAGE USA1 ON IPP1.USAGE_CODE=USA1.USAGE_CODE 
                    WHERE 
                        IPP1.IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s 
                    ORDER BY 
                        CAST (IPP1.IPPAN_ID AS INTEGER)""", db_params)

                ###############################################################
                ### EXCELのヘッダ部のセルに、入力データ_ヘッダ部分の値を埋め込む。
                ### ※ k ループの回数＝1
                ###############################################################
                print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 10_3/11.', 'DEBUG')
                if bool(local_ippan_header_list) == True:
                    for k, local_ippan_header in enumerate(local_ippan_header_list):
                        if (bool(str(local_ippan_header.ken_name)) and 
                            bool(str(local_ippan_header.ken_code)) and 
                            bool(local_ippan_header.ken_name) and 
                            bool(local_ippan_header.ken_code)):
                            ws_ippan[i].cell(row=7, column=2).value = (
                                str(local_ippan_header.ken_name) + ":" + 
                                str(local_ippan_header.ken_code)
                            )
                        
                        if (bool(str(local_ippan_header.city_name)) and 
                            bool(str(local_ippan_header.city_code)) and 
                            bool(local_ippan_header.city_name) and 
                            bool(local_ippan_header.city_code)):
                            ws_ippan[i].cell(row=7, column=3).value = (
                                str(local_ippan_header.city_name) + ":" + 
                                str(local_ippan_header.city_code)
                            )
    
                        if (bool(str(local_ippan_header.begin_date)) and 
                            bool(local_ippan_header.begin_date)):
                            ws_ippan[i].cell(row=7, column=4).value = (
                                str(local_ippan_header.begin_date)
                            )
    
                        if (bool(str(local_ippan_header.end_date)) and 
                            bool(local_ippan_header.end_date)):
                            ws_ippan[i].cell(row=7, column=5).value = (
                                str(local_ippan_header.end_date)
                            )
    
                        if (bool(str(local_ippan_header.cause_1_name)) and 
                            bool(str(local_ippan_header.cause_1_code)) and 
                            bool(local_ippan_header.cause_1_name) and 
                            bool(local_ippan_header.cause_1_code)):
                            ws_ippan[i].cell(row=7, column=6).value = (
                                str(local_ippan_header.cause_1_name) + ":" + 
                                str(local_ippan_header.cause_1_code)
                            )
    
                        if (bool(str(local_ippan_header.cause_2_name)) and 
                            bool(str(local_ippan_header.cause_2_code)) and 
                            bool(local_ippan_header.cause_2_name) and 
                            bool(local_ippan_header.cause_2_code)):
                            ws_ippan[i].cell(row=7, column=7).value = (
                                str(local_ippan_header.cause_2_name) + ":" + 
                                str(local_ippan_header.cause_2_code)
                            )
    
                        if (bool(str(local_ippan_header.cause_3_name)) and 
                            bool(str(local_ippan_header.cause_3_code)) and 
                            bool(local_ippan_header.cause_3_name) and 
                            bool(local_ippan_header.cause_3_code)):
                            ws_ippan[i].cell(row=7, column=8).value = (
                                str(local_ippan_header.cause_3_name) + ":" + 
                                str(local_ippan_header.cause_3_code)
                            )
    
                        if (bool(str(local_ippan_header.area_name)) and 
                            bool(str(local_ippan_header.area_id)) and 
                            bool(local_ippan_header.area_name) and 
                            bool(local_ippan_header.area_id)):
                            ws_ippan[i].cell(row=7, column=9).value = (
                                str(local_ippan_header.area_name) + ":" + 
                                str(local_ippan_header.area_id)
                            )
    
                        if (bool(str(local_ippan_header.suikei_name)) and 
                            bool(str(local_ippan_header.suikei_code)) and 
                            bool(local_ippan_header.suikei_name) and 
                            bool(local_ippan_header.suikei_code)):
                            ws_ippan[i].cell(row=10, column=2).value = (
                                str(local_ippan_header.suikei_name) + ":" + 
                                str(local_ippan_header.suikei_code)
                            )
    
                        if (bool(str(local_ippan_header.suikei_type_name)) and 
                            bool(str(local_ippan_header.suikei_type_code)) and 
                            bool(local_ippan_header.suikei_type_name) and 
                            bool(local_ippan_header.suikei_type_code)):
                            ws_ippan[i].cell(row=10, column=3).value = (
                                str(local_ippan_header.suikei_type_name) + ":" + 
                                str(local_ippan_header.suikei_type_code)
                            )
    
                        if (bool(str(local_ippan_header.kasen_name)) and 
                            bool(str(local_ippan_header.kasen_code)) and 
                            bool(local_ippan_header.kasen_name) and
                            bool(local_ippan_header.kasen_code)):
                            ws_ippan[i].cell(row=10, column=4).value = (
                                str(local_ippan_header.kasen_name) + ":" + 
                                str(local_ippan_header.kasen_code)
                            )
    
                        if (bool(str(local_ippan_header.kasen_type_name)) and 
                            bool(str(local_ippan_header.kasen_type_code)) and 
                            bool(local_ippan_header.kasen_type_name) and 
                            bool(local_ippan_header.kasen_type_code)):
                            ws_ippan[i].cell(row=10, column=5).value = (
                                str(local_ippan_header.kasen_type_name) + ":" + 
                                str(local_ippan_header.kasen_type_code)
                            )
    
                        if (bool(str(local_ippan_header.gradient_name)) and 
                            bool(str(local_ippan_header.gradient_code)) and 
                            bool(local_ippan_header.gradient_name) and 
                            bool(local_ippan_header.gradient_code)):
                            ws_ippan[i].cell(row=10, column=6).value = (
                                str(local_ippan_header.gradient_name) + ":" + 
                                str(local_ippan_header.gradient_code)
                            )
    
                        if (bool(str(local_ippan_header.residential_area)) and 
                            bool(local_ippan_header.residential_area)):
                            ws_ippan[i].cell(row=14, column=2).value = (
                                str(local_ippan_header.residential_area)
                            )
    
                        if (bool(str(local_ippan_header.agricultural_area)) and 
                            bool(local_ippan_header.agricultural_area)):
                            ws_ippan[i].cell(row=14, column=3).value = (
                                str(local_ippan_header.agricultural_area)
                            )
    
                        if (bool(str(local_ippan_header.underground_area)) and
                            bool(local_ippan_header.underground_area)):
                            ws_ippan[i].cell(row=14, column=4).value = (
                                str(local_ippan_header.underground_area)
                            )
    
                        if (bool(str(local_ippan_header.kasen_kaigan_name)) and 
                            bool(str(local_ippan_header.kasen_kaigan_code)) and 
                            bool(local_ippan_header.kasen_kaigan_name) and 
                            bool(local_ippan_header.kasen_kaigan_code)):
                            ws_ippan[i].cell(row=14, column=6).value = (
                                str(local_ippan_header.kasen_kaigan_name) + ":" + 
                                str(local_ippan_header.kasen_kaigan_code)
                            )
    
                        if (bool(str(local_ippan_header.crop_damage)) and 
                            bool(local_ippan_header.crop_damage)):
                            ws_ippan[i].cell(row=14, column=8).value = (
                                str(local_ippan_header.crop_damage)
                            )
    
                        if (bool(str(local_ippan_header.weather_name)) and 
                            bool(str(local_ippan_header.weather_id)) and 
                            bool(local_ippan_header.weather_name) and 
                            bool(local_ippan_header.weather_id)):
                            ws_ippan[i].cell(row=14, column=10).value = (
                                str(local_ippan_header.weather_name) + ":" + 
                                str(local_ippan_header.weather_id)
                            )
    
                        if (bool(str(local_ippan_header.ippan_header_id)) and 
                            bool(local_ippan_header.ippan_header_id)):
                            ws_ippan[i].cell(row=3, column=28).value = (
                                local_ippan_header.ippan_header_id
                            )

                ###############################################################
                ### EXCELの一覧部のセルに、入力データ_一覧部分の値を埋め込む。
                ### ※ k ループの回数＝行数
                ###############################################################
                print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 10_4/11.', 'DEBUG')
                if bool(ippan_list) == True:
                    for k, ippan in enumerate(ippan_list):
                        if (bool(str(ippan.ippan_name)) == True):
                            ws_ippan[i].cell(row=k+20, column=2).value = (
                                str(ippan.ippan_name)
                            )
                        
                        if (bool(str(ippan.building_name)) == True and 
                            bool(str(ippan.building_code)) == True):
                            ws_ippan[i].cell(row=k+20, column=3).value = (
                                str(ippan.building_name) + ":" + 
                                str(ippan.building_code)
                            )
    
                        if (bool(str(ippan.underground_name)) == True and 
                            bool(str(ippan.underground_code)) == True):
                            ws_ippan[i].cell(row=k+20, column=4).value = (
                                str(ippan.underground_name) + ":" + 
                                str(ippan.underground_code)
                            )
    
                        if (bool(str(ippan.flood_sediment_name)) == True and 
                            bool(str(ippan.flood_sediment_code)) == True):
                            ws_ippan[i].cell(row=k+20, column=5).value = (
                                str(ippan.flood_sediment_name) + ":" + 
                                str(ippan.flood_sediment_code)
                            )
    
                        if (bool(str(ippan.building_lv00)) == True):
                            ws_ippan[i].cell(row=k+20, column=6).value = (
                                ippan.building_lv00
                            )
    
                        if (bool(str(ippan.building_lv01_49)) == True):
                            ws_ippan[i].cell(row=k+20, column=7).value = (
                                ippan.building_lv01_49
                            )
    
                        if (bool(str(ippan.building_lv50_99)) == True):
                            ws_ippan[i].cell(row=k+20, column=8).value = (
                                ippan.building_lv50_99
                            )
    
                        if (bool(str(ippan.building_lv100)) == True):
                            ws_ippan[i].cell(row=k+20, column=9).value = (
                                ippan.building_lv100
                            )
    
                        if (bool(str(ippan.building_half)) == True):
                            ws_ippan[i].cell(row=k+20, column=10).value = (
                                ippan.building_half
                            )
    
                        if (bool(str(ippan.building_full)) == True):
                            ws_ippan[i].cell(row=k+20, column=11).value = (
                                ippan.building_full
                            )
    
                        if (bool(str(ippan.floor_area)) == True):
                            ws_ippan[i].cell(row=k+20, column=12).value = (
                                ippan.floor_area
                            )
    
                        if (bool(str(ippan.family)) == True):
                            ws_ippan[i].cell(row=k+20, column=13).value = (
                                ippan.family
                            )
    
                        if (bool(str(ippan.office)) == True):
                            ws_ippan[i].cell(row=k+20, column=14).value = (
                                ippan.office
                            )
    
                        if (bool(str(ippan.farmer_fisher_lv00)) == True):
                            ws_ippan[i].cell(row=k+20, column=15).value = (
                                ippan.farmer_fisher_lv00
                            )
    
                        if (bool(str(ippan.farmer_fisher_lv01_49)) == True):
                            ws_ippan[i].cell(row=k+20, column=16).value = (
                                ippan.farmer_fisher_lv01_49
                            )
    
                        if (bool(str(ippan.farmer_fisher_lv50_99)) == True):
                            ws_ippan[i].cell(row=k+20, column=17).value = (
                                ippan.farmer_fisher_lv50_99
                            )
    
                        if (bool(str(ippan.farmer_fisher_lv100)) == True):
                            ws_ippan[i].cell(row=k+20, column=18).value = (
                                ippan.farmer_fisher_lv100
                            )
    
                        if (bool(str(ippan.farmer_fisher_full)) == True):
                            ws_ippan[i].cell(row=k+20, column=19).value = (
                                ippan.farmer_fisher_full
                            )
    
                        if (bool(str(ippan.employee_lv00)) == True):
                            ws_ippan[i].cell(row=k+20, column=20).value = (
                                ippan.employee_lv00
                            )
    
                        if (bool(str(ippan.employee_lv01_49)) == True):
                            ws_ippan[i].cell(row=k+20, column=21).value = (
                                ippan.employee_lv01_49
                            )
    
                        if (bool(str(ippan.employee_lv50_99)) == True):
                            ws_ippan[i].cell(row=k+20, column=22).value = (
                                ippan.employee_lv50_99
                            )
    
                        if (bool(str(ippan.employee_lv100)) == True):
                            ws_ippan[i].cell(row=k+20, column=23).value = (
                                ippan.employee_lv100
                            )
    
                        if (bool(str(ippan.employee_full)) == True):
                            ws_ippan[i].cell(row=k+20, column=24).value = (
                                ippan.employee_full
                            )
    
                        if (bool(str(ippan.industry_name)) == True and 
                            bool(str(ippan.industry_code)) == True):
                            ws_ippan[i].cell(row=k+20, column=25).value = (
                                str(ippan.industry_name) + ":" + 
                                str(ippan.industry_code)
                            )
    
                        if (bool(str(ippan.usage_name)) == True and 
                            bool(str(ippan.usage_code)) == True):
                            ws_ippan[i].cell(row=k+20, column=26).value = (
                                str(ippan.usage_name) + ":" + 
                                str(ippan.usage_code)
                            )
    
                        if (bool(str(ippan.comment)) == True):
                            ws_ippan[i].cell(row=k+20, column=27).value = (
                                ippan.comment
                            )
    
                        if (bool(str(ippan.ippan_id)) == True):
                            ws_ippan[i].cell(row=k+20, column=28).value = (
                                ippan.ippan_id
                            )

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0100)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 11/11.', 'DEBUG')
            print_log('[INFO] P0000Common.create_ippan_chosa_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
        
        except:
            return False, ""
        
    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_ippan_chosa_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        ### ※単数EXCELファイル、複数EXCELシートに対応するため、
        ### ※IPPAN_HEADER_ID(=1シートに対応)から、UPLOAD_FILE_PATHを経由して、IPPAN_HEADER_IDのリスト(=全シートに対応)を取得する。
        ### ※この処理の前提条件は、UPLOAD_FILE_PATHがユニークである必要があり、そのためにアップロード日時をファイル名に付与している。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 2/9.', 'DEBUG')
        db_params = dict({
            'IPPAN_HEADER_ID': func_params["IPPAN_HEADER_ID"]
        })
        local_ippan_header_list = IPPAN_HEADER.objects.raw("""
            SELECT 
                * 
            FROM IPPAN_HEADER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s LIMIT 1""", db_params)
        
        if bool(local_ippan_header_list) == False:
            print_log('[WARN] P0000Common.get_ippan_chosa_csv_excel()関数が警告終了しました。', 'WARN')
            return False, ""

        db_params = dict({
            'UPLOAD_FILE_PATH': local_ippan_header_list[0].upload_file_path
        })
        ippan_header_list = IPPAN_HEADER.objects.raw("""
            SELECT 
                * 
            FROM IPPAN_HEADER 
            WHERE 
                UPLOAD_FILE_PATH=%(UPLOAD_FILE_PATH)s
            ORDER BY CAST(IPPAN_HEADER_ID AS INTEGER)""", db_params)

        if bool(ippan_header_list) == False:
            print_log('[WARN] P0000Common.get_ippan_chosa_csv_excel()関数が警告終了しました。', 'WARN')
            return False, ""

        if bool(ippan_header_list) == True:
            ippan_header_count = len(ippan_header_list)
        else:
            ippan_header_count = 0

        #######################################################################
        ### DBアクセス処理(0020)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 3/9.', 'DEBUG')
        building_list = BUILDING.objects.raw("""SELECT * FROM BUILDING ORDER BY CAST(BUILDING_CODE AS INTEGER)""")
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(KASEN_KAIGAN_CODE AS INTEGER)""")
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        cause_list = CAUSE.objects.raw("""SELECT * FROM CAUSE ORDER BY CAST(CAUSE_CODE AS INTEGER)""")
        underground_list = UNDERGROUND.objects.raw("""SELECT * FROM UNDERGROUND ORDER BY CAST(UNDERGROUND_CODE AS INTEGER)""")
        usage_list = USAGE.objects.raw("""SELECT * FROM USAGE ORDER BY CAST(USAGE_CODE AS INTEGER)""")
        flood_sediment_list = FLOOD_SEDIMENT.objects.raw("""SELECT * FROM FLOOD_SEDIMENT ORDER BY CAST(FLOOD_SEDIMENT_CODE AS INTEGER)""")
        gradient_list = GRADIENT.objects.raw("""SELECT * FROM GRADIENT ORDER BY CAST(GRADIENT_CODE AS INTEGER)""")
        industry_list = INDUSTRY.objects.raw("""SELECT * FROM INDUSTRY ORDER BY CAST(INDUSTRY_CODE AS INTEGER)""")
        area_list = AREA.objects.raw("""SELECT * FROM AREA ORDER BY CAST(AREA_ID AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/ippan_chosa_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'ippan_chosa_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/ippan_chosa_'+ str(hash_code) + '.csv'
        csv_file_name = 'ippan_chosa_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_ippan_chosa.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0060)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_ippan_chosa_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0080)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_chosa_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if func_params["FILE_TYPE"] == _IPP_CHO_EXC:
            return True, excel_file_path
        elif func_params["FILE_TYPE"] == _IPP_CHO_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_ippan_chosa_csv_excel()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_ippan_chosa_csv_excel()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_ippan_chosa_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公共土木施設地方単独事業調査票ファイル生成処理
### func_params["CHITAN_HEADER_ID"]
### func_params["FILE_TYPE"]
###############################################################################
def get_chitan_chosa_csv_excel(request, func_params):

    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、単数EXCELシート対応版
    ###########################################################################
    def create_chitan_chosa_workbook():
        try:
            ### nonlocal ken_list
            ### nonlocal kasen_setubi_list
            ### nonlocal suikei_list
            ### nonlocal suikei_type_list
            ### nonlocal kasen_type_list
            ### nonlocal weather_list
            ### nonlocal chitan_header_list
            ### nonlocal template_file_path
            
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0000)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_chitan_chosa_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 1/10.', 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 2/10.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_chitan = workbook["CHITAN"]
            ws_chitan_header = workbook["CHITAN_HEADER"]
            ws_ken = workbook["KEN"]
            ws_city = workbook["CITY"]
            ws_kasen_setubi = workbook["KASEN_SETUBI"]
            ws_suikei = workbook["SUIKEI"]
            ws_suikei_type = workbook["SUIKEI_TYPE"]
            ws_kasen = workbook["KASEN"]
            ws_kasen_type = workbook["KASEN_TYPE"]
            ws_weather = workbook["WEATHER"]
            ws_city_vlook = workbook["CITY_VLOOK"]
            ws_kasen_vlook = workbook["KASEN_VLOOK"]

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 3/10.', 'DEBUG')
            ws_chitan.sheet_view.showGridLines = False
            ws_chitan_header.sheet_view.showGridLines = False
            
            ws_ken.sheet_view.showGridLines = False
            ws_city.sheet_view.showGridLines = False
            ws_kasen_setubi.sheet_view.showGridLines = False
            ws_suikei.sheet_view.showGridLines = False
            ws_suikei_type.sheet_view.showGridLines = False
            ws_kasen.sheet_view.showGridLines = False
            ws_kasen_type.sheet_view.showGridLines = False
            ws_weather.sheet_view.showGridLines = False
            
            ws_city_vlook.sheet_view.showGridLines = False
            ws_kasen_vlook.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### マスタ用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 4/10.', 'DEBUG')
            ### 1010: 都道府県シート
            print("create_chitan_chosa_workbook_4_1", flush=True)
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_ken.cell(row=i+1, column=1).value = ken.ken_code
                    ws_ken.cell(row=i+1, column=2).value = str(ken.ken_name) + ":" + str(ken.ken_code)
    
            ### 1020: 市区町村シート
            print("create_chitan_chosa_workbook_4_2", flush=True)
            cities_list = []
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    db_params = dict({
                        'KEN_CODE': ken.ken_code
                    })
                    cities_list.append(CITY.objects.raw("""
                        SELECT 
                            * 
                        FROM CITY 
                        WHERE 
                            ken_code=%(KEN_CODE)s 
                        ORDER BY 
                            CAST(CITY_CODE AS INTEGER)""", db_params))
    
            print("create_chitan_chosa_workbook_4_3", flush=True)
            if bool(cities_list) == True:
                for i, cities in enumerate(cities_list):
                    if cities:
                        for j, city in enumerate(cities):
                            ws_city.cell(row=j+1, column=i*5+1).value = city.city_code
                            ws_city.cell(row=j+1, column=i*5+2).value = str(city.city_name) + ":" + str(city.city_code)
                            ws_city.cell(row=j+1, column=i*5+3).value = city.ken_code
                            ws_city.cell(row=j+1, column=i*5+4).value = city.city_population
                            ws_city.cell(row=j+1, column=i*5+5).value = city.city_area
    
            ### 1030: 災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
            print("create_chitan_chosa_workbook_4_4", flush=True)
            if bool(kasen_setubi_list) == True:
                for i, kasen_setubi in enumerate(kasen_setubi_list):
                    ws_kasen_setubi.cell(row=i+1, column=1).value = kasen_setubi.kasen_setubi_code
                    ws_kasen_setubi.cell(row=i+1, column=2).value = str(kasen_setubi.kasen_setubi_name) + ":" + str(kasen_setubi.kasen_setubi_code)
    
            ### 1040: 水系（水系・沿岸）
            print("create_chitan_chosa_workbook_4_5", flush=True)
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_suikei.cell(row=i+1, column=1).value = suikei.suikei_code
                    ws_suikei.cell(row=i+1, column=2).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
                    ws_suikei.cell(row=i+1, column=3).value = suikei.suikei_type_code
    
            ### 1050: 水系種別（水系・沿岸種別）
            print("create_chitan_chosa_workbook_4_6", flush=True)
            if bool(suikei_type_list) == True:
                for i, suikei_type in enumerate(suikei_type_list):
                    ws_suikei_type.cell(row=i+1, column=1).value = suikei_type.suikei_type_code
                    ws_suikei_type.cell(row=i+1, column=2).value = str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code)
    
            ### 1060: 河川（河川・海岸）、連動プルダウン用
            print("create_chitan_chosa_workbook_4_7", flush=True)
            kasens_list = []
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    db_params = dict({
                        'SUIKEI_CODE': suikei.suikei_code
                    })
                    kasens_list.append(KASEN.objects.raw("""
                        SELECT 
                            * 
                        FROM KASEN 
                        WHERE 
                            suikei_code=%(SUIKEI_CODE)s 
                        ORDER BY 
                            CAST(kasen_code AS INTEGER)""", db_params))
    
            print("create_chitan_chosa_workbook_4_8", flush=True)
            if bool(kasens_list) == True:
                for i, kasens in enumerate(kasens_list):
                    if kasens:
                        for j, kasen in enumerate(kasens):
                            ws_kasen.cell(row=j+1, column=i*5+1).value = kasen.kasen_code
                            ws_kasen.cell(row=j+1, column=i*5+2).value = str(kasen.kasen_name) + ":" + str(kasen.kasen_code)
                            ws_kasen.cell(row=j+1, column=i*5+3).value = kasen.kasen_type_code
                            ws_kasen.cell(row=j+1, column=i*5+4).value = kasen.suikei_code
    
            ### 1070: 河川種別（河川・海岸種別）
            print("create_chitan_chosa_workbook_4_9", flush=True)
            if bool(kasen_type_list) == True:
                for i, kasen_type in enumerate(kasen_type_list):
                    ws_kasen_type.cell(row=i+1, column=1).value = kasen_type.kasen_type_code
                    ws_kasen_type.cell(row=i+1, column=2).value = str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code)
    
            ### 7010: 入力データ_異常気象
            print("create_chitan_chosa_workbook_4_10", flush=True)
            if bool(weather_list) == True:
                for i, weather in enumerate(weather_list):
                    ws_weather.cell(row=i+1, column=1).value = weather.weather_id
                    ws_weather.cell(row=i+1, column=2).value = str(weather.weather_name) + ":" + str(weather.weather_id)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### VLOOKUP用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 5/10.', 'DEBUG')
            ### 1020: 市区町村VLOOKUP
            print("create_chitan_chosa_workbook_5_1", flush=True)
            if bool(ken_list) == True and bool(cities_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_city_vlook.cell(row=i+1, column=1).value = str(ken.ken_name) + ":" + str(ken.ken_code)
        
                for i, cities in enumerate(cities_list):
                    ws_city_vlook.cell(row=i+1, column=2).value = 'CITY!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(cities)
    
            ### 1060: 河川（河川・海岸）VLOOKUP
            print("create_chitan_chosa_workbook_5_2", flush=True)
            if bool(suikei_list) == True and bool(kasens_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_kasen_vlook.cell(row=i+1, column=1).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
    
                for i, kasens in enumerate(kasens_list):
                    ws_kasen_vlook.cell(row=i+1, column=2).value = 'KASEN!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(kasens)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 6/10.', 'DEBUG')
            ### ws_chitan.cell(row=6, column=1).value = 'NO.'
            ### ws_chitan.cell(row=6, column=2).value = '水系・沿岸名[全角]'
            ### ws_chitan.cell(row=6, column=3).value = '水系種別[全角]'
            ### ws_chitan.cell(row=6, column=4).value = '河川・海岸名[全角]'
            ### ws_chitan.cell(row=6, column=5).value = '河川種別[全角]'
            ### ws_chitan.cell(row=6, column=6).value = '代表被災地区名[全角]'
            ### ws_chitan.cell(row=6, column=7).value = '都道府県名[全角]'
            ### ws_chitan.cell(row=6, column=8).value = '市区町村名[全角]'
            ### ws_chitan.cell(row=6, column=9).value = '都道府県コード'
            ### ws_chitan.cell(row=6, column=10).value = ''
            ### ws_chitan.cell(row=6, column=11).value = '異常気象コード'
            ### ws_chitan.cell(row=6, column=12).value = '水害発生'
            ### ws_chitan.cell(row=6, column=13).value = ''
            ### ws_chitan.cell(row=6, column=14).value = ''
            ### ws_chitan.cell(row=6, column=15).value = ''
            ### ws_chitan.cell(row=6, column=16).value = '工種区分'
            ### ws_chitan.cell(row=6, column=17).value = ''
            ### ws_chitan.cell(row=6, column=18).value = '市区町村コード'
            ### ws_chitan.cell(row=6, column=19).value = '災害復旧'
            ### ws_chitan.cell(row=6, column=20).value = ''
            ### ws_chitan.cell(row=6, column=21).value = '備考'
            ### ws_chitan.cell(row=7, column=1).value = ''
            ### ws_chitan.cell(row=7, column=2).value = ''
            ### ws_chitan.cell(row=7, column=3).value = ''
            ### ws_chitan.cell(row=7, column=4).value = ''
            ### ws_chitan.cell(row=7, column=5).value = ''
            ### ws_chitan.cell(row=7, column=6).value = ''
            ### ws_chitan.cell(row=7, column=7).value = ''
            ### ws_chitan.cell(row=7, column=8).value = ''
            ### ws_chitan.cell(row=7, column=9).value = ''
            ### ws_chitan.cell(row=7, column=10).value = ''
            ### ws_chitan.cell(row=7, column=11).value = ''
            ### ws_chitan.cell(row=7, column=12).value = '月'
            ### ws_chitan.cell(row=7, column=13).value = '日'
            ### ws_chitan.cell(row=7, column=14).value = '月'
            ### ws_chitan.cell(row=7, column=15).value = '日'
            ### ws_chitan.cell(row=7, column=16).value = ''
            ### ws_chitan.cell(row=7, column=17).value = ''
            ### ws_chitan.cell(row=7, column=18).value = ''
            ### ws_chitan.cell(row=7, column=19).value = '箇所'
            ### ws_chitan.cell(row=7, column=20).value = '査定額(千円)'
            ### ws_chitan.cell(row=7, column=21).value = ''

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0060)
            ### 入力データ用のEXCELシートのプルダウンリストをセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 7/10.', 'DEBUG')
            ### 1040: 水系（水系・沿岸）
            if len(suikei_list) > 0:
                dv_suikei = DataValidation(type="list", formula1="SUIKEI!$B$1:$B$%d" % len(suikei_list))
                dv_suikei.ranges = 'B8:B6007'
                ws_chitan.add_data_validation(dv_suikei)

            ### 1050: 水系種別（水系・沿岸種別）
            if len(suikei_type_list) > 0:
                dv_suikei_type = DataValidation(type="list", formula1="SUIKEI_TYPE!$B$1:$B$%d" % len(suikei_type_list))
                dv_suikei_type.ranges = 'C8:C6007'
                ws_chitan.add_data_validation(dv_suikei_type)

            ### 1060: 河川（河川・海岸）
            ### dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AA8)")
            ### dv_kasen.ranges = 'D8:D8'
            ### ws_chitan.add_data_validation(dv_kasen)
            ### ws_chitan.cell(row=8, column=27).value = "=VLOOKUP(B8,KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
            ### ws_chitan.cell(row=8, column=27).value = "=VLOOKUP(B8,KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS
            for i in range(8, 6008):
                dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AA"+str(i)+")")
                dv_kasen.ranges = 'D'+str(i)+':D'+str(i)
                ws_chitan.add_data_validation(dv_kasen)
                ### ws_chitan.cell(row=i, column=27).value = "=VLOOKUP(B"+str(i)+",KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
                ws_chitan.cell(row=i, column=27).value = "=VLOOKUP(B"+str(i)+",KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS

            ### 1070: 河川種別（河川・海岸種別）
            if len(kasen_type_list) > 0:
                dv_kasen_type = DataValidation(type="list", formula1="KASEN_TYPE!$B$1:$B$%d" % len(kasen_type_list))
                dv_kasen_type.ranges = 'E8:E6007'
                ws_chitan.add_data_validation(dv_kasen_type)

            ### 1010: 都道府県
            if len(ken_list) > 0:
                dv_ken = DataValidation(type="list", formula1="KEN!$B$1:$B$%d" % len(ken_list))
                dv_ken.ranges = 'G8:G6007'
                ws_chitan.add_data_validation(dv_ken)

            ### 1010: 都道府県コード
            for i in range(8, 6008):
                ws_chitan.cell(row=i, column=9).value = "=RIGHT(G"+str(i)+",2)"

            ### 1020: 市区町村
            ### dv_city = DataValidation(type="list", formula1="=INDIRECT(AB8)")
            ### dv_city.ranges = 'H8:H8'
            ### ws_chitan.add_data_validation(dv_city)
            ### ws_chitan.cell(row=8, column=28).value = "=VLOOKUP(G8,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
            ### ws_chitan.cell(row=8, column=28).value = "=VLOOKUP(G8,CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS
            for i in range(8, 6008):
                dv_city = DataValidation(type="list", formula1="=INDIRECT(AB"+str(i)+")")
                dv_city.ranges = 'H'+str(i)+':H'+str(i)
                ws_chitan.add_data_validation(dv_city)
                ### ws_chitan.cell(row=i, column=28).value = "=VLOOKUP(G8,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
                ws_chitan.cell(row=i, column=28).value = "=VLOOKUP(G"+str(i)+",CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS

            ### 1020: 市区町村コード
            for i in range(8, 6008):
                ws_chitan.cell(row=i, column=18).value = "=RIGHT(H"+str(i)+",6)"

            ### 7010: 入力データ_異常気象
            if len(weather_list) > 0:
                dv_weather = DataValidation(type="list", formula1="WEATHER!$B$1:$B$%d" % len(weather_list))
                dv_weather.ranges = 'K8:K6007'
                ws_chitan.add_data_validation(dv_weather)

            ### 1030: 災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
            if len(kasen_setubi_list) > 0:
                dv_kasen_setubi = DataValidation(type="list", formula1="KASEN_SETUBI!$B$1:$B$%d" % len(kasen_setubi_list))
                dv_kasen_setubi.ranges = 'P8:P6007'
                ws_chitan.add_data_validation(dv_kasen_setubi)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0070)
            ### EXCELのセルに、値を埋め込む。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 8/10.', 'DEBUG')
            db_params = dict({
                'CHITAN_HEADER_ID': chitan_header_list[0].chitan_header_id
            })
            chitan_list = CHITAN.objects.raw("""
                SELECT 
                    CHI1.CHITAN_ID,
                    CHI1.CHITAN_NAME,
                    CHI1.CHITAN_HEADER_ID, 
                    CHI1.CHITAN_HEADER_NAME, 
                    CHI1.KEN_CODE, 
                    KEN1.KEN_NAME, 
                    CHI1.CITY_CODE, 
                    CIT1.CITY_NAME, 
                    TO_CHAR(TIMEZONE('JST', CHI1.BEGIN_DATE::TIMESTAMPTZ), 'MM') AS BEGIN_MONTH, 
                    TO_CHAR(TIMEZONE('JST', CHI1.BEGIN_DATE::TIMESTAMPTZ), 'DD') AS BEGIN_DAY, 
                    TO_CHAR(TIMEZONE('JST', CHI1.END_DATE::TIMESTAMPTZ), 'MM') AS END_MONTH, 
                    TO_CHAR(TIMEZONE('JST', CHI1.END_DATE::TIMESTAMPTZ), 'DD') AS END_DAY, 
                    CHI1.SUIKEI_CODE, 
                    SUI1.SUIKEI_NAME, 
                    SUI1.SUIKEI_TYPE_CODE, 
                    SUT1.SUIKEI_TYPE_NAME, 
                    CHI1.KASEN_CODE, 
                    KAS1.KASEN_NAME, 
                    KAS1.KASEN_TYPE_CODE, 
                    KAT1.KASEN_TYPE_NAME, 
                    CHI1.WEATHER_ID, 
                    WEA1.WEATHER_NAME, 
                    CHI1.KASEN_SETUBI_CODE,
                    KAB1.KASEN_SETUBI_NAME,  
                    CHI1.DISASTER_POINT,
                    CAST(CHI1.ESTIMATED_COST AS NUMERIC(20,10)) AS ESTIMATED_COST, 
                    CHI1.COMMENT AS COMMENT 
                FROM CHITAN_VIEW CHI1 
                LEFT JOIN KEN KEN1 ON CHI1.KEN_CODE=KEN1.KEN_CODE 
                LEFT JOIN CITY CIT1 ON CHI1.CITY_CODE=CIT1.CITY_CODE 
                LEFT JOIN SUIKEI SUI1 ON CHI1.SUIKEI_CODE=SUI1.SUIKEI_CODE 
                LEFT JOIN SUIKEI_TYPE SUT1 ON SUI1.SUIKEI_TYPE_CODE=SUT1.SUIKEI_TYPE_CODE 
                LEFT JOIN KASEN KAS1 ON CHI1.KASEN_CODE=KAS1.KASEN_CODE 
                LEFT JOIN KASEN_TYPE KAT1 ON KAS1.KASEN_TYPE_CODE=KAT1.KASEN_TYPE_CODE 
                LEFT JOIN WEATHER WEA1 ON CHI1.WEATHER_ID=WEA1.WEATHER_ID 
                LEFT JOIN KASEN_SETUBI KAB1 ON CHI1.KASEN_SETUBI_CODE=KAB1.KASEN_SETUBI_CODE 
                WHERE 
                    CHI1.CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s 
                ORDER BY 
                    CAST(CHI1.CHITAN_ID AS INTEGER)""", db_params)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0080)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 9/10.', 'DEBUG')
            green_fill = PatternFill(fgColor='CCFFCC', patternType='solid')
            if bool(chitan_list) == True:
                for i, chitan in enumerate(chitan_list):
                    if (bool(str(chitan.chitan_id)) == True):
                        ws_chitan.cell(row=8+i, column=1).value = (
                            str(chitan.chitan_id)
                        )
                        ws_chitan.cell(row=8+i, column=1).fill = green_fill
                    
                    if (bool(str(chitan.suikei_name)) == True and 
                        bool(str(chitan.suikei_code)) == True):
                        ws_chitan.cell(row=8+i, column=2).value = (
                            str(chitan.suikei_name) + ":" + 
                            str(chitan.suikei_code)
                        )

                    if (bool(str(chitan.suikei_type_name)) == True and 
                        bool(str(chitan.suikei_type_code)) == True):
                        ws_chitan.cell(row=8+i, column=3).value = (
                            str(chitan.suikei_type_name) + ":" + 
                            str(chitan.suikei_type_code)
                        )
                    
                    if (bool(str(chitan.kasen_name)) == True and 
                        bool(str(chitan.kasen_code)) == True):
                        ws_chitan.cell(row=8+i, column=4).value = (
                            str(chitan.kasen_name) + ":" + 
                            str(chitan.kasen_code)
                        )
                        
                    if (bool(str(chitan.kasen_type_name)) == True and 
                        bool(str(chitan.kasen_type_code)) == True):
                        ws_chitan.cell(row=8+i, column=5).value = (
                            str(chitan.kasen_type_name) + ":" + 
                            str(chitan.kasen_type_code)
                        )
                    
                    if (bool(str(chitan.chitan_name)) == True):
                        ws_chitan.cell(row=8+i, column=6).value = (
                            str(chitan.chitan_name)
                        )
                        
                    if (bool(str(chitan.ken_name)) == True and 
                        bool(str(chitan.ken_code)) == True):
                        ws_chitan.cell(row=8+i, column=7).value = (
                            str(chitan.ken_name) + ":" + 
                            str(chitan.ken_code)
                        )
                    
                    if (bool(str(chitan.city_name)) == True and 
                        bool(str(chitan.city_code)) == True):
                        ws_chitan.cell(row=8+i, column=8).value = (
                            str(chitan.city_name) + ":" + 
                            str(chitan.city_code)
                        )
                    
                    if (bool(str(chitan.ken_code)) == True):
                        ws_chitan.cell(row=8+i, column=9).value = (
                            str(chitan.ken_code)
                        )

                    ws_chitan.cell(row=8+i, column=10).value = ""
                    
                    if (bool(str(chitan.weather_name)) == True and 
                        bool(str(chitan.weather_id)) == True):
                        ws_chitan.cell(row=8+i, column=11).value = (
                            str(chitan.weather_name) + ":" + 
                            str(chitan.weather_id)
                        )
                        
                    if (bool(str(chitan.begin_month)) == True):
                        ws_chitan.cell(row=8+i, column=12).value = (
                            str(chitan.begin_month)
                        )

                    if (bool(str(chitan.begin_day)) == True):
                        ws_chitan.cell(row=8+i, column=13).value = (
                            str(chitan.begin_day)
                        )
                    
                    if (bool(str(chitan.end_month)) == True):
                        ws_chitan.cell(row=8+i, column=14).value = (
                            str(chitan.end_month)
                        )
                    
                    if (bool(str(chitan.end_day)) == True):
                        ws_chitan.cell(row=8+i, column=15).value = (
                            str(chitan.end_day)
                        )
                        
                    if (bool(str(chitan.kasen_setubi_name)) == True and 
                        bool(str(chitan.kasen_setubi_code)) == True):
                        ws_chitan.cell(row=8+i, column=16).value = (
                            str(chitan.kasen_setubi_name) + ":" + 
                            str(chitan.kasen_setubi_code)
                        )

                    ws_chitan.cell(row=8+i, column=17).value = ""
                        
                    if (bool(str(chitan.city_code)) == True):
                        ws_chitan.cell(row=8+i, column=18).value = (
                            str(chitan.city_code)
                        )
                        
                    if (bool(str(chitan.disaster_point)) == True):
                        ws_chitan.cell(row=8+i, column=19).value = (
                            str(chitan.disaster_point)
                        )
                        
                    if (bool(str(chitan.estimated_cost)) == True):
                        ws_chitan.cell(row=8+i, column=20).value = (
                            str(chitan.estimated_cost)
                        )
                    
                    if (bool(str(chitan.comment)) == True):
                        ws_chitan.cell(row=8+i, column=21).value = (
                            str(chitan.comment)
                        )

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0090)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 10/10.', 'DEBUG')
            print_log('[INFO] P0000Common.create_chitan_chosa_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
        
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_chitan_chosa_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        ### ※単数EXCELファイル、単数EXCELシートのため、get_ippan_chosa_excelのような処理は不要である。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 2/9.', 'DEBUG')
        db_params = dict({
            'CHITAN_HEADER_ID': func_params["CHITAN_HEADER_ID"]
        })
        chitan_header_list = CHITAN_HEADER.objects.raw("""
            SELECT 
                * 
            FROM CHITAN_HEADER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s LIMIT 1""", db_params)

        if bool(chitan_header_list) == False:
            print_log('[WARN] P0000Common.get_chitan_chosa_csv_excel()関数が警告終了しました。', 'WARN')
            return False, ""

        #######################################################################
        ### DBアクセス処理(0020)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 3/9.', 'DEBUG')
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        kasen_setubi_list = KASEN_SETUBI.objects.raw("""SELECT * FROM KASEN_SETUBI ORDER BY CAST(KASEN_SETUBI_CODE AS INTEGER)""")
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/chitan_chosa_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'chitan_chosa_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/chitan_chosa_'+ str(hash_code) + '.csv'
        csv_file_name = 'chitan_chosa_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_chitan_chosa.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0060)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_chitan_chosa_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0080)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_chosa_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if func_params["FILE_TYPE"] == _CHI_CHO_EXC:
            return True, excel_file_path
        elif func_params["FILE_TYPE"] == _CHI_CHO_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_chitan_chosa_csv_excel()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_chitan_chosa_csv_excel()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_chitan_chosa_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公共土木施設補助事業調査票ファイル生成処理
### func_params["HOJO_HEADER_ID"]
### func_params["FILE_TYPE"]
###############################################################################
def get_hojo_chosa_csv_excel(request, func_params):

    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、単数EXCELシート対応版
    ###########################################################################
    def create_hojo_chosa_workbook():
        try:
            ### nonlocal ken_list
            ### nonlocal kasen_setubi_list
            ### nonlocal suikei_list
            ### nonlocal suikei_type_list
            ### nonlocal kasen_type_list
            ### nonlocal weather_list
            ### nonlocal chitan_header_list
            ### nonlocal template_file_path

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0000)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_hojo_chosa_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 1/10.', 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 2/10.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_hojo = workbook["HOJO"]
            ws_hojo_header = workbook["HOJO_HEADER"]
            ws_ken = workbook["KEN"]
            ws_city = workbook["CITY"]
            ws_kasen_setubi = workbook["KASEN_SETUBI"]
            ws_suikei = workbook["SUIKEI"]
            ws_suikei_type = workbook["SUIKEI_TYPE"]
            ws_kasen = workbook["KASEN"]
            ws_kasen_type = workbook["KASEN_TYPE"]
            ws_weather = workbook["WEATHER"]
            ws_city_vlook = workbook["CITY_VLOOK"]
            ws_kasen_vlook = workbook["KASEN_VLOOK"]

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 3/10.', 'DEBUG')
            ws_hojo.sheet_view.showGridLines = False
            ws_hojo_header.sheet_view.showGridLines = False
            
            ws_ken.sheet_view.showGridLines = False
            ws_city.sheet_view.showGridLines = False
            ws_kasen_setubi.sheet_view.showGridLines = False
            ws_suikei.sheet_view.showGridLines = False
            ws_suikei_type.sheet_view.showGridLines = False
            ws_kasen.sheet_view.showGridLines = False
            ws_kasen_type.sheet_view.showGridLines = False
            ws_weather.sheet_view.showGridLines = False
            
            ws_city_vlook.sheet_view.showGridLines = False
            ws_kasen_vlook.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### マスタ用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 4/10.', 'DEBUG')
            ### 1010: 都道府県シート
            print("create_hojo_chosa_workbook_4_1", flush=True)
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_ken.cell(row=i+1, column=1).value = ken.ken_code
                    ws_ken.cell(row=i+1, column=2).value = str(ken.ken_name) + ":" + str(ken.ken_code)
    
            ### 1020: 市区町村シート
            print("create_hojo_chosa_workbook_4_2", flush=True)
            cities_list = []
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    db_params = dict({
                        'KEN_CODE': ken.ken_code
                    })
                    cities_list.append(CITY.objects.raw("""
                        SELECT 
                            * 
                        FROM CITY 
                        WHERE 
                            ken_code=%(KEN_CODE)s 
                        ORDER BY 
                            CAST(CITY_CODE AS INTEGER)""", db_params))
    
            print("create_hojo_chosa_workbook_4_3", flush=True)
            if bool(cities_list) == True:
                for i, cities in enumerate(cities_list):
                    if cities:
                        for j, city in enumerate(cities):
                            ws_city.cell(row=j+1, column=i*5+1).value = city.city_code
                            ws_city.cell(row=j+1, column=i*5+2).value = str(city.city_name) + ":" + str(city.city_code)
                            ws_city.cell(row=j+1, column=i*5+3).value = city.ken_code
                            ws_city.cell(row=j+1, column=i*5+4).value = city.city_population
                            ws_city.cell(row=j+1, column=i*5+5).value = city.city_area
    
            ### 1030: 災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
            print("create_hojo_chosa_workbook_4_4", flush=True)
            if bool(kasen_setubi_list) == True:
                for i, kasen_setubi in enumerate(kasen_setubi_list):
                    ws_kasen_setubi.cell(row=i+1, column=1).value = kasen_setubi.kasen_setubi_code
                    ws_kasen_setubi.cell(row=i+1, column=2).value = str(kasen_setubi.kasen_setubi_name) + ":" + str(kasen_setubi.kasen_setubi_code)
    
            ### 1040: 水系（水系・沿岸）
            print("create_hojo_chosa_workbook_4_5", flush=True)
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_suikei.cell(row=i+1, column=1).value = suikei.suikei_code
                    ws_suikei.cell(row=i+1, column=2).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
                    ws_suikei.cell(row=i+1, column=3).value = suikei.suikei_type_code
    
            ### 1050: 水系種別（水系・沿岸種別）
            print("create_hojo_chosa_workbook_4_6", flush=True)
            if bool(suikei_type_list) == True:
                for i, suikei_type in enumerate(suikei_type_list):
                    ws_suikei_type.cell(row=i+1, column=1).value = suikei_type.suikei_type_code
                    ws_suikei_type.cell(row=i+1, column=2).value = str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code)
    
            ### 1060: 河川（河川・海岸）、連動プルダウン用
            print("create_hojo_chosa_workbook_4_7", flush=True)
            kasens_list = []
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    db_params = dict({
                        'SUIKEI_CODE': suikei.suikei_code
                    })
                    kasens_list.append(KASEN.objects.raw("""
                        SELECT 
                            * 
                        FROM KASEN 
                        WHERE 
                            suikei_code=%(SUIKEI_CODE)s 
                        ORDER BY 
                            CAST(kasen_code AS INTEGER)""", db_params))
    
            print("create_hojo_chosa_workbook_4_8", flush=True)
            if bool(kasens_list) == True:
                for i, kasens in enumerate(kasens_list):
                    if kasens:
                        for j, kasen in enumerate(kasens):
                            ws_kasen.cell(row=j+1, column=i*5+1).value = kasen.kasen_code
                            ws_kasen.cell(row=j+1, column=i*5+2).value = str(kasen.kasen_name) + ":" + str(kasen.kasen_code)
                            ws_kasen.cell(row=j+1, column=i*5+3).value = kasen.kasen_type_code
                            ws_kasen.cell(row=j+1, column=i*5+4).value = kasen.suikei_code
    
            ### 1070: 河川種別（河川・海岸種別）
            print("create_hojo_chosa_workbook_4_9", flush=True)
            if bool(kasen_type_list) == True:
                for i, kasen_type in enumerate(kasen_type_list):
                    ws_kasen_type.cell(row=i+1, column=1).value = kasen_type.kasen_type_code
                    ws_kasen_type.cell(row=i+1, column=2).value = str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code)
    
            ### 7010: 入力データ_異常気象
            print("create_hojo_chosa_workbook_4_10", flush=True)
            if bool(weather_list) == True:
                for i, weather in enumerate(weather_list):
                    ws_weather.cell(row=i+1, column=1).value = weather.weather_id
                    ws_weather.cell(row=i+1, column=2).value = str(weather.weather_name) + ":" + str(weather.weather_id)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### VLOOKUP用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 5/10.', 'DEBUG')
            ### 1020: 市区町村VLOOKUP
            print("create_hojo_chosa_workbook_5_1", flush=True)
            if bool(ken_list) == True and bool(cities_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_city_vlook.cell(row=i+1, column=1).value = str(ken.ken_name) + ":" + str(ken.ken_code)
        
                for i, cities in enumerate(cities_list):
                    ws_city_vlook.cell(row=i+1, column=2).value = 'CITY!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(cities)
    
            ### 1060: 河川（河川・海岸）VLOOKUP
            print("create_hojo_chosa_workbook_5_2", flush=True)
            if bool(suikei_list) == True and bool(kasens_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_kasen_vlook.cell(row=i+1, column=1).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
    
                for i, kasens in enumerate(kasens_list):
                    ws_kasen_vlook.cell(row=i+1, column=2).value = 'KASEN!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(kasens)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 6/10.', 'DEBUG')
            ### ws_hojo.cell(row=6, column=1).value = 'NO.'
            ### ws_hojo.cell(row=6, column=2).value = '水系・沿岸名[全角]'
            ### ws_hojo.cell(row=6, column=3).value = '水系種別[全角]'
            ### ws_hojo.cell(row=6, column=4).value = '河川・海岸名[全角]'
            ### ws_hojo.cell(row=6, column=5).value = '河川種別[全角]'
            ### ws_hojo.cell(row=6, column=6).value = '都道府県名[全角]'
            ### ws_hojo.cell(row=6, column=7).value = '工事番号'
            ### ws_hojo.cell(row=6, column=8).value = ''
            ### ws_hojo.cell(row=6, column=9).value = '工事区分'
            ### ws_hojo.cell(row=6, column=10).value = '市区町村コード'
            ### ws_hojo.cell(row=6, column=11).value = '工種区分'
            ### ws_hojo.cell(row=6, column=12).value = ''
            ### ws_hojo.cell(row=6, column=13).value = '異常気象コード'
            ### ws_hojo.cell(row=6, column=14).value = '水害発生'
            ### ws_hojo.cell(row=6, column=15).value = ''
            ### ws_hojo.cell(row=6, column=16).value = '決定額(千円)'
            ### ws_hojo.cell(row=6, column=17).value = '備考'
            ### ws_hojo.cell(row=7, column=1).value = ''
            ### ws_hojo.cell(row=7, column=2).value = ''
            ### ws_hojo.cell(row=7, column=3).value = ''
            ### ws_hojo.cell(row=7, column=4).value = ''
            ### ws_hojo.cell(row=7, column=5).value = ''
            ### ws_hojo.cell(row=7, column=6).value = ''
            ### ws_hojo.cell(row=7, column=7).value = '工事番号'
            ### ws_hojo.cell(row=7, column=8).value = '枝番'
            ### ws_hojo.cell(row=7, column=9).value = ''
            ### ws_hojo.cell(row=7, column=10).value = ''
            ### ws_hojo.cell(row=7, column=11).value = ''
            ### ws_hojo.cell(row=7, column=12).value = ''
            ### ws_hojo.cell(row=7, column=13).value = ''
            ### ws_hojo.cell(row=7, column=14).value = '月'
            ### ws_hojo.cell(row=7, column=15).value = '日'
            ### ws_hojo.cell(row=7, column=16).value = ''
            ### ws_hojo.cell(row=7, column=17).value = ''

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0060)
            ### 入力データ用のEXCELシートのプルダウンリストをセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7/10.', 'DEBUG')
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_0/10.', 'DEBUG')
            ### 1040: 水系（水系・沿岸）
            if len(suikei_list) > 0:
                dv_suikei = DataValidation(type="list", formula1="SUIKEI!$B$1:$B$%d" % len(suikei_list))
                dv_suikei.ranges = 'B8:B6007'
                ws_hojo.add_data_validation(dv_suikei)

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_1/10.', 'DEBUG')
            ### 1050: 水系種別（水系・沿岸種別）
            if len(suikei_type_list) > 0:
                dv_suikei_type = DataValidation(type="list", formula1="SUIKEI_TYPE!$B$1:$B$%d" % len(suikei_type_list))
                dv_suikei_type.ranges = 'C8:C6007'
                ws_hojo.add_data_validation(dv_suikei_type)

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_2/10.', 'DEBUG')
            ### 1060: 河川（河川・海岸）
            ### dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AA8)")
            ### dv_kasen.ranges = 'D8:D8'
            ### ws_hojo.add_data_validation(dv_kasen)
            ### ws_hojo.cell(row=8, column=27).value = "=VLOOKUP(B8,KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
            ### ws_hojo.cell(row=8, column=27).value = "=VLOOKUP(B8,KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS
            for i in range(8, 6008):
                dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AA"+str(i)+")")
                dv_kasen.ranges = 'D'+str(i)+':D'+str(i)
                ws_hojo.add_data_validation(dv_kasen)
                ### ws_hojo.cell(row=i, column=27).value = "=VLOOKUP(B"+str(i)+",KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
                ws_hojo.cell(row=i, column=27).value = "=VLOOKUP(B"+str(i)+",KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_3/10.', 'DEBUG')
            ### 1070: 河川種別（河川・海岸種別）
            if len(kasen_type_list) > 0:
                dv_kasen_type = DataValidation(type="list", formula1="KASEN_TYPE!$B$1:$B$%d" % len(kasen_type_list))
                dv_kasen_type.ranges = 'E8:E6007'
                ws_hojo.add_data_validation(dv_kasen_type)

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_4/10.', 'DEBUG')
            ### 1010: 都道府県
            if len(ken_list) > 0:
                dv_ken = DataValidation(type="list", formula1="KEN!$B$1:$B$%d" % len(ken_list))
                dv_ken.ranges = 'G8:G6007'
                ws_hojo.add_data_validation(dv_ken)

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_5/10.', 'DEBUG')
            ### 1010: 都道府県コード
            for i in range(8, 6008):
                ws_hojo.cell(row=i, column=9).value = "=RIGHT(G"+str(i)+",2)"

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_6/10.', 'DEBUG')
            ### 1020: 市区町村
            ### dv_city = DataValidation(type="list", formula1="=INDIRECT(AB8)")
            ### dv_city.ranges = 'H8:H8'
            ### ws_hojo.add_data_validation(dv_city)
            ### ws_hojo.cell(row=8, column=28).value = "=VLOOKUP(G8,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
            ### ws_hojo.cell(row=8, column=28).value = "=VLOOKUP(G8,CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS
            for i in range(8, 6008):
                dv_city = DataValidation(type="list", formula1="=INDIRECT(AB"+str(i)+")")
                dv_city.ranges = 'H'+str(i)+':H'+str(i)
                ws_hojo.add_data_validation(dv_city)
                ### ws_hojo.cell(row=i, column=28).value = "=VLOOKUP(G8,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
                ws_hojo.cell(row=i, column=28).value = "=VLOOKUP(G"+str(i)+",CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_7/10.', 'DEBUG')
            ### 1020: 市区町村コード
            for i in range(8, 6008):
                ws_hojo.cell(row=i, column=18).value = "=RIGHT(H"+str(i)+",6)"

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_8/10.', 'DEBUG')
            ### 7010: 入力データ_異常気象
            if len(weather_list) > 0:
                dv_weather = DataValidation(type="list", formula1="WEATHER!$B$1:$B$%d" % len(weather_list))
                dv_weather.ranges = 'K8:K6007'
                ws_hojo.add_data_validation(dv_weather)

            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 7_9/10.', 'DEBUG')
            ### 1030: 災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
            if len(kasen_setubi_list) > 0:
                dv_kasen_setubi = DataValidation(type="list", formula1="KASEN_SETUBI!$B$1:$B$%d" % len(kasen_setubi_list))
                dv_kasen_setubi.ranges = 'P8:P6007'
                ws_hojo.add_data_validation(dv_kasen_setubi)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0070)
            ### EXCELのセルに、値を埋め込む。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 8/10.', 'DEBUG')
            db_params = dict({
                'HOJO_HEADER_ID': hojo_header_list[0].hojo_header_id
            })
            hojo_list = HOJO.objects.raw("""
                SELECT 
                    HOJ1.HOJO_ID, 
                    HOJ1.HOJO_NAME, 
                    HOJ1.HOJO_HEADER_ID, 
                    HOJ1.HOJO_HEADER_NAME, 
                    HOJ1.KEN_CODE, 
                    KEN1.KEN_NAME, 
                    HOJ1.CITY_CODE, 
                    CIT1.CITY_NAME, 
                    TO_CHAR(TIMEZONE('JST', HOJ1.BEGIN_DATE::TIMESTAMPTZ), 'MM') AS BEGIN_MONTH, 
                    TO_CHAR(TIMEZONE('JST', HOJ1.BEGIN_DATE::TIMESTAMPTZ), 'DD') AS BEGIN_DAY, 
                    TO_CHAR(TIMEZONE('JST', HOJ1.END_DATE::TIMESTAMPTZ), 'MM') AS END_MONTH, 
                    TO_CHAR(TIMEZONE('JST', HOJ1.END_DATE::TIMESTAMPTZ), 'DD') AS END_DAY, 
                    HOJ1.SUIKEI_CODE, 
                    SUI1.SUIKEI_NAME, 
                    SUI1.SUIKEI_TYPE_CODE, 
                    SUT1.SUIKEI_TYPE_NAME, 
                    HOJ1.KASEN_CODE, 
                    KAS1.KASEN_NAME, 
                    KAS1.KASEN_TYPE_CODE, 
                    KAT1.KASEN_TYPE_NAME, 
                    HOJ1.WEATHER_ID, 
                    WEA1.WEATHER_NAME, 
                    HOJ1.KASEN_SETUBI_CODE, 
                    KAB1.KASEN_SETUBI_NAME, 
                    HOJ1.KOJI_CODE, 
                    HOJ1.BRANCH_CODE, 
                    HOJ1.KOJI_TYPE_CODE, 
                    HOJ1.KOSH_TYPE_CODE, 
                    CAST(HOJ1.DETERMINED_COST AS NUMERIC(20,10)) AS DETERMINED_COST, 
                    HOJ1.COMMENT AS COMMENT 
                FROM HOJO_VIEW HOJ1 
                LEFT JOIN KEN KEN1 ON HOJ1.KEN_CODE=KEN1.KEN_CODE 
                LEFT JOIN CITY CIT1 ON HOJ1.CITY_CODE=CIT1.CITY_CODE 
                LEFT JOIN SUIKEI SUI1 ON HOJ1.SUIKEI_CODE=SUI1.SUIKEI_CODE 
                LEFT JOIN SUIKEI_TYPE SUT1 ON SUI1.SUIKEI_TYPE_CODE=SUT1.SUIKEI_TYPE_CODE 
                LEFT JOIN KASEN KAS1 ON HOJ1.KASEN_CODE=KAS1.KASEN_CODE 
                LEFT JOIN KASEN_TYPE KAT1 ON KAS1.KASEN_TYPE_CODE=KAT1.KASEN_TYPE_CODE 
                LEFT JOIN WEATHER WEA1 ON HOJ1.WEATHER_ID=WEA1.WEATHER_ID 
                LEFT JOIN KASEN_SETUBI KAB1 ON HOJ1.KASEN_SETUBI_CODE=KAB1.KASEN_SETUBI_CODE 
                WHERE 
                    HOJ1.HOJO_HEADER_ID=%(HOJO_HEADER_ID)s 
                ORDER BY 
                    CAST(HOJ1.HOJO_ID AS INTEGER)""", db_params)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0080)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9/10.', 'DEBUG')
            green_fill = PatternFill(fgColor='CCFFCC', patternType='solid')
            if bool(hojo_list) == True:
                for i, hojo in enumerate(hojo_list):
                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_1/10.', 'DEBUG')
                    if (bool(str(hojo.hojo_id)) == True):
                        ws_hojo.cell(row=8+i, column=1).value = (
                            str(hojo.hojo_id)
                        )
                        ws_hojo.cell(row=8+i, column=1).fill = green_fill
                    
                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_2/10.', 'DEBUG')
                    if (bool(str(hojo.suikei_name)) == True and 
                        bool(str(hojo.suikei_code)) == True):
                        ws_hojo.cell(row=8+i, column=2).value = (
                            str(hojo.suikei_name) + ":" + 
                            str(hojo.suikei_code)
                        )

                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_3/10.', 'DEBUG')
                    if (bool(str(hojo.suikei_type_name)) == True and 
                        bool(str(hojo.suikei_type_code)) == True):
                        ws_hojo.cell(row=8+i, column=3).value = (
                            str(hojo.suikei_type_name) + ":" + 
                            str(hojo.suikei_type_code)
                        )
                    
                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_4/10.', 'DEBUG')
                    if (bool(str(hojo.kasen_name)) == True and 
                        bool(str(hojo.kasen_code)) == True):
                        ws_hojo.cell(row=8+i, column=4).value = (
                            str(hojo.kasen_name) + ":" + 
                            str(hojo.kasen_code)
                        )
                        
                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_5/10.', 'DEBUG')
                    if (bool(str(hojo.kasen_type_name)) == True and 
                        bool(str(hojo.kasen_type_code)) == True):
                        ws_hojo.cell(row=8+i, column=5).value = (
                            str(hojo.kasen_type_name) + ":" + 
                            str(hojo.kasen_type_code)
                        )
                    
                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_6/10.', 'DEBUG')
                    if (bool(str(hojo.ken_name)) == True and 
                        bool(str(hojo.ken_code)) == True):
                        ws_hojo.cell(row=8+i, column=6).value = (
                            str(hojo.ken_name) + ":" + 
                            str(hojo.ken_code)
                        )

                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_7/10.', 'DEBUG')
                    if (bool(str(hojo.koji_code)) == True):
                        ws_hojo.cell(row=8+i, column=7).value = (
                            str(hojo.koji_code)
                        )

                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_8/10.', 'DEBUG')
                    if (bool(str(hojo.branch_code)) == True):
                        ws_hojo.cell(row=8+i, column=8).value = (
                            str(hojo.branch_code)
                        )

                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_9/10.', 'DEBUG')
                    if (bool(str(hojo.koji_type_code)) == True):
                        ws_hojo.cell(row=8+i, column=9).value = (
                            str(hojo.koji_type_code)
                        )
                    
                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_10/10.', 'DEBUG')
                    if (bool(str(hojo.city_name)) == True and 
                        bool(str(hojo.city_code)) == True):
                        ws_hojo.cell(row=8+i, column=10).value = (
                            str(hojo.city_name) + ":" + 
                            str(hojo.city_code)
                        )

                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_11/10.', 'DEBUG')
                    if (bool(str(hojo.kosh_type_code)) == True):
                        ws_hojo.cell(row=8+i, column=11).value = (
                            str(hojo.kosh_type_code)
                        )
                    
                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_12/10.', 'DEBUG')
                    if (bool(str(hojo.weather_name)) == True and 
                        bool(str(hojo.weather_id)) == True):
                        ws_hojo.cell(row=8+i, column=13).value = (
                            str(hojo.weather_name) + ":" + 
                            str(hojo.weather_id)
                        )
                        
                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_13/10.', 'DEBUG')
                    if (bool(str(hojo.begin_month)) == True):
                        ws_hojo.cell(row=8+i, column=14).value = (
                            str(hojo.begin_month)
                        )

                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_14/10.', 'DEBUG')
                    if (bool(str(hojo.begin_day)) == True):
                        ws_hojo.cell(row=8+i, column=15).value = (
                            str(hojo.begin_day)
                        )
                        
                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_15/10.', 'DEBUG')
                    if (bool(str(hojo.determined_cost)) == True):
                        ws_hojo.cell(row=8+i, column=16).value = (
                            str(hojo.determined_cost)
                        )
                    
                    print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 9_16/10.', 'DEBUG')
                    if (bool(str(hojo.comment)) == True):
                        ws_hojo.cell(row=8+i, column=17).value = (
                            str(hojo.comment)
                        )

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0090)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 10/10.', 'DEBUG')
            print_log('[INFO] P0000Common.create_hojo_chosa_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
        
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False

    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_hojo_chosa_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        ### ※単数EXCELファイル、単数EXCELシートのため、get_ippan_chosa_excelのような処理は不要である。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 2/9.', 'DEBUG')
        db_params = dict({
            'HOJO_HEADER_ID': func_params["HOJO_HEADER_ID"]
        })
        hojo_header_list = HOJO_HEADER.objects.raw("""
            SELECT 
                * 
            FROM HOJO_HEADER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s LIMIT 1""", db_params)

        if bool(hojo_header_list) == False:
            print_log('[WARN] P0000Common.get_hojo_chosa_csv_excel()関数が警告終了しました。', 'WARN')
            return False, ""

        #######################################################################
        ### DBアクセス処理(0020)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 3/9.', 'DEBUG')
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        kasen_setubi_list = KASEN_SETUBI.objects.raw("""SELECT * FROM KASEN_SETUBI ORDER BY CAST(KASEN_SETUBI_CODE AS INTEGER)""")
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/hojo_chosa_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'hojo_chosa_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/hojo_chosa_'+ str(hash_code) + '.csv'
        csv_file_name = 'hojo_chosa_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_hojo_chosa.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0060)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_hojo_chosa_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0080)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_chosa_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if func_params["FILE_TYPE"] == _HOJ_CHO_EXC:
            return True, excel_file_path
        elif func_params["FILE_TYPE"] == _HOJ_CHO_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_hojo_chosa_csv_excel()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_hojo_chosa_csv_excel()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_hojo_chosa_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公益事業調査票ファイル生成処理
### func_params["KOEKI_HEADER_ID"]
### func_params["FILE_TYPE"]
###############################################################################
def get_koeki_chosa_csv_excel(request, func_params):
    
    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、単数EXCELシート対応版
    ###########################################################################
    def create_koeki_chosa_workbook():
        try:
            ### nonlocal ken_list
            ### nonlocal kasen_setubi_list
            ### nonlocal suikei_list
            ### nonlocal suikei_type_list
            ### nonlocal kasen_type_list
            ### nonlocal weather_list
            ### nonlocal koeki_header_list
            ### nonlocal template_file_path

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0000)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_koeki_chosa_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 1/10.', 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 2/10.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_koeki = workbook["KOEKI"]
            ws_koeki_header = workbook["KOEKI_HEADER"]
            ws_ken = workbook["KEN"]
            ws_city = workbook["CITY"]
            ws_kasen_setubi = workbook["KASEN_SETUBI"]
            ws_suikei = workbook["SUIKEI"]
            ws_suikei_type = workbook["SUIKEI_TYPE"]
            ws_kasen = workbook["KASEN"]
            ws_kasen_type = workbook["KASEN_TYPE"]
            ws_weather = workbook["WEATHER"]
            ws_business = workbook["BUSINESS"]
            ws_city_vlook = workbook["CITY_VLOOK"]
            ws_kasen_vlook = workbook["KASEN_VLOOK"]

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 3/10.', 'DEBUG')
            ws_koeki.sheet_view.showGridLines = False
            ws_koeki_header.sheet_view.showGridLines = False
            ws_ken.sheet_view.showGridLines = False
            ws_city.sheet_view.showGridLines = False
            ws_kasen_setubi.sheet_view.showGridLines = False
            ws_suikei.sheet_view.showGridLines = False
            ws_suikei_type.sheet_view.showGridLines = False
            ws_kasen.sheet_view.showGridLines = False
            ws_kasen_type.sheet_view.showGridLines = False
            ws_weather.sheet_view.showGridLines = False
            ws_business.sheet_view.showGridLines = False
            ws_city_vlook.sheet_view.showGridLines = False
            ws_kasen_vlook.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### マスタ用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 4/10.', 'DEBUG')
            ### 1010: 都道府県シート
            print("create_koeki_chosa_workbook_4_1", flush=True)
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_ken.cell(row=i+1, column=1).value = ken.ken_code
                    ws_ken.cell(row=i+1, column=2).value = str(ken.ken_name) + ":" + str(ken.ken_code)
    
            ### 1020: 市区町村シート
            print("create_koeki_chosa_workbook_4_2", flush=True)
            cities_list = []
            if bool(ken_list) == True:
                for i, ken in enumerate(ken_list):
                    db_params = dict({
                        'KEN_CODE': ken.ken_code
                    })
                    cities_list.append(CITY.objects.raw("""
                        SELECT 
                            * 
                        FROM CITY 
                        WHERE 
                            ken_code=%(KEN_CODE)s 
                        ORDER BY 
                            CAST(CITY_CODE AS INTEGER)""", db_params))
    
            print("create_koeki_chosa_workbook_4_3", flush=True)
            if bool(cities_list) == True:
                for i, cities in enumerate(cities_list):
                    if cities:
                        for j, city in enumerate(cities):
                            ws_city.cell(row=j+1, column=i*5+1).value = city.city_code
                            ws_city.cell(row=j+1, column=i*5+2).value = str(city.city_name) + ":" + str(city.city_code)
                            ws_city.cell(row=j+1, column=i*5+3).value = city.ken_code
                            ws_city.cell(row=j+1, column=i*5+4).value = city.city_population
                            ws_city.cell(row=j+1, column=i*5+5).value = city.city_area
    
            ### 1030: 災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
            print("create_koeki_chosa_workbook_4_4", flush=True)
            if bool(kasen_setubi_list) == True:
                for i, kasen_setubi in enumerate(kasen_setubi_list):
                    ws_kasen_setubi.cell(row=i+1, column=1).value = kasen_setubi.kasen_setubi_code
                    ws_kasen_setubi.cell(row=i+1, column=2).value = str(kasen_setubi.kasen_setubi_name) + ":" + str(kasen_setubi.kasen_setubi_code)
    
            ### 1040: 水系（水系・沿岸）
            print("create_koeki_chosa_workbook_4_5", flush=True)
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_suikei.cell(row=i+1, column=1).value = suikei.suikei_code
                    ws_suikei.cell(row=i+1, column=2).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
                    ws_suikei.cell(row=i+1, column=3).value = suikei.suikei_type_code
    
            ### 1050: 水系種別（水系・沿岸種別）
            print("create_koeki_chosa_workbook_4_6", flush=True)
            if bool(suikei_type_list) == True:
                for i, suikei_type in enumerate(suikei_type_list):
                    ws_suikei_type.cell(row=i+1, column=1).value = suikei_type.suikei_type_code
                    ws_suikei_type.cell(row=i+1, column=2).value = str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code)
    
            ### 1060: 河川（河川・海岸）、連動プルダウン用
            print("create_koeki_chosa_workbook_4_7", flush=True)
            kasens_list = []
            if bool(suikei_list) == True:
                for i, suikei in enumerate(suikei_list):
                    db_params = dict({
                        'SUIKEI_CODE': suikei.suikei_code
                    })
                    kasens_list.append(KASEN.objects.raw("""
                        SELECT 
                            * 
                        FROM KASEN 
                        WHERE 
                            suikei_code=%(SUIKEI_CODE)s 
                        ORDER BY 
                            CAST(kasen_code AS INTEGER)""", db_params))
    
            print("create_koeki_chosa_workbook_4_8", flush=True)
            if bool(kasens_list) == True:
                for i, kasens in enumerate(kasens_list):
                    if kasens:
                        for j, kasen in enumerate(kasens):
                            ws_kasen.cell(row=j+1, column=i*5+1).value = kasen.kasen_code
                            ws_kasen.cell(row=j+1, column=i*5+2).value = str(kasen.kasen_name) + ":" + str(kasen.kasen_code)
                            ws_kasen.cell(row=j+1, column=i*5+3).value = kasen.kasen_type_code
                            ws_kasen.cell(row=j+1, column=i*5+4).value = kasen.suikei_code
    
            ### 1070: 河川種別（河川・海岸種別）
            print("create_koeki_chosa_workbook_4_9", flush=True)
            if bool(kasen_type_list) == True:
                for i, kasen_type in enumerate(kasen_type_list):
                    ws_kasen_type.cell(row=i+1, column=1).value = kasen_type.kasen_type_code
                    ws_kasen_type.cell(row=i+1, column=2).value = str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code)


            ### 1080: 水害原因
            print("create_koeki_chosa_workbook_4_10", flush=True)
            ### if bool(cause_list) == True:
            ###     for i, cause in enumerate(cause_list):
            ###         ws_cause.cell(row=i+1, column=1).value = cause.cause_code
            ###         ws_cause.cell(row=i+1, column=2).value = str(cause.cause_name) + ":" + str(cause.cause_code)
    
            ### 7010: 入力データ_異常気象
            print("create_koeki_chosa_workbook_4_11", flush=True)
            ### if bool(weather_list) == True:
            ###     for i, weather in enumerate(weather_list):
            ###         ws_weather.cell(row=i+1, column=1).value = weather.weather_id
            ###         ws_weather.cell(row=i+1, column=2).value = str(weather.weather_name) + ":" + str(weather.weather_id)

            ### 1140: 公益事業分類
            print("create_koeki_chosa_workbook_4_12", flush=True)
            ### if bool(business_list) == True:
            ###     for i, business in enumerate(business_list):
            ###         ws_business.cell(row=i+1, column=1).value = business.business_code
            ###         ws_business.cell(row=i+1, column=2).value = str(business.business_name) + ":" + str(business.business_code)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### VLOOKUP用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 5/10.', 'DEBUG')
            ### 1020: 市区町村VLOOKUP
            print("create_koeki_chosa_workbook_5_1", flush=True)
            if bool(ken_list) == True and bool(cities_list) == True:
                for i, ken in enumerate(ken_list):
                    ws_city_vlook.cell(row=i+1, column=1).value = str(ken.ken_name) + ":" + str(ken.ken_code)
        
                for i, cities in enumerate(cities_list):
                    ws_city_vlook.cell(row=i+1, column=2).value = 'CITY!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(cities)
    
            ### 1060: 河川（河川・海岸）VLOOKUP
            print("create_koeki_chosa_workbook_5_2", flush=True)
            if bool(suikei_list) == True and bool(kasens_list) == True:
                for i, suikei in enumerate(suikei_list):
                    ws_kasen_vlook.cell(row=i+1, column=1).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
    
                for i, kasens in enumerate(kasens_list):
                    ws_kasen_vlook.cell(row=i+1, column=2).value = 'KASEN!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(kasens)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 6/10.', 'DEBUG')
            ### ws_koeki.cell(row=6, column=1).value = 'NO.'
            ### ws_koeki.cell(row=6, column=2).value = '水害発生年月日'
            ### ws_koeki.cell(row=6, column=3).value = ''
            ### ws_koeki.cell(row=6, column=4).value = ''
            ### ws_koeki.cell(row=6, column=5).value = ''
            ### ws_koeki.cell(row=6, column=6).value = '被害箇所'
            ### ws_koeki.cell(row=6, column=7).value = ''
            ### ws_koeki.cell(row=6, column=8).value = ''
            ### ws_koeki.cell(row=6, column=9).value = ''
            ### ws_koeki.cell(row=6, column=10).value = ''
            ### ws_koeki.cell(row=6, column=11).value = '河川・海岸名・地区名'
            ### ws_koeki.cell(row=6, column=12).value = ''
            ### ws_koeki.cell(row=6, column=13).value = ''
            ### ws_koeki.cell(row=6, column=14).value = ''
            ### ws_koeki.cell(row=6, column=15).value = '工種区分'
            ### ws_koeki.cell(row=6, column=16).value = '水害原因コード'
            ### ws_koeki.cell(row=6, column=17).value = ''
            ### ws_koeki.cell(row=6, column=18).value = ''
            ### ws_koeki.cell(row=6, column=19).value = '異常気象コード'
            ### ws_koeki.cell(row=6, column=20).value = '事業コード'
            ### ws_koeki.cell(row=6, column=21).value = '調査対象機関名称[全角]'
            ### ws_koeki.cell(row=6, column=22).value = '被害金額'
            ### ws_koeki.cell(row=6, column=23).value = ''
            ### ws_koeki.cell(row=6, column=24).value = ''
            ### ws_koeki.cell(row=6, column=25).value = ''
            ### ws_koeki.cell(row=6, column=26).value = ''
            ### ws_koeki.cell(row=6, column=27).value = '営業停止期間等'
            ### ws_koeki.cell(row=6, column=28).value = ''
            ### ws_koeki.cell(row=6, column=29).value = ''
            ### ws_koeki.cell(row=6, column=30).value = '照会先'
            ### ws_koeki.cell(row=6, column=31).value = ''
            ### ws_koeki.cell(row=6, column=32).value = ''
            ### ws_koeki.cell(row=6, column=33).value = '備考'
            ### ws_koeki.cell(row=7, column=1).value = ''
            ### ws_koeki.cell(row=7, column=2).value = ''
            ### ws_koeki.cell(row=7, column=3).value = ''
            ### ws_koeki.cell(row=7, column=4).value = ''
            ### ws_koeki.cell(row=7, column=5).value = ''
            ### ws_koeki.cell(row=7, column=6).value = '都道府県[全角]'
            ### ws_koeki.cell(row=7, column=7).value = '都道府県コード'
            ### ws_koeki.cell(row=7, column=8).value = '市区町村名[全角]'
            ### ws_koeki.cell(row=7, column=9).value = '市区町村コード'
            ### ws_koeki.cell(row=7, column=10).value = '町丁名・大字名[全角]'
            ### ws_koeki.cell(row=7, column=11).value = '水系・沿岸名[全角]'
            ### ws_koeki.cell(row=7, column=12).value = '水系種別[全角]'
            ### ws_koeki.cell(row=7, column=13).value = '河川・海岸名[全角]'
            ### ws_koeki.cell(row=7, column=14).value = '河川種別[全角]'
            ### ws_koeki.cell(row=7, column=15).value = ''
            ### ws_koeki.cell(row=7, column=16).value = ''
            ### ws_koeki.cell(row=7, column=17).value = ''
            ### ws_koekivv.cell(row=7, column=18).value = ''
            ### ws_koeki.cell(row=7, column=19).value = ''
            ### ws_koeki.cell(row=7, column=20).value = ''
            ### ws_koeki.cell(row=7, column=21).value = ''
            ### ws_koeki.cell(row=7, column=22).value = '物的被害額(千円)'
            ### ws_koeki.cell(row=7, column=23).value = '営業停止損失額(千円)'
            ### ws_koeki.cell(row=7, column=24).value = ''
            ### ws_koeki.cell(row=7, column=25).value = ''
            ### ws_koeki.cell(row=7, column=26).value = '営業停止損失額合計(千円)'
            ### ws_koeki.cell(row=7, column=27).value = '停止期間'
            ### ws_koeki.cell(row=7, column=28).value = ''
            ### ws_koeki.cell(row=7, column=29).value = '停止数量'
            ### ws_koeki.cell(row=7, column=30).value = '調査担当課名[全角]'
            ### ws_koeki.cell(row=7, column=31).value = '調査担当者名[全角]'
            ### ws_koeki.cell(row=7, column=32).value = '電話番号'
            ### ws_koeki.cell(row=7, column=33).value = '備考'
            ### ws_koeki.cell(row=8, column=1).value = ''
            ### ws_koeki.cell(row=8, column=2).value = '月'
            ### ws_koeki.cell(row=8, column=3).value = '日'
            ### ws_koeki.cell(row=8, column=4).value = '月'
            ### ws_koeki.cell(row=8, column=5).value = '日'
            ### ws_koeki.cell(row=8, column=6).value = ''
            ### ws_koeki.cell(row=8, column=7).value = ''
            ### ws_koeki.cell(row=8, column=8).value = ''
            ### ws_koeki.cell(row=8, column=9).value = ''
            ### ws_koeki.cell(row=8, column=10).value = ''
            ### ws_koeki.cell(row=8, column=11).value = ''
            ### ws_koeki.cell(row=8, column=12).value = ''
            ### ws_koeki.cell(row=8, column=13).value = ''
            ### ws_koeki.cell(row=8, column=14).value = ''
            ### ws_koeki.cell(row=8, column=15).value = ''
            ### ws_koeki.cell(row=8, column=16).value = '1'
            ### ws_koeki.cell(row=8, column=17).value = '2'
            ### ws_koeki.cell(row=8, column=18).value = '3'
            ### ws_koeki.cell(row=8, column=19).value = ''
            ### ws_koeki.cell(row=8, column=20).value = ''
            ### ws_koeki.cell(row=8, column=21).value = ''
            ### ws_koeki.cell(row=8, column=22).value = ''
            ### ws_koeki.cell(row=8, column=23).value = '営業停止に伴う売上減少額'
            ### ws_koeki.cell(row=8, column=24).value = '代替活動費（外注費）'
            ### ws_koeki.cell(row=8, column=25).value = 'その他'
            ### ws_koeki.cell(row=8, column=26).value = ''
            ### ws_koeki.cell(row=8, column=27).value = '日'
            ### ws_koeki.cell(row=8, column=28).value = '時間'
            ### ws_koeki.cell(row=8, column=29).value = ''
            ### ws_koeki.cell(row=8, column=30).value = ''
            ### ws_koeki.cell(row=8, column=31).value = ''
            ### ws_koeki.cell(row=8, column=32).value = ''
            ### ws_koeki.cell(row=8, column=33).value = ''

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0060)
            ### 入力データ用のEXCELシートのプルダウンリストをセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7/10.', 'DEBUG')
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_0/10.', 'DEBUG')
            ### 1040: 水系（水系・沿岸）
            ### if len(suikei_list) > 0:
            ###     dv_suikei = DataValidation(type="list", formula1="SUIKEI!$B$1:$B$%d" % len(suikei_list))
            ###     dv_suikei.ranges = 'B8:B6007'
            ###     ws_koeki.add_data_validation(dv_suikei)

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_1/10.', 'DEBUG')
            ### 1050: 水系種別（水系・沿岸種別）
            ### if len(suikei_type_list) > 0:
            ###     dv_suikei_type = DataValidation(type="list", formula1="SUIKEI_TYPE!$B$1:$B$%d" % len(suikei_type_list))
            ###     dv_suikei_type.ranges = 'C8:C6007'
            ###     ws_koeki.add_data_validation(dv_suikei_type)

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_2/10.', 'DEBUG')
            ### 1060: 河川（河川・海岸）
            ### ### dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AA8)")
            ### ### dv_kasen.ranges = 'D8:D8'
            ### ### ws_koeki.add_data_validation(dv_kasen)
            ### ### ws_koeki.cell(row=8, column=27).value = "=VLOOKUP(B8,KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
            ### ### ws_koeki.cell(row=8, column=27).value = "=VLOOKUP(B8,KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS
            ### for i in range(8, 6008):
            ###     dv_kasen = DataValidation(type="list", formula1="=INDIRECT(AA"+str(i)+")")
            ###     dv_kasen.ranges = 'D'+str(i)+':D'+str(i)
            ###     ws_koeki.add_data_validation(dv_kasen)
            ###     ### ws_koeki.cell(row=i, column=27).value = "=VLOOKUP(B"+str(i)+",KASEN_VLOOK.A:B,2,0)" ### FOR LINUX?
            ###     ws_koeki.cell(row=i, column=27).value = "=VLOOKUP(B"+str(i)+",KASEN_VLOOK!A:B,2,0)" ### FOR WINDOWS

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_3/10.', 'DEBUG')
            ### 1070: 河川種別（河川・海岸種別）
            ### if len(kasen_type_list) > 0:
            ###     dv_kasen_type = DataValidation(type="list", formula1="KASEN_TYPE!$B$1:$B$%d" % len(kasen_type_list))
            ###     dv_kasen_type.ranges = 'E8:E6007'
            ###     ws_koeki.add_data_validation(dv_kasen_type)

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_4/10.', 'DEBUG')
            ### 1010: 都道府県
            ### if len(ken_list) > 0:
            ###     dv_ken = DataValidation(type="list", formula1="KEN!$B$1:$B$%d" % len(ken_list))
            ###     dv_ken.ranges = 'G8:G6007'
            ###     ws_koeki.add_data_validation(dv_ken)

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_5/10.', 'DEBUG')
            ### 1010: 都道府県コード
            ### for i in range(8, 6008):
            ###     ws_koeki.cell(row=i, column=9).value = "=RIGHT(G"+str(i)+",2)"

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_6/10.', 'DEBUG')
            ### 1020: 市区町村
            ### ### dv_city = DataValidation(type="list", formula1="=INDIRECT(AB8)")
            ### ### dv_city.ranges = 'H8:H8'
            ### ### ws_koeki.add_data_validation(dv_city)
            ### ### ws_koeki.cell(row=8, column=28).value = "=VLOOKUP(G8,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
            ### ### ws_koeki.cell(row=8, column=28).value = "=VLOOKUP(G8,CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS
            ### for i in range(8, 6008):
            ###     dv_city = DataValidation(type="list", formula1="=INDIRECT(AB"+str(i)+")")
            ###     dv_city.ranges = 'H'+str(i)+':H'+str(i)
            ###     ws_koeki.add_data_validation(dv_city)
            ###     ### ws_koeki.cell(row=i, column=28).value = "=VLOOKUP(G8,CITY_VLOOK.A:B,2,0)" ### FOR LINUX?
            ###     ws_koeki.cell(row=i, column=28).value = "=VLOOKUP(G"+str(i)+",CITY_VLOOK!A:B,2,0)" ### FOR WINDOWS

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_7/10.', 'DEBUG')
            ### 1020: 市区町村コード
            ### for i in range(8, 6008):
            ###     ws_koeki.cell(row=i, column=18).value = "=RIGHT(H"+str(i)+",6)"

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_8/10.', 'DEBUG')
            ### 7010: 入力データ_異常気象
            ### if len(weather_list) > 0:
            ###     dv_weather = DataValidation(type="list", formula1="WEATHER!$B$1:$B$%d" % len(weather_list))
            ###     dv_weather.ranges = 'K8:K6007'
            ###     ws_koeki.add_data_validation(dv_weather)

            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 7_9/10.', 'DEBUG')
            ### 1030: 災害復旧事業工種（河川海岸砂防設備地すべり防止施設区分）
            ### if len(kasen_setubi_list) > 0:
            ###     dv_kasen_setubi = DataValidation(type="list", formula1="KASEN_SETUBI!$B$1:$B$%d" % len(kasen_setubi_list))
            ###     dv_kasen_setubi.ranges = 'P8:P6007'
            ###     ws_koeki.add_data_validation(dv_kasen_setubi)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0070)
            ### EXCELのセルに、値を埋め込む。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 8/10.', 'DEBUG')
            db_params = dict({
                'KOEKI_HEADER_ID': koeki_header_list[0].koeki_header_id
            })
            koeki_list = KOEKI.objects.raw("""
                SELECT 
                    KOE1.KOEKI_ID,
                    KOE1.KOEKI_NAME,
                    KOE1.KOEKI_HEADER_ID, 
                    KOE1.KOEKI_HEADER_NAME, 
                    KOE1.KEN_CODE, 
                    KEN1.KEN_NAME, 
                    KOE1.CITY_CODE, 
                    CIT1.CITY_NAME, 
                    KOE1.SUIKEI_CODE, 
                    SUI1.SUIKEI_NAME, 
                    SUI1.SUIKEI_TYPE_CODE, 
                    SUT1.SUIKEI_TYPE_NAME, 
                    KOE1.KASEN_CODE, 
                    KAS1.KASEN_NAME, 
                    KAS1.KASEN_TYPE_CODE, 
                    KAT1.KASEN_TYPE_NAME, 
                    TO_CHAR(TIMEZONE('JST', KOE1.BEGIN_DATE::TIMESTAMPTZ), 'MM') AS BEGIN_MONTH, 
                    TO_CHAR(TIMEZONE('JST', KOE1.BEGIN_DATE::TIMESTAMPTZ), 'DD') AS BEGIN_DAY, 
                    TO_CHAR(TIMEZONE('JST', KOE1.END_DATE::TIMESTAMPTZ), 'MM') AS END_MONTH, 
                    TO_CHAR(TIMEZONE('JST', KOE1.END_DATE::TIMESTAMPTZ), 'DD') AS END_DAY, 
                    KOE1.KASEN_SETUBI_CODE, 
                    KAB1.KASEN_SETUBI_NAME, 
                    KOE1.WEATHER_ID, 
                    WEA1.WEATHER_NAME, 
                    KOE1.CAUSE_1_CODE, 
                    CAU1.CAUSE_NAME AS CAUSE_1_NAME, 
                    KOE1.CAUSE_2_CODE, 
                    CAU2.CAUSE_NAME AS CAUSE_2_NAME, 
                    KOE1.CAUSE_3_CODE, 
                    CAU3.CAUSE_NAME AS CAUSE_3_NAME, 
                    KOE1.BUSINESS_CODE, 
                    BUS1.BUSINESS_NAME, 
                    KOE1.ORGANIZATION_NAME, 
                    CAST(KOE1.PHYSICAL_DAMAGE AS NUMERIC(20,10)) AS PHYSICAL_DAMAGE, 
                    CAST(KOE1.SALES_DAMAGE AS NUMERIC(20,10)) AS SALES_DAMAGE,
                    CAST(KOE1.ALT_DAMAGE AS NUMERIC(20,10)) AS ALT_DAMAGE, 
                    CAST(KOE1.OTHER_DAMAGE AS NUMERIC(20,10)) AS OTHER_DAMAGE, 
                    CAST(KOE1.SALES_ALT_OTHER_DAMAGE AS NUMERIC(20,10)) AS SALES_ALT_OTHER_DAMAGE, 
                    CAST(KOE1.SUSPENDED_DAYS AS NUMERIC(20,10)) AS SUSPENDED_DAYS, 
                    CAST(KOE1.SUSPENDED_HOURS AS NUMERIC(20,10)) AS SUSPENDED_HOURS, 
                    CAST(KOE1.SUSPENDED_AMOUNTS AS NUMERIC(20,10)) AS SUSPENDED_AMOUNTS, 
                    KOE1.DEPARTMENT_NAME, 
                    KOE1.EMPLOYEE_NAME, 
                    KOE1.TELEPHONE, 
                    KOE1.COMMENT 
                FROM KOEKI_VIEW KOE1 
                LEFT JOIN KEN KEN1 ON KOE1.KEN_CODE=KEN1.KEN_CODE 
                LEFT JOIN CITY CIT1 ON KOE1.CITY_CODE=CIT1.CITY_CODE 
                LEFT JOIN SUIKEI SUI1 ON KOE1.SUIKEI_CODE=SUI1.SUIKEI_CODE 
                LEFT JOIN KASEN KAS1 ON KOE1.KASEN_CODE=KAS1.KASEN_CODE 
                LEFT JOIN KASEN_SETUBI KAB1 ON KOE1.KASEN_SETUBI_CODE=KAB1.KASEN_SETUBI_CODE 
                LEFT JOIN WEATHER WEA1 ON KOE1.WEATHER_ID=WEA1.WEATHER_ID 
                LEFT JOIN CAUSE CAU1 ON KOE1.CAUSE_1_CODE=CAU1.CAUSE_CODE 
                LEFT JOIN CAUSE CAU2 ON KOE1.CAUSE_2_CODE=CAU2.CAUSE_CODE 
                LEFT JOIN CAUSE CAU3 ON KOE1.CAUSE_3_CODE=CAU3.CAUSE_CODE 
                LEFT JOIN SUIKEI_TYPE SUT1 ON SUT1.SUIKEI_TYPE_CODE=SUT1.SUIKEI_TYPE_CODE 
                LEFT JOIN KASEN_TYPE KAT1 ON KAS1.KASEN_TYPE_CODE=KAT1.KASEN_TYPE_CODE 
                LEFT JOIN BUSINESS BUS1 ON KOE1.BUSINESS_CODE=BUS1.BUSINESS_CODE 
                WHERE 
                    KOE1.KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s 
                ORDER BY 
                    CAST(KOE1.KOEKI_ID AS INTEGER)""", db_params)

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0080)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9/10.', 'DEBUG')
            green_fill = PatternFill(fgColor='CCFFCC', patternType='solid')
            if bool(koeki_list) == True:
                for i, koeki in enumerate(koeki_list):
                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_1/10.', 'DEBUG')
                    if (bool(str(koeki.koeki_id)) == True):
                        ws_koeki.cell(row=9+i, column=1).value = (
                            str(koeki.koeki_id)
                        )
                        ws_koeki.cell(row=9+i, column=1).fill = green_fill

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_2/10.', 'DEBUG')
                    if (bool(str(koeki.begin_month)) == True):
                        ws_koeki.cell(row=9+i, column=2).value = (
                            str(koeki.begin_month)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_3/10.', 'DEBUG')
                    if (bool(str(koeki.begin_day)) == True):
                        ws_koeki.cell(row=9+i, column=3).value = (
                            str(koeki.begin_day)
                        )
                    
                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_4/10.', 'DEBUG')
                    if (bool(str(koeki.end_month)) == True):
                        ws_koeki.cell(row=9+i, column=4).value = (
                            str(koeki.end_month)
                        )
                        
                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_5/10.', 'DEBUG')
                    if (bool(str(koeki.end_day)) == True):
                        ws_koeki.cell(row=9+i, column=5).value = (
                            str(koeki.end_day)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_6/10.', 'DEBUG')
                    if (bool(str(koeki.ken_name)) == True and 
                        bool(str(koeki.ken_code)) == True):
                        ws_koeki.cell(row=9+i, column=6).value = (
                            str(koeki.ken_name) + ":" + 
                            str(koeki.ken_code)
                        )
                    
                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_7/10.', 'DEBUG')
                    if (bool(str(koeki.ken_code)) == True):
                        ws_koeki.cell(row=9+i, column=7).value = (
                            str(koeki.ken_code)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_8/10.', 'DEBUG')
                    if (bool(str(koeki.city_name)) == True and 
                        bool(str(koeki.city_code)) == True):
                        ws_koeki.cell(row=9+i, column=8).value = (
                            str(koeki.city_name) + ":" + 
                            str(koeki.city_code)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_9/10.', 'DEBUG')
                    if (bool(str(koeki.city_code)) == True):
                        ws_koeki.cell(row=9+i, column=9).value = (
                            str(koeki.city_code)
                        )
                    
                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_10/10.', 'DEBUG')
                    if (bool(str(koeki.koeki_name)) == True):
                        ws_koeki.cell(row=9+i, column=10).value = (
                            str(koeki.koeki_name)
                        )
                   
                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_11/10.', 'DEBUG')
                    if (bool(str(koeki.suikei_name)) == True and 
                        bool(str(koeki.suikei_code)) == True):
                        ws_koeki.cell(row=9+i, column=11).value = (
                            str(koeki.suikei_name) + ":" + 
                            str(koeki.suikei_code)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_12/10.', 'DEBUG')
                    if (bool(str(koeki.suikei_type_name)) == True and 
                        bool(str(koeki.suikei_type_code)) == True):
                        ws_koeki.cell(row=9+i, column=12).value = (
                            str(koeki.suikei_type_name) + ":" + 
                            str(koeki.suikei_type_code)
                        )
                    
                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_13/10.', 'DEBUG')
                    if (bool(str(koeki.kasen_name)) == True and 
                        bool(str(koeki.kasen_code)) == True):
                        ws_koeki.cell(row=9+i, column=13).value = (
                            str(koeki.kasen_name) + ":" + 
                            str(koeki.kasen_code)
                        )
                        
                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_14/10.', 'DEBUG')
                    if (bool(str(koeki.kasen_type_name)) == True and 
                        bool(str(koeki.kasen_type_code)) == True):
                        ws_koeki.cell(row=9+i, column=14).value = (
                            str(koeki.kasen_type_name) + ":" + 
                            str(koeki.kasen_type_code)
                        )
                    
                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_15/10.', 'DEBUG')
                    if (bool(str(koeki.kasen_setubi_name)) == True and 
                        bool(str(koeki.kasen_setubi_code)) == True):
                        ws_koeki.cell(row=9+i, column=15).value = (
                            str(koeki.kasen_setubi_name) + ":" + 
                            str(koeki.kasen_setubi_code)
                        )
                        
                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_16/10.', 'DEBUG')
                    if (bool(str(koeki.cause_1_name)) == True and 
                        bool(str(koeki.cause_1_code)) == True):
                        ws_koeki.cell(row=9+i, column=16).value = (
                            str(koeki.cause_1_name) + ":" + 
                            str(koeki.cause_1_code)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_17/10.', 'DEBUG')
                    if (bool(str(koeki.cause_2_name)) == True and 
                        bool(str(koeki.cause_2_code)) == True):
                        ws_koeki.cell(row=9+i, column=17).value = (
                            str(koeki.cause_2_name) + ":" + 
                            str(koeki.cause_2_code)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_18/10.', 'DEBUG')
                    if (bool(str(koeki.cause_3_name)) == True and 
                        bool(str(koeki.cause_3_code)) == True):
                        ws_koeki.cell(row=9+i, column=18).value = (
                            str(koeki.cause_3_name) + ":" + 
                            str(koeki.cause_3_code)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_19/10.', 'DEBUG')
                    if (bool(str(koeki.weather_name)) == True and 
                        bool(str(koeki.weather_id)) == True):
                        ws_koeki.cell(row=9+i, column=19).value = (
                            str(koeki.weather_name) + ":" + 
                            str(koeki.weather_id)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_20/10.', 'DEBUG')
                    if (bool(str(koeki.business_name)) == True and 
                        bool(str(koeki.business_code)) == True):
                        ws_koeki.cell(row=9+i, column=20).value = (
                            str(koeki.business_name) + ":" + 
                            str(koeki.business_code)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_21/10.', 'DEBUG')
                    if (bool(str(koeki.organization_name)) == True):
                        ws_koeki.cell(row=9+i, column=21).value = (
                            str(koeki.organization_name)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_22/10.', 'DEBUG')
                    if (bool(str(koeki.physical_damage)) == True):
                        ws_koeki.cell(row=9+i, column=22).value = (
                            str(koeki.physical_damage)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_23/10.', 'DEBUG')
                    if (bool(str(koeki.sales_damage)) == True):
                        ws_koeki.cell(row=9+i, column=23).value = (
                            str(koeki.sales_damage)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_24/10.', 'DEBUG')
                    if (bool(str(koeki.alt_damage)) == True):
                        ws_koeki.cell(row=9+i, column=24).value = (
                            str(koeki.alt_damage)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_25/10.', 'DEBUG')
                    if (bool(str(koeki.other_damage)) == True):
                        ws_koeki.cell(row=9+i, column=25).value = (
                            str(koeki.other_damage)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_26/10.', 'DEBUG')
                    if (bool(str(koeki.sales_alt_other_damage)) == True):
                        ws_koeki.cell(row=9+i, column=26).value = (
                            str(koeki.sales_alt_other_damage)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_27/10.', 'DEBUG')
                    if (bool(str(koeki.suspended_days)) == True):
                        ws_koeki.cell(row=9+i, column=27).value = (
                            str(koeki.suspended_days)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_28/10.', 'DEBUG')
                    if (bool(str(koeki.suspended_hours)) == True):
                        ws_koeki.cell(row=9+i, column=28).value = (
                            str(koeki.suspended_hours)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_29/10.', 'DEBUG')
                    if (bool(str(koeki.suspended_amounts)) == True):
                        ws_koeki.cell(row=9+i, column=29).value = (
                            str(koeki.suspended_amounts)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_30/10.', 'DEBUG')
                    if (bool(str(koeki.department_name)) == True):
                        ws_koeki.cell(row=9+i, column=30).value = (
                            str(koeki.department_name)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_31/10.', 'DEBUG')
                    if (bool(str(koeki.employee_name)) == True):
                        ws_koeki.cell(row=9+i, column=31).value = (
                            str(koeki.employee_name)
                        )

                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_32/10.', 'DEBUG')
                    if (bool(str(koeki.telephone)) == True):
                        ws_koeki.cell(row=9+i, column=32).value = (
                            str(koeki.telephone)
                        )
                    
                    print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 9_33/10.', 'DEBUG')
                    if (bool(str(koeki.comment)) == True):
                        ws_koeki.cell(row=9+i, column=33).value = (
                            str(koeki.comment)
                        )

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0090)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 10/10.', 'DEBUG')
            print_log('[INFO] P0000Common.create_koeki_chosa_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
        
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_koeki_chosa_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        ### ※単数EXCELファイル、単数EXCELシートのため、get_ippan_chosa_excelのような処理は不要である。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 2/9.', 'DEBUG')
        db_params = dict({
            'KOEKI_HEADER_ID': func_params["KOEKI_HEADER_ID"]
        })
        koeki_header_list = KOEKI_HEADER.objects.raw("""
            SELECT 
                * 
            FROM KOEKI_HEADER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s LIMIT 1""", db_params)

        if bool(koeki_header_list) == False:
            print_log('[WARN] P0000Common.get_koeki_chosa_csv_excel()関数が警告終了しました。', 'WARN')
            return False, ""

        #######################################################################
        ### DBアクセス処理(0020)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 3/9.', 'DEBUG')
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        kasen_setubi_list = KASEN_SETUBI.objects.raw("""SELECT * FROM KASEN_SETUBI ORDER BY CAST(KASEN_SETUBI_CODE AS INTEGER)""")
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/koeki_chosa_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'koeki_chosa_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/koeki_chosa_'+ str(hash_code) + '.csv'
        csv_file_name = 'koeki_chosa_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_koeki_chosa.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0060)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_koeki_chosa_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0080)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_chosa_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if func_params["FILE_TYPE"] == _KOE_CHO_EXC:
            return True, excel_file_path
        elif func_params["FILE_TYPE"] == _KOE_CHO_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_koeki_chosa_csv_excel()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_koeki_chosa_csv_excel()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_koeki_chosa_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 一般資産集計結果ファイル生成処理
### func_params["IPPAN_HEADER_ID"]
### func_params["FILE_TYPE"]
###############################################################################
def get_ippan_summary_csv_excel(request, func_params):

    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、複数EXCELシート対応版
    ###########################################################################
    def create_ippan_summary_workbook():
        try:
            
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0000)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_ippan_summary_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 1/6.', 'DEBUG')
            
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 2/6.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_ippan_summary = workbook["IPPAN_SUMMARY"]
            
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 3/6.', 'DEBUG')
            ws_ippan_summary.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 4/6.', 'DEBUG')
            ws_ippan_summary.cell(row=6, column=1).value = ''
            ws_ippan_summary.cell(row=6, column=2).value = ''
            ws_ippan_summary.cell(row=6, column=3).value = ''
            ws_ippan_summary.cell(row=6, column=4).value = ''
            ws_ippan_summary.cell(row=6, column=5).value = ''
            ws_ippan_summary.cell(row=6, column=6).value = ''

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### 入力データ用のEXCELシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_chosa_workbook()関数 STEP 5/6.', 'DEBUG')
            for i, ippan_header in enumerate(ippan_header_list):
                db_params = dict({
                    'IPPAN_HEADER_ID': ippan_header.ippan_header_id
                })
                ippan_summary_list = IPPAN_SUMMARY.objects.raw("""
                    SELECT 
                        IPS1.ID, 
                        IPS1.IPPAN_ID, 
                        IPP1.IPPAN_NAME, 
                        IPS1.IPPAN_HEADER_ID, 
                        IPH1.IPPAN_HEADER_NAME, 
                        IPH1.KEN_CODE, 
                        KEN1.KEN_NAME, 
                        IPH1.CITY_CODE, 
                        CIT1.CITY_NAME, 
                        CAST(IPS1.HOUSE_SUMMARY_LV00 AS NUMERIC(20,10)) AS HOUSE_SUMMARY_LV00, 
                        CAST(IPS1.HOUSE_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS HOUSE_SUMMARY_LV01_49, 
                        CAST(IPS1.HOUSE_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS HOUSE_SUMMARY_LV50_99, 
                        CAST(IPS1.HOUSE_SUMMARY_LV100 AS NUMERIC(20,10)) AS HOUSE_SUMMARY_LV100, 
                        CAST(IPS1.HOUSE_SUMMARY_HALF AS NUMERIC(20,10)) AS HOUSE_SUMMARY_HALF, 
                        CAST(IPS1.HOUSE_SUMMARY_FULL AS NUMERIC(20,10)) AS HOUSE_SUMMARY_FULL, 
                        CAST(IPS1.HOUSEHOLD_SUMMARY_LV00 AS NUMERIC(20,10)) AS HOUSEHOLD_SUMMARY_LV00, 
                        CAST(IPS1.HOUSEHOLD_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS HOUSEHOLD_SUMMARY_LV01_49, 
                        CAST(IPS1.HOUSEHOLD_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS HOUSEHOLD_SUMMARY_LV50_99, 
                        CAST(IPS1.HOUSEHOLD_SUMMARY_LV100 AS NUMERIC(20,10)) AS HOUSEHOLD_SUMMARY_LV100, 
                        CAST(IPS1.HOUSEHOLD_SUMMARY_HALF AS NUMERIC(20,10)) AS HOUSEHOLD_SUMMARY_HALF, 
                        CAST(IPS1.HOUSEHOLD_SUMMARY_FULL AS NUMERIC(20,10)) AS HOUSEHOLD_SUMMARY_FULL, 
                        CAST(IPS1.CAR_SUMMARY_LV00 AS NUMERIC(20,10)) AS CAR_SUMMARY_LV00, 
                        CAST(IPS1.CAR_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS CAR_SUMMARY_LV01_49, 
                        CAST(IPS1.CAR_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS CAR_SUMMARY_LV50_99, 
                        CAST(IPS1.CAR_SUMMARY_LV100 AS NUMERIC(20,10)) AS CAR_SUMMARY_LV100, 
                        CAST(IPS1.CAR_SUMMARY_HALF AS NUMERIC(20,10)) AS CAR_SUMMARY_HALF, 
                        CAST(IPS1.CAR_SUMMARY_FULL AS NUMERIC(20,10)) AS CAR_SUMMARY_FULL, 
                        CAST(IPS1.HOUSE_ALT_SUMMARY_LV00 AS NUMERIC(20,10)) AS HOUSE_ALT_SUMMARY_LV00, 
                        CAST(IPS1.HOUSE_ALT_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS HOUSE_ALT_SUMMARY_LV01_49, 
                        CAST(IPS1.HOUSE_ALT_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS HOUSE_ALT_SUMMARY_LV50_99, 
                        CAST(IPS1.HOUSE_ALT_SUMMARY_LV100 AS NUMERIC(20,10)) AS HOUSE_ALT_SUMMARY_LV100, 
                        CAST(IPS1.HOUSE_ALT_SUMMARY_HALF AS NUMERIC(20,10)) AS HOUSE_ALT_SUMMARY_HALF, 
                        CAST(IPS1.HOUSE_ALT_SUMMARY_FULL AS NUMERIC(20,10)) AS HOUSE_ALT_SUMMARY_FULL, 
                        CAST(IPS1.HOUSE_CLEAN_SUMMARY_LV00 AS NUMERIC(20,10)) AS HOUSE_CLEAN_SUMMARY_LV00, 
                        CAST(IPS1.HOUSE_CLEAN_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS HOUSE_CLEAN_SUMMARY_LV01_49, 
                        CAST(IPS1.HOUSE_CLEAN_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS HOUSE_CLEAN_SUMMARY_LV50_99, 
                        CAST(IPS1.HOUSE_CLEAN_SUMMARY_LV100 AS NUMERIC(20,10)) AS HOUSE_CLEAN_SUMMARY_LV100, 
                        CAST(IPS1.HOUSE_CLEAN_SUMMARY_HALF AS NUMERIC(20,10)) AS HOUSE_CLEAN_SUMMARY_HALF, 
                        CAST(IPS1.HOUSE_CLEAN_SUMMARY_FULL AS NUMERIC(20,10)) AS HOUSE_CLEAN_SUMMARY_FULL, 
                        CAST(IPS1.OFFICE_DEP_SUMMARY_LV00 AS NUMERIC(20,10)) AS OFFICE_DEP_SUMMARY_LV00, 
                        CAST(IPS1.OFFICE_DEP_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS OFFICE_DEP_SUMMARY_LV01_49, 
                        CAST(IPS1.OFFICE_DEP_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS OFFICE_DEP_SUMMARY_LV50_99, 
                        CAST(IPS1.OFFICE_DEP_SUMMARY_LV100 AS NUMERIC(20,10)) AS OFFICE_DEP_SUMMARY_LV100, 
                        CAST(IPS1.OFFICE_DEP_SUMMARY_FULL AS NUMERIC(20,10)) AS OFFICE_DEP_SUMMARY_FULL, 
                        CAST(IPS1.OFFICE_INV_SUMMARY_LV00 AS NUMERIC(20,10)) AS OFFICE_INV_SUMMARY_LV00, 
                        CAST(IPS1.OFFICE_INV_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS OFFICE_INV_SUMMARY_LV01_49, 
                        CAST(IPS1.OFFICE_INV_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS OFFICE_INV_SUMMARY_LV50_99, 
                        CAST(IPS1.OFFICE_INV_SUMMARY_LV100 AS NUMERIC(20,10)) AS OFFICE_INV_SUMMARY_LV100, 
                        CAST(IPS1.OFFICE_INV_SUMMARY_FULL AS NUMERIC(20,10)) AS OFFICE_INV_SUMMARY_FULL, 
                        CAST(IPS1.OFFICE_SUS_SUMMARY_LV00 AS NUMERIC(20,10)) AS OFFICE_SUS_SUMMARY_LV00, 
                        CAST(IPS1.OFFICE_SUS_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS OFFICE_SUS_SUMMARY_LV01_49, 
                        CAST(IPS1.OFFICE_SUS_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS OFFICE_SUS_SUMMARY_LV50_99, 
                        CAST(IPS1.OFFICE_SUS_SUMMARY_LV100 AS NUMERIC(20,10)) AS OFFICE_SUS_SUMMARY_LV100, 
                        CAST(IPS1.OFFICE_SUS_SUMMARY_FULL AS NUMERIC(20,10)) AS OFFICE_SUS_SUMMARY_FULL, 
                        CAST(IPS1.OFFICE_STG_SUMMARY_LV00 AS NUMERIC(20,10)) AS OFFICE_STG_SUMMARY_LV00, 
                        CAST(IPS1.OFFICE_STG_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS OFFICE_STG_SUMMARY_LV01_49, 
                        CAST(IPS1.OFFICE_STG_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS OFFICE_STG_SUMMARY_LV50_99, 
                        CAST(IPS1.OFFICE_STG_SUMMARY_LV100 AS NUMERIC(20,10)) AS OFFICE_STG_SUMMARY_LV100, 
                        CAST(IPS1.OFFICE_STG_SUMMARY_FULL AS NUMERIC(20,10)) AS OFFICE_STG_SUMMARY_FULL, 
                        CAST(IPS1.FARMER_FISHER_DEP_SUMMARY_LV00 AS NUMERIC(20,10)) AS FARMER_FISHER_DEP_SUMMARY_LV00, 
                        CAST(IPS1.FARMER_FISHER_DEP_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS FARMER_FISHER_DEP_SUMMARY_LV01_49, 
                        CAST(IPS1.FARMER_FISHER_DEP_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS FARMER_FISHER_DEP_SUMMARY_LV50_99, 
                        CAST(IPS1.FARMER_FISHER_DEP_SUMMARY_LV100 AS NUMERIC(20,10)) AS FARMER_FISHER_DEP_SUMMARY_LV100, 
                        CAST(IPS1.FARMER_FISHER_DEP_SUMMARY_FULL AS NUMERIC(20,10)) AS FARMER_FISHER_DEP_SUMMARY_FULL, 
                        CAST(IPS1.FARMER_FISHER_INV_SUMMARY_LV00 AS NUMERIC(20,10)) AS FARMER_FISHER_INV_SUMMARY_LV00, 
                        CAST(IPS1.FARMER_FISHER_INV_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS FARMER_FISHER_INV_SUMMARY_LV01_49, 
                        CAST(IPS1.FARMER_FISHER_INV_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS FARMER_FISHER_INV_SUMMARY_LV50_99, 
                        CAST(IPS1.FARMER_FISHER_INV_SUMMARY_LV100 AS NUMERIC(20,10)) AS FARMER_FISHER_INV_SUMMARY_LV100, 
                        CAST(IPS1.FARMER_FISHER_INV_SUMMARY_FULL AS NUMERIC(20,10)) AS FARMER_FISHER_INV_SUMMARY_FULL, 
                        CAST(IPS1.OFFICE_ALT_SUMMARY_LV00 AS NUMERIC(20,10)) AS OFFICE_ALT_SUMMARY_LV00, 
                        CAST(IPS1.OFFICE_ALT_SUMMARY_LV01_49 AS NUMERIC(20,10)) AS OFFICE_ALT_SUMMARY_LV01_49, 
                        CAST(IPS1.OFFICE_ALT_SUMMARY_LV50_99 AS NUMERIC(20,10)) AS OFFICE_ALT_SUMMARY_LV50_99, 
                        CAST(IPS1.OFFICE_ALT_SUMMARY_LV100 AS NUMERIC(20,10)) AS OFFICE_ALT_SUMMARY_LV100, 
                        CAST(IPS1.OFFICE_ALT_SUMMARY_HALF AS NUMERIC(20,10)) AS OFFICE_ALT_SUMMARY_HALF, 
                        CAST(IPS1.OFFICE_ALT_SUMMARY_FULL AS NUMERIC(20,10)) AS OFFICE_ALT_SUMMARY_FULL 
                    FROM IPPAN_SUMMARY IPS1 
                    LEFT JOIN IPPAN IPP1 ON IPS1.IPPAN_ID=IPP1.IPPAN_ID 
                    LEFT JOIN IPPAN_HEADER IPH1 ON IPS1.IPPAN_HEADER_ID=IPH1.IPPAN_HEADER_ID 
                    LEFT JOIN KEN KEN1 ON IPH1.KEN_CODE=KEN1.KEN_CODE 
                    LEFT JOIN CITY CIT1 ON IPH1.CITY_CODE=CIT1.CITY_CODE 
                    WHERE 
                        IPS1.IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s  
                    ORDER BY 
                        CAST(IPS1.IPPAN_ID AS INTEGER)""", db_params)
                
                if bool(ippan_summary_list) == True:
                    for j, ippan_summary in enumerate(ippan_summary_list):
                        ws_ippan_summary.cell(row=j+20, column=1).value = ippan_summary.ken_name
                        ws_ippan_summary.cell(row=j+20, column=2).value = ippan_summary.ken_name
                        ws_ippan_summary.cell(row=j+20, column=3).value = ippan_summary.ken_name
                        ws_ippan_summary.cell(row=j+20, column=4).value = ippan_summary.ken_name
                        ws_ippan_summary.cell(row=j+20, column=5).value = ippan_summary.ken_name
                        ws_ippan_summary.cell(row=j+20, column=6).value = ippan_summary.ken_name
                        ws_ippan_summary.cell(row=j+20, column=7).value = ippan_summary.ken_name
                        ws_ippan_summary.cell(row=j+20, column=8).value = ippan_summary.ken_name
                        ws_ippan_summary.cell(row=j+20, column=9).value = ippan_summary.ken_name
                        ws_ippan_summary.cell(row=j+20, column=10).value = ippan_summary.ken_name
            
            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_ippan_summary_workbook()関数 STEP 6/6.', 'DEBUG')
            print_log('[INFO] P0000Common.create_ippan_summary_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
        
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
            
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_ippan_summary_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        ### ※単数EXCELファイル、複数EXCELシートに対応するため、
        ### ※IPPAN_HEADER_ID(=1シートに対応)から、UPLOAD_FILE_PATHを経由して、IPPAN_HEADER_IDのリスト(=全シートに対応)を取得する。
        ### ※この処理の前提条件は、UPLOAD_FILE_PATHがユニークである必要があり、そのためにアップロード日時をファイル名に付与している。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 2/9.', 'DEBUG')
        db_params = dict({
            'IPPAN_HEADER_ID': func_params["IPPAN_HEADER_ID"]
        })
        local_ippan_header_list = IPPAN_HEADER.objects.raw("""
            SELECT 
                * 
            FROM IPPAN_HEADER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s LIMIT 1""", db_params)
        
        if bool(local_ippan_header_list) == False:
            print_log('[WARN] P0000Common.get_ippan_summary_csv_excel()関数が警告終了しました。', 'WARN')
            return False, ""

        db_params = dict({
            'UPLOAD_FILE_PATH': local_ippan_header_list[0].upload_file_path
        })
        ippan_header_list = IPPAN_HEADER.objects.raw("""
            SELECT 
                * 
            FROM IPPAN_HEADER 
            WHERE 
                UPLOAD_FILE_PATH=%(UPLOAD_FILE_PATH)s
            ORDER BY CAST(IPPAN_HEADER_ID AS INTEGER)""", db_params)

        if bool(ippan_header_list) == False:
            print_log('[WARN] P0000Common.get_ippan_summary_csv_excel()関数が警告終了しました。', 'WARN')
            return False, ""

        if bool(ippan_header_list) == True:
            ippan_header_count = len(ippan_header_list)
        else:
            ippan_header_count = 0

        #######################################################################
        ### DBアクセス処理(0020)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 3/9.', 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/ippan_summary_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'ippan_summary_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/ippan_summary_'+ str(hash_code) + '.csv'
        csv_file_name = 'ippan_summary_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_ippan_summary.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0060)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_ippan_summary_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0080)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_ippan_summary_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if func_params["FILE_TYPE"] == _IPP_SUM_EXC:
            return True, excel_file_path
        elif func_params["FILE_TYPE"] == _IPP_SUM_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_ippan_summary_csv_excel()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_ippan_summary_csv_excel()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_ippan_summary_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公共土木施設地方単独事業集計結果ファイル生成処理
### func_params["CHITAN_HEADER_ID"]
### func_params["FILE_TYPE"]
###############################################################################
def get_chitan_summary_csv_excel(request, func_params):

    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、複数EXCELシート対応版
    ###########################################################################
    def create_chitan_summary_workbook():
        try:

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0000)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_chitan_summary_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_chitan_summary_workbook()関数 STEP 1/6.', 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_summary_workbook()関数 STEP 2/6.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_chitan_summary = workbook["CHITAN_SUMMARY"]

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_summary_workbook()関数 STEP 3/6.', 'DEBUG')
            ws_chitan_summary.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_summary_workbook()関数 STEP 4/6.', 'DEBUG')
            ws_chitan_summary.cell(row=6, column=1).value = ''
            ws_chitan_summary.cell(row=6, column=2).value = ''
            ws_chitan_summary.cell(row=6, column=3).value = ''
            ws_chitan_summary.cell(row=6, column=4).value = ''
            ws_chitan_summary.cell(row=6, column=5).value = ''
            ws_chitan_summary.cell(row=6, column=6).value = ''

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### 入力データ用のEXCELシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_chosa_workbook()関数 STEP 5/6.', 'DEBUG')
            for i, chitan_summary in enumerate(chitan_summary_list):
                ws_chitan_summary.cell(row=i+20, column=1).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=2).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=3).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=4).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=5).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=6).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=7).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=8).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=9).value = chitan_summary.ken_name
                ws_chitan_summary.cell(row=i+20, column=10).value = chitan_summary.ken_name

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_chitan_summary_workbook()関数 STEP 6/6.', 'DEBUG')
            print_log('[INFO] P0000Common.create_chitan_summary_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
            
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_chitan_summary_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 2/9.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0020)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 3/9.', 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/chitan_summary_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'chitan_summary_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/chitan_summary_'+ str(hash_code) + '.csv'
        csv_file_name = 'chitan_summary_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_chitan_summary.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0060)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_chitan_summary_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0080)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_chitan_summary_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if func_params["FILE_TYPE"] == _CHI_SUM_EXC:
            return True, excel_file_path
        elif func_params["FILE_TYPE"] == _CHI_SUM_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_chitan_summary_csv_excel()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_chitan_summary_csv_excel()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_chitan_summary_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公共土木施設補助事業集計結果ファイル生成処理
### func_params["HOJO_HEADER_ID"]
### func_params["FILE_TYPE"]
###############################################################################
def get_hojo_summary_csv_excel(request, func_params):

    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、複数EXCELシート対応版
    ###########################################################################
    def create_hojo_summary_workbook():
        try:

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0000)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_hojo_summary_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_hojo_summary_workbook()関数 STEP 1/6.', 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_summary_workbook()関数 STEP 2/6.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_hojo_summary = workbook["HOJO_SUMMARY"]

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_summary_workbook()関数 STEP 3/6.', 'DEBUG')
            ws_hojo_summary.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_summary_workbook()関数 STEP 4/6.', 'DEBUG')
            ws_hojo_summary.cell(row=6, column=1).value = ''
            ws_hojo_summary.cell(row=6, column=2).value = ''
            ws_hojo_summary.cell(row=6, column=3).value = ''
            ws_hojo_summary.cell(row=6, column=4).value = ''
            ws_hojo_summary.cell(row=6, column=5).value = ''
            ws_hojo_summary.cell(row=6, column=6).value = ''

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### 入力データ用のEXCELシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_chosa_workbook()関数 STEP 5/6.', 'DEBUG')
            for i, hojo_summary in enumerate(hojo_summary_list):
                ws_hojo_summary.cell(row=i+20, column=1).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=2).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=3).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=4).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=5).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=6).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=7).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=8).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=9).value = hojo_summary.ken_name
                ws_hojo_summary.cell(row=i+20, column=10).value = hojo_summary.ken_name

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_hojo_summary_workbook()関数 STEP 6/6.', 'DEBUG')
            print_log('[INFO] P0000Common.create_hojo_summary_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
            
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_hojo_summary_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 2/9.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0020)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 3/9.', 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 5/6.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/hojo_summary_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'hojo_summary_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/hojo_summary_'+ str(hash_code) + '.csv'
        csv_file_name = 'hojo_summary_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_hojo_summary.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0060)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_hojo_summary_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0080)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_hojo_summary_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if func_params["FILE_TYPE"] == _HOJ_SUM_EXC:
            return True, excel_file_path
        elif func_params["FILE_TYPE"] == _HOJ_SUM_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_hojo_summary_csv_excel()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_hojo_summary_csv_excel()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_hojo_summary_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公益事業集計結果ファイル生成処理
### func_params["KOEKI_HEADER_ID"]
### func_params["FILE_TYPE"]
###############################################################################
def get_koeki_summary_csv_excel(request, func_params):
    
    ###########################################################################
    ### 関数内関数：ワークブック生成処理
    ### ※単数EXCELファイル、複数EXCELシート対応版
    ###########################################################################
    def create_koeki_summary_workbook():
        try:

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0000)
            ### ブラウザからのリクエストと引数をチェックする。
            ###################################################################
            print_log('[INFO] P0000Common.create_koeki_summary_workbook()関数が開始しました。', 'INFO')
            print_log('[DEBUG] P0000Common.create_koeki_summary_workbook()関数 STEP 1/6.', 'DEBUG')

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0010)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_summary_workbook()関数 STEP 2/6.', 'DEBUG')
            workbook = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_koeki_summary = workbook["KOEKI_SUMMARY"]

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0020)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_summary_workbook()関数 STEP 3/6.', 'DEBUG')
            ws_koeki_summary.sheet_view.showGridLines = False

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0030)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_summary_workbook()関数 STEP 4/6.', 'DEBUG')
            ws_koeki_summary.cell(row=6, column=1).value = ''
            ws_koeki_summary.cell(row=6, column=2).value = ''
            ws_koeki_summary.cell(row=6, column=3).value = ''
            ws_koeki_summary.cell(row=6, column=4).value = ''
            ws_koeki_summary.cell(row=6, column=5).value = ''
            ws_koeki_summary.cell(row=6, column=6).value = ''

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0040)
            ### 入力データ用のEXCELシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_chosa_workbook()関数 STEP 5/6.', 'DEBUG')
            for i, koeki_summary in enumerate(koeki_summary_list):
                ws_koeki_summary.cell(row=i+20, column=1).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=2).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=3).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=4).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=5).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=6).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=7).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=8).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=9).value = koeki_summary.ken_name
                ws_koeki_summary.cell(row=i+20, column=10).value = koeki_summary.ken_name

            ###################################################################
            ### 関数内関数：ワークブック生成処理(0050)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] P0000Common.create_koeki_summary_workbook()関数 STEP 6/6.', 'DEBUG')
            print_log('[INFO] P0000Common.create_koeki_summary_workbook()関数が正常終了しました。', 'INFO')
            return True, workbook
            
        except:
            return False, ""

    ###########################################################################
    ### 関数内関数：EXCELからCSVへの変換処理
    ###########################################################################
    def convert_excel_to_csv(excel_file_path, csv_file_path):
        try:
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 1/2.', 'DEBUG')
            workbook = openpyxl.load_workbook(excel_file_path, data_only=True)
            worksheet = workbook.worksheets[0]
            with open(csv_file_path, 'w', newline='', encoding='utf-16') as csvfile:
                writer = csv.writer(csvfile)
                for row in worksheet.rows:
                    writer.writerow([cell.value for cell in row])
                    
            print_log('[DEBUG] P0000Common.convert_excel_to_csv()関数 STEP 2/2.', 'DEBUG')
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_koeki_summary_csv_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 1/9.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 2/9.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0020)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 3/9.', 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 4/9.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 5/9.', 'DEBUG')
        excel_file_path = 'static/tmp/' + str(hash_code) + '/koeki_summary_'+ str(hash_code) + '.xlsx'
        excel_file_name = 'koeki_summary_'+ str(hash_code) + '.xlsx'
        csv_file_path = 'static/tmp/' + str(hash_code) + '/koeki_summary_'+ str(hash_code) + '.csv'
        csv_file_name = 'koeki_summary_'+ str(hash_code) + '.csv'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 6/9.', 'DEBUG')
        template_file_path = 'static/template/template_koeki_summary.xlsx'

        #######################################################################
        ### 関数内関数コール処理(0060)
        ### EXCELワークブックを生成する関数内関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 7/9.', 'DEBUG')
        bool_return, workbook_return = create_koeki_summary_workbook()
        if bool_return == False:
            raise Exception
            
        workbook_return.save(excel_file_path)

        #######################################################################
        ### 関数内関数コール処理(0070)
        ### EXCELをCSVに変換する関数をコールする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 8/9.', 'DEBUG')
        bool_return = convert_excel_to_csv(excel_file_path, csv_file_path)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0080)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_koeki_summary_csv_excel()関数 STEP 9/9.', 'DEBUG')
        if func_params["FILE_TYPE"] == _KOE_SUM_EXC:
            return True, excel_file_path
        elif func_params["FILE_TYPE"] == _KOE_SUM_CSV:
            return True, csv_file_path

    except:
        print_log('[ERROR] P0000Common.get_koeki_summary_csv_excel()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_koeki_summary_csv_excel()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_koeki_summary_csv_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 水害区域図ファイル生成処理
### func_params["AREA_ID"]
### func_params["FILE_TYPE"]
###############################################################################
def get_area_kml_pdf(request, func_params):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.get_area_kml_pdf()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.get_area_kml_pdf()関数 STEP 1/5.', 'DEBUG')
        print_log('[DEBUG] P0000Common.get_area_kml_pdf()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.get_area_kml_pdf()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_area_kml_pdf()関数 STEP 2/5.', 'DEBUG')
        db_params = dict({
            'AREA_ID': func_params["AREA_ID"]
        })
        area_list = AREA.objects.raw("""
            SELECT 
                * 
            FROM AREA 
            WHERE 
                AREA_ID=%(AREA_ID)s LIMIT 1""", db_params)

        #######################################################################
        ### 局所変数セット処理(0020)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_area_kml_pdf()関数 STEP 3/5.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.get_area_kml_pdf()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_area_kml_pdf()関数 STEP 4/5.', 'DEBUG')
        pdf_file_path = 'static/tmp/' + str(hash_code) + '/area_'+ str(hash_code) + '.pdf'
        pdf_file_name = 'area_'+ str(hash_code) + '.pdf'
        kml_file_path = 'static/tmp/' + str(hash_code) + '/area_'+ str(hash_code) + '.kml'
        kml_file_name = 'area_'+ str(hash_code) + '.kml'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)
        shutil.copyfile(area_list[0].upload_file_path, pdf_file_path)

        #######################################################################
        ### レスポンスセット処理(0040)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.get_area_kml_pdf()関数 STEP 5/5.', 'DEBUG')
        if func_params["FILE_TYPE"] == _ARE_PDF:
            return True, pdf_file_path
        elif func_params["FILE_TYPE"] == _ARE_KML:
            return True, kml_file_path

    except:
        print_log('[ERROR] P0000Common.get_area_kml_pdf()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.get_area_kml_pdf()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.get_area_kml_pdf()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 一般資産調査員調査票ファイル新規生成処理
### func_params[""]
###############################################################################
def create_ippan_chosa_excel(request, func_params):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.create_ippan_chosa_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.create_ippan_chosa_excel()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0000Common.create_ippan_chosa_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.create_ippan_chosa_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_excel()関数 STEP 2/6.', 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、Falseを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_excel()関数 STEP 3/6.', 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_excel()関数 STEP 4/6.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.create_ippan_chosa_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_excel()関数 STEP 5/6.', 'DEBUG')
        file_path = 'static/tmp/' + str(hash_code) + '/ippan_chosa_'+ str(hash_code) + '.xlsx'
        file_name = 'ippan_chosa_'+ str(hash_code) + '.xlsx'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### レスポンスセット処理(0050)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_ippan_chosa_excel()関数 STEP 6/6.', 'DEBUG')
        return True, file_path

    except:
        print_log('[ERROR] P0000Common.create_ippan_chosa_excel()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.create_ippan_chosa_excel()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.create_ippan_chosa_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公共土木施設地方単独事業調査票ファイル新規生成処理
### func_params[""]
###############################################################################
def create_chitan_chosa_excel(request, func_params):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.create_chitan_chosa_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.create_chitan_chosa_excel()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0000Common.create_chitan_chosa_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.create_chitan_chosa_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_chitan_chosa_excel()関数 STEP 2/6.', 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、Falseを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_chitan_chosa_excel()関数 STEP 3/6.', 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_chitan_chosa_excel()関数 STEP 4/6.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.create_chitan_chosa_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_chitan_chosa_excel()関数 STEP 5/6.', 'DEBUG')
        file_path = 'static/tmp/' + str(hash_code) + '/chitan_chosa_'+ str(hash_code) + '.xlsx'
        file_name = 'chitan_chosa_'+ str(hash_code) + '.xlsx'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### レスポンスセット処理(0050)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_chitan_chosa_excel()関数 STEP 6/6.', 'DEBUG')
        return True, file_path

    except:
        print_log('[ERROR] P0000Common.create_chitan_chosa_excel()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.create_chitan_chosa_excel()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.create_chitan_chosa_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公共土木施設補助事業調査票ファイル新規生成処理
### func_params[""]
###############################################################################
def create_hojo_chosa_excel(request, func_params):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.create_hojo_chosa_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.create_hojo_chosa_excel()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0000Common.create_hojo_chosa_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.create_hojo_chosa_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_hojo_chosa_excel()関数 STEP 2/6.', 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、Falseを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_hojo_chosa_excel()関数 STEP 3/6.', 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_hojo_chosa_excel()関数 STEP 4/6.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.create_hojo_chosa_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_hojo_chosa_excel()関数 STEP 5/6.', 'DEBUG')
        file_path = 'static/tmp/' + str(hash_code) + '/hojo_chosa_'+ str(hash_code) + '.xlsx'
        file_name = 'hojo_chosa_'+ str(hash_code) + '.xlsx'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### レスポンスセット処理(0050)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_hojo_chosa_excel()関数 STEP 6/6.', 'DEBUG')
        return True, file_path

    except:
        print_log('[ERROR] P0000Common.create_hojo_chosa_excel()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.create_hojo_chosa_excel()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.create_hojo_chosa_excel()関数が異常終了しました。', 'ERROR')
        return False, ""

###############################################################################
### 公益事業調査票ファイル新規生成処理
### func_params[""]
###############################################################################
def create_koeki_chosa_excel(request, func_params):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0000Common.create_koeki_chosa_excel()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0000Common.create_koeki_chosa_excel()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0000Common.create_koeki_chosa_excel()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0000Common.create_koeki_chosa_excel()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_koeki_chosa_excel()関数 STEP 2/6.', 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、Falseを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_koeki_chosa_excel()関数 STEP 3/6.', 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0030)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_koeki_chosa_excel()関数 STEP 4/6.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0000Common.create_koeki_chosa_excel()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ファイルパス、ファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_koeki_chosa_excel()関数 STEP 5/6.', 'DEBUG')
        file_path = 'static/tmp/' + str(hash_code) + '/koeki_chosa_'+ str(hash_code) + '.xlsx'
        file_name = 'koeki_chosa_'+ str(hash_code) + '.xlsx'
        dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(dir_path, exist_ok=True)

        #######################################################################
        ### レスポンスセット処理(0050)
        ### 正常ケースの場合、Trueとファイルパスを戻す。
        #######################################################################
        print_log('[DEBUG] P0000Common.create_koeki_chosa_excel()関数 STEP 6/6.', 'DEBUG')
        return True, file_path

    except:
        print_log('[ERROR] P0000Common.create_koeki_chosa_excel()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0000Common.create_koeki_chosa_excel()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0000Common.create_koeki_chosa_excel()関数が異常終了しました。', 'ERROR')
        return False, ""
