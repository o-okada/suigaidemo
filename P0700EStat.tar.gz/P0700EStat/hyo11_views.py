###############################################################################
### 帳票名：hyo_11主要異常気象別都道府県別水害被害.xlsx
### ファイル名：P0700EStat/hyo11_views.py
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO11:
    def __init__(self, ):
        pass

###############################################################################
### 帳票名：hyo_11主要異常気象別都道府県別水害被害.xlsx
### 関数名：get_hyo11_weather_ids()
### 0 異常気象一覧
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo11_weather_ids():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo11_weather_ids()関数 STEP 1/4.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo11_weather_ids()関数 STEP 2/4.', 'DEBUG')
        hyo11_weather_ids = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 

                weather_id 
            FROM weather 
            ORDER BY weather_id 
            LIMIT 3 
            """, [])
        
        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo11_weather_ids()関数 STEP 3/4.', 'DEBUG')
        weather_1_id = None
        weather_2_id = None
        weather_3_id = None
        for i, weather in enumerate(hyo11_weather_ids):
            if i == 0:
                weather_1_id = weather.weather_id
            if i == 1:
                weather_2_id = weather.weather_id
            if i == 2:
                weather_3_id = weather.weather_id

        #######################################################################
        ### 戻り値セット処理(0030)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo11_weather_ids()関数 STEP 4/4.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo11_weather_ids()関数が正常終了しました。', 'INFO')
        return True, weather_1_id, weather_2_id, weather_3_id 
    except:
        print_log('[ERROR] P0700EStat.get_hyo11_weather_ids()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo11_weather_ids()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo11_weather_ids()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_11主要異常気象別都道府県別水害被害.xlsx
### 関数名：get_hyo11_weather_ken(weather_id, ken_code)
### 1 主要異常気象別_都道府県別_被害額
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo11_weather_ken(weather_id, ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo11_weather_ken()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo11_weather_ken()関数 weather_id={}'.format(weather_id), 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo11_weather_ken()関数 ken_code={}'.format(ken_code), 'DEBUG')
        ### if ken_code in constants.ken_values:
        ###     pass
        ### else:
        ###     print_log('[WARN] P0700EStat.get_hyo11_weather_ken()関数が警告終了しました。', 'INFO')
        ###     return False, []
        
        if ken_code in constants.ken_values:
            pass
        else:
            print_log('[WARN] P0700EStat.get_hyo11_weather_ken()関数が警告終了しました。', 'INFO')
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        weather_keys = ['WEATHER_ID']
        weather_values = [weather_id]
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(weather_keys + ken_keys + constants.setubi_keys, weather_values + ken_values + constants.setubi_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo11_weather_ken()関数 STEP 2/3.', 'DEBUG')
        hyo11_weather_ken_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.ippan_suikei_num) IS NULL THEN 0.00 ELSE IPPAN01.ippan_suikei_num END, 
                CASE WHEN (IPPAN02.ippan_kasen_num) IS NULL THEN 0.00 ELSE IPPAN02.ippan_kasen_num END, 
                CASE WHEN (IPPAN03.ippan_city_num) IS NULL THEN 0.00 ELSE IPPAN03.ippan_city_num END, 
                CASE WHEN (IPPAN04.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN04.residential_underground_area END, 
                CASE WHEN (IPPAN04.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN04.agricultural_area END, 
                CASE WHEN (IPPAN04.residential_underground_agricultural_area) IS NULL THEN 0.00 ELSE IPPAN04.residential_underground_agricultural_area END, 
                CASE WHEN (IPPAN05.building_full) IS NULL THEN 0.00 ELSE IPPAN05.building_full END, 
                CASE WHEN (IPPAN05.building_half) IS NULL THEN 0.00 ELSE IPPAN05.building_half END, 
                CASE WHEN (IPPAN05.building_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN05.building_lv01_50_100 END, 
                CASE WHEN (IPPAN05.building_lv00) IS NULL THEN 0.00 ELSE IPPAN05.building_lv00 END, 
                CASE WHEN (IPPAN05.building_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN05.building_lv00_01_50_100_half_full END, 
                CASE WHEN (IPPAN06.asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_damage END, 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END, 
                CASE WHEN (IPPAN06.asset_sales_crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_crop_damage END, 
                
                CASE WHEN (KOKYO01.kokyo_suikei_num) IS NULL THEN 0.00 ELSE KOKYO01.kokyo_suikei_num END, 
                CASE WHEN (KOKYO02.kokyo_kasen_num) IS NULL THEN 0.00 ELSE KOKYO02.kokyo_kasen_num END, 
                CASE WHEN (KOKYO03.kokyo_city_num) IS NULL THEN 0.00 ELSE KOKYO03.kokyo_city_num END, 
                
                CASE WHEN (CHITAN04.kasen_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN04.kasen_estimated_damage END+
                CASE WHEN (HOJO04.kasen_determined_damage) IS NULL THEN 0.00 ELSE HOJO04.kasen_determined_damage END
                AS kasen_damage, 
                
                CASE WHEN (CHITAN05.kaigan_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN05.kaigan_estimated_damage END+
                CASE WHEN (HOJO05.kaigan_determined_damage) IS NULL THEN 0.00 ELSE HOJO05.kaigan_determined_damage END
                AS kaigan_damage, 
                
                CASE WHEN (CHITAN06.sabou_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN06.sabou_estimated_damage END+
                CASE WHEN (HOJO06.sabou_determined_damage) IS NULL THEN 0.00 ELSE HOJO06.sabou_determined_damage END
                AS sabou_damage, 
                
                CASE WHEN (CHITAN07.landslide_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN07.landslide_estimated_damage END+
                CASE WHEN (HOJO07.landslide_determined_damage) IS NULL THEN 0.00 ELSE HOJO07.landslide_determined_damage END
                AS landslide_damage, 
                
                CASE WHEN (CHITAN08.steepslope_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN08.steepslope_estimated_damage END+
                CASE WHEN (HOJO08.steepslope_determined_damage) IS NULL THEN 0.00 ELSE HOJO08.steepslope_determined_damage END
                AS steepslope_damage, 
                
                CASE WHEN (CHITAN09.road_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN09.road_estimated_damage END+
                CASE WHEN (HOJO09.road_determined_damage) IS NULL THEN 0.00 ELSE HOJO09.road_determined_damage END
                AS road_damage, 
                
                CASE WHEN (CHITAN10.bridge_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN10.bridge_estimated_damage END+
                CASE WHEN (HOJO10.bridge_determined_damage) IS NULL THEN 0.00 ELSE HOJO10.bridge_determined_damage END
                AS bridge_damage, 
                
                CASE WHEN (CHITAN11.sewer_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN11.sewer_estimated_damage END+
                CASE WHEN (HOJO11.sewer_determined_damage) IS NULL THEN 0.00 ELSE HOJO11.sewer_determined_damage END
                AS sewer_damage, 
                
                CASE WHEN (CHITAN12.park_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN12.park_estimated_damage END+
                CASE WHEN (HOJO12.park_determined_damage) IS NULL THEN 0.00 ELSE HOJO12.park_determined_damage END
                AS park_damage, 
                
                CASE WHEN (CHITAN13.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN13.estimated_damage END+
                CASE WHEN (HOJO13.determined_damage) IS NULL THEN 0.00 ELSE HOJO13.determined_damage END
                AS chitan_hojo_damage, 
                
                CASE WHEN (KOEKI01.koeki_suikei_num) IS NULL THEN 0.00 ELSE KOEKI01.koeki_suikei_num END, 
                CASE WHEN (KOEKI02.koeki_kasen_num) IS NULL THEN 0.00 ELSE KOEKI02.koeki_kasen_num END, 
                CASE WHEN (KOEKI03.koeki_city_num) IS NULL THEN 0.00 ELSE KOEKI03.koeki_city_num END, 
                CASE WHEN (KOEKI04.physical_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_damage END, 
                CASE WHEN (KOEKI04.sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.sales_alt_other_damage END, 
                CASE WHEN (KOEKI04.physical_sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_sales_alt_other_damage END, 
                
                CASE WHEN (IPPAN06.asset_sales_crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_crop_damage END+
                CASE WHEN (CHITAN13.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN13.estimated_damage END+
                CASE WHEN (HOJO13.determined_damage) IS NULL THEN 0.00 ELSE HOJO13.determined_damage END+
                CASE WHEN (KOEKI04.physical_sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_sales_alt_other_damage END
                AS ippan_chitan_hojo_koeki_damage 
                
            FROM 
            
            -- 一般_水系・沿岸数
            (SELECT 
                COUNT(1) AS ippan_suikei_num 
            FROM 
            (SELECT 
                suikei_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            GROUP BY suikei_code 
            ) SUB00 
            ) IPPAN01, 

            -- 一般_河川・海岸数
            (SELECT 
                COUNT(1) AS ippan_kasen_num 
            FROM 
            (SELECT 
                kasen_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            GROUP BY kasen_code 
            ) SUB00 
            ) IPPAN02, 

            -- 一般_市区町村数
            (SELECT 
                COUNT(1) AS ippan_city_num 
            FROM 
            (SELECT 
                city_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) SUB00 
            ) IPPAN03, 

            -- 水害区域面積(ha)
            (SELECT 
                -- 宅地・その他
                SUM(
                    CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                    CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END
                ) AS residential_underground_area, 
                -- 農地
                SUM(
                    CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END
                ) AS agricultural_area, 
                -- 計
                SUM(
                    CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                    CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END+
                    CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END
                ) AS residential_underground_agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            ) IPPAN04, 
            
            -- 被害家屋棟数_全壊・流失
            (SELECT 
                -- 全壊・流失
                SUM(
                    CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END
                ) AS building_full, 
                -- 半壊
                SUM(
                    CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END
                ) AS building_half, 
                -- 床上浸水
                SUM(
                    CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+
                    CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+
                    CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END 
                ) AS building_lv01_50_100, 
                -- 床下浸水
                SUM(
                    CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END
                ) AS building_lv00, 
                -- 計
                SUM(
                    CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END+
                    CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+
                    CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+
                    CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END+
                    CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END+
                    CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END
                ) AS building_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            ) IPPAN05, 

            -- 一般資産等被害額
            (SELECT 
                -- 一般資産･営業停止損失額
                SUM(
                    CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                    CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                    CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                    CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                    CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                    CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                    CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                    CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                    CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                    CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                    CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                    CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                    CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                    CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                    CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                    CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                    CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                    CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                    CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                    CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                    CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                    CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                    CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                    CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                    CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                    CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                    CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                    CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                    CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                    CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                    CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                    CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                    CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                    CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                    CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                    CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                    CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                    CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                    CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                    CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                    CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                    CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                    CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                    CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                    CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                    CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                    CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                    CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                    CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                    CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                    CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                    CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                    CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                    CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                    CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                    CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END
                ) AS asset_sales_damage, 
                -- 農作物
                SUM(
                    crop_damage
                ) AS crop_damage, 
                -- 計
                SUM(
                    CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                    CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                    CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                    CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                    CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                    CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                    CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                    CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                    CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                    CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                    CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                    CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                    CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                    CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                    CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                    CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                    CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                    CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                    CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                    CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                    CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                    CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                    CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                    CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                    CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                    CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                    CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                    CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                    CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                    CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                    CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                    CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                    CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                    CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                    CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                    CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                    CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                    CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                    CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                    CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                    CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                    CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                    CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                    CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                    CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                    CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                    CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                    CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                    CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                    CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                    CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                    CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                    CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                    CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                    CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                    CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END+ 
                    CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END 
                ) AS asset_sales_crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            ) IPPAN06, 
            
            -- 公共_水系・沿岸数
            (SELECT 
                COUNT(1) AS kokyo_suikei_num 
            FROM 
            (
            SELECT 
                suikei_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            GROUP BY suikei_code 
            UNION 
            SELECT 
                suikei_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            GROUP BY suikei_code 
            ) SUB00 
            ) KOKYO01, 

            -- 公共_河川・海岸数
            (SELECT 
                COUNT(1) AS kokyo_kasen_num 
            FROM 
            (
            SELECT 
                kasen_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            GROUP BY kasen_code 
            UNION 
            SELECT 
                kasen_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            GROUP BY kasen_code 
            ) SUB00 
            ) KOKYO02, 

            -- 公共_市区町村数
            (SELECT 
                COUNT(1) AS kokyo_city_num 
            FROM 
            (
            SELECT 
                city_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            UNION 
            SELECT 
                city_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) SUB00 
            ) KOKYO03, 

            -- 地方単独事業被害_被害額_河川 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS kasen_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(KASEN)s 
            ) CHITAN04, 
            
            -- 地方単独事業被害_被害額_海岸・港湾 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS kaigan_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) CHITAN05, 
            
            -- 地方単独事業被害_被害額_砂防設備 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS sabou_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(SABOU)s 
            ) CHITAN06, 
            
            -- 地方単独事業被害_被害額_地すべり防止施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS landslide_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(LANDSLIDE)s 
            ) CHITAN07, 
            
            -- 地方単独事業被害_被害額_急傾斜地崩壊防止施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS steepslope_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) CHITAN08, 
            
            -- 地方単独事業被害_被害額_道路 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS road_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(ROAD)s 
            ) CHITAN09, 
            
            -- 地方単独事業被害_被害額_橋梁 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS bridge_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(BRIDGE)s 
            ) CHITAN10, 
            
            -- 地方単独事業被害_被害額_下水道 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS sewer_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(SEWER)s 
            ) CHITAN11, 
            
            -- 地方単独事業被害_被害額_公園・都市施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS park_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) CHITAN12, 
            
            -- 地方単独事業被害_被害額_計 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            ) CHITAN13, 

            -- 補助事業被害_被害額_河川 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS kasen_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(KASEN)s 
            ) HOJO04, 
            
            -- 補助事業被害_被害額_海岸・港湾 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS kaigan_determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) HOJO05, 
            
            -- 補助事業被害_被害額_砂防設備 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS sabou_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(SABOU)s 
            ) HOJO06, 
            
            -- 補助事業被害_被害額_地すべり防止施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS landslide_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(LANDSLIDE)s 
            ) HOJO07, 
            
            -- 補助事業被害_被害額_急傾斜地崩壊防止施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS steepslope_determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) HOJO08, 
            
            -- 補助事業被害_被害額_道路 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS road_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(ROAD)s 
            ) HOJO09, 
            
            -- 補助事業被害_被害額_橋梁 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS bridge_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(BRIDGE)s 
            ) HOJO10, 
            
            -- 補助事業被害_被害額_下水道 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS sewer_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code=%(SEWER)s 
            ) HOJO11, 
            
            -- 補助事業被害_被害額_公園・都市施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS park_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) HOJO12, 
            
            -- 補助事業被害_被害額_計 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            ) HOJO13, 
            
            -- 公益_水系・沿岸数
            (SELECT 
                COUNT(1) AS koeki_suikei_num 
            FROM 
            (SELECT 
                suikei_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            GROUP BY suikei_code 
            ) SUB00 
            ) KOEKI01, 
            
            -- 公益_河川・海岸数
            (SELECT 
                COUNT(1) AS koeki_kasen_num 
            FROM 
            (SELECT 
                kasen_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            GROUP BY kasen_code 
            ) SUB00 
            ) KOEKI02, 
            
            -- 公益_市区町村数
            (SELECT 
                COUNT(1) AS koeki_city_num 
            FROM 
            (SELECT 
                city_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) SUB00 
            ) KOEKI03, 
            
            -- 公益事業等被害額
            (SELECT 
                -- 物的被害額
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END
                ) AS physical_damage, 
                -- 営業停止損失額
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END
                ) AS sales_alt_other_damage, 
                -- 計
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END
                ) AS physical_sales_alt_other_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE weather_id=%(WEATHER_ID)s AND ken_code=%(KEN_CODE)s 
            ) KOEKI04 
                
            """, params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo11_weather_ken()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo11_weather_ken()関数が正常終了しました。', 'INFO')
        return True, hyo11_weather_ken_list
    
    except:
        print_log('[ERROR] P0700EStat.get_hyo11_weather_ken()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo11_weather_ken()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo11_weather_ken()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_11主要異常気象別都道府県別水害被害.xlsx
### 関数名：get_hyo11_weather_zenkoku(weather_id)
### 2 主要異常気象別_全国_被害額
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo11_weather_zenkoku(weather_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo11_weather_zenkoku()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo11_weather_zenkoku()関数 weather_id={}'.format(weather_id), 'DEBUG')
        ### if ken_code in constants.ken_values:
        ###     pass
        ### else:
        ###     print_log('[WARN] P0700EStat.get_hyo11_weather_ken()関数が警告終了しました。', 'INFO')
        ###     return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        weather_keys = ['WEATHER_ID']
        weather_values = [weather_id]
        params = dict(zip(weather_keys + constants.setubi_keys, weather_values + constants.setubi_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo11_weather_zenkoku()関数 STEP 2/3.', 'DEBUG')
        hyo11_weather_zenkoku_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.ippan_suikei_num) IS NULL THEN 0.00 ELSE IPPAN01.ippan_suikei_num END, 
                CASE WHEN (IPPAN02.ippan_kasen_num) IS NULL THEN 0.00 ELSE IPPAN02.ippan_kasen_num END, 
                CASE WHEN (IPPAN03.ippan_city_num) IS NULL THEN 0.00 ELSE IPPAN03.ippan_city_num END, 
                CASE WHEN (IPPAN04.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN04.residential_underground_area END, 
                CASE WHEN (IPPAN04.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN04.agricultural_area END, 
                CASE WHEN (IPPAN04.residential_underground_agricultural_area) IS NULL THEN 0.00 ELSE IPPAN04.residential_underground_agricultural_area END, 
                CASE WHEN (IPPAN05.building_full) IS NULL THEN 0.00 ELSE IPPAN05.building_full END, 
                CASE WHEN (IPPAN05.building_half) IS NULL THEN 0.00 ELSE IPPAN05.building_half END, 
                CASE WHEN (IPPAN05.building_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN05.building_lv01_50_100 END, 
                CASE WHEN (IPPAN05.building_lv00) IS NULL THEN 0.00 ELSE IPPAN05.building_lv00 END, 
                CASE WHEN (IPPAN05.building_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN05.building_lv00_01_50_100_half_full END, 
                CASE WHEN (IPPAN06.asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_damage END, 
                CASE WHEN (IPPAN06.crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.crop_damage END, 
                CASE WHEN (IPPAN06.asset_sales_crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_crop_damage END, 
                
                CASE WHEN (KOKYO01.kokyo_suikei_num) IS NULL THEN 0.00 ELSE KOKYO01.kokyo_suikei_num END, 
                CASE WHEN (KOKYO02.kokyo_kasen_num) IS NULL THEN 0.00 ELSE KOKYO02.kokyo_kasen_num END, 
                CASE WHEN (KOKYO03.kokyo_city_num) IS NULL THEN 0.00 ELSE KOKYO03.kokyo_city_num END, 
                
                CASE WHEN (CHITAN04.kasen_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN04.kasen_estimated_damage END+
                CASE WHEN (HOJO04.kasen_determined_damage) IS NULL THEN 0.00 ELSE HOJO04.kasen_determined_damage END
                AS kasen_damage, 
                
                CASE WHEN (CHITAN05.kaigan_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN05.kaigan_estimated_damage END+
                CASE WHEN (HOJO05.kaigan_determined_damage) IS NULL THEN 0.00 ELSE HOJO05.kaigan_determined_damage END
                AS kaigan_damage, 
                
                CASE WHEN (CHITAN06.sabou_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN06.sabou_estimated_damage END+
                CASE WHEN (HOJO06.sabou_determined_damage) IS NULL THEN 0.00 ELSE HOJO06.sabou_determined_damage END
                AS sabou_damage, 
                
                CASE WHEN (CHITAN07.landslide_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN07.landslide_estimated_damage END+
                CASE WHEN (HOJO07.landslide_determined_damage) IS NULL THEN 0.00 ELSE HOJO07.landslide_determined_damage END
                AS landslide_damage, 
                
                CASE WHEN (CHITAN08.steepslope_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN08.steepslope_estimated_damage END+
                CASE WHEN (HOJO08.steepslope_determined_damage) IS NULL THEN 0.00 ELSE HOJO08.steepslope_determined_damage END
                AS steepslope_damage, 
                
                CASE WHEN (CHITAN09.road_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN09.road_estimated_damage END+
                CASE WHEN (HOJO09.road_determined_damage) IS NULL THEN 0.00 ELSE HOJO09.road_determined_damage END
                AS road_damage, 
                
                CASE WHEN (CHITAN10.bridge_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN10.bridge_estimated_damage END+
                CASE WHEN (HOJO10.bridge_determined_damage) IS NULL THEN 0.00 ELSE HOJO10.bridge_determined_damage END
                AS bridge_damage, 
                
                CASE WHEN (CHITAN11.sewer_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN11.sewer_estimated_damage END+
                CASE WHEN (HOJO11.sewer_determined_damage) IS NULL THEN 0.00 ELSE HOJO11.sewer_determined_damage END
                AS sewer_damage, 
                
                CASE WHEN (CHITAN12.park_estimated_damage) IS NULL THEN 0.00 ELSE CHITAN12.park_estimated_damage END+
                CASE WHEN (HOJO12.park_determined_damage) IS NULL THEN 0.00 ELSE HOJO12.park_determined_damage END
                AS park_damage, 
                
                CASE WHEN (CHITAN13.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN13.estimated_damage END+
                CASE WHEN (HOJO13.determined_damage) IS NULL THEN 0.00 ELSE HOJO13.determined_damage END
                AS chitan_hojo_damage, 
                
                CASE WHEN (KOEKI01.koeki_suikei_num) IS NULL THEN 0.00 ELSE KOEKI01.koeki_suikei_num END, 
                CASE WHEN (KOEKI02.koeki_kasen_num) IS NULL THEN 0.00 ELSE KOEKI02.koeki_kasen_num END, 
                CASE WHEN (KOEKI03.koeki_city_num) IS NULL THEN 0.00 ELSE KOEKI03.koeki_city_num END, 
                CASE WHEN (KOEKI04.physical_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_damage END, 
                CASE WHEN (KOEKI04.sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.sales_alt_other_damage END, 
                CASE WHEN (KOEKI04.physical_sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_sales_alt_other_damage END, 
                
                CASE WHEN (IPPAN06.asset_sales_crop_damage) IS NULL THEN 0.00 ELSE IPPAN06.asset_sales_crop_damage END+
                CASE WHEN (CHITAN13.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN13.estimated_damage END+
                CASE WHEN (HOJO13.determined_damage) IS NULL THEN 0.00 ELSE HOJO13.determined_damage END+
                CASE WHEN (KOEKI04.physical_sales_alt_other_damage) IS NULL THEN 0.00 ELSE KOEKI04.physical_sales_alt_other_damage END
                AS ippan_chitan_hojo_koeki_damage 
                
            FROM 
            
            -- 一般_水系・沿岸数
            (SELECT 
                COUNT(1) AS ippan_suikei_num 
            FROM 
            (SELECT 
                suikei_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY suikei_code 
            ) SUB00 
            ) IPPAN01, 

            -- 一般_河川・海岸数
            (SELECT 
                COUNT(1) AS ippan_kasen_num 
            FROM 
            (SELECT 
                kasen_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY kasen_code 
            ) SUB00 
            ) IPPAN02, 

            -- 一般_市区町村数
            (SELECT 
                COUNT(1) AS ippan_city_num 
            FROM 
            (SELECT 
                city_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY city_code 
            ) SUB00 
            ) IPPAN03, 

            -- 水害区域面積(ha)
            (SELECT 
                -- 宅地・その他
                SUM(
                    CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                    CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END
                ) AS residential_underground_area, 
                -- 農地
                SUM(
                    CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END
                ) AS agricultural_area, 
                -- 計
                SUM(
                    CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                    CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END+
                    CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END
                ) AS residential_underground_agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            ) IPPAN04, 
            
            -- 被害家屋棟数_全壊・流失
            (SELECT 
                -- 全壊・流失
                SUM(
                    CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END
                ) AS building_full, 
                -- 半壊
                SUM(
                    CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END
                ) AS building_half, 
                -- 床上浸水
                SUM(
                    CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+
                    CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+
                    CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END 
                ) AS building_lv01_50_100, 
                -- 床下浸水
                SUM(
                    CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END
                ) AS building_lv00, 
                -- 計
                SUM(
                    CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END+
                    CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+
                    CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+
                    CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END+
                    CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END+
                    CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END
                ) AS building_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            ) IPPAN05, 

            -- 一般資産等被害額
            (SELECT 
                -- 一般資産･営業停止損失額
                SUM(
                    CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                    CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                    CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                    CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                    CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                    CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                    CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                    CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                    CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                    CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                    CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                    CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                    CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                    CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                    CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                    CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                    CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                    CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                    CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                    CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                    CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                    CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                    CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                    CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                    CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                    CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                    CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                    CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                    CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                    CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                    CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                    CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                    CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                    CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                    CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                    CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                    CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                    CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                    CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                    CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                    CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                    CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                    CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                    CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                    CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                    CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                    CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                    CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                    CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                    CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                    CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                    CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                    CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                    CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                    CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                    CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END
                ) AS asset_sales_damage, 
                -- 農作物
                SUM(
                    crop_damage
                ) AS crop_damage, 
                -- 計
                SUM(
                    CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                    CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                    CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                    CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                    CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                    CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                    CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                    CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                    CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                    CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                    CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                    CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                    CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                    CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                    CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                    CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                    CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                    CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                    CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                    CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                    CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                    CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                    CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                    CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                    CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                    CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                    CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                    CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                    CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                    CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                    CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                    CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                    CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                    CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                    CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                    CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                    CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                    CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                    CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                    CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                    CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                    CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                    CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                    CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                    CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                    CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                    CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                    CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                    CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                    CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                    CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                    CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                    CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                    CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                    CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                    CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                    CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END+ 
                    CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END 
                ) AS asset_sales_crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            ) IPPAN06, 
            
            -- 公共_水系・沿岸数
            (SELECT 
                COUNT(1) AS kokyo_suikei_num 
            FROM 
            (
            SELECT 
                suikei_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY suikei_code 
            UNION 
            SELECT 
                suikei_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY suikei_code 
            ) SUB00 
            ) KOKYO01, 

            -- 公共_河川・海岸数
            (SELECT 
                COUNT(1) AS kokyo_kasen_num 
            FROM 
            (
            SELECT 
                kasen_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY kasen_code 
            UNION 
            SELECT 
                kasen_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY kasen_code 
            ) SUB00 
            ) KOKYO02, 

            -- 公共_市区町村数
            (SELECT 
                COUNT(1) AS kokyo_city_num 
            FROM 
            (
            SELECT 
                city_code 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY city_code 
            UNION 
            SELECT 
                city_code 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY city_code 
            ) SUB00 
            ) KOKYO03, 

            -- 地方単独事業被害_被害額_河川 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS kasen_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s 
            ) CHITAN04, 
            
            -- 地方単独事業被害_被害額_海岸・港湾 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS kaigan_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) CHITAN05, 
            
            -- 地方単独事業被害_被害額_砂防設備 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS sabou_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(SABOU)s 
            ) CHITAN06, 
            
            -- 地方単独事業被害_被害額_地すべり防止施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS landslide_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(LANDSLIDE)s 
            ) CHITAN07, 
            
            -- 地方単独事業被害_被害額_急傾斜地崩壊防止施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS steepslope_estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) CHITAN08, 
            
            -- 地方単独事業被害_被害額_道路 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS road_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(ROAD)s 
            ) CHITAN09, 
            
            -- 地方単独事業被害_被害額_橋梁 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS bridge_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(BRIDGE)s 
            ) CHITAN10, 
            
            -- 地方単独事業被害_被害額_下水道 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS sewer_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(SEWER)s 
            ) CHITAN11, 
            
            -- 地方単独事業被害_被害額_公園・都市施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS park_estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) CHITAN12, 
            
            -- 地方単独事業被害_被害額_計 百万円
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END
                ) AS estimated_damage
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s 
            ) CHITAN13, 

            -- 補助事業被害_被害額_河川 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS kasen_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(KASEN)s 
            ) HOJO04, 
            
            -- 補助事業被害_被害額_海岸・港湾 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS kaigan_determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) HOJO05, 
            
            -- 補助事業被害_被害額_砂防設備 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS sabou_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(SABOU)s 
            ) HOJO06, 
            
            -- 補助事業被害_被害額_地すべり防止施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS landslide_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(LANDSLIDE)s 
            ) HOJO07, 
            
            -- 補助事業被害_被害額_急傾斜地崩壊防止施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS steepslope_determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) HOJO08, 
            
            -- 補助事業被害_被害額_道路 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS road_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(ROAD)s 
            ) HOJO09, 
            
            -- 補助事業被害_被害額_橋梁 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS bridge_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(BRIDGE)s 
            ) HOJO10, 
            
            -- 補助事業被害_被害額_下水道 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS sewer_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code=%(SEWER)s 
            ) HOJO11, 
            
            -- 補助事業被害_被害額_公園・都市施設 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS park_determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) HOJO12, 
            
            -- 補助事業被害_被害額_計 百万円
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END
                ) AS determined_damage
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            AND weather_id=%(WEATHER_ID)s 
            ) HOJO13, 
            
            -- 公益_水系・沿岸数
            (SELECT 
                COUNT(1) AS koeki_suikei_num 
            FROM 
            (SELECT 
                suikei_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY suikei_code 
            ) SUB00 
            ) KOEKI01, 
            
            -- 公益_河川・海岸数
            (SELECT 
                COUNT(1) AS koeki_kasen_num 
            FROM 
            (SELECT 
                kasen_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY kasen_code 
            ) SUB00 
            ) KOEKI02, 
            
            -- 公益_市区町村数
            (SELECT 
                COUNT(1) AS koeki_city_num 
            FROM 
            (SELECT 
                city_code 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND weather_id=%(WEATHER_ID)s 
            GROUP BY city_code 
            ) SUB00 
            ) KOEKI03, 
            
            -- 公益事業等被害額
            (SELECT 
                -- 物的被害額
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END
                ) AS physical_damage, 
                -- 営業停止損失額
                SUM(
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END
                ) AS sales_alt_other_damage, 
                -- 計
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END
                ) AS physical_sales_alt_other_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE weather_id=%(WEATHER_ID)s 
            ) KOEKI04 
                
            """, params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo11_weather_zenkoku()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo11_weather_zenkoku()関数が正常終了しました。', 'INFO')
        return True, hyo11_weather_zenkoku_list
    
    except:
        print_log('[ERROR] P0700EStat.get_hyo11_weather_zenkoku()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo11_weather_zenkoku()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo11_weather_zenkoku()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_11主要異常気象別都道府県別水害被害.xlsx
### 関数名：hyo11_view(request)
### urlpattern：path('hyo11/', hyo11_views.hyo11_view, name='hyo11_view'),
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo11_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo11_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo11_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo11_view()関数 STEP 1/4.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo11_view()関数 STEP 2/4.', 'DEBUG')

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo11_view()関数 STEP 3/4.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### コンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo11_view()関数 STEP 4/4.', 'DEBUG')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'cat_code': 'hyo11', 
        }
        print_log('[INFO] P0700EStat.hyo11_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0700EStat.hyo11_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo11_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo11_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_11主要異常気象別都道府県別水害被害.xlsx
### 関数名：set_cell_value(ws, weather, row_index)
###############################################################################
def set_cell_value(ws, weather, row_index):
    try:
        ws.cell(row=row_index, column=1).value = ''
        ws.cell(row=row_index, column=2).value = weather.ippan_suikei_num
        ws.cell(row=row_index, column=3).value = weather.kokyo_suikei_num
        ws.cell(row=row_index, column=4).value = weather.koeki_suikei_num
        ws.cell(row=row_index, column=5).value = weather.ippan_kasen_num
        ws.cell(row=row_index, column=6).value = weather.kokyo_kasen_num
        ws.cell(row=row_index, column=7).value = weather.koeki_kasen_num
        ws.cell(row=row_index, column=8).value = weather.ippan_city_num
        ws.cell(row=row_index, column=9).value = weather.kokyo_city_num
        ws.cell(row=row_index, column=10).value = weather.koeki_city_num

        ws.cell(row=row_index, column=11).value = weather.residential_underground_area
        ws.cell(row=row_index, column=12).value = weather.agricultural_area
        ws.cell(row=row_index, column=13).value = weather.residential_underground_agricultural_area
        ws.cell(row=row_index, column=14).value = weather.building_full
        ws.cell(row=row_index, column=15).value = weather.building_half
        ws.cell(row=row_index, column=16).value = weather.building_lv01_50_100
        ws.cell(row=row_index, column=17).value = weather.building_lv00
        ws.cell(row=row_index, column=18).value = weather.building_lv00_01_50_100_half_full
        ws.cell(row=row_index, column=19).value = weather.asset_sales_damage
        ws.cell(row=row_index, column=20).value = weather.crop_damage

        ws.cell(row=row_index, column=21).value = weather.asset_sales_crop_damage
        ws.cell(row=row_index, column=22).value = weather.kasen_damage
        ws.cell(row=row_index, column=23).value = weather.kaigan_damage
        ws.cell(row=row_index, column=24).value = weather.sabou_damage
        ws.cell(row=row_index, column=25).value = weather.landslide_damage
        ws.cell(row=row_index, column=26).value = weather.steepslope_damage
        ws.cell(row=row_index, column=27).value = weather.road_damage
        ws.cell(row=row_index, column=28).value = weather.bridge_damage
        ws.cell(row=row_index, column=29).value = weather.sewer_damage
        ws.cell(row=row_index, column=30).value = weather.park_damage

        ws.cell(row=row_index, column=31).value = weather.chitan_hojo_damage
        ws.cell(row=row_index, column=32).value = weather.physical_damage
        ws.cell(row=row_index, column=33).value = weather.sales_alt_other_damage
        ws.cell(row=row_index, column=34).value = weather.physical_sales_alt_other_damage
        ws.cell(row=row_index, column=35).value = weather.ippan_chitan_hojo_koeki_damage
        
        return True
    except:
        return False

###############################################################################
### 帳票名：hyo_11主要異常気象別都道府県別水害被害.xlsx
### 関数名：hyo11_download_view(request)
### urlpattern：path('download/hyo11/', hyo11_views.hyo11_download_view, name='hyo11_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo11_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo11_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo11_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo11_download_view()関数 STEP 1/5.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo11_download_view()関数 STEP 2/5.', 'DEBUG')
        ### 主要異常気象を3件取得する。
        bool_return, weather_1_id, weather_2_id, weather_3_id = get_hyo11_weather_ids()
        if bool_return == False:
            raise Exception
            
        if weather_1_id == None:
            weather_1_id = '0'
            
        if weather_2_id == None:
            weather_2_id = '0'
            
        if weather_3_id == None:
            weather_3_id = '0'

        ### 1 異常気象別_都道府県別_被害額
        weather_ken_1_list = []
        weather_ken_2_list = []
        weather_ken_3_list = []
        
        for ken_code in constants.ken_values:
            bool_return, temp = get_hyo11_weather_ken(weather_1_id, ken_code)
            if bool_return == False:
                raise Exception
            
            weather_ken_1_list.append(temp)
            
        for ken_code in constants.ken_values:
            bool_return, temp = get_hyo11_weather_ken(weather_2_id, ken_code)
            if bool_return == False:
                raise Exception
            
            weather_ken_2_list.append(temp)
        
        for ken_code in constants.ken_values:
            bool_return, temp = get_hyo11_weather_ken(weather_3_id, ken_code)
            if bool_return == False:
                raise Exception
            
            weather_ken_3_list.append(temp)

        ### 2 異常気象別_全国_被害額
        bool_return, weather_zenkoku_1_list = get_hyo11_weather_zenkoku(weather_1_id)
        if bool_return == False:
            raise Exception

        bool_return, weather_zenkoku_2_list = get_hyo11_weather_zenkoku(weather_2_id)
        if bool_return == False:
            raise Exception

        bool_return, weather_zenkoku_3_list = get_hyo11_weather_zenkoku(weather_3_id)
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo11_download_view()関数 STEP 3/5.', 'DEBUG')
        ### 1 異常気象別_都道府県別_被害額
        print_log('[DEBUG] P0700EStat.hyo11_download_view()関数 STEP 3_1/5.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, weather_ken in enumerate(weather_ken_1_list[i]):
                print('i={} j={} weather_ken.ippan_suikei_num={}'.format(i, j, weather_ken.ippan_suikei_num), flush=True)

        print_log('[DEBUG] P0700EStat.hyo11_download_view()関数 STEP 3_2/5.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, weather_ken in enumerate(weather_ken_2_list[i]):
                print('i={} j={} weather_ken.ippan_suikei_num={}'.format(i, j, weather_ken.ippan_suikei_num), flush=True)

        print_log('[DEBUG] P0700EStat.hyo11_download_view()関数 STEP 3_3/5.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, weather_ken in enumerate(weather_ken_3_list[i]):
                print('i={} j={} weather_ken.ippan_suikei_num={}'.format(i, j, weather_ken.ippan_suikei_num), flush=True)
        
        ### 2 異常気象別_全国_被害額
        print_log('[DEBUG] P0700EStat.hyo11_download_view()関数 STEP 3_4/5.', 'DEBUG')
        for i, weather_zenkoku in enumerate(weather_zenkoku_1_list):
            print('i={} weather_zenkoku.ippan_suikei_num={}'.format(i, weather_zenkoku.ippan_suikei_num), flush=True)

        print_log('[DEBUG] P0700EStat.hyo11_download_view()関数 STEP 3_5/5.', 'DEBUG')
        for i, weather_zenkoku in enumerate(weather_zenkoku_2_list):
            print('i={} weather_zenkoku.ippan_suikei_num={}'.format(i, weather_zenkoku.ippan_suikei_num), flush=True)

        print_log('[DEBUG] P0700EStat.hyo11_download_view()関数 STEP 3_6/5.', 'DEBUG')
        for i, weather_zenkoku in enumerate(weather_zenkoku_3_list):
            print('i={} weather_zenkoku.ippan_suikei_num={}'.format(i, weather_zenkoku.ippan_suikei_num), flush=True)

        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo11_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo11.xlsx'
        ### download_file_path = 'static/download_hyo11.xlsx'
        template_file_path = 'static/template/template_hyo11.xlsx'
        download_file_path = 'static/tmp/download_hyo11.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo11'
        
        for row_index in [0, 54, 108]:
            ws.cell(row=row_index+1, column=1).value = '表－１１－①　主要異常気象別都道府県別水害被害 〔豪雨及び台風１４号　(9.3～9.8)〕'
            ws.cell(row=row_index+2, column=35).value = '（単位：百万円）'
            ws.cell(row=row_index+3, column=1).value = ''
            ws.cell(row=row_index+3, column=2).value = ''
            ws.cell(row=row_index+3, column=3).value = ''
            ws.cell(row=row_index+3, column=4).value = ''
            ws.cell(row=row_index+3, column=5).value = ''
            ws.cell(row=row_index+3, column=6).value = ''
            ws.cell(row=row_index+3, column=7).value = ''
            ws.cell(row=row_index+3, column=8).value = ''
            ws.cell(row=row_index+3, column=9).value = ''
            ws.cell(row=row_index+3, column=10).value = ''
            ws.cell(row=row_index+3, column=11).value = '水害区域面積(ha)'
            ws.cell(row=row_index+3, column=14).value = '被害家屋棟数'
            ws.cell(row=row_index+3, column=19).value = '一般資産等被害額'
            ws.cell(row=row_index+3, column=22).value = '公　共　土　木　施　設　被　害　額'
            ws.cell(row=row_index+3, column=32).value = '公益事業等被害額'
            ws.cell(row=row_index+3, column=35).value = ''
            ws.cell(row=row_index+4, column=1).value = '都道'
            ws.cell(row=row_index+4, column=2).value = '水系・沿岸数'
            ws.cell(row=row_index+4, column=5).value = '河川・海岸数'
            ws.cell(row=row_index+4, column=8).value = '市区町村数'
            ws.cell(row=row_index+4, column=11).value = '宅　地'
            ws.cell(row=row_index+4, column=12).value = ''
            ws.cell(row=row_index+4, column=13).value = ''
            ws.cell(row=row_index+4, column=14).value = '全壊'
            ws.cell(row=row_index+4, column=15).value = ''
            ws.cell(row=row_index+4, column=16).value = '床上'
            ws.cell(row=row_index+4, column=17).value = '床下'
            ws.cell(row=row_index+4, column=18).value = ''
            ws.cell(row=row_index+4, column=19).value = '一般資産･'
            ws.cell(row=row_index+4, column=20).value = ''
            ws.cell(row=row_index+4, column=21).value = ''
            ws.cell(row=row_index+4, column=22).value = ''
            ws.cell(row=row_index+4, column=23).value = '海岸'
            ws.cell(row=row_index+4, column=24).value = '砂防'
            ws.cell(row=row_index+4, column=25).value = '地すべり'
            ws.cell(row=row_index+4, column=26).value = '急傾斜地'
            ws.cell(row=row_index+4, column=27).value = ''
            ws.cell(row=row_index+4, column=28).value = ''
            ws.cell(row=row_index+4, column=29).value = ''
            ws.cell(row=row_index+4, column=30).value = '公園'
            ws.cell(row=row_index+4, column=31).value = ''
            ws.cell(row=row_index+4, column=32).value = '物的'
            ws.cell(row=row_index+4, column=33).value = '営業'
            ws.cell(row=row_index+4, column=34).value = ''
            ws.cell(row=row_index+4, column=35).value = ''
            ws.cell(row=row_index+5, column=1).value = '府県名'
            ws.cell(row=row_index+5, column=2).value = ''
            ws.cell(row=row_index+5, column=3).value = ''
            ws.cell(row=row_index+5, column=4).value = ''
            ws.cell(row=row_index+5, column=5).value = ''
            ws.cell(row=row_index+5, column=6).value = ''
            ws.cell(row=row_index+5, column=7).value = ''
            ws.cell(row=row_index+5, column=8).value = ''
            ws.cell(row=row_index+5, column=9).value = ''
            ws.cell(row=row_index+5, column=10).value = ''
            ws.cell(row=row_index+5, column=11).value = ''
            ws.cell(row=row_index+5, column=12).value = '農　地'
            ws.cell(row=row_index+5, column=13).value = '計'
            ws.cell(row=row_index+5, column=14).value = '　・'
            ws.cell(row=row_index+5, column=15).value = '半壊'
            ws.cell(row=row_index+5, column=16).value = ''
            ws.cell(row=row_index+5, column=17).value = ''
            ws.cell(row=row_index+5, column=18).value = '計'
            ws.cell(row=row_index+5, column=19).value = '営業停止'
            ws.cell(row=row_index+5, column=20).value = '農作物'
            ws.cell(row=row_index+5, column=21).value = '計'
            ws.cell(row=row_index+5, column=22).value = '河川'
            ws.cell(row=row_index+5, column=23).value = ''
            ws.cell(row=row_index+5, column=24).value = ''
            ws.cell(row=row_index+5, column=25).value = ''
            ws.cell(row=row_index+5, column=26).value = '崩壊防止'
            ws.cell(row=row_index+5, column=27).value = '道路'
            ws.cell(row=row_index+5, column=28).value = '橋梁'
            ws.cell(row=row_index+5, column=29).value = '下水道'
            ws.cell(row=row_index+5, column=30).value = '・都市'
            ws.cell(row=row_index+5, column=31).value = '計'
            ws.cell(row=row_index+5, column=32).value = ''
            ws.cell(row=row_index+5, column=33).value = '停止'
            ws.cell(row=row_index+5, column=34).value = '計'
            ws.cell(row=row_index+5, column=35).value = '合計'
            ws.cell(row=row_index+6, column=1).value = ''
            ws.cell(row=row_index+6, column=2).value = '一般'
            ws.cell(row=row_index+6, column=3).value = '公共'
            ws.cell(row=row_index+6, column=4).value = '公益'
            ws.cell(row=row_index+6, column=5).value = '一般'
            ws.cell(row=row_index+6, column=6).value = '公共'
            ws.cell(row=row_index+6, column=7).value = '公益'
            ws.cell(row=row_index+6, column=8).value = '一般'
            ws.cell(row=row_index+6, column=9).value = '公共'
            ws.cell(row=row_index+6, column=10).value = '公益'
            ws.cell(row=row_index+6, column=11).value = 'その他'
            ws.cell(row=row_index+6, column=12).value = ''
            ws.cell(row=row_index+6, column=13).value = ''
            ws.cell(row=row_index+6, column=14).value = '流失'
            ws.cell(row=row_index+6, column=15).value = ''
            ws.cell(row=row_index+6, column=16).value = '浸水'
            ws.cell(row=row_index+6, column=17).value = '浸水'
            ws.cell(row=row_index+6, column=18).value = ''
            ws.cell(row=row_index+6, column=19).value = '損失額'
            ws.cell(row=row_index+6, column=20).value = ''
            ws.cell(row=row_index+6, column=21).value = ''
            ws.cell(row=row_index+6, column=22).value = ''
            ws.cell(row=row_index+6, column=23).value = '・港湾'
            ws.cell(row=row_index+6, column=24).value = '設備'
            ws.cell(row=row_index+6, column=25).value = '防止施設'
            ws.cell(row=row_index+6, column=26).value = '施設'
            ws.cell(row=row_index+6, column=27).value = ''
            ws.cell(row=row_index+6, column=28).value = ''
            ws.cell(row=row_index+6, column=29).value = ''
            ws.cell(row=row_index+6, column=30).value = '施設'
            ws.cell(row=row_index+6, column=31).value = ''
            ws.cell(row=row_index+6, column=32).value = '被害額'
            ws.cell(row=row_index+6, column=33).value = '損失額'
            ws.cell(row=row_index+6, column=34).value = ''
            ws.cell(row=row_index+6, column=35).value = ''

        ### 1 異常気象別_都道府県別_被害額
        row_index = 6
        for i, ken_code in enumerate(constants.ken_values):
            for j, weather_ken in enumerate(weather_ken_1_list[i]):
                row_index += 1
                bool_return = set_cell_value(ws, weather_ken, row_index)
                if bool_return == False:
                    raise Exception

        ### 1 異常気象別_都道府県別_被害額
        row_index = 60
        for i, ken_code in enumerate(constants.ken_values):
            for j, weather_ken in enumerate(weather_ken_2_list[i]):
                row_index += 1
                bool_return = set_cell_value(ws, weather_ken, row_index)
                if bool_return == False:
                    raise Exception

        ### 1 異常気象別_都道府県別_被害額
        row_index = 114
        for i, ken_code in enumerate(constants.ken_values):
            for j, weather_ken in enumerate(weather_ken_3_list[i]):
                row_index += 1
                bool_return = set_cell_value(ws, weather_ken, row_index)
                if bool_return == False:
                    raise Exception

        ### 2 異常気象別_全国_被害額
        row_index = 53
        for i, weather_zenkoku in enumerate(weather_zenkoku_1_list):
            row_index += 1
            bool_return = set_cell_value(ws, weather_zenkoku, row_index)
            if bool_return == False:
                raise Exception

        ### 2 異常気象別_全国_被害額
        row_index = 107
        for i, weather_zenkoku in enumerate(weather_zenkoku_2_list):
            row_index += 1
            bool_return = set_cell_value(ws, weather_zenkoku, row_index)
            if bool_return == False:
                raise Exception

        ### 2 異常気象別_全国_被害額
        row_index = 161
        for i, weather_zenkoku in enumerate(weather_zenkoku_3_list):
            row_index += 1
            bool_return = set_cell_value(ws, weather_zenkoku, row_index)
            if bool_return == False:
                raise Exception

        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo11_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo11_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo11.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo11_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo11_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo11_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
