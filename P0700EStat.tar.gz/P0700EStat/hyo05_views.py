###############################################################################
### 帳票名：hyo_05市町村別主要異常気象別一般資産等水害被害.xlsx
### ファイル名：P0700EStat/hyo05_views.py
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO05:
    def __init__(self, ):
        pass

###############################################################################
### 帳票名：hyo_05市町村別主要異常気象別一般資産等水害被害.xlsx
### 関数名：get_hyo05_city_values(ken_code)
### 1_1 市区町村別_主要異常気象別_被害額_合計 (市町村の一覧)
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
### ※ken_codeを検索条件として市区町村の一覧をIPPAN_SUMMARY_VIEWから取得する。
###############################################################################
def get_hyo05_city_values(ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_city_values()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo05_city_values()関数 ken_code={}'.format(ken_code), 'DEBUG')
        if ken_code in constants.ken_values:
            pass
        else:
            print_log('[WARN] P0700EStat.get_hyo05_city_values()関数が警告終了しました。', 'INFO')
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(ken_keys, ken_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_city_values()関数 STEP 2/3.', 'DEBUG')
        hyo05_city_values_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CITY1.city_code, 
                CITY1.city_name 
                
            FROM 
            
            -- 市区町村
            (SELECT 
                SUB00.city_code, 
                CIT00.city_name 
            FROM 
            (SELECT 
                city_code 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) SUB00  
            LEFT JOIN CITY CIT00 ON SUB00.city_code=CIT00.city_code 
            ORDER BY SUB00.city_code 
            ) CITY1 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_city_values()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo05_city_values()関数が正常終了しました。', 'INFO')
        return True, hyo05_city_values_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo05_city_values()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo05_city_values()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo05_city_values()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_05市町村別主要異常気象別一般資産等水害被害.xlsx
### 関数名：get_hyo05_city(city_code)
### 1_2 市区町村別_主要異常気象別_被害額_合計 (市町村別_被害額)
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
### ※city_codeを検索条件として市区町村別_水害被害額の一覧（1件）をIPPAN_SUMMARY_VIEWから取得する。
###############################################################################
def get_hyo05_city(city_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_city()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo05_city()関数 city_code={}'.format(city_code), 'DEBUG')

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        city_keys = ['CITY_CODE']
        city_values = [city_code]
        params = dict(zip(city_keys, city_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_city()関数 STEP 2/3.', 'DEBUG')
        hyo05_city_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CITY1.city_code, 
                CITY1.city_name, 

                CASE WHEN (IPPAN01.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN01.residential_underground_area END, 
                CASE WHEN (IPPAN02.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN02.agricultural_area END, 
                CASE WHEN (IPPAN03.residential_underground_agricultural_area) IS NULL THEN 0.00 ELSE IPPAN03.residential_underground_agricultural_area END, 
                
                CASE WHEN (IPPAN04.building_full) IS NULL THEN 0.00 ELSE IPPAN04.building_full END, 
                CASE WHEN (IPPAN04.building_half) IS NULL THEN 0.00 ELSE IPPAN04.building_half END, 
                CASE WHEN (IPPAN04.building_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_50_100 END, 
                CASE WHEN (IPPAN04.building_lv00) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00 END, 
                CASE WHEN (IPPAN04.building_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00_01_50_100_half_full END, 
                
                CASE WHEN (IPPAN05.family_full) IS NULL THEN 0.00 ELSE IPPAN05.family_full END, 
                CASE WHEN (IPPAN05.family_lv01_50_100_half) IS NULL THEN 0.00 ELSE IPPAN05.family_lv01_50_100_half END, 
                CASE WHEN (IPPAN05.family_lv00) IS NULL THEN 0.00 ELSE IPPAN05.family_lv00 END, 
                CASE WHEN (IPPAN05.family_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN05.family_lv00_01_50_100_half_full END, 
                
                CASE WHEN (IPPAN06.office_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN06.office_lv00_01_50_100_half_full END, 
                CASE WHEN (IPPAN07.employee_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN07.employee_lv00_01_50_100_full END, 
                CASE WHEN (IPPAN08.farmer_fisher_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN08.farmer_fisher_lv00_01_50_100_full END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END, 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END+ 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END 
                AS ippan_damage 
                
            FROM 

            -- 市区町村
            (SELECT 
                city_code, 
                city_name 
            FROM CITY 
            WHERE city_code=%(CITY_CODE)s 
            ) CITY1, 
            
            -- 水害区域面積_宅地・その他
            (SELECT 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+ 
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END) 
                AS residential_underground_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            ) IPPAN01, 
                
            -- 水害区域面積_農地
            (SELECT
                SUM(
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END)
                AS agricultural_area
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            ) IPPAN02, 
                
            -- 水害区域面積_合計
            (SELECT 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END+
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS residential_underground_agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            ) IPPAN03, 
            
            -- 被災家屋棟数
            (SELECT 
                -- 全壊流失
                SUM(
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_full, 
                -- 半壊
                SUM(
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END) 
                AS building_half, 
                -- 床上
                SUM(
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END) 
                AS building_lv01_50_100, 
                -- 床下
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END) 
                AS building_lv00, 
                -- 計
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END+
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END+
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END+
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            ) IPPAN04, 

            -- 被災世帯数
            (SELECT 
                -- 全壊流失
                SUM(
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_full, 
                -- 床上
                SUM(
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+ 
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+ 
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END+ 
                CASE WHEN (family_half) IS NULL THEN 0.00 ELSE family_half END) 
                AS family_lv01_50_100_half, 
                -- 床下
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END) 
                AS family_lv00, 
                -- 計
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END+ 
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+ 
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+ 
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END+ 
                CASE WHEN (family_half) IS NULL THEN 0.00 ELSE family_half END+ 
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_lv00_01_50_100_half_full 
               
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            ) IPPAN05, 

            -- 被災事業所数
            (SELECT 
                SUM(
                CASE WHEN (office_lv00) IS NULL THEN 0.00 ELSE office_lv00 END+ 
                CASE WHEN (office_lv01_49) IS NULL THEN 0.00 ELSE office_lv01_49 END+ 
                CASE WHEN (office_lv50_99) IS NULL THEN 0.00 ELSE office_lv50_99 END+ 
                CASE WHEN (office_lv100) IS NULL THEN 0.00 ELSE office_lv100 END+ 
                CASE WHEN (office_half) IS NULL THEN 0.00 ELSE office_half END+ 
                CASE WHEN (office_full) IS NULL THEN 0.00 ELSE office_full END) 
                AS office_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            ) IPPAN06, 

            -- 被災事業所従業者数
            (SELECT 
                SUM(
                CASE WHEN (employee_lv00) IS NULL THEN 0.00 ELSE employee_lv00 END+ 
                CASE WHEN (employee_lv01_49) IS NULL THEN 0.00 ELSE employee_lv01_49 END+ 
                CASE WHEN (employee_lv50_99) IS NULL THEN 0.00 ELSE employee_lv50_99 END+ 
                CASE WHEN (employee_lv100) IS NULL THEN 0.00 ELSE employee_lv100 END+ 
                CASE WHEN (employee_full) IS NULL THEN 0.00 ELSE employee_full END) 
                AS employee_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            ) IPPAN07, 

            -- 被災農漁家数
            (SELECT 
                SUM(
                CASE WHEN (farmer_fisher_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_lv00 END+ 
                CASE WHEN (farmer_fisher_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_lv01_49 END+ 
                CASE WHEN (farmer_fisher_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_lv50_99 END+ 
                CASE WHEN (farmer_fisher_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_lv100 END+ 
                CASE WHEN (farmer_fisher_full) IS NULL THEN 0.00 ELSE farmer_fisher_full END) 
                AS farmer_fisher_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            ) IPPAN08, 

            -- 一般資産_営業停止損失
            (SELECT 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END) 
                AS ippan_asset_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            ) IPPAN09, 
            
            -- 一般資産_農作物被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END) 
                AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            ) IPPAN10 
                
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_city()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo05_city()関数が正常終了しました。', 'INFO')
        return True, hyo05_city_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo05_city()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo05_city()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo05_city()関数が異常終了しました。', 'ERROR')
        return False, []
        
###############################################################################
### 帳票名：hyo_05市町村別主要異常気象別一般資産等水害被害.xlsx
### 関数名：get_hyo05_city_weather(city_code)
### 1_3 市区町村別_主要異常気象別_被害額_合計 (市町村別_主要異常気象別_被害額)
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
### ※city_codeを検索条件として市区町村別_主要異常気象別_水害被害額の一覧（複数件）をIPPAN_SUMMARY_VIEWから取得する。
###############################################################################
def get_hyo05_city_weather(city_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_city_weather()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo05_city_weather()関数 city_code={}'.format(city_code), 'DEBUG')

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        city_keys = ['CITY_CODE']
        city_values = [city_code]
        params = dict(zip(city_keys, city_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_city_weather()関数 STEP 2/3.', 'DEBUG')
        hyo05_city_weather_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                WEATHER1.weather_id, 
                WEATHER1.weather_name, 
                
                CASE WHEN (IPPAN01.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN01.residential_underground_area END, 
                CASE WHEN (IPPAN02.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN02.agricultural_area END, 
                CASE WHEN (IPPAN03.residential_underground_agricultural_area) IS NULL THEN 0.00 ELSE IPPAN03.residential_underground_agricultural_area END, 
                
                CASE WHEN (IPPAN04.building_full) IS NULL THEN 0.00 ELSE IPPAN04.building_full END, 
                CASE WHEN (IPPAN04.building_half) IS NULL THEN 0.00 ELSE IPPAN04.building_half END, 
                CASE WHEN (IPPAN04.building_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_50_100 END, 
                CASE WHEN (IPPAN04.building_lv00) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00 END, 
                CASE WHEN (IPPAN04.building_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00_01_50_100_half_full END, 
                
                CASE WHEN (IPPAN05.family_full) IS NULL THEN 0.00 ELSE IPPAN05.family_full END, 
                CASE WHEN (IPPAN05.family_lv01_50_100_half) IS NULL THEN 0.00 ELSE IPPAN05.family_lv01_50_100_half END, 
                CASE WHEN (IPPAN05.family_lv00) IS NULL THEN 0.00 ELSE IPPAN05.family_lv00 END, 
                CASE WHEN (IPPAN05.family_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN05.family_lv00_01_50_100_half_full END, 
                
                CASE WHEN (IPPAN06.office_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN06.office_lv00_01_50_100_half_full END, 
                CASE WHEN (IPPAN07.employee_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN07.employee_lv00_01_50_100_full END, 
                CASE WHEN (IPPAN08.farmer_fisher_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN08.farmer_fisher_lv00_01_50_100_full END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END, 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END+ 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END 
                AS ippan_damage 
                
            FROM 
            
            -- 異常気象
            (SELECT 
                SUB00.weather_id, 
                SUB00.weather_name 
            FROM 
            (SELECT 
                weather_id 
            FROM IPPAN_SUMMARY_VIEW
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            GROUP BY weather_id 
            ) SUB00 
            LEFT JOIN WEATHER WEA00 ON SUB00.weather_id=WEA00.weather_id 
            ) WEATHER1 
            
            -- 水害区域面積_宅地・その他
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+ 
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END) 
                AS residential_underground_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            GROUP BY weather_id 
            ) IPPAN01 
            ON WEATHER1.weather_id=IPPAN01.weather_id 

            -- 水害区域面積_農地
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            GROUP BY weather_id 
            ) IPPAN02 
            ON WEATHER1.weather_id=IPPAN02.weather_id 

            -- 水害区域面積_合計
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+ 
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END+ 
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS residential_underground_agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            GROUP BY weather_id 
            ) IPPAN03 
            ON WEATHER1.weather_id=IPPAN03.weather_id 
            
            -- 被災家屋棟数
            LEFT JOIN 
            (SELECT 
                weather_id, 
                -- 全壊流失
                SUM(
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_full, 
                -- 半壊
                SUM(
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END) 
                AS building_half, 
                -- 床上
                SUM(
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END) 
                AS building_lv01_50_100, 
                -- 床下
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END) 
                AS building_lv00, 
                -- 計
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END+ 
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END+ 
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END+ 
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            GROUP BY weather_id 
            ) IPPAN04 
            ON WEATHER1.weather_id=IPPAN04.weather_id 

            -- 被災世帯数
            LEFT JOIN 
            (SELECT 
                weather_id, 
                -- 全壊流失
                SUM(
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_full, 
                -- 床上
                SUM(
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+ 
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+ 
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END+ 
                CASE WHEN (family_half) IS NULL THEN 0.00 ELSE family_half END) 
                AS family_lv01_50_100_half, 
                -- 床下
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END) 
                AS family_lv00, 
                -- 計
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END+ 
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+ 
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+ 
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END+ 
                CASE WHEN (family_half) IS NULL THEN 0.00 ELSE family_half END+ 
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            GROUP BY weather_id 
            ) IPPAN05 
            ON WEATHER1.weather_id=IPPAN05.weather_id 

            -- 被災事業所数
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (office_lv00) IS NULL THEN 0.00 ELSE office_lv00 END+ 
                CASE WHEN (office_lv01_49) IS NULL THEN 0.00 ELSE office_lv01_49 END+ 
                CASE WHEN (office_lv50_99) IS NULL THEN 0.00 ELSE office_lv50_99 END+ 
                CASE WHEN (office_lv100) IS NULL THEN 0.00 ELSE office_lv100 END+ 
                CASE WHEN (office_half) IS NULL THEN 0.00 ELSE office_half END+ 
                CASE WHEN (office_full) IS NULL THEN 0.00 ELSE office_full END) 
                AS office_lv00_01_50_100_half_full                 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            GROUP BY weather_id 
            ) IPPAN06 
            ON WEATHER1.weather_id=IPPAN06.weather_id 

            -- 被災事業所従業者数
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (employee_lv00) IS NULL THEN 0.00 ELSE employee_lv00 END+ 
                CASE WHEN (employee_lv01_49) IS NULL THEN 0.00 ELSE employee_lv01_49 END+ 
                CASE WHEN (employee_lv50_99) IS NULL THEN 0.00 ELSE employee_lv50_99 END+ 
                CASE WHEN (employee_lv100) IS NULL THEN 0.00 ELSE employee_lv100 END+ 
                CASE WHEN (employee_full) IS NULL THEN 0.00 ELSE employee_full END) 
                AS employee_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            GROUP BY weather_id 
            ) IPPAN07 
            ON WEATHER1.weather_id=IPPAN07.weather_id 

            -- 被災農漁家数
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (farmer_fisher_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_lv00 END+ 
                CASE WHEN (farmer_fisher_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_lv01_49 END+ 
                CASE WHEN (farmer_fisher_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_lv50_99 END+ 
                CASE WHEN (farmer_fisher_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_lv100 END+ 
                CASE WHEN (farmer_fisher_full) IS NULL THEN 0.00 ELSE farmer_fisher_full END) 
                AS farmer_fisher_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            GROUP BY weather_id 
            ) IPPAN08 
            ON WEATHER1.weather_id=IPPAN08.weather_id 
            
            -- 一般資産_営業停止損失
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END) 
                AS ippan_asset_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            GROUP BY weather_id 
            ) IPPAN09 
            ON WEATHER1.weather_id=IPPAN09.weather_id 
            
            -- 一般資産_農作物被害額
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END) 
                AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND city_code=%(CITY_CODE)s 
            GROUP BY weather_id 
            ) IPPAN10 
            ON WEATHER1.weather_id=IPPAN10.weather_id 
            
            """, params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_city_weather()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo05_city_weather()関数が正常終了しました。', 'INFO')
        return True, hyo05_city_weather_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo05_city_weather()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo05_city_weather()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo05_city_weather()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_05市町村別主要異常気象別一般資産等水害被害.xlsx
### 関数名：get_hyo05_ken(ken_code)
### 2_1 都道府県別_被害額_合計 中間
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
### ※ken_codeを検索条件として都道府県別_水害被害額の一覧（1件）をIPPAN_SUMMARY_VIEWから取得する。
###############################################################################
def get_hyo05_ken(ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_ken()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo05_ken()関数 ken_code={}'.format(ken_code), 'DEBUG')

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(ken_keys, ken_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_ken()関数 STEP 2/3.', 'DEBUG')
        hyo05_ken_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                KEN1.ken_code, 
                KEN1.ken_name, 
                
                CASE WHEN (IPPAN01.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN01.residential_underground_area END, 
                CASE WHEN (IPPAN02.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN02.agricultural_area END, 
                CASE WHEN (IPPAN03.residential_underground_agricultural_area) IS NULL THEN 0.00 ELSE IPPAN03.residential_underground_agricultural_area END, 
                
                CASE WHEN (IPPAN04.building_full) IS NULL THEN 0.00 ELSE IPPAN04.building_full END, 
                CASE WHEN (IPPAN04.building_half) IS NULL THEN 0.00 ELSE IPPAN04.building_half END, 
                CASE WHEN (IPPAN04.building_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_50_100 END, 
                CASE WHEN (IPPAN04.building_lv00) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00 END, 
                CASE WHEN (IPPAN04.building_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00_01_50_100_half_full END, 
                
                CASE WHEN (IPPAN05.family_full) IS NULL THEN 0.00 ELSE IPPAN05.family_full END, 
                CASE WHEN (IPPAN05.family_lv01_50_100_half) IS NULL THEN 0.00 ELSE IPPAN05.family_lv01_50_100_half END, 
                CASE WHEN (IPPAN05.family_lv00) IS NULL THEN 0.00 ELSE IPPAN05.family_lv00 END, 
                CASE WHEN (IPPAN05.family_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN05.family_lv00_01_50_100_half_full END, 
                
                CASE WHEN (IPPAN06.office_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN06.office_lv00_01_50_100_half_full END, 
                CASE WHEN (IPPAN07.employee_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN07.employee_lv00_01_50_100_full END, 
                CASE WHEN (IPPAN08.farmer_fisher_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN08.farmer_fisher_lv00_01_50_100_full END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END, 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END+ 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END 
                AS ippan_damage 
                
            FROM 
            
            -- 都道府県
            (SELECT 
                ken_code, 
                ken_name 
            FROM KEN 
            WHERE ken_code=%(KEN_CODE)s 
            ) KEN1, 
            
            -- 水害区域面積_宅地・その他
            (SELECT 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+ 
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END) 
                AS residential_underground_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN01, 

            -- 水害区域面積_農地
            (SELECT 
                SUM(
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN02, 

            -- 水害区域面積_合計
            (SELECT 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+ 
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END+ 
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS residential_underground_agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN03, 
            
            -- 被災家屋棟数
            (SELECT 
                -- 全壊流失
                SUM(
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_full, 
                -- 半壊
                SUM(
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END) 
                AS building_half, 
                -- 床上
                SUM(
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END) 
                AS building_lv01_50_100, 
                -- 床下
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END) 
                AS building_lv00, 
                -- 計
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END+ 
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END+ 
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END+ 
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_lv00_01_50_100_half_full 
                
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN04, 

            -- 被災世帯数
            (SELECT 
                -- 全壊流失
                SUM(
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_full, 
                -- 床上
                SUM(
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+ 
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+ 
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END+ 
                CASE WHEN (family_half) IS NULL THEN 0.00 ELSE family_half END) 
                AS family_lv01_50_100_half, 
                -- 床下
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END) 
                AS family_lv00, 
                -- 計
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END+ 
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+ 
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+ 
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END+ 
                CASE WHEN (family_half) IS NULL THEN 0.00 ELSE family_half END+ 
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN05, 

            -- 被災事業所数
            (SELECT 
                SUM(
                CASE WHEN (office_lv00) IS NULL THEN 0.00 ELSE office_lv00 END+ 
                CASE WHEN (office_lv01_49) IS NULL THEN 0.00 ELSE office_lv01_49 END+ 
                CASE WHEN (office_lv50_99) IS NULL THEN 0.00 ELSE office_lv50_99 END+ 
                CASE WHEN (office_lv100) IS NULL THEN 0.00 ELSE office_lv100 END+ 
                CASE WHEN (office_half) IS NULL THEN 0.00 ELSE office_half END+ 
                CASE WHEN (office_full) IS NULL THEN 0.00 ELSE office_full END) 
                AS office_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN06, 

            -- 被災事業所従業者数
            (SELECT 
                SUM(
                CASE WHEN (employee_lv00) IS NULL THEN 0.00 ELSE employee_lv00 END+ 
                CASE WHEN (employee_lv01_49) IS NULL THEN 0.00 ELSE employee_lv01_49 END+ 
                CASE WHEN (employee_lv50_99) IS NULL THEN 0.00 ELSE employee_lv50_99 END+ 
                CASE WHEN (employee_lv100) IS NULL THEN 0.00 ELSE employee_lv100 END+ 
                CASE WHEN (employee_full) IS NULL THEN 0.00 ELSE employee_full END) 
                AS employee_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN07, 

            -- 被災農漁家数
            (SELECT 
                SUM(
                CASE WHEN (farmer_fisher_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_lv00 END+ 
                CASE WHEN (farmer_fisher_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_lv01_49 END+ 
                CASE WHEN (farmer_fisher_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_lv50_99 END+ 
                CASE WHEN (farmer_fisher_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_lv100 END+ 
                CASE WHEN (farmer_fisher_full) IS NULL THEN 0.00 ELSE farmer_fisher_full END) 
                AS farmer_fisher_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN08, 
            
            -- 一般資産_営業停止損失
            (SELECT 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END) 
                AS ippan_asset_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN09, 
            
            -- 一般資産_農作物被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END) 
                AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN10 
            
            """, params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_ken()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo05_ken()関数が正常終了しました。', 'INFO')
        return True, hyo05_ken_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo05_ken()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo05_ken()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo05_ken()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_05市町村別主要異常気象別一般資産等水害被害.xlsx
### 関数名：get_hyo05_ken_weather(ken_code)
### 2_2 都道府県別_被害額_合計 中間
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
### ※ken_codeを検索条件として都道府県別_主要異常気象別_水害被害額の一覧（複数件）をIPPAN_SUMMARY_VIEWから取得する。
###############################################################################
def get_hyo05_ken_weather(ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_ken_weather()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo05_ken_weather()関数 ken_code={}'.format(ken_code), 'DEBUG')

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(ken_keys, ken_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_ken_weather()関数 STEP 2/3.', 'DEBUG')
        hyo05_ken_weather_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                WEATHER1.weather_id, 
                WEATHER1.weather_name, 
                
                CASE WHEN (IPPAN01.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN01.residential_underground_area END, 
                CASE WHEN (IPPAN02.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN02.agricultural_area END, 
                CASE WHEN (IPPAN03.residential_underground_agricultural_area) IS NULL THEN 0.00 ELSE IPPAN03.residential_underground_agricultural_area END, 
                
                CASE WHEN (IPPAN04.building_full) IS NULL THEN 0.00 ELSE IPPAN04.building_full END, 
                CASE WHEN (IPPAN04.building_half) IS NULL THEN 0.00 ELSE IPPAN04.building_half END, 
                CASE WHEN (IPPAN04.building_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_50_100 END, 
                CASE WHEN (IPPAN04.building_lv00) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00 END, 
                CASE WHEN (IPPAN04.building_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00_01_50_100_half_full END, 
                
                CASE WHEN (IPPAN05.family_full) IS NULL THEN 0.00 ELSE IPPAN05.family_full END, 
                CASE WHEN (IPPAN05.family_lv01_50_100_half) IS NULL THEN 0.00 ELSE IPPAN05.family_lv01_50_100_half END, 
                CASE WHEN (IPPAN05.family_lv00) IS NULL THEN 0.00 ELSE IPPAN05.family_lv00 END, 
                CASE WHEN (IPPAN05.family_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN05.family_lv00_01_50_100_half_full END, 
                
                CASE WHEN (IPPAN06.office_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN06.office_lv00_01_50_100_half_full END, 
                CASE WHEN (IPPAN07.employee_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN07.employee_lv00_01_50_100_full END, 
                CASE WHEN (IPPAN08.farmer_fisher_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN08.farmer_fisher_lv00_01_50_100_full END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END, 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END+ 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END 
                AS ippan_damage 
                
            FROM 
            
            -- 異常気象
            (SELECT 
                SUB00.weather_id, 
                WEA00.weather_name 
            FROM 
            (SELECT 
                weather_id 
            FROM IPPAN_SUMMARY_VIEW
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY weather_id 
            ) SUB00 
            LEFT JOIN WEATHER WEA00 ON SUB00.weather_id=WEA00.weather_id 
            ) WEATHER1 
            
            -- 水害区域面積_宅地・その他
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+ 
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END) 
                AS residential_underground_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY weather_id 
            ) IPPAN01 
            ON WEATHER1.weather_id=IPPAN01.weather_id 

            -- 水害区域面積_農地
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY weather_id 
            ) IPPAN02 
            ON WEATHER1.weather_id=IPPAN02.weather_id 

            -- 水害区域面積_合計
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+ 
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END+ 
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS residential_underground_agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY weather_id 
            ) IPPAN03 
            ON WEATHER1.weather_id=IPPAN03.weather_id 
            
            -- 被災家屋棟数
            LEFT JOIN 
            (SELECT 
                weather_id, 
                -- 全壊流失
                SUM(
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_full, 
                -- 半壊
                SUM(
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END) 
                AS building_half, 
                -- 床上
                SUM(
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END) 
                AS building_lv01_50_100, 
                -- 床下
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END) 
                AS building_lv00, 
                -- 計
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END+ 
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END+ 
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END+ 
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY weather_id 
            ) IPPAN04 
            ON WEATHER1.weather_id=IPPAN04.weather_id 

            -- 被災世帯数
            LEFT JOIN 
            (SELECT 
                weather_id, 
                -- 全壊流失
                SUM(
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_full, 
                -- 床上
                SUM(
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+ 
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+ 
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END+ 
                CASE WHEN (family_half) IS NULL THEN 0.00 ELSE family_half END) 
                AS family_lv01_50_100_half, 
                -- 床下
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END) 
                AS family_lv00, 
                -- 計
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END+ 
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+ 
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+ 
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END+ 
                CASE WHEN (family_half) IS NULL THEN 0.00 ELSE family_half END+ 
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY weather_id 
            ) IPPAN05 
            ON WEATHER1.weather_id=IPPAN05.weather_id 

            -- 被災事業所数
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (office_lv00) IS NULL THEN 0.00 ELSE office_lv00 END+ 
                CASE WHEN (office_lv01_49) IS NULL THEN 0.00 ELSE office_lv01_49 END+ 
                CASE WHEN (office_lv50_99) IS NULL THEN 0.00 ELSE office_lv50_99 END+ 
                CASE WHEN (office_lv100) IS NULL THEN 0.00 ELSE office_lv100 END+ 
                CASE WHEN (office_half) IS NULL THEN 0.00 ELSE office_half END+ 
                CASE WHEN (office_full) IS NULL THEN 0.00 ELSE office_full END) 
                AS office_lv00_01_50_100_half_full                 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY weather_id 
            ) IPPAN06 
            ON WEATHER1.weather_id=IPPAN06.weather_id 

            -- 被災事業所従業者数
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (employee_lv00) IS NULL THEN 0.00 ELSE employee_lv00 END+ 
                CASE WHEN (employee_lv01_49) IS NULL THEN 0.00 ELSE employee_lv01_49 END+ 
                CASE WHEN (employee_lv50_99) IS NULL THEN 0.00 ELSE employee_lv50_99 END+ 
                CASE WHEN (employee_lv100) IS NULL THEN 0.00 ELSE employee_lv100 END+ 
                CASE WHEN (employee_full) IS NULL THEN 0.00 ELSE employee_full END) 
                AS employee_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY weather_id 
            ) IPPAN07 
            ON WEATHER1.weather_id=IPPAN07.weather_id 

            -- 被災農漁家数
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (farmer_fisher_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_lv00 END+ 
                CASE WHEN (farmer_fisher_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_lv01_49 END+ 
                CASE WHEN (farmer_fisher_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_lv50_99 END+ 
                CASE WHEN (farmer_fisher_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_lv100 END+ 
                CASE WHEN (farmer_fisher_full) IS NULL THEN 0.00 ELSE farmer_fisher_full END) 
                AS farmer_fisher_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY weather_id 
            ) IPPAN08 
            ON WEATHER1.weather_id=IPPAN08.weather_id 
            
            -- 一般資産_営業停止損失
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END) 
                AS ippan_asset_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY weather_id 
            ) IPPAN09 
            ON WEATHER1.weather_id=IPPAN09.weather_id 
            
            -- 一般資産_農作物被害額
            LEFT JOIN 
            (SELECT 
                weather_id, 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END) 
                AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY weather_id 
            ) IPPAN10 
            ON WEATHER1.weather_id=IPPAN10.weather_id 
            
            """, params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_ken_weather()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo05_ken_weather()関数が正常終了しました。', 'INFO')
        return True, hyo05_ken_weather_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo05_ken_weather()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo05_ken_weather()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo05_ken_weather()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_05市町村別主要異常気象別一般資産等水害被害.xlsx
### 関数名：get_hyo05_zenkoku()
### 3 全国_被害額_合計 最下端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
### ※全国_水害被害額の一覧（1件）をIPPAN_SUMMARY_VIEWから取得する。
###############################################################################
def get_hyo05_zenkoku():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_zenkoku()関数 STEP 1/3.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_zenkoku()関数 STEP 2/3.', 'DEBUG')
        hyo05_zenkoku_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN01.residential_underground_area END, 
                CASE WHEN (IPPAN02.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN02.agricultural_area END, 
                CASE WHEN (IPPAN03.residential_underground_agricultural_area) IS NULL THEN 0.00 ELSE IPPAN03.residential_underground_agricultural_area END, 
                
                CASE WHEN (IPPAN04.building_full) IS NULL THEN 0.00 ELSE IPPAN04.building_full END, 
                CASE WHEN (IPPAN04.building_half) IS NULL THEN 0.00 ELSE IPPAN04.building_half END, 
                CASE WHEN (IPPAN04.building_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_50_100 END, 
                CASE WHEN (IPPAN04.building_lv00) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00 END, 
                CASE WHEN (IPPAN04.building_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00_01_50_100_half_full END, 
                
                CASE WHEN (IPPAN05.family_full) IS NULL THEN 0.00 ELSE IPPAN05.family_full END, 
                CASE WHEN (IPPAN05.family_lv01_50_100_half) IS NULL THEN 0.00 ELSE IPPAN05.family_lv01_50_100_half END, 
                CASE WHEN (IPPAN05.family_lv00) IS NULL THEN 0.00 ELSE IPPAN05.family_lv00 END, 
                CASE WHEN (IPPAN05.family_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN05.family_lv00_01_50_100_half_full END, 
                
                CASE WHEN (IPPAN06.office_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN06.office_lv00_01_50_100_half_full END, 
                CASE WHEN (IPPAN07.employee_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN07.employee_lv00_01_50_100_full END, 
                CASE WHEN (IPPAN08.farmer_fisher_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN08.farmer_fisher_lv00_01_50_100_full END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END, 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END+ 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END 
                AS ippan_damage 
                
            FROM 
            
            -- 水害区域面積_宅地・その他
            (SELECT 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+ 
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END) 
                AS residential_underground_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN01, 

            -- 水害区域面積_農地
            (SELECT 
                SUM(
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN02, 

            -- 水害区域面積_合計
            (SELECT 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+ 
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END+ 
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS residential_underground_agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN03, 
            
            -- 被災家屋棟数
            (SELECT 
                -- 全壊流失
                SUM(
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_full, 
                -- 半壊
                SUM(
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END) 
                AS building_half, 
                -- 床上
                SUM(
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END) 
                AS building_lv01_50_100, 
                -- 床下
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END) 
                AS building_lv00, 
                -- 計
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END+ 
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END+ 
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END+ 
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_lv00_01_50_100_half_full 
                
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN04, 

            -- 被災世帯数
            (SELECT 
                -- 全壊流失
                SUM(
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_full, 
                -- 床上
                SUM(
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+ 
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+ 
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END+ 
                CASE WHEN (family_half) IS NULL THEN 0.00 ELSE family_half END) 
                AS family_lv01_50_100_half, 
                -- 床下
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END) 
                AS family_lv00, 
                -- 計
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END+ 
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+ 
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+ 
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END+ 
                CASE WHEN (family_half) IS NULL THEN 0.00 ELSE family_half END+ 
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_lv00_01_50_100_half_full 
                
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN05, 

            -- 被災事業所数
            (SELECT 
                SUM(
                CASE WHEN (office_lv00) IS NULL THEN 0.00 ELSE office_lv00 END+ 
                CASE WHEN (office_lv01_49) IS NULL THEN 0.00 ELSE office_lv01_49 END+ 
                CASE WHEN (office_lv50_99) IS NULL THEN 0.00 ELSE office_lv50_99 END+ 
                CASE WHEN (office_lv100) IS NULL THEN 0.00 ELSE office_lv100 END+ 
                CASE WHEN (office_half) IS NULL THEN 0.00 ELSE office_half END+ 
                CASE WHEN (office_full) IS NULL THEN 0.00 ELSE office_full END) 
                AS office_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN06, 

            -- 被災事業所従業者数
            (SELECT 
                SUM(
                CASE WHEN (employee_lv00) IS NULL THEN 0.00 ELSE employee_lv00 END+ 
                CASE WHEN (employee_lv01_49) IS NULL THEN 0.00 ELSE employee_lv01_49 END+ 
                CASE WHEN (employee_lv50_99) IS NULL THEN 0.00 ELSE employee_lv50_99 END+ 
                CASE WHEN (employee_lv100) IS NULL THEN 0.00 ELSE employee_lv100 END+ 
                CASE WHEN (employee_full) IS NULL THEN 0.00 ELSE employee_full END) 
                AS employee_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN07, 

            -- 被災農漁家数
            (SELECT 
                SUM(
                CASE WHEN (farmer_fisher_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_lv00 END+ 
                CASE WHEN (farmer_fisher_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_lv01_49 END+ 
                CASE WHEN (farmer_fisher_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_lv50_99 END+ 
                CASE WHEN (farmer_fisher_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_lv100 END+ 
                CASE WHEN (farmer_fisher_full) IS NULL THEN 0.00 ELSE farmer_fisher_full END) 
                AS farmer_fisher_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN08, 
            
            -- 一般資産_営業停止損失
            (SELECT 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END) 
                AS ippan_asset_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN09, 
            
            -- 一般資産_農作物被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END) 
                AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN10 
            
            """, [])
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo05_zenkoku()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo05_zenkoku()関数が正常終了しました。', 'INFO')
        return True, hyo05_zenkoku_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo05_zenkoku()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo05_zenkoku()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo05_zenkoku()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_05市町村別主要異常気象別一般資産等水害被害.xlsx
### 関数名：hyo05_view(request)
### urlpattern：path('hyo05/', hyo05_views.hyo05_view, name='hyo05_view'),
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo05_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo05_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo05_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo05_view()関数 STEP 1/4.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo05_view()関数 STEP 2/4.', 'DEBUG')
        ### 1_1 市区町村別_主要異常気象別_被害額_合計 (市区町村の一覧)
        city_values = []
        for i, ken_code in enumerate(constants.ken_values):
            bool_return, temp = get_hyo05_city_values(ken_code)
            if bool_return == False:
                raise Exception
                
            city_values.append(temp)
        
        ### 1_2 市区町村別_主要異常気象別_被害額_合計 (市区町村別_被害額)
        city_list = []
        for i, ken_code in enumerate(constants.ken_values):
            temp_list = []
            for j, city_code in enumerate(city_values[i]):
                bool_return, temp = get_hyo05_city(city_code)
                if bool_return == False:
                    raise Exception
                
                temp_list.append(temp)
            
            city_list.append(temp_list)
        
        ### 1_3 市区町村別_主要異常気象別_被害額_合計 (市区町村別_主要異常気象別_被害額)
        city_weather_list = []
        for i, ken_code in enumerate(constants.ken_values):
            temp_list = []
            for j, city_code in enumerate(city_values[i]):
                bool_return, temp = get_hyo05_city_weather(city_code)
                if bool_return == False:
                    raise Exception
                    
                temp_list.append(temp)
                
            city_weather_list.append(temp_list)
        
        ### 2_1 都道府県別_被害額_合計 中間
        ken_list = []
        for i, ken_code in enumerate(constants.ken_values):
            bool_return, temp = get_hyo05_ken(ken_code)
            if bool_return == False:
                raise Exception
                
            ken_list.append(temp)
        
        ### 2_2 都道府県別_主要異常気象別_被害額_合計 中間
        ken_weather_list = []
        for i, ken_code in enumerate(constants.ken_values):
            bool_return, temp = get_hyo05_ken_weather(ken_code)
            if bool_return == False:
                raise Exception
                    
            ken_weather_list.append(temp)
        
        ### 3 全国_被害額_合計 最下端
        bool_return, zenkoku_list = get_hyo05_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo05_view()関数 STEP 3/4.', 'DEBUG')
        ### 1_1 市区町村別_主要異常気象別_被害額_合計 (市区町村の一覧)
        print_log('[DEBUG] P0700EStat.hyo05_view()関数 STEP 3_1/4.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, city in enumerate(city_values[i]):
                print('i={} j={} city.city_code={}'.format(i, j, city.city_code), flush=True)
                print('i={} j={} city.city_name={}'.format(i, j, city.city_name), flush=True)

        ### 1_2 市区町村別_主要異常気象別_被害額_合計 (市区町村別_被害額)
        print_log('[DEBUG] P0700EStat.hyo05_view()関数 STEP 3_2/4.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, temp in enumerate(city_list[i]):
                for k, city in enumerate(temp):
                    print('i={} j={} k={} city.city_code={}'.format(i, j, k, city.city_code), flush=True)
                    print('i={} j={} k={} city.city_name={}'.format(i, j, k, city.city_name), flush=True)

        ### 1_3 市区町村別_主要異常気象別_被害額_合計 (市区町村別_主要異常気象別_被害額)
        print_log('[DEBUG] P0700EStat.hyo05_view()関数 STEP 3_3/4.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, temp in enumerate(city_weather_list):
                for k, city_weather in enumerate(temp):
                    print('i={} j={} k={} city_weather.weather_id={}'.format(i, j, k, city_weather.weather_id), flush=True)
                    print('i={} j={} k={} city_weather.weather_name={}'.format(i, j, k, city_weather.weather_name), flush=True)

        ### 2_1 都道府県別_被害額_合計 中間
        print_log('[DEBUG] P0700EStat.hyo05_view()関数 STEP 3_4/4.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, ken in enumerate(ken_list[i]):
                print('i={} j={} ken.ken_code={}'.format(i, j, ken.ken_code), flush=True)
                print('i={} j={} ken.ken_name={}'.format(i, j, ken.ken_name), flush=True)

        ### 2_2 都道府県別_主要異常気象別_被害額_合計 中間
        print_log('[DEBUG] P0700EStat.hyo05_view()関数 STEP 3_5/4.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, ken_weather in enumerate(ken_weather_list[i]):
                print('i={} j={} ken_weather.ippan_damage={}'.format(i, j, ken_weather.ippan_damage), flush=True)

        ### 3 全国_被害額_合計 最下端
        print_log('[DEBUG] P0700EStat.hyo05_view()関数 STEP 3_6/4.', 'DEBUG')
        for i, zenkoku in enumerate(zenkoku_list):
            print('i={} zenkoku.ippan_damage={}'.format(i, zenkoku.ippan_damage), flush=True)

        #######################################################################
        ### レスポンスセット処理(0030)
        ### コンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo05_view()関数 STEP 4/4.', 'DEBUG')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'cat_code': 'hyo05', 
            'city_values': city_values, 
            'city_list': city_list, 
            'city_weather_list': city_weather_list, 
            'ken_list': ken_list, 
            'ken_weather_list': ken_weather_list, 
            'zenkoku_list': zenkoku_list, 
        }
        print_log('[INFO] P0700EStat.hyo05_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0700EStat.hyo05_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo05_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo05_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_05市町村別主要異常気象別一般資産等水害被害.xlsx
### 関数名：hyo05_download_view(request)
### urlpattern：path('download/hyo05/', hyo05_views.hyo05_download_view, name='hyo05_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo05_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo05_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo05_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo05_download_view()関数 STEP 1/5.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo05_download_view()関数 STEP 2/5.', 'DEBUG')
        ### 1_1 市区町村別_主要異常気象別_被害額_合計 (市区町村の一覧)
        city_values = []
        for i, ken_code in enumerate(constants.ken_values):
            bool_return, temp = get_hyo05_city_values(ken_code)
            if bool_return == False:
                raise Exception
                
            city_values.append(temp)
        
        ### 1_2 市区町村別_主要異常気象別_被害額_合計 (市区町村別_被害額)
        city_list = []
        for i, ken_code in enumerate(constants.ken_values):
            temp_list = []
            for j, city_code in enumerate(city_values[i]):
                bool_return, temp = get_hyo05_city(city_code)
                if bool_return == False:
                    raise Exception
                
                temp_list.append(temp)
            
            city_list.append(temp_list)
        
        ### 1_3 市区町村別_主要異常気象別_被害額_合計 (市区町村別_主要異常気象別_被害額)
        city_weather_list = []
        for i, ken_code in enumerate(constants.ken_values):
            temp_list = []
            for j, city_code in enumerate(city_values[i]):
                bool_return, temp = get_hyo05_city_weather(city_code)
                if bool_return == False:
                    raise Exception
                    
                temp_list.append(temp)
                
            city_weather_list.append(temp_list)
        
        ### 2_1 都道府県別_被害額_合計 中間
        ken_list = []
        for i, ken_code in enumerate(constants.ken_values):
            bool_return, temp = get_hyo05_ken(ken_code)
            if bool_return == False:
                raise Exception
                
            ken_list.append(temp)
        
        ### 2_2 都道府県別_主要異常気象別_被害額_合計 中間
        ken_weather_list = []
        for i, ken_code in enumerate(constants.ken_values):
            bool_return, temp = get_hyo05_ken_weather(ken_code)
            if bool_return == False:
                raise Exception
                    
            ken_weather_list.append(temp)
        
        ### 3 全国_被害額_合計 最下端
        bool_return, zenkoku_list = get_hyo05_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo05_download_view()関数 STEP 3/5.', 'DEBUG')
        ### 1_1 市区町村別_主要異常気象別_被害額_合計 (市区町村の一覧)
        print_log('[DEBUG] P0700EStat.hyo05_download_view()関数 STEP 3_1/5.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, city in enumerate(city_values[i]):
                print('i={} j={} city.city_code={}'.format(i, j, city.city_code), flush=True)
                print('i={} j={} city.city_name={}'.format(i, j, city.city_name), flush=True)

        ### 1_2 市区町村別_主要異常気象別_被害額_合計 (市区町村別_被害額)
        print_log('[DEBUG] P0700EStat.hyo05_download_view()関数 STEP 3_2/5.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, temp in enumerate(city_list[i]):
                for k, city in enumerate(temp):
                    print('i={} j={} k={} city.city_code={}'.format(i, j, k, city.city_code), flush=True)
                    print('i={} j={} k={} city.city_name={}'.format(i, j, k, city.city_name), flush=True)

        ### 1_3 市区町村別_主要異常気象別_被害額_合計 (市区町村別_主要異常気象別_被害額)
        print_log('[DEBUG] P0700EStat.hyo05_download_view()関数 STEP 3_3/5.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, temp in enumerate(city_weather_list):
                for k, city_weather in enumerate(temp):
                    print('i={} j={} k={} city_weather.weather_id={}'.format(i, j, k, city_weather.weather_id), flush=True)
                    print('i={} j={} k={} city_weather.weather_name={}'.format(i, j, k, city_weather.weather_name), flush=True)

        ### 2_1 都道府県別_被害額_合計 中間
        print_log('[DEBUG] P0700EStat.hyo05_download_view()関数 STEP 3_4/5.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, ken in enumerate(ken_list[i]):
                print('i={} j={} ken.ken_code={}'.format(i, j, ken.ken_code), flush=True)
                print('i={} j={} ken.ken_name={}'.format(i, j, ken.ken_name), flush=True)

        ### 2_2 都道府県別_主要異常気象別_被害額_合計 中間
        print_log('[DEBUG] P0700EStat.hyo05_download_view()関数 STEP 3_5/5.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, ken_weather in enumerate(ken_weather_list[i]):
                print('i={} j={} ken_weather.ippan_damage={}'.format(i, j, ken_weather.ippan_damage), flush=True)

        ### 3 全国_被害額_合計 最下端
        print_log('[DEBUG] P0700EStat.hyo05_download_view()関数 STEP 3_6/5.', 'DEBUG')
        for i, zenkoku in enumerate(zenkoku_list):
            print('i={} zenkoku.ippan_damage={}'.format(i, zenkoku.ippan_damage), flush=True)
        
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo05_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo05.xlsx'
        ### download_file_path = 'static/download_hyo05.xlsx'
        template_file_path = 'static/template/template_hyo05.xlsx'
        download_file_path = 'static/tmp/download_hyo05.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo05'
        
        ws.cell(row=1, column=1).value = '表－５　市区町村別主要異常気象別一般資産等水害被害'
        
        ws.cell(row=3, column=1).value = '都道'
        ws.cell(row=3, column=2).value = ''
        ws.cell(row=3, column=3).value = '異常気象'
        ws.cell(row=3, column=4).value = '水害区域面積（㎡）'
        ws.cell(row=3, column=7).value = '被害家屋棟数（棟）'
        ws.cell(row=3, column=12).value = '被災世帯数'
        ws.cell(row=3, column=16).value = '被 災 数'
        ws.cell(row=3, column=19).value = '一般資産等被害額（千円）'

        ws.cell(row=4, column=1).value = ''
        ws.cell(row=4, column=2).value = '市区町村名'
        ws.cell(row=4, column=3).value = ''
        ws.cell(row=4, column=4).value = '宅地'
        ws.cell(row=4, column=5).value = '農地'
        ws.cell(row=4, column=6).value = '計'
        ws.cell(row=4, column=7).value = '全壊'
        ws.cell(row=4, column=8).value = '半壊'
        ws.cell(row=4, column=9).value = '床上'
        ws.cell(row=4, column=10).value = '床下'
        ws.cell(row=4, column=11).value = '計'
        ws.cell(row=4, column=12).value = '全壊'
        ws.cell(row=4, column=13).value = '床上'
        ws.cell(row=4, column=14).value = '床下'
        ws.cell(row=4, column=15).value = '計'
        ws.cell(row=4, column=16).value = '農漁家'
        ws.cell(row=4, column=17).value = '事業所'
        ws.cell(row=4, column=18).value = '従業者'
        ws.cell(row=4, column=19).value = '一般資産・'
        ws.cell(row=4, column=20).value = '農作物'
        ws.cell(row=4, column=21).value = '計'

        ws.cell(row=5, column=1).value = '府県名'
        ws.cell(row=5, column=2).value = ''
        ws.cell(row=5, column=3).value = 'コード'
        ws.cell(row=5, column=4).value = '　その他'
        ws.cell(row=5, column=7).value = '流失'
        ws.cell(row=5, column=12).value = '流失'
        ws.cell(row=5, column=19).value = '営業停止損失'
        
        row_index = 5
        
        for i, ken_code in enumerate(constants.ken_values):
            ### 1_2 市区町村別_主要異常気象別_被害額_合計 (市区町村別_被害額)
            for j, city in enumerate(city_list[i]):
                row_index += 1
    
                ws.cell(row=row_index, column=1).value = ''
                ws.cell(row=row_index, column=2).value = city.city_name
                ws.cell(row=row_index, column=3).value = ''
                ws.cell(row=row_index, column=4).value = city.residential_underground_area
                ws.cell(row=row_index, column=5).value = city.agricultural_area
                ws.cell(row=row_index, column=6).value = city.residential_underground_agricultural_area
                ws.cell(row=row_index, column=7).value = city.building_full
                ws.cell(row=row_index, column=8).value = city.building_half
                ws.cell(row=row_index, column=9).value = city.building_lv01_50_100
                ws.cell(row=row_index, column=10).value = city.building_lv00
                ws.cell(row=row_index, column=11).value = city.building_lv00_01_50_100_half_full
                ws.cell(row=row_index, column=12).value = city.family_full
                ws.cell(row=row_index, column=13).value = city.family_lv01_50_100_half
                ws.cell(row=row_index, column=14).value = city.family_lv00
                ws.cell(row=row_index, column=15).value = city.family_lv00_01_50_100_half_full
                ws.cell(row=row_index, column=16).value = city.farmer_fisher_lv00_01_50_100_full
                ws.cell(row=row_index, column=17).value = city.office_lv00_01_50_100_half_full
                ws.cell(row=row_index, column=18).value = city.employee_lv00_01_50_100_full
                ws.cell(row=row_index, column=19).value = city.ippan_asset_sales_damage
                ws.cell(row=row_index, column=20).value = city.crop_damage
                ws.cell(row=row_index, column=21).value = city.ippan_damage
            
                ### 1_3 市区町村別_主要異常気象別_被害額_合計 (市区町村別_主要異常気象別_被害額)
                for k, city_weather in enumerate(city_weather_list[i][j]):
                    row_index += 1

                    ws.cell(row=row_index, column=1).value = ''
                    ws.cell(row=row_index, column=2).value = ''
                    ws.cell(row=row_index, column=3).value = city_weather.weather_code
                    ws.cell(row=row_index, column=4).value = city_weather.residential_underground_area
                    ws.cell(row=row_index, column=5).value = city_weather.agricultural_area
                    ws.cell(row=row_index, column=6).value = city_weather.residential_underground_agricultural_area
                    ws.cell(row=row_index, column=7).value = city_weather.building_full
                    ws.cell(row=row_index, column=8).value = city_weather.building_half
                    ws.cell(row=row_index, column=9).value = city_weather.building_lv01_50_100
                    ws.cell(row=row_index, column=10).value = city_weather.building_lv00
                    ws.cell(row=row_index, column=11).value = city_weather.building_lv00_01_50_100_half_full
                    ws.cell(row=row_index, column=12).value = city_weather.family_full
                    ws.cell(row=row_index, column=13).value = city_weather.family_lv01_50_100_half
                    ws.cell(row=row_index, column=14).value = city_weather.family_lv00
                    ws.cell(row=row_index, column=15).value = city_weather.family_lv00_01_50_100_half_full
                    ws.cell(row=row_index, column=16).value = city_weather.farmer_fisher_lv00_01_50_100_full
                    ws.cell(row=row_index, column=17).value = city_weather.office_lv00_01_50_100_half_full
                    ws.cell(row=row_index, column=18).value = city_weather.employee_lv00_01_50_100_full
                    ws.cell(row=row_index, column=19).value = city_weather.ippan_asset_sales_damage
                    ws.cell(row=row_index, column=20).value = city_weather.crop_damage
                    ws.cell(row=row_index, column=21).value = city_weather.ippan_damage
            
            ### 2_1 都道府県別_被害額_合計 中間
            for j, ken in enumerate(ken_list[i]):
                row_index += 1
                
                ws.cell(row=row_index, column=1).value = ken.ken_name
                ws.cell(row=row_index, column=2).value = ken.ken_name + '  合計'
                ws.cell(row=row_index, column=3).value = ''
                ws.cell(row=row_index, column=4).value = ken.residential_underground_area
                ws.cell(row=row_index, column=5).value = ken.agricultural_area
                ws.cell(row=row_index, column=6).value = ken.residential_underground_agricultural_area
                ws.cell(row=row_index, column=7).value = ken.building_full
                ws.cell(row=row_index, column=8).value = ken.building_half
                ws.cell(row=row_index, column=9).value = ken.building_lv01_50_100
                ws.cell(row=row_index, column=10).value = ken.building_lv00
                ws.cell(row=row_index, column=11).value = ken.building_lv00_01_50_100_half_full
                ws.cell(row=row_index, column=12).value = ken.family_full
                ws.cell(row=row_index, column=13).value = ken.family_lv01_50_100_half
                ws.cell(row=row_index, column=14).value = ken.family_lv00
                ws.cell(row=row_index, column=15).value = ken.family_lv00_01_50_100_half_full
                ws.cell(row=row_index, column=16).value = ken.farmer_fisher_lv00_01_50_100_full
                ws.cell(row=row_index, column=17).value = ken.office_lv00_01_50_100_half_full
                ws.cell(row=row_index, column=18).value = ken.employee_lv00_01_50_100_full
                ws.cell(row=row_index, column=19).value = ken.ippan_asset_sales_damage
                ws.cell(row=row_index, column=20).value = ken.crop_damage
                ws.cell(row=row_index, column=21).value = ken.ippan_damage

            ### 2_2 都道府県別_主要異常気象別_被害額_合計 中間
            for j, ken_weather in enumerate(ken_weather_list[i]):
                row_index += 1
                
                ws.cell(row=row_index, column=1).value = ''
                ws.cell(row=row_index, column=2).value = ''
                ws.cell(row=row_index, column=3).value = ken_weather.weather_name
                ws.cell(row=row_index, column=4).value = ken_weather.residential_underground_area
                ws.cell(row=row_index, column=5).value = ken_weather.agricultural_area
                ws.cell(row=row_index, column=6).value = ken_weather.residential_underground_agricultural_area
                ws.cell(row=row_index, column=7).value = ken_weather.building_full
                ws.cell(row=row_index, column=8).value = ken_weather.building_half
                ws.cell(row=row_index, column=9).value = ken_weather.building_lv01_50_100
                ws.cell(row=row_index, column=10).value = ken_weather.building_lv00
                ws.cell(row=row_index, column=11).value = ken_weather.building_lv00_01_50_100_half_full
                ws.cell(row=row_index, column=12).value = ken_weather.family_full
                ws.cell(row=row_index, column=13).value = ken_weather.family_lv01_50_100_half
                ws.cell(row=row_index, column=14).value = ken_weather.family_lv00
                ws.cell(row=row_index, column=15).value = ken_weather.family_lv00_01_50_100_half_full
                ws.cell(row=row_index, column=16).value = ken_weather.farmer_fisher_lv00_01_50_100_full
                ws.cell(row=row_index, column=17).value = ken_weather.office_lv00_01_50_100_half_full
                ws.cell(row=row_index, column=18).value = ken_weather.employee_lv00_01_50_100_full
                ws.cell(row=row_index, column=19).value = ken_weather.ippan_asset_sales_damage
                ws.cell(row=row_index, column=20).value = ken_weather.crop_damage
                ws.cell(row=row_index, column=21).value = ken_weather.ippan_damage

        ### 3 全国_被害額_合計 最下端
        for i, zenkoku in enumerate(zenkoku_list):
            row_index += 1

            ws.cell(row=row_index, column=1).value = '全国計'
            ws.cell(row=row_index, column=2).value = ''
            ws.cell(row=row_index, column=3).value = ''
            ws.cell(row=row_index, column=4).value = zenkoku.residential_underground_area
            ws.cell(row=row_index, column=5).value = zenkoku.agricultural_area
            ws.cell(row=row_index, column=6).value = zenkoku.residential_underground_agricultural_area
            ws.cell(row=row_index, column=7).value = zenkoku.building_full
            ws.cell(row=row_index, column=8).value = zenkoku.building_half
            ws.cell(row=row_index, column=9).value = zenkoku.building_lv01_50_100
            ws.cell(row=row_index, column=10).value = zenkoku.building_lv00
            ws.cell(row=row_index, column=11).value = zenkoku.building_lv00_01_50_100_half_full
            ws.cell(row=row_index, column=12).value = zenkoku.family_full
            ws.cell(row=row_index, column=13).value = zenkoku.family_lv01_50_100_half
            ws.cell(row=row_index, column=14).value = zenkoku.family_lv00
            ws.cell(row=row_index, column=15).value = zenkoku.family_lv00_01_50_100_half_full
            ws.cell(row=row_index, column=16).value = zenkoku.farmer_fisher_lv00_01_50_100_full
            ws.cell(row=row_index, column=17).value = zenkoku.office_lv00_01_50_100_half_full
            ws.cell(row=row_index, column=18).value = zenkoku.employee_lv00_01_50_100_full
            ws.cell(row=row_index, column=19).value = zenkoku.ippan_asset_sales_damage
            ws.cell(row=row_index, column=20).value = zenkoku.crop_damage
            ws.cell(row=row_index, column=21).value = zenkoku.ippan_damage
        
        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo05_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo05_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo05.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo05_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo05_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo05_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
