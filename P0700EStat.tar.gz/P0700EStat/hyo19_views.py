###############################################################################
### 帳票名：hyo_19河川等種類別市町村別一般資産等被害額.xlsx
### ファイル名：P0700EStat/hyo19_views.py
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO19:
    def __init__(self, city_code, city_name, direct_damage, specified_damage, sub_total_damage, second_damage, mutandis_damage, ordinary_damage, kaigan_damage, other_damage, sum_total_damage):
        self.city_code = city_code
        self.city_name = city_name
        self.direct_damage = direct_damage
        self.specified_damage = specified_damage
        self.sub_total_damage = sub_total_damage
        self.second_damage = second_damage
        self.mutandis_damage = mutandis_damage
        self.ordinary_damage = ordinary_damage
        self.kaigan_damage = kaigan_damage
        self.other_damage = other_damage
        self.sum_total_damage = sum_total_damage

###############################################################################
### 帳票名：hyo_19河川等種類別市町村別一般資産等被害額.xlsx
### 関数名：get_hyo19(kasen_type_code, ken_code)
### 1 市区町村別_河川等種類別_被害額_合計
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo19(kasen_type_code, ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo19()関数 kasen_type_code={}'.format(kasen_type_code), 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo19()関数 ken_code={}'.format(ken_code), 'DEBUG')
        if kasen_type_code in constants.kasen_type_values:
            pass
        else:
            return False, []

        if ken_code in constants.ken_values:
            pass
        else:
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        kasen_type_keys = ['KASEN_TYPE_CODE']
        kasen_type_values = [kasen_type_code]
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(kasen_type_keys + ken_keys, kasen_type_values + ken_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19()関数 STEP 2/3.', 'DEBUG')
        hyo19_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CITY1.city_code, 
                CITY1.city_name, 
                
                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+ 
                CASE WHEN (CHITAN01.chitan_damage) IS NULL THEN 0.00 ELSE CHITAN01.chitan_damage END+ 
                CASE WHEN (HOJO01.hojo_damage) IS NULL THEN 0.00 ELSE HOJO01.hojo_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 
            
            -- 市区町村
            (SELECT SUB1.city_code, CITY0.city_name 
            FROM 
                (SELECT SUB0.city_code  
                FROM 
                    (SELECT city_code 
                    FROM IPPAN_SUMMARY_VIEW 
                    WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
                    GROUP BY city_code 
                    UNION 
                    SELECT city_code 
                    FROM CHITAN_SUMMARY_VIEW 
                    WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
                    GROUP BY city_code 
                    UNION 
                    SELECT city_code 
                    FROM HOJO_SUMMARY_VIEW 
                    WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
                    GROUP BY city_code 
                    UNION 
                    SELECT city_code 
                    FROM KOEKI_SUMMARY_VIEW 
                    WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
                    GROUP BY city_code 
                    ) SUB0 
                GROUP BY SUB0.city_code 
                ) SUB1 
            LEFT JOIN CITY CITY0 ON SUB1.city_code=CITY0.city_code 
            ORDER BY SUB1.city_code 
            ) CITY1
                    
            -- 一般資産被害額
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            )  IPPAN01 
            ON CITY1.city_code=IPPAN01.city_code
            
            -- 地方単独事業被害額
            LEFT JOIN
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS chitan_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) CHITAN01 
            ON CITY1.city_code=CHITAN01.city_code 
            
            -- 補助事業被害額
            LEFT JOIN 
            (SELECT 
                city_code,
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS hojo_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s AND ken_code=%(KEN_CODE)s
            GROUP BY city_code 
            ) HOJO01 
            ON CITY1.city_code=HOJO01.city_code 
            
            -- 公益事業被害額
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) KOEKI01 
            ON CITY1.city_code=KOEKI01.city_code 
                
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19()関数 STEP 3/3.', 'DEBUG')
        return True, hyo19_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_19河川等種類別市町村別一般資産等被害額.xlsx
### 関数名：get_hyo19_zenken(kasen_type_code, ken_code)
### 2_1 全県_河川等種類別_被害額_合計 中間下端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo19_zenken(kasen_type_code, ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_zenken()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo19_zenken()関数 kasen_type_code={}'.format(kasen_type_code), 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo19_zenken()関数 ken_code={}'.format(ken_code), 'DEBUG')
        if kasen_type_code in constants.kasen_type_values:
            pass
        else:
            return False, []

        if ken_code in constants.ken_values:
            pass
        else:
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        kasen_type_keys = ['KASEN_TYPE_CODE']
        kasen_type_values = [kasen_type_code]
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(kasen_type_keys + ken_keys, kasen_type_values + ken_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_zenken()関数 STEP 2/3.', 'DEBUG')
        hyo19_zenken_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+ 
                CASE WHEN (CHITAN01.chitan_damage) IS NULL THEN 0.00 ELSE CHITAN01.chitan_damage END+ 
                CASE WHEN (HOJO01.hojo_damage) IS NULL THEN 0.00 ELSE HOJO01.hojo_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 
                    
            -- 一般資産被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s AND ken_code=%(KEN_CODE)s 
            ) IPPAN01, 
            
            -- 地方単独事業被害額
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS chitan_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s AND ken_code=%(KEN_CODE)s 
            ) CHITAN01, 
            
            -- 補助事業被害額
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS hojo_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s AND ken_code=%(KEN_CODE)s
            ) HOJO01, 
            
            -- 公益事業被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s AND ken_code=%(KEN_CODE)s 
            ) KOEKI01 
                
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_zenken()関数 STEP 3/3.', 'DEBUG')
        return True, hyo19_zenken_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_19河川等種類別市町村別一般資産等被害額.xlsx
### 関数名：get_hyo19_zenkoku(kasen_type_code)
### 2_2 全国_河川等種類別_被害額_合計 最下端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo19_zenkoku(kasen_type_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_zenkoku()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo19_zenkoku()関数 kasen_type_code={}'.format(kasen_type_code), 'DEBUG')
        if kasen_type_code in constants.kasen_type_values:
            pass
        else:
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        kasen_type_keys = ['KASEN_TYPE_CODE']
        kasen_type_values = [kasen_type_code]
        params = dict(zip(kasen_type_keys, kasen_type_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_zenkoku()関数 STEP 2/3.', 'DEBUG')
        hyo19_zenkoku_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+ 
                CASE WHEN (CHITAN01.chitan_damage) IS NULL THEN 0.00 ELSE CHITAN01.chitan_damage END+ 
                CASE WHEN (HOJO01.hojo_damage) IS NULL THEN 0.00 ELSE HOJO01.hojo_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 
                    
            -- 一般資産被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s 
            )  IPPAN01, 
            
            -- 地方単独事業被害額
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS chitan_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s 
            ) CHITAN01, 
            
            -- 補助事業被害額
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS hojo_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s 
            ) HOJO01, 
            
            -- 公益事業被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_type_code=%(KASEN_TYPE_CODE)s 
            ) KOEKI01 
                
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_zenkoku()関数 STEP 3/3.', 'DEBUG')
        return True, hyo19_zenkoku_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_19河川等種類別市町村別一般資産等被害額.xlsx
### 関数名：get_hyo19_sum_total(ken_code)
### 3 市区町村別_全河川等種類別_被害額_合計 右端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo19_sum_total(ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_sum_total()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo19_sum_total()関数 ken_code={}'.format(ken_code), 'DEBUG')

        if ken_code in constants.ken_values:
            pass
        else:
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(ken_keys, ken_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_sum_total()関数 STEP 2/3.', 'DEBUG')
        hyo19_sum_total_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 

                CITY1.city_code, 
                CITY1.city_name, 
                
                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+ 
                CASE WHEN (CHITAN01.chitan_damage) IS NULL THEN 0.00 ELSE CHITAN01.chitan_damage END+
                CASE WHEN (HOJO01.hojo_damage) IS NULL THEN 0.00 ELSE HOJO01.hojo_damage END+
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 

            -- 市区町村
            (SELECT SUB1.city_code, CITY0.city_name 
            FROM 
                (SELECT SUB0.city_code  
                FROM 
                    (SELECT city_code 
                    FROM IPPAN_SUMMARY_VIEW 
                    WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
                    GROUP BY city_code 
                    UNION 
                    SELECT city_code 
                    FROM CHITAN_SUMMARY_VIEW 
                    WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
                    GROUP BY city_code 
                    UNION 
                    SELECT city_code 
                    FROM HOJO_SUMMARY_VIEW 
                    WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
                    GROUP BY city_code 
                    UNION 
                    SELECT city_code 
                    FROM KOEKI_SUMMARY_VIEW 
                    WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
                    GROUP BY city_code 
                    ) SUB0 
                GROUP BY SUB0.city_code 
                ) SUB1 
            LEFT JOIN CITY CITY0 ON SUB1.city_code=CITY0.city_code 
            ORDER BY SUB1.city_code 
            ) CITY1

            -- 一般資産被害額
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) IPPAN01 
            ON CITY1.city_code=IPPAN01.city_code 

            -- 地方単独事業被害額
            LEFT JOIN
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS chitan_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) CHITAN01 
            ON CITY1.city_code=CHITAN01.city_code 

            -- 補助事業被害額
            LEFT JOIN 
            (SELECT 
                city_code,
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS hojo_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s
            GROUP BY city_code 
            ) HOJO01 
            ON CITY1.city_code=HOJO01.city_code 
            
            -- 公益事業被害額
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) KOEKI01 
            ON CITY1.city_code=KOEKI01.city_code 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_sum_total()関数 STEP 3/3.', 'DEBUG')
        return True, hyo19_sum_total_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_19河川等種類別市町村別一般資産等被害額.xlsx
### 関数名：get_hyo19_sum_total_zenken(ken_code)
### 4_1 全県_全河川等種類別_被害額_合計 中間下端 右端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo19_sum_total_zenken(ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_sum_total_zenken()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo19_sum_total_zenken()関数 ken_code={}'.format(ken_code), 'DEBUG')

        if ken_code in constants.ken_values:
            pass
        else:
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(ken_keys, ken_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_sum_total_zenken()関数 STEP 2/3.', 'DEBUG')
        hyo19_sum_total_zenken_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+ 
                CASE WHEN (CHITAN01.chitan_damage) IS NULL THEN 0.00 ELSE CHITAN01.chitan_damage END+
                CASE WHEN (HOJO01.hojo_damage) IS NULL THEN 0.00 ELSE HOJO01.hojo_damage END+
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 

            -- 一般資産被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN01, 

            -- 地方単独事業被害額
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS chitan_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) CHITAN01, 

            -- 補助事業被害額
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS hojo_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) HOJO01, 
            
            -- 公益事業被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) KOEKI01 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_sum_total_zenken()関数 STEP 3/3.', 'DEBUG')
        return True, hyo19_sum_total_zenken_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_19河川等種類別市町村別一般資産等被害額.xlsx
### 関数名：get_hyo19_sum_total_zenkoku()
### 4_2 全国_全河川等種類別_被害額_合計 最下端 右端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo19_sum_total_zenkoku():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_sum_total_zenkoku()関数 STEP 1/3.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_sum_total_zenkoku()関数 STEP 2/3.', 'DEBUG')
        hyo19_sum_total_zenkoku_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN01.ippan_damage END+ 
                CASE WHEN (CHITAN01.chitan_damage) IS NULL THEN 0.00 ELSE CHITAN01.chitan_damage END+
                CASE WHEN (HOJO01.hojo_damage) IS NULL THEN 0.00 ELSE HOJO01.hojo_damage END+
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS damage 
                
            FROM 

            -- 一般資産被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN01, 

            -- 地方単独事業被害額
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS chitan_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) CHITAN01, 

            -- 補助事業被害額
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS hojo_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) HOJO01, 
            
            -- 公益事業被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+ 
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+ 
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+ 
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) KOEKI01 
            
            """, [])

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo19_sum_total_zenkoku()関数 STEP 3/3.', 'DEBUG')
        return True, hyo19_sum_total_zenkoku_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_19河川等種類別市町村別一般資産等被害額.xlsx
### 関数名：hyo19_view(request)
### urlpattern：path('hyo19/', hyo19_views.hyo19_view, name='hyo19_view'),
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo19_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo19_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo19_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo19_view()関数 STEP 1/4.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo19_view()関数 STEP 2/4.', 'DEBUG')
        params = dict(zip(constants.kasen_type_keys, constants.kasen_type_values))

        ### 1 市区町村別_河川等種類別_被害額_合計
        direct_list = []
        specified_list = []
        second_list = []
        mutandis_list = []
        ordinary_list = []
        kaigan_list = []
        other_list = []
        
        for ken_code in constants.ken_values:
            bool_return, temp_direct_list = get_hyo19(params['DIRECT'], ken_code)
            if bool_return == False:
                raise Exception
                
            bool_return, temp_specified_list = get_hyo19(params['SPECIFIED'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_second_list = get_hyo19(params['SECOND'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_mutandis_list = get_hyo19(params['MUTANDIS'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_ordinary_list = get_hyo19(params['ORDINARY'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_kaigan_list = get_hyo19(params['KAIGAN'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_other_list = get_hyo19(params['OTHER'], ken_code)
            if bool_return == False:
                raise Exception
                
            direct_list.append(temp_direct_list)
            specified_list.append(temp_specified_list)
            second_list.append(temp_second_list)
            mutandis_list.append(temp_mutandis_list)
            ordinary_list.append(temp_ordinary_list)
            kaigan_list.append(temp_kaigan_list)
            other_list.append(temp_other_list)

        ### 2_1 全県_河川等種類別_被害額_合計 中間下端
        direct_zenken_list = []
        specified_zenken_list = []
        second_zenken_list = []
        mutandis_zenken_list = []
        ordinary_zenken_list = []
        kaigan_zenken_list = []
        other_zenken_list = []
        
        for ken_code in constants.ken_values:
            bool_return, temp_direct_zenken_list = get_hyo19_zenken(params['DIRECT'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_specified_zenken_list = get_hyo19_zenken(params['SPECIFIED'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_second_zenken_list = get_hyo19_zenken(params['SECOND'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_mutandis_zenken_list = get_hyo19_zenken(params['MUTANDIS'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_ordinary_zenken_list = get_hyo19_zenken(params['ORDINARY'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_kaigan_zenken_list = get_hyo19_zenken(params['KAIGAN'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_other_zenken_list = get_hyo19_zenken(params['OTHER'], ken_code)
            if bool_return == False:
                raise Exception

            direct_zenken_list.append(temp_direct_zenken_list)
            specified_zenken_list.append(temp_specified_zenken_list)
            second_zenken_list.append(temp_second_zenken_list)
            mutandis_zenken_list.append(temp_mutandis_zenken_list)
            ordinary_zenken_list.append(temp_ordinary_zenken_list)
            kaigan_zenken_list.append(temp_kaigan_zenken_list)
            other_zenken_list.append(temp_other_zenken_list)

        ### 2_2 全国_河川等種類別_被害額_合計 最下端
        bool_return, direct_zenkoku_list = get_hyo19_zenkoku(params['DIRECT'])
        if bool_return == False:
            raise Exception

        bool_return, specified_zenkoku_list = get_hyo19_zenkoku(params['SPECIFIED'])
        if bool_return == False:
            raise Exception

        bool_return, second_zenkoku_list = get_hyo19_zenkoku(params['SECOND'])
        if bool_return == False:
            raise Exception

        bool_return, mutandis_zenkoku_list = get_hyo19_zenkoku(params['MUTANDIS'])
        if bool_return == False:
            raise Exception

        bool_return, ordinary_zenkoku_list = get_hyo19_zenkoku(params['ORDINARY'])
        if bool_return == False:
            raise Exception

        bool_return, kaigan_zenkoku_list = get_hyo19_zenkoku(params['KAIGAN'])
        if bool_return == False:
            raise Exception

        bool_return, other_zenkoku_list = get_hyo19_zenkoku(params['OTHER'])
        if bool_return == False:
            raise Exception

        ### 3 市区町村別_全河川等種類別_被害額_合計 右端
        sum_total_list = []

        for ken_code in constants.ken_values:
            bool_return, temp_sum_total_list = get_hyo19_sum_total(ken_code)
            if bool_return == False:
                raise Exception
            
            sum_total_list.append(temp_sum_total_list)

        ### 4_1 全県_全河川等種類別_被害額_合計 中間下端 右端
        sum_total_zenken_list = []

        for ken_code in constants.ken_values:
            bool_return, temp_sum_total_zenken_list = get_hyo19_sum_total_zenken(ken_code)
            if bool_return == False:
                raise Exception
                
            sum_total_zenken_list.append(temp_sum_total_zenken_list)

        ### 4_2 全国_全河川等種類別_被害額_合計 最下端 右端
        bool_return, sum_total_zenkoku_list = get_hyo19_sum_total_zenkoku()
        if bool_return == False:
            raise Exception
        
        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo19_view()関数 STEP 3/4.', 'DEBUG')
        ### 1 市区町村別_河川等種類別_被害額_合計
        ### 3 市区町村別_全河川等種類別_被害額_合計 右端
        city_list = []
        for i, ken_code in enumerate(constants.ken_values):
            temp_list = []
            for direct, specified, second, mutandis, ordinary, kaigan, other, sum_total in zip(
                direct_list[i], specified_list[i], second_list[i], mutandis_list[i], 
                ordinary_list[i], kaigan_list[i], other_list[i], sum_total_list[i]):
                print('direct.city_code={}'.format(direct.city_code), flush=True)
                print('direct.city_name={}'.format(direct.city_code), flush=True)
                print('direct.damage={}'.format(direct.damage), flush=True)
                print('specified.damage={}'.format(specified.damage), flush=True)
                print('second.damage={}'.format(second.damage), flush=True)
                print('mutandis.damage={}'.format(mutandis.damage), flush=True)
                print('ordinary.damage={}'.format(ordinary.damage), flush=True)
                print('kaigan.damage={}'.format(kaigan.damage), flush=True)
                print('other.damage={}'.format(other.damage), flush=True)
                print('sum_total.damage={}'.format(sum_total.damage), flush=True)
                hyo19 = HYO19(
                    direct.city_code, direct.city_name, 
                    direct.damage, specified.damage, direct.damage + specified.damage, second.damage, 
                    mutandis.damage, ordinary.damage, kaigan.damage, other.damage, sum_total.damage)
                temp_list.append(hyo19)
                
            city_list.append(temp_list)

        ### 2_1 全県_河川等種類別_被害額_合計 中間下端
        ### 4_1 全県_全河川等種類別_被害額_合計 中間下端 右端
        zenken_list = []
        for i, ken_code in enumerate(constants.ken_values):
            temp_list = []
            for direct_zenken, specified_zenken, second_zenken, mutandis_zenken, ordinary_zenken, kaigan_zenken, other_zenken, sum_total_zenken in zip(
                direct_zenken_list[i], specified_zenken_list[i], second_zenken_list[i], mutandis_zenken_list[i], 
                ordinary_zenken_list[i], kaigan_zenken_list[i], other_zenken_list[i], sum_total_zenken_list[i]):
                print('direct_zenken.damage={}'.format(direct_zenken.damage), flush=True)
                print('specified_zenken.damage={}'.format(specified_zenken.damage), flush=True)
                print('second_zenken.damage={}'.format(second_zenken.damage), flush=True)
                print('mutandis_zenken.damage={}'.format(mutandis_zenken.damage), flush=True)
                print('ordinary_zenken.damage={}'.format(ordinary_zenken.damage), flush=True)
                print('kaigan_zenken.damage={}'.format(kaigan_zenken.damage), flush=True)
                print('other_zenken.damage={}'.format(other_zenken.damage), flush=True)
                print('sum_total_zenken.damage={}'.format(sum_total_zenken.damage), flush=True)
                hyo19 = HYO19(
                    '', '', 
                    direct_zenken.damage, specified_zenken.damage, direct_zenken.damage + specified_zenken.damage, second_zenken.damage, 
                    mutandis_zenken.damage, ordinary_zenken.damage, kaigan_zenken.damage, other_zenken.damage, sum_total_zenken.damage)
                temp_list.append(hyo19)

            zenken_list.append(temp_list)

        ### 2_2 全国_河川等種類別_被害額_合計 最下端
        ### 4_2 全国_全河川等種類別_被害額_合計 最下端 右端
        zenkoku_list = []
        for direct_zenkoku, specified_zenkoku, second_zenkoku, mutandis_zenkoku, ordinary_zenkoku, kaigan_zenkoku, other_zenkoku, sum_total_zenkoku in zip(
            direct_zenkoku_list, specified_zenkoku_list, second_zenkoku_list, mutandis_zenkoku_list, 
            ordinary_zenkoku_list, kaigan_zenkoku_list, other_zenkoku_list, sum_total_zenkoku_list):
            print('direct_zenkoku.damage={}'.format(direct_zenkoku.damage), flush=True)
            print('specified_zenkoku.damage={}'.format(specified_zenkoku.damage), flush=True)
            print('second_zenkoku.damage={}'.format(second_zenkoku.damage), flush=True)
            print('mutandis_zenkoku.damage={}'.format(mutandis_zenkoku.damage), flush=True)
            print('ordinary_zenkoku.damage={}'.format(ordinary_zenkoku.damage), flush=True)
            print('kaigan_zenkoku.damage={}'.format(kaigan_zenkoku.damage), flush=True)
            print('other_zenkoku.damage={}'.format(other_zenkoku.damage), flush=True)
            print('sum_total_zenkoku.damage={}'.format(sum_total_zenkoku.damage), flush=True)
            hyo19 = HYO19(
                '', '', 
                direct_zenkoku.damage, specified_zenkoku.damage, direct_zenkoku.damage + specified_zenkoku.damage, second_zenkoku.damage, 
                mutandis_zenkoku.damage, ordinary_zenkoku.damage, kaigan_zenkoku.damage, other_zenkoku.damage, sum_total_zenkoku.damage)
            zenkoku_list.append(hyo19)

        #######################################################################
        ### レスポンスセット処理(0030)
        ### コンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo19_view()関数 STEP 4/4.', 'DEBUG')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'cat_code': 'hyo19', 
            'city_list': city_list, 
            'zenken_list': zenken_list, 
            'zenkoku_list': zenkoku_list, 
        }
        print_log('[INFO] P0700EStat.hyo19_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0700EStat.hyo19_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo19_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo19_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_19河川等種類別市町村別一般資産等被害額.xlsx
### 関数名：hyo19_download_view(request)
### urlpattern：path('download/hyo19/', hyo19_views.hyo19_download_view, name='hyo19_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo19_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo19_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo19_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo19_download_view()関数 STEP 1/5.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo19_download_view()関数 STEP 2/5.', 'DEBUG')
        params = dict(zip(constants.kasen_type_keys, constants.kasen_type_values))

        ### 1 市区町村別_河川等種類別_被害額_合計
        direct_list = []
        specified_list = []
        second_list = []
        mutandis_list = []
        ordinary_list = []
        kaigan_list = []
        other_list = []
        
        for ken_code in constants.ken_values:
            bool_return, temp_direct_list = get_hyo19(params['DIRECT'], ken_code)
            if bool_return == False:
                raise Exception
                
            bool_return, temp_specified_list = get_hyo19(params['SPECIFIED'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_second_list = get_hyo19(params['SECOND'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_mutandis_list = get_hyo19(params['MUTANDIS'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_ordinary_list = get_hyo19(params['ORDINARY'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_kaigan_list = get_hyo19(params['KAIGAN'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_other_list = get_hyo19(params['OTHER'], ken_code)
            if bool_return == False:
                raise Exception
                
            direct_list.append(temp_direct_list)
            specified_list.append(temp_specified_list)
            second_list.append(temp_second_list)
            mutandis_list.append(temp_mutandis_list)
            ordinary_list.append(temp_ordinary_list)
            kaigan_list.append(temp_kaigan_list)
            other_list.append(temp_other_list)

        ### 2_1 全県_河川等種類別_被害額_合計 中間下端
        direct_zenken_list = []
        specified_zenken_list = []
        second_zenken_list = []
        mutandis_zenken_list = []
        ordinary_zenken_list = []
        kaigan_zenken_list = []
        other_zenken_list = []
        
        for ken_code in constants.ken_values:
            bool_return, temp_direct_zenken_list = get_hyo19_zenken(params['DIRECT'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_specified_zenken_list = get_hyo19_zenken(params['SPECIFIED'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_second_zenken_list = get_hyo19_zenken(params['SECOND'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_mutandis_zenken_list = get_hyo19_zenken(params['MUTANDIS'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_ordinary_zenken_list = get_hyo19_zenken(params['ORDINARY'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_kaigan_zenken_list = get_hyo19_zenken(params['KAIGAN'], ken_code)
            if bool_return == False:
                raise Exception

            bool_return, temp_other_zenken_list = get_hyo19_zenken(params['OTHER'], ken_code)
            if bool_return == False:
                raise Exception

            direct_zenken_list.append(temp_direct_zenken_list)
            specified_zenken_list.append(temp_specified_zenken_list)
            second_zenken_list.append(temp_second_zenken_list)
            mutandis_zenken_list.append(temp_mutandis_zenken_list)
            ordinary_zenken_list.append(temp_ordinary_zenken_list)
            kaigan_zenken_list.append(temp_kaigan_zenken_list)
            other_zenken_list.append(temp_other_zenken_list)

        ### 2_2 全国_河川等種類別_被害額_合計 最下端
        bool_return, direct_zenkoku_list = get_hyo19_zenkoku(params['DIRECT'])
        if bool_return == False:
            raise Exception

        bool_return, specified_zenkoku_list = get_hyo19_zenkoku(params['SPECIFIED'])
        if bool_return == False:
            raise Exception

        bool_return, second_zenkoku_list = get_hyo19_zenkoku(params['SECOND'])
        if bool_return == False:
            raise Exception

        bool_return, mutandis_zenkoku_list = get_hyo19_zenkoku(params['MUTANDIS'])
        if bool_return == False:
            raise Exception

        bool_return, ordinary_zenkoku_list = get_hyo19_zenkoku(params['ORDINARY'])
        if bool_return == False:
            raise Exception

        bool_return, kaigan_zenkoku_list = get_hyo19_zenkoku(params['KAIGAN'])
        if bool_return == False:
            raise Exception

        bool_return, other_zenkoku_list = get_hyo19_zenkoku(params['OTHER'])
        if bool_return == False:
            raise Exception

        ### 3 市区町村別_全河川等種類別_被害額_合計 右端
        sum_total_list = []

        for ken_code in constants.ken_values:
            bool_return, temp_sum_total_list = get_hyo19_sum_total(ken_code)
            if bool_return == False:
                raise Exception
            
            sum_total_list.append(temp_sum_total_list)

        ### 4_1 全県_全河川等種類別_被害額_合計 中間下端 右端
        sum_total_zenken_list = []

        for ken_code in constants.ken_values:
            bool_return, temp_sum_total_zenken_list = get_hyo19_sum_total_zenken(ken_code)
            if bool_return == False:
                raise Exception
                
            sum_total_zenken_list.append(temp_sum_total_zenken_list)

        ### 4_2 全国_全河川等種類別_被害額_合計 最下端 右端
        bool_return, sum_total_zenkoku_list = get_hyo19_sum_total_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo19_download_view()関数 STEP 3/5.', 'DEBUG')
        ### 1 市区町村別_河川等種類別_被害額_合計
        ### 3 市区町村別_全河川等種類別_被害額_合計 右端
        city_list = []
        for i, ken_code in enumerate(constants.ken_values):
            temp_list = []
            for direct, specified, second, mutandis, ordinary, kaigan, other, sum_total in zip(
                direct_list[i], specified_list[i], second_list[i], mutandis_list[i], 
                ordinary_list[i], kaigan_list[i], other_list[i], sum_total_list[i]):
                print('direct.city_code={}'.format(direct.city_code), flush=True)
                print('direct.city_name={}'.format(direct.city_code), flush=True)
                print('direct.damage={}'.format(direct.damage), flush=True)
                print('specified.damage={}'.format(specified.damage), flush=True)
                print('second.damage={}'.format(second.damage), flush=True)
                print('mutandis.damage={}'.format(mutandis.damage), flush=True)
                print('ordinary.damage={}'.format(ordinary.damage), flush=True)
                print('kaigan.damage={}'.format(kaigan.damage), flush=True)
                print('other.damage={}'.format(other.damage), flush=True)
                print('sum_total.damage={}'.format(sum_total.damage), flush=True)
                hyo19 = HYO19(
                    direct.city_code, direct.city_name, 
                    direct.damage, specified.damage, direct.damage + specified.damage, second.damage, 
                    mutandis.damage, ordinary.damage, kaigan.damage, other.damage, sum_total.damage)
                temp_list.append(hyo19)
                
            city_list.append(temp_list)

        ### 2_1 全県_河川等種類別_被害額_合計 中間下端
        ### 4_1 全県_全河川等種類別_被害額_合計 中間下端 右端
        zenken_list = []
        for i, ken_code in enumerate(constants.ken_values):
            temp_list = []
            for direct_zenken, specified_zenken, second_zenken, mutandis_zenken, ordinary_zenken, kaigan_zenken, other_zenken, sum_total_zenken in zip(
                direct_zenken_list[i], specified_zenken_list[i], second_zenken_list[i], mutandis_zenken_list[i], 
                ordinary_zenken_list[i], kaigan_zenken_list[i], other_zenken_list[i], sum_total_zenken_list[i]):
                print('direct_zenken.damage={}'.format(direct_zenken.damage), flush=True)
                print('specified_zenken.damage={}'.format(specified_zenken.damage), flush=True)
                print('second_zenken.damage={}'.format(second_zenken.damage), flush=True)
                print('mutandis_zenken.damage={}'.format(mutandis_zenken.damage), flush=True)
                print('ordinary_zenken.damage={}'.format(ordinary_zenken.damage), flush=True)
                print('kaigan_zenken.damage={}'.format(kaigan_zenken.damage), flush=True)
                print('other_zenken.damage={}'.format(other_zenken.damage), flush=True)
                print('sum_total_zenken.damage={}'.format(sum_total_zenken.damage), flush=True)
                hyo19 = HYO19(
                    '', '', 
                    direct_zenken.damage, specified_zenken.damage, direct_zenken.damage + specified_zenken.damage, second_zenken.damage, 
                    mutandis_zenken.damage, ordinary_zenken.damage, kaigan_zenken.damage, other_zenken.damage, sum_total_zenken.damage)
                temp_list.append(hyo19)

            zenken_list.append(temp_list)

        ### 2_2 全国_河川等種類別_被害額_合計 最下端
        ### 4_2 全国_全河川等種類別_被害額_合計 最下端 右端
        zenkoku_list = []
        for direct_zenkoku, specified_zenkoku, second_zenkoku, mutandis_zenkoku, ordinary_zenkoku, kaigan_zenkoku, other_zenkoku, sum_total_zenkoku in zip(
            direct_zenkoku_list, specified_zenkoku_list, second_zenkoku_list, mutandis_zenkoku_list, 
            ordinary_zenkoku_list, kaigan_zenkoku_list, other_zenkoku_list, sum_total_zenkoku_list):
            print('direct_zenkoku.damage={}'.format(direct_zenkoku.damage), flush=True)
            print('specified_zenkoku.damage={}'.format(specified_zenkoku.damage), flush=True)
            print('second_zenkoku.damage={}'.format(second_zenkoku.damage), flush=True)
            print('mutandis_zenkoku.damage={}'.format(mutandis_zenkoku.damage), flush=True)
            print('ordinary_zenkoku.damage={}'.format(ordinary_zenkoku.damage), flush=True)
            print('kaigan_zenkoku.damage={}'.format(kaigan_zenkoku.damage), flush=True)
            print('other_zenkoku.damage={}'.format(other_zenkoku.damage), flush=True)
            print('sum_total_zenkoku.damage={}'.format(sum_total_zenkoku.damage), flush=True)
            hyo19 = HYO19(
                '', '', 
                direct_zenkoku.damage, specified_zenkoku.damage, direct_zenkoku.damage + specified_zenkoku.damage, second_zenkoku.damage, 
                mutandis_zenkoku.damage, ordinary_zenkoku.damage, kaigan_zenkoku.damage, other_zenkoku.damage, sum_total_zenkoku.damage)
            zenkoku_list.append(hyo19)
        
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo19_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo19.xlsx'
        ### download_file_path = 'static/download_hyo19.xlsx'
        template_file_path = 'static/template/template_hyo19.xlsx'
        download_file_path = 'static/tmp/download_hyo19.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo19'
        
        ws.cell(row=1, column=1).value = '表－１９　河川等種類別市区町村別一般資産等被害額'
        ws.cell(row=3, column=11).value = '（単位：千円）'
        ws.cell(row=4, column=1).value = '都　道'
        ws.cell(row=4, column=2).value = '市区町村名'
        ws.cell(row=4, column=3).value = '一級河川'
        ws.cell(row=4, column=6).value = '二級'
        ws.cell(row=4, column=7).value = '準用'
        ws.cell(row=4, column=8).value = '普通'
        ws.cell(row=4, column=9).value = '海岸'
        ws.cell(row=4, column=10).value = 'その他'
        ws.cell(row=4, column=11).value = '合　計'
        ws.cell(row=5, column=1).value = '府県名'
        ws.cell(row=5, column=3).value = '直轄区間'
        ws.cell(row=5, column=4).value = '指定区間'
        ws.cell(row=5, column=5).value = '小計'
        ws.cell(row=5, column=6).value = '河川'
        ws.cell(row=5, column=7).value = '河川'
        ws.cell(row=5, column=8).value = '河川'
        
        row_index = 5
        for i, ken_code in enumerate(constants.ken_values):
            for j, zencity in enumerate(city_list[i]):
                for k, city in enumerate(zencity):
                    row_index += 1
                    if k == 0 and i == 0:
                        ws.cell(row=row_index, column=1).value = '北海道'
                    elif k == 0 and i == 1:
                        ws.cell(row=row_index, column=1).value = '青森'
                    elif k == 0 and i == 2:
                        ws.cell(row=row_index, column=1).value = '岩手'
                    elif k == 0 and i == 3:
                        ws.cell(row=row_index, column=1).value = '宮城'
                    elif k == 0 and i == 4:
                        ws.cell(row=row_index, column=1).value = '秋田'
                    elif k == 0 and i == 5:
                        ws.cell(row=row_index, column=1).value = '山形'
                    elif k == 0 and i == 6:
                        ws.cell(row=row_index, column=1).value = '福島'
                    elif k == 0 and i == 7:
                        ws.cell(row=row_index, col=1).value = '茨城'
                    elif k == 0 and i == 8:
                        ws.cell(row=row_index, column=1).value = '栃木'
                    elif k == 0 and i == 9:
                        ws.cell(row=row_index, column=1).value = '群馬'
                    elif k == 0 and i == 10:
                        ws.cell(row=row_index, column=1).value = '埼玉'
                    elif k == 0 and i == 11:
                        ws.cell(row=row_index, column=1).value = '千葉'
                    elif k == 0 and i == 12:
                        ws.cell(row=row_index, column=1).value = '東京'
                    elif k == 0 and i == 13:
                        ws.cell(row=row_index, column=1).value = '神奈川'
                    elif k == 0 and i == 14:
                        ws.cell(row=row_index, column=1).value = '新潟'
                    elif k == 0 and i == 15:
                        ws.cell(row=row_index, column=1).value = '富山'
                    elif k == 0 and i == 16:
                        ws.cell(row=row_index, column=1).value = '石川'
                    elif k == 0 and i == 17:
                        ws.cell(row=row_index, column=1).value = '福井'
                    elif k == 0 and i == 18:
                        ws.cell(row=row_index, column=1).value = '山梨'
                    elif k == 0 and i == 19:
                        ws.cell(row=row_index, column=1).value = '長野'
                    elif k == 0 and i == 20:
                        ws.cell(row=row_index, column=1).value = '岐阜'
                    elif k == 0 and i == 21:
                        ws.cell(row=row_index, column=1).value = '静岡'
                    elif k == 0 and i == 22:
                        ws.cell(row=row_index, column=1).value = '愛知'
                    elif k == 0 and i == 23:
                        ws.cell(row=row_index, column=1).value = '三重'
                    elif k == 0 and i == 24:
                        ws.cell(row=row_index, column=1).value = '滋賀'
                    elif k == 0 and i == 25:
                        ws.cell(row=row_index, column=1).value = '京都'
                    elif k == 0 and i == 26:
                        ws.cell(row=row_index, column=1).value = '大阪'
                    elif k == 0 and i == 27:
                        ws.cell(row=row_index, column=1).value = '兵庫'
                    elif k == 0 and i == 28:
                        ws.cell(row=row_index, column=1).value = '奈良'
                    elif k == 0 and i == 29:
                        ws.cell(row=row_index, column=1).value = '和歌山'
                    elif k == 0 and i == 30:
                        ws.cell(row=row_index, column=1).value = '鳥取'
                    elif k == 0 and i == 31:
                        ws.cell(row=row_index, column=1).value = '島根'
                    elif k == 0 and i == 32:
                        ws.cell(row=row_index, column=1).value = '岡山'
                    elif k == 0 and i == 33:
                        ws.cell(row=row_index, column=1).value = '広島'
                    elif k == 0 and i == 34:
                        ws.cell(row=row_index, column=1).value = '山口'
                    elif k == 0 and i == 35:
                        ws.cell(row=row_index, column=1).value = '徳島'
                    elif k == 0 and i == 36:
                        ws.cell(row=row_index, column=1).value = '香川'
                    elif k == 0 and i == 37:
                        ws.cell(row=row_index, column=1).value = '愛媛'
                    elif k == 0 and i == 38:
                        ws.cell(row=row_index, column=1).value = '高知'
                    elif k == 0 and i == 39:
                        ws.cell(row=row_index, column=1).value = '福岡'
                    elif k == 0 and i == 40:
                        ws.cell(row=row_index, column=1).value = '佐賀'
                    elif k == 0 and i == 41:
                        ws.cell(row=row_index, column=1).value = '長崎'
                    elif k == 0 and i == 42:
                        ws.cell(row=row_index, column=1).value = '熊本'
                    elif k == 0 and i == 43:
                        ws.cell(row=row_index, column=1).value = '大分'
                    elif k == 0 and i == 44:
                        ws.cell(row=row_index, column=1).value = '宮崎'
                    elif k == 0 and i == 45:
                        ws.cell(row=row_index, column=1).value = '鹿児島'
                    elif k == 0 and i == 46:
                        ws.cell(row=row_index, col=1).value = '沖縄'
                        
                    ws.cell(row=row_index, column=2).value = city.city_name
                    ws.cell(row=row_index, column=3).value = city.direct_damage
                    ws.cell(row=row_index, column=4).value = city.specified_damage
                    ws.cell(row=row_index, column=5).value = city.sub_total_damage
                    ws.cell(row=row_index, column=6).value = city.second_damage
                    ws.cell(row=row_index, column=7).value = city.mutandis_damage
                    ws.cell(row=row_index, column=8).value = city.ordinary_damage
                    ws.cell(row=row_index, column=9).value = city.kaigan_damage
                    ws.cell(row=row_index, column=10).value = city.other_damage
                    ws.cell(row=row_index, column=11).value = city.sum_total_damage

            for j, zenken in enumerate(zenken_list[i]):
                row_index += 1
                if len(city_list[i]) == 0 and i == 0:
                    ws.cell(row=row_index, column=1).value = '北海道'
                elif len(city_list[i]) == 0 and i == 1:
                    ws.cell(row=row_index, column=1).value = '青森'
                elif len(city_list[i]) == 0 and i == 2:
                    ws.cell(row=row_index, column=1).value = '岩手'
                elif len(city_list[i]) == 0 and i == 3:
                    ws.cell(row=row_index, column=1).value = '宮城'
                elif len(city_list[i]) == 0 and i == 4:
                    ws.cell(row=row_index, column=1).value = '秋田'
                elif len(city_list[i]) == 0 and i == 5:
                    ws.cell(row=row_index, column=1).value = '山形'
                elif len(city_list[i]) == 0 and i == 6:
                    ws.cell(row=row_index, column=1).value = '福島'
                elif len(city_list[i]) == 0 and i == 7:
                    ws.cell(row=row_index, column=1).value = '茨城'
                elif len(city_list[i]) == 0 and i == 8:
                    ws.cell(row=row_index, column=1).value = '栃木'
                elif len(city_list[i]) == 0 and i == 9:
                    ws.cell(row=row_index, column=1).value = '群馬'
                elif len(city_list[i]) == 0 and i == 10:
                    ws.cell(row=row_index, column=1).value = '埼玉'
                elif len(city_list[i]) == 0 and i == 11:
                    ws.cell(row=row_index, column=1).value = '千葉'
                elif len(city_list[i]) == 0 and i == 12:
                    ws.cell(row=row_index, column=1).value = '東京'
                elif len(city_list[i]) == 0 and i == 13:
                    ws.cell(row=row_index, column=1).value = '神奈川'
                elif len(city_list[i]) == 0 and i == 14:
                    ws.cell(row=row_index, column=1).value = '新潟'
                elif len(city_list[i]) == 0 and i == 15:
                    ws.cell(row=row_index, column=1).value = '富山'
                elif len(city_list[i]) == 0 and i == 16:
                    ws.cell(row=row_index, column=1).value = '石川'
                elif len(city_list[i]) == 0 and i == 17:
                    ws.cell(row=row_index, column=1).value = '福井'
                elif len(city_list[i]) == 0 and i == 18:
                    ws.cell(row=row_index, column=1).value = '山梨'
                elif len(city_list[i]) == 0 and i == 19:
                    ws.cell(row=row_index, column=1).value = '長野'
                elif len(city_list[i]) == 0 and i == 20:
                    ws.cell(row=row_index, column=1).value = '岐阜'
                elif len(city_list[i]) == 0 and i == 21:
                    ws.cell(row=row_index, column=1).value = '静岡'
                elif len(city_list[i]) == 0 and i == 22:
                    ws.cell(row=row_index, column=1).value = '愛知'
                elif len(city_list[i]) == 0 and i == 23:
                    ws.cell(row=row_index, column=1).value = '三重'
                elif len(city_list[i]) == 0 and i == 24:
                    ws.cell(row=row_index, column=1).value = '滋賀'
                elif len(city_list[i]) == 0 and i == 25:
                    ws.cell(row=row_index, column=1).value = '京都'
                elif len(city_list[i]) == 0 and i == 26:
                    ws.cell(row=row_index, column=1).value = '大阪'
                elif len(city_list[i]) == 0 and i == 27:
                    ws.cell(row=row_index, column=1).value = '兵庫'
                elif len(city_list[i]) == 0 and i == 28:
                    ws.cell(row=row_index, column=1).value = '奈良'
                elif len(city_list[i]) == 0 and i == 29:
                    ws.cell(row=row_index, column=1).value = '和歌山'
                elif len(city_list[i]) == 0 and i == 30:
                    ws.cell(row=row_index, column=1).value = '鳥取'
                elif len(city_list[i]) == 0 and i == 31:
                    ws.cell(row=row_index, column=1).value = '島根'
                elif len(city_list[i]) == 0 and i == 32:
                    ws.cell(row=row_index, column=1).value = '岡山'
                elif len(city_list[i]) == 0 and i == 33:
                    ws.cell(row=row_index, column=1).value = '広島'
                elif len(city_list[i]) == 0 and i == 34:
                    ws.cell(row=row_index, column=1).value = '山口'
                elif len(city_list[i]) == 0 and i == 35:
                    ws.cell(row=row_index, column=1).value = '徳島'
                elif len(city_list[i]) == 0 and i == 36:
                    ws.cell(row=row_index, column=1).value = '香川'
                elif len(city_list[i]) == 0 and i == 37:
                    ws.cell(row=row_index, column=1).value = '愛媛'
                elif len(city_list[i]) == 0 and i == 38:
                    ws.cell(row=row_index, column=1).value = '高知'
                elif len(city_list[i]) == 0 and i == 39:
                    ws.cell(row=row_index, column=1).value = '福岡'
                elif len(city_list[i]) == 0 and i == 40:
                    ws.cell(row=row_index, column=1).value = '佐賀'
                elif len(city_list[i]) == 0 and i == 41:
                    ws.cell(row=row_index, column=1).value = '長崎'
                elif len(city_list[i]) == 0 and i == 42:
                    ws.cell(row=row_index, column=1).value = '熊本'
                elif len(city_list[i]) == 0 and i == 43:
                    ws.cell(row=row_index, column=1).value = '大分'
                elif len(city_list[i]) == 0 and i == 44:
                    ws.cell(row=row_index, column=1).value = '宮崎'
                elif len(city_list[i]) == 0 and i == 45:
                    ws.cell(row=row_index, column=1).value = '鹿児島'
                elif len(city_list[i]) == 0 and i == 46:
                    ws.cell(row=row_index, column=1).value = '沖縄'
                    
                ws.cell(row=row_index, column=2).value = '計'
                ws.cell(row=row_index, column=3).value = zenken.direct_damage
                ws.cell(row=row_index, column=4).value = zenken.specified_damage
                ws.cell(row=row_index, column=5).value = zenken.sub_total_damage
                ws.cell(row=row_index, column=6).value = zenken.second_damage
                ws.cell(row=row_index, column=7).value = zenken.mutandis_damage
                ws.cell(row=row_index, column=8).value = zenken.ordinary_damage
                ws.cell(row=row_index, column=9).value = zenken.kaigan_damage
                ws.cell(row=row_index, column=10).value = zenken.other_damage
                ws.cell(row=row_index, column=11).value = zenken.sum_total_damage

        row_index += 1
        ws.cell(row=row_index, column=1).value = '全国計'
        ws.cell(row=row_index, column=2).value = ''
        ws.cell(row=row_index, column=3).value = zenkoku_list[0].direct_damage
        ws.cell(row=row_index, column=4).value = zenkoku_list[0].specified_damage
        ws.cell(row=row_index, column=5).value = zenkoku_list[0].sub_total_damage
        ws.cell(row=row_index, column=6).value = zenkoku_list[0].second_damage
        ws.cell(row=row_index, column=7).value = zenkoku_list[0].mutandis_damage
        ws.cell(row=row_index, column=8).value = zenkoku_list[0].ordinary_damage
        ws.cell(row=row_index, column=9).value = zenkoku_list[0].kaigan_damage
        ws.cell(row=row_index, column=10).value = zenkoku_list[0].other_damage
        ws.cell(row=row_index, column=11).value = zenkoku_list[0].sum_total_damage
        
        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo19_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo19_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo19.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo19_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo19_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo19_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
