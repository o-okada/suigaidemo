from django.urls import path
from . import views
from . import hyo01_views
from . import hyo02_views
from . import hyo03_views
from . import hyo04_views
from . import hyo05_views
from . import hyo06_views
from . import hyo07_views
from . import hyo08_views
from . import hyo09_1_views
from . import hyo09_2_views
from . import hyo10_views
from . import hyo11_views
from . import hyo12_views
from . import hyo13_views
from . import hyo14_views
from . import hyo15_views
from . import hyo16_views
from . import hyo17_views
from . import hyo18_views
from . import hyo19_views
from . import hyo20_views
from . import hyo21_views
from . import hyo22_views
from . import hyo23_views
from . import hyo24_views
from . import hyo25_views
from . import hyo43_views
from . import hyo45_views
from . import hyo46_views
from . import hyo47_views
from . import hyo48_views
from . import hyo49_views
from . import hyo50_views
from . import hyo51_views

app_name = 'P0700EStat'
urlpatterns = [
    path('', views.index_view, name='index_view'),
    
    ### path('cat/<slug:cat_code>/', views.cat_view, name='cat_view'),
    
    ### path('hyo01/', hyo01_views.hyo01_view, name='hyo01_view'),
    ### path('hyo02/', hyo02_views.hyo02_view, name='hyo02_view'),
    ### path('hyo03/', hyo03_views.hyo03_view, name='hyo03_view'),
    ### path('hyo04/', hyo04_views.hyo04_view, name='hyo04_view'),
    ### path('hyo05/', hyo05_views.hyo05_view, name='hyo05_view'),
    ### path('hyo06/', hyo06_views.hyo06_view, name='hyo06_view'),
    ### path('hyo07/', hyo07_views.hyo07_view, name='hyo07_view'),
    ### path('hyo08/', hyo08_views.hyo08_view, name='hyo08_view'),
    ### path('hyo09_1/', hyo09_1_views.hyo09_1_view, name='hyo09_1_view'),
    ### path('hyo09_2/', hyo09_2_views.hyo09_2_view, name='hyo09_2_view'),
    ### path('hyo10/', hyo10_views.hyo10_view, name='hyo10_view'),
    ### path('hyo11/', hyo11_views.hyo11_view, name='hyo11_view'),
    ### path('hyo12/', hyo12_views.hyo12_view, name='hyo12_view'),
    ### path('hyo13/', hyo13_views.hyo13_view, name='hyo13_view'),
    ### path('hyo14/', hyo14_views.hyo14_view, name='hyo14_view'),
    ### path('hyo15/', hyo15_views.hyo15_view, name='hyo15_view'),
    ### path('hyo16/', hyo16_views.hyo16_view, name='hyo16_view'),
    ### path('hyo17/', hyo17_views.hyo17_view, name='hyo17_view'),
    ### path('hyo18/', hyo18_views.hyo18_view, name='hyo18_view'),
    ### path('hyo19/', hyo19_views.hyo19_view, name='hyo19_view'),
    ### path('hyo20/', hyo20_views.hyo20_view, name='hyo20_view'),
    ### path('hyo21/', hyo21_views.hyo21_view, name='hyo21_view'),
    ### path('hyo22/', hyo22_views.hyo22_view, name='hyo22_view'),
    ### path('hyo23/', hyo23_views.hyo23_view, name='hyo23_view'),
    ### path('hyo24/', hyo24_views.hyo24_view, name='hyo24_view'),
    ### path('hyo25/', hyo25_views.hyo25_view, name='hyo25_view'),
    ### ### path('hyo26/', hyo26_views.hyo26_view, name='hyo26_view'),
    ### ### path('hyo27/', hyo27_views.hyo27_view, name='hyo27_view'),
    ### ### path('hyo28/', hyo28_views.hyo28_view, name='hyo28_view'),
    ### ### path('hyo29_1/', hyo29_1_views.hyo29_1_view, name='hyo29_1_view'),
    ### ### path('hyo29_2/', hyo29_2_views.hyo29_2_view, name='hyo29_2_view'),
    ### ### path('hyo29_3/', hyo29_3_views.hyo29_3_view, name='hyo29_3_view'),
    ### ### path('hyo30/', hyo30_views.hyo30_view, name='hyo30_view'),
    ### ### path('hyo31_1/', hyo31_1_views.hyo31_1_view, name='hyo31_1_view'),
    ### ### path('hyo31_2/', hyo31_2_views.hyo31_2_view, name='hyo31_2_view'),
    ### ### path('hyo32_1/', hyo32_1_views.hyo32_1_view, name='hyo32_1_view'),
    ### ### path('hyo32_2/', hyo32_2_views.hyo32_2_view, name='hyo32_2_view'),
    ### ### path('hyo33/', hyo33_views.hyo33_view, name='hyo33_view'),
    ### ### path('hyo34_1/', hyo34_1_views.hyo34_1_view, name='hyo34_1_view'),
    ### ### path('hyo34_2/', hyo34_2_views.hyo34_2_view, name='hyo34_2_view'),
    ### ### path('hyo34_3/', hyo34_3_views.hyo34_3_view, name='hyo34_3_view'),
    ### ### path('hyo35/', hyo35_views.hyo35_view, name='hyo35_view'),
    ### ### path('hyo36/', hyo36_views.hyo36_view, name='hyo36_view'),
    ### ### path('hyo37/', hyo37_views.hyo37_view, name='hyo37_view'),
    ### ### path('hyo38/', hyo38_views.hyo38_view, name='hyo38_view'),
    ### ### path('hyo39/', hyo39_views.hyo39_view, name='hyo39_view'),
    ### ### path('hyo40/', hyo40_views.hyo40_view, name='hyo40_view'),
    ### ### path('hyo41/', hyo41_views.hyo41_view, name='hyo41_view'),
    ### ### path('hyo42/', hyo42_views.hyo42_view, name='hyo42_view'),
    ### path('hyo43/', hyo43_views.hyo43_view, name='hyo43_view'),
    ### ### path('hyo44/', hyo44_views.hyo44_view, name='hyo44_view'),
    ### path('hyo45/', hyo45_views.hyo45_view, name='hyo45_view'),
    ### path('hyo46/', hyo46_views.hyo46_view, name='hyo46_view'),
    ### path('hyo47/', hyo47_views.hyo47_view, name='hyo47_view'),
    ### path('hyo48/', hyo48_views.hyo48_view, name='hyo48_view'),
    ### path('hyo49/', hyo49_views.hyo49_view, name='hyo49_view'),
    ### path('hyo50/', hyo50_views.hyo50_view, name='hyo50_view'),
    ### path('hyo51/', hyo51_views.hyo51_view, name='hyo51_view'),

    path('download/hyo01/', hyo01_views.hyo01_download_view, name='hyo01_download_view'), 
    path('download/hyo02/', hyo02_views.hyo02_download_view, name='hyo02_download_view'), 
    path('download/hyo03/', hyo03_views.hyo03_download_view, name='hyo03_download_view'), 
    path('download/hyo04/', hyo04_views.hyo04_download_view, name='hyo04_download_view'), 
    path('download/hyo05/', hyo05_views.hyo05_download_view, name='hyo05_download_view'), 
    path('download/hyo06/', hyo06_views.hyo06_download_view, name='hyo06_download_view'), 
    path('download/hyo07/', hyo07_views.hyo07_download_view, name='hyo07_download_view'), 
    path('download/hyo08/', hyo08_views.hyo08_download_view, name='hyo08_download_view'), 
    path('download/hyo09_1/', hyo09_1_views.hyo09_1_download_view, name='hyo09_1_download_view'), 
    path('download/hyo09_2/', hyo09_2_views.hyo09_2_download_view, name='hyo09_2_download_view'), 
    path('download/hyo10/', hyo10_views.hyo10_download_view, name='hyo10_download_view'), 
    path('download/hyo11/', hyo11_views.hyo11_download_view, name='hyo11_download_view'), 
    path('download/hyo12/', hyo12_views.hyo12_download_view, name='hyo12_download_view'), 
    path('download/hyo13/', hyo13_views.hyo13_download_view, name='hyo13_download_view'), 
    path('download/hyo14/', hyo14_views.hyo14_download_view, name='hyo14_download_view'), 
    path('download/hyo15/', hyo15_views.hyo15_download_view, name='hyo15_download_view'), 
    path('download/hyo16/', hyo16_views.hyo16_download_view, name='hyo16_download_view'), 
    path('download/hyo17/', hyo17_views.hyo17_download_view, name='hyo17_download_view'), 
    path('download/hyo18/', hyo18_views.hyo18_download_view, name='hyo18_download_view'), 
    path('download/hyo19/', hyo19_views.hyo19_download_view, name='hyo19_download_view'), 
    path('download/hyo20/', hyo20_views.hyo20_download_view, name='hyo20_download_view'), 
    path('download/hyo21/', hyo21_views.hyo21_download_view, name='hyo21_download_view'), 
    path('download/hyo22/', hyo22_views.hyo22_download_view, name='hyo22_download_view'), 
    path('download/hyo23/', hyo23_views.hyo23_download_view, name='hyo23_download_view'), 
    path('download/hyo24/', hyo24_views.hyo24_download_view, name='hyo24_download_view'), 
    path('download/hyo25/', hyo25_views.hyo25_download_view, name='hyo25_download_view'), 
    ### path('download/hyo26/', hyo26_views.hyo26_download_view, name='hyo26_download_view'), 
    ### path('download/hyo27/', hyo27_views.hyo27_download_view, name='hyo27_download_view'), 
    ### path('download/hyo28/', hyo28_views.hyo28_download_view, name='hyo28_download_view'), 
    ### path('download/hyo29_1/', hyo29_1_views._hyo29_1_download_view, name='hyo29_1_download_view'), 
    ### path('download/hyo29_2/', hyo29_2_views.hyo29_2_download_view, name='hyo29_2_download_view'), 
    ### path('download/hyo29_3/', hyo29_3_views.hyo29_3_download_view, name='hyo29_3_download_view'), 
    ### path('download/hyo30/', hyo30_views.hyo30_download_view, name='hyo30_download_view'), 
    ### path('download/hyo31_1/', hyo31_1_views.hyo31_1_download_view, name='hyo31_1_download_view'), 
    ### path('download/hyo31_2/', hyo31_2_views.hyo31_2_download_view, name='hyo31_2_download_view'), 
    ### path('download/hyo32_1/', hyo32_1_views.hyo32_1_download_view, name='hyo32_1_download_view'), 
    ### path('download/hyo32_2/', hyo32_2_views.hyo32_2_download_view, name='hyo32_2_download_view'), 
    ### path('download/hyo33/', hyo33_views.hyo33_download_view, name='hyo33_download_view'), 
    ### path('download/hyo34_1/', hyo34_1_views.hyo34_1_download_view, name='hyo34_1_download_view'), 
    ### path('download/hyo34_2/', hyo34_2_views.hyo34_2_download_view, name='hyo34_2_download_view'), 
    ### path('download/hyo34_3/', hyo34_3_views.hyo34_3_download_view, name='hyo34_3_download_view'), 
    ### path('download/hyo35/', hyo35_views.hyo35_download_view, name='hyo35_download_view'), 
    ### path('download/hyo36/', hyo36_views.hyo36_download_view, name='hyo36_download_view'), 
    ### path('download/hyo37/', hyo37_views.hyo37_download_view, name='hyo37_download_view'), 
    ### path('download/hyo38/', hyo38_views.hyo38_download_view, name='hyo38_download_view'), 
    ### path('download/hyo39/', hyo39_views.hyo39_download_view, name='hyo39_download_view'), 
    ### path('download/hyo40/', hyo40_views.hyo40_download_view, name='hyo40_download_view'), 
    ### path('download/hyo41/', hyo41_views.hyo41_download_view, name='hyo41_download_view'), 
    ### path('download/hyo42/', hyo42_views.hyo42_download_view, name='hyo42_download_view'), 
    path('download/hyo43/', hyo43_views.hyo43_download_view, name='hyo43_download_view'), 
    ### path('download/hyo44/', hyo44_views.hyo44_download_view, name='hyo44_download_view'), 
    path('download/hyo45/', hyo45_views.hyo45_download_view, name='hyo45_download_view'), 
    path('download/hyo46/', hyo46_views.hyo46_download_view, name='hyo46_download_view'), 
    path('download/hyo47/', hyo47_views.hyo47_download_view, name='hyo47_download_view'), 
    path('download/hyo48/', hyo48_views.hyo48_download_view, name='hyo48_download_view'), 
    path('download/hyo49/', hyo49_views.hyo49_download_view, name='hyo49_download_view'), 
    path('download/hyo50/', hyo50_views.hyo50_download_view, name='hyo50_download_view'), 
    path('download/hyo51/', hyo51_views.hyo51_download_view, name='hyo51_download_view'), 
]
