###############################################################################
### 帳票名：hyo_20水害原因別一般資産等被害額及び公益事業等被害額.xlsx
### ファイル名：P0700EStat/hyo20_views.py
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO20:
    def __init__(self, cause_code, cause_name, sales_damage, crop_damage, ippan_damage, koeki_damage, sum_total_damage, sales_ratio, crop_ratio, ippan_ratio, koeki_ratio, sum_total_ratio):
        self.cause_code = cause_code
        self.cause_name = cause_name
        self.sales_damage = sales_damage
        self.crop_damage = crop_damage
        self.ippan_damage = ippan_damage
        self.koeki_damage = koeki_damage
        self.sum_total_damage = sum_total_damage
        self.sales_ratio = sales_ratio
        self.crop_ratio = crop_ratio
        self.ippan_ratio = ippan_ratio
        self.koeki_ratio = koeki_ratio
        self.sum_total_ratio = sum_total_ratio

###############################################################################
### 帳票名：hyo_20水害原因別一般資産等被害額及び公益事業等被害額.xlsx
### 関数名：get_hyo20(cause_code)
### 1 水害原因別_被害額_合計
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo20(cause_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo20()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo20()関数 cause_code={}'.format(cause_code), 'DEBUG')
        if cause_code in constants.cause_values:
            pass
        else:
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダに対応が難しいためである。
        cause_keys = ['CAUSE_CODE']
        cause_values = [cause_code]
        params = dict(zip(cause_keys, cause_values))
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo20()関数 STEP 2/3.', 'DEBUG')
        hyo20_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                %(CAUSE_CODE)s AS cause_code, 
                
                CASE WHEN (IPPAN01.sales_damage) IS NULL THEN 0.00 ELSE IPPAN01.sales_damage END, 
                CASE WHEN (IPPAN02.crop_damage) IS NULL THEN 0.00 ELSE IPPAN02.crop_damage END, 
                CASE WHEN (IPPAN03.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN03.ippan_damage END, 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END, 
                
                CASE WHEN (IPPAN01.sales_damage) IS NULL THEN 0.00 ELSE IPPAN01.sales_damage END+ 
                CASE WHEN (IPPAN02.crop_damage) IS NULL THEN 0.00 ELSE IPPAN02.crop_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS sum_total_damage 
                
            FROM 
            
            -- 一般資産被害額
            (SELECT 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND cause_1_code=%(CAUSE_CODE)s 
            ) IPPAN01,  
            
            -- 一般資産被害額_農作物
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END 
                ) AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND cause_1_code=%(CAUSE_CODE)s
            ) IPPAN02, 
            
            -- 一般資産被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND cause_1_code=%(CAUSE_CODE)s 
            ) IPPAN03, 
            
            -- 公益事業等被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND cause_1_code=%(CAUSE_CODE)s 
            ) KOEKI01 
            
            """, params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo20()関数 STEP 3/3.', 'DEBUG')
        return True, hyo20_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_20水害原因別一般資産等被害額及び公益事業等被害額.xlsx
### 関数名：get_hyo20_zencause()
### 2 全水害原因_被害額_合計 下端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo20_zencause():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo20_zencause()関数 STEP 1/3.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo20_zencause()関数 STEP 2/3.', 'DEBUG')
        hyo20_zencause_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 

                CASE WHEN (IPPAN01.sales_damage) IS NULL THEN 0.00 ELSE IPPAN01.sales_damage END, 
                CASE WHEN (IPPAN02.crop_damage) IS NULL THEN 0.00 ELSE IPPAN02.crop_damage END, 
                CASE WHEN (IPPAN03.ippan_damage) IS NULL THEN 0.00 ELSE IPPAN03.ippan_damage END, 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END, 
                
                CASE WHEN (IPPAN01.sales_damage) IS NULL THEN 0.00 ELSE IPPAN01.sales_damage END+ 
                CASE WHEN (IPPAN02.crop_damage) IS NULL THEN 0.00 ELSE IPPAN02.crop_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS sum_total_damage 
                
            FROM 
            
            -- 一般資産被害額
            (SELECT 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN01,  
            
            -- 一般資産被害額_農作物
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END 
                ) AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL
            ) IPPAN02, 
            
            -- 一般資産被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END+ 
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END 
                ) AS ippan_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN03, 
            
            -- 公益事業等被害額
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_damage) IS NULL THEN 0.00 ELSE sales_damage END+
                CASE WHEN (alt_damage) IS NULL THEN 0.00 ELSE alt_damage END+
                CASE WHEN (other_damage) IS NULL THEN 0.00 ELSE other_damage END 
                ) AS koeki_damage
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) KOEKI01 
            
            """, [])

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo20_zencause()関数 STEP 3/3.', 'DEBUG')
        return True, hyo20_zencause_list
    except:
        return False, []

###############################################################################
### 帳票名：hyo_20水害原因別一般資産等被害額及び公益事業等被害額.xlsx
### 関数名：hyo20_view(request, cat_code)
### urlpattern：path('hyo20/', hyo20_views.hyo20_view, name='hyo20_view'),
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo20_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo20_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo20_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo20_view()関数 STEP 1/4.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo20_view()関数 STEP 2/4.', 'DEBUG')
        params = dict(zip(constants.cause_keys, constants.cause_values))

        ### 1 水害原因別_被害額_合計
        bool_return, breach = get_hyo20(params['BREACH'])
        if bool_return == False:
            raise Exception

        bool_return, with_dike = get_hyo20(params['WITH_DIKE'])
        if bool_return == False:
            raise Exception

        bool_return, without_dike = get_hyo20(params['WITHOUT_DIKE'])
        if bool_return == False:
            raise Exception

        bool_return, inland = get_hyo20(params['INLAND'])
        if bool_return == False:
            raise Exception

        bool_return, pit = get_hyo20(params['PIT'])
        if bool_return == False:
            raise Exception

        bool_return, scouring = get_hyo20(params['SCOURING'])
        if bool_return == False:
            raise Exception

        bool_return, debris = get_hyo20(params['DEBRIS'])
        if bool_return == False:
            raise Exception

        bool_return, landslide = get_hyo20(params['LANDSLIDE'])
        if bool_return == False:
            raise Exception

        bool_return, steepslope = get_hyo20(params['STEEPSLOPE'])
        if bool_return == False:
            raise Exception

        bool_return, surge = get_hyo20(params['SURGE'])
        if bool_return == False:
            raise Exception

        bool_return, tsunami = get_hyo20(params['TSUNAMI'])
        if bool_return == False:
            raise Exception

        bool_return, waves = get_hyo20(params['WAVES'])
        if bool_return == False:
            raise Exception

        bool_return, other = get_hyo20(params['OTHER'])
        if bool_return == False:
            raise Exception

        ### 2 全水害原因_被害額_合計 下端
        bool_return, zencause = get_hyo20_zencause()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo20_view()関数 STEP 3/4.', 'DEBUG')
        temp_list = []
        hyo20 = HYO20(
            constants.cause_values[0], '破　　堤', 
            breach[0].sales_damage, breach[0].crop_damage, breach[0].ippan_damage, breach[0].koeki_damage, breach[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)
        
        hyo20 = HYO20(
            constants.cause_values[1], '有堤部溢水', 
            with_dike[0].sales_damage, with_dike[0].crop_damage, with_dike[0].ippan_damage, with_dike[0].koeki_damage, with_dike[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[2], '無堤部溢水', 
            without_dike[0].sales_damage, without_dike[0].crop_damage, without_dike[0].ippan_damage, without_dike[0].koeki_damage, without_dike[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[3], '内　　水', 
            inland[0].sales_damage, inland[0].crop_damage, inland[0].ippan_damage, inland[0].koeki_damage, inland[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[4], '窪地内水', 
            pit[0].sales_damage, pit[0].crop_damage, pit[0].ippan_damage, pit[0].koeki_damage, pit[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[5], '洗掘・流失', 
            scouring[0].sales_damage, scouring[0].crop_damage, scouring[0].ippan_damage, scouring[0].koeki_damage, scouring[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[6], '土 石 流', 
            debris[0].sales_damage, debris[0].crop_damage, debris[0].ippan_damage, debris[0].koeki_damage, debris[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[7], '地すべり', 
            landslide[0].sales_damage, landslide[0].crop_damage, landslide[0].ippan_damage, landslide[0].koeki_damage, landslide[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[8], '急傾斜地崩壊', 
            steepslope[0].sales_damage, steepslope[0].crop_damage, steepslope[0].ippan_damage, steepslope[0].koeki_damage, steepslope[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[9], '高　潮', 
            surge[0].sales_damage, surge[0].crop_damage, surge[0].ippan_damage, surge[0].koeki_damage, surge[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[10], '津　波', 
            tsunami[0].sales_damage, tsunami[0].crop_damage, tsunami[0].ippan_damage, tsunami[0].koeki_damage, tsunami[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[11], '波　浪', 
            waves[0].sales_damage, waves[0].crop_damage, waves[0].ippan_damage, waves[0].koeki_damage, waves[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[12], 'そ の 他', 
            other[0].sales_damage, other[0].crop_damage, other[0].ippan_damage, other[0].koeki_damage, other[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)
        
        zencause_list = []
        hyo20 = HYO20(
            '', '計', 
            zencause[0].sales_damage, zencause[0].crop_damage, zencause[0].ippan_damage, zencause[0].koeki_damage, zencause[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        zencause_list.append(hyo20)
        
        for i, temp in enumerate(temp_list):
            if zencause_list[0].sales_damage == 0:
                temp.sales_ratio = 0.0
            else:
                temp.sales_ratio = temp.sales_damage / zencause_list[0].sales_damage
                
            if zencause_list[0].crop_damage == 0:
                temp.crop_ratio = 0.0
            else:
                temp.crop_ratio = temp.crop_damage / zencause_list[0].crop_damage
                
            if zencause_list[0].ippan_damage == 0:
                temp.ippan_ratio = 0.0
            else:
                temp.ippan_ratio = temp.ippan_damage / zencause_list[0].ippan_damage
                
            if zencause_list[0].koeki_damage == 0:
                temp.koeki_ratio = 0.0
            else:
                temp.koeki_ratio = temp.koeki_damage / zencause_list[0].koeki_damage
                
            if zencause_list[0].sum_total_damage == 0:
                temp.sum_total_ratio = 0.0
            else:
                temp.sum_total_ratio = temp.sum_total_damage / zencause_list[0].sum_total_damage

        #######################################################################
        ### レスポンスセット処理(0030)
        ### コンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo20_view()関数 STEP 4/4.', 'DEBUG')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'cat_code': 'hyo20', 
            'temp_list': temp_list, 
            'zencause_list': zencause_list, 
        }
        print_log('[INFO] P0700EStat.hyo20_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0700EStat.hyo20_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo20_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo20_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_20水害原因別一般資産等被害額及び公益事業等被害額.xlsx
### 関数名：hyo20_download_view(request)
### urlpattern：path('download/hyo20/', hyo20_views.hyo20_download_view, name='hyo20_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo20_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo20_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo20_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo20_download_view()関数 STEP 1/5.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo20_download_view()関数 STEP 2/5.', 'DEBUG')
        params = dict(zip(constants.cause_keys, constants.cause_values))

        ### 1 水害原因別_被害額_合計
        bool_return, breach = get_hyo20(params['BREACH'])
        if bool_return == False:
            raise Exception

        bool_return, with_dike = get_hyo20(params['WITH_DIKE'])
        if bool_return == False:
            raise Exception

        bool_return, without_dike = get_hyo20(params['WITHOUT_DIKE'])
        if bool_return == False:
            raise Exception

        bool_return, inland = get_hyo20(params['INLAND'])
        if bool_return == False:
            raise Exception

        bool_return, pit = get_hyo20(params['PIT'])
        if bool_return == False:
            raise Exception

        bool_return, scouring = get_hyo20(params['SCOURING'])
        if bool_return == False:
            raise Exception

        bool_return, debris = get_hyo20(params['DEBRIS'])
        if bool_return == False:
            raise Exception

        bool_return, landslide = get_hyo20(params['LANDSLIDE'])
        if bool_return == False:
            raise Exception

        bool_return, steepslope = get_hyo20(params['STEEPSLOPE'])
        if bool_return == False:
            raise Exception

        bool_return, surge = get_hyo20(params['SURGE'])
        if bool_return == False:
            raise Exception

        bool_return, tsunami = get_hyo20(params['TSUNAMI'])
        if bool_return == False:
            raise Exception

        bool_return, waves = get_hyo20(params['WAVES'])
        if bool_return == False:
            raise Exception

        bool_return, other = get_hyo20(params['OTHER'])
        if bool_return == False:
            raise Exception

        ### 2 全水害原因_被害額_合計 下端
        bool_return, zencause = get_hyo20_zencause()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo20_download_view()関数 STEP 3/5.', 'DEBUG')
        temp_list = []
        hyo20 = HYO20(
            constants.cause_values[0], '破　　堤', 
            breach[0].sales_damage, breach[0].crop_damage, breach[0].ippan_damage, breach[0].koeki_damage, breach[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)
        
        hyo20 = HYO20(
            constants.cause_values[1], '有堤部溢水', 
            with_dike[0].sales_damage, with_dike[0].crop_damage, with_dike[0].ippan_damage, with_dike[0].koeki_damage, with_dike[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[2], '無堤部溢水', 
            without_dike[0].sales_damage, without_dike[0].crop_damage, without_dike[0].ippan_damage, without_dike[0].koeki_damage, without_dike[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[3], '内　　水', 
            inland[0].sales_damage, inland[0].crop_damage, inland[0].ippan_damage, inland[0].koeki_damage, inland[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[4], '窪地内水', 
            pit[0].sales_damage, pit[0].crop_damage, pit[0].ippan_damage, pit[0].koeki_damage, pit[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[5], '洗掘・流失', 
            scouring[0].sales_damage, scouring[0].crop_damage, scouring[0].ippan_damage, scouring[0].koeki_damage, scouring[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[6], '土 石 流', 
            debris[0].sales_damage, debris[0].crop_damage, debris[0].ippan_damage, debris[0].koeki_damage, debris[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[7], '地すべり', 
            landslide[0].sales_damage, landslide[0].crop_damage, landslide[0].ippan_damage, landslide[0].koeki_damage, landslide[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[8], '急傾斜地崩壊', 
            steepslope[0].sales_damage, steepslope[0].crop_damage, steepslope[0].ippan_damage, steepslope[0].koeki_damage, steepslope[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[9], '高　潮', 
            surge[0].sales_damage, surge[0].crop_damage, surge[0].ippan_damage, surge[0].koeki_damage, surge[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[10], '津　波', 
            tsunami[0].sales_damage, tsunami[0].crop_damage, tsunami[0].ippan_damage, tsunami[0].koeki_damage, tsunami[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[11], '波　浪', 
            waves[0].sales_damage, waves[0].crop_damage, waves[0].ippan_damage, waves[0].koeki_damage, waves[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)

        hyo20 = HYO20(
            constants.cause_values[12], 'そ の 他', 
            other[0].sales_damage, other[0].crop_damage, other[0].ippan_damage, other[0].koeki_damage, other[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        temp_list.append(hyo20)
        
        zencause_list = []
        hyo20 = HYO20(
            '', '計', 
            zencause[0].sales_damage, zencause[0].crop_damage, zencause[0].ippan_damage, zencause[0].koeki_damage, zencause[0].sum_total_damage, 
            0.0, 0.0, 0.0, 0.0, 0.0)
        zencause_list.append(hyo20)
        
        for i, temp in enumerate(temp_list):
            if zencause_list[0].sales_damage == 0:
                temp.sales_ratio = 0.0
            else:
                temp.sales_ratio = temp.sales_damage / zencause_list[0].sales_damage
                
            if zencause_list[0].crop_damage == 0:
                temp.crop_ratio = 0.0
            else:
                temp.crop_ratio = temp.crop_damage / zencause_list[0].crop_damage
                
            if zencause_list[0].ippan_damage == 0:
                temp.ippan_ratio = 0.0
            else:
                temp.ippan_ratio = temp.ippan_damage / zencause_list[0].ippan_damage
                
            if zencause_list[0].koeki_damage == 0:
                temp.koeki_ratio = 0.0
            else:
                temp.koeki_ratio = temp.koeki_damage / zencause_list[0].koeki_damage
                
            if zencause_list[0].sum_total_damage == 0:
                temp.sum_total_ratio = 0.0
            else:
                temp.sum_total_ratio = temp.sum_total_damage / zencause_list[0].sum_total_damage
        
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo20_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo20.xlsx'
        ### download_file_path = 'static/download_hyo20.xlsx'
        template_file_path = 'static/template/template_hyo20.xlsx'
        download_file_path = 'static/tmp/download_hyo20.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo20'
        
        ws.cell(row=1, column=1).value = '７．水害原因別被害'
        ws.cell(row=4, column=1).value = '表－２０　水害原因別一般資産等被害額及び公益事業等被害額'
        ws.cell(row=6, column=10).value = '（単位：百万円,％）'
        ws.cell(row=7, column=2).value = '一　般　資　産　等'
        ws.cell(row=8, column=1).value = '原　因'
        ws.cell(row=8, column=2).value = '一般資産・'
        ws.cell(row=8, column=4).value = '農　作　物'
        ws.cell(row=8, column=6).value = '計'
        ws.cell(row=8, column=8).value = '公益事業等'
        ws.cell(row=8, column=10).value = '合　　計'
        ws.cell(row=9, column=2).value = '営業停止損失額'
        ws.cell(row=10, column=2).value = '被害額'
        ws.cell(row=10, column=3).value = '構成比'
        ws.cell(row=10, column=4).value = '被害額'
        ws.cell(row=10, column=5).value = '構成比'
        ws.cell(row=10, column=6).value = '被害額'
        ws.cell(row=10, column=7).value = '構成比'
        ws.cell(row=10, column=8).value = '被害額'
        ws.cell(row=10, column=9).value = '構成比'
        ws.cell(row=10, column=10).value = '被害額'
        ws.cell(row=10, column=11).value = '構成比'
        
        row_index = 10
        for i, temp in enumerate(temp_list):
            row_index += 1
            print('temp.cause_code={}'.format(temp.cause_code), flush=True)
            print('temp.cause_name={}'.format(temp.cause_name), flush=True)
            print('temp.sales_damage={}'.format(temp.sales_damage), flush=True)
            print('temp.crop_damage={}'.format(temp.crop_damage), flush=True)
            print('temp.ippan_damage={}'.format(temp.ippan_damage), flush=True)
            print('temp.koeki_damage={}'.format(temp.koeki_damage), flush=True)
            print('temp.sum_total_damage={}'.format(temp.sum_total_damage), flush=True)
            print('temp.sales_ratio={}'.format(temp.sales_ratio), flush=True)
            print('temp.crop_ratio={}'.format(temp.crop_ratio), flush=True)
            print('temp.ippan_ratio={}'.format(temp.ippan_ratio), flush=True)
            print('temp.koeki_ratio={}'.format(temp.koeki_ratio), flush=True)
            print('temp.sum_total_ratio={}'.format(temp.sum_total_ratio), flush=True)
            ws.cell(row=row_index, column=1).value = temp.cause_name
            ws.cell(row=row_index, column=2).value = temp.sales_damage
            ws.cell(row=row_index, column=3).value = temp.sales_ratio
            ws.cell(row=row_index, column=4).value = temp.crop_damage
            ws.cell(row=row_index, column=5).value = temp.crop_ratio
            ws.cell(row=row_index, column=6).value = temp.ippan_damage
            ws.cell(row=row_index, column=7).value = temp.ippan_ratio
            ws.cell(row=row_index, column=8).value = temp.koeki_damage
            ws.cell(row=row_index, column=9).value = temp.koeki_ratio
            ws.cell(row=row_index, column=10).value = temp.sum_total_damage
            ws.cell(row=row_index, column=11).value = temp.sum_total_ratio

        for i, zencause in enumerate(zencause_list):
            row_index += 1
            print('zencause.cause_code={}'.format(zencause.cause_code), flush=True)
            print('zencause.cause_name={}'.format(zencause.cause_name), flush=True)
            print('zencause.sales_damage={}'.format(zencause.sales_damage), flush=True)
            print('zencause.crop_damage={}'.format(zencause.crop_damage), flush=True)
            print('zencause.ippan_damage={}'.format(zencause.ippan_damage), flush=True)
            print('zencause.koeki_damage={}'.format(zencause.koeki_damage), flush=True)
            print('zencause.sum_total_damage={}'.format(zencause.sum_total_damage), flush=True)
            print('zencause.sales_ratio={}'.format(zencause.sales_ratio), flush=True)
            print('zencause.crop_ratio={}'.format(zencause.crop_ratio), flush=True)
            print('zencause.ippan_ratio={}'.format(zencause.ippan_ratio), flush=True)
            print('zencause.koeki_ratio={}'.format(zencause.koeki_ratio), flush=True)
            print('zencause.sum_total_ratio={}'.format(zencause.sum_total_ratio), flush=True)
            ws.cell(row=row_index, column=1).value = zencause.cause_name
            ws.cell(row=row_index, column=2).value = zencause.sales_damage
            ws.cell(row=row_index, column=3).value = zencause.sales_ratio
            ws.cell(row=row_index, column=4).value = zencause.crop_damage
            ws.cell(row=row_index, column=5).value = zencause.crop_ratio
            ws.cell(row=row_index, column=6).value = zencause.ippan_damage
            ws.cell(row=row_index, column=7).value = zencause.ippan_ratio
            ws.cell(row=row_index, column=8).value = zencause.koeki_damage
            ws.cell(row=row_index, column=9).value = zencause.koeki_ratio
            ws.cell(row=row_index, column=10).value = zencause.sum_total_damage
            ws.cell(row=row_index, column=11).value = zencause.sum_total_ratio
        
        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo20_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo20_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo20.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo20_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo20_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo20_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
