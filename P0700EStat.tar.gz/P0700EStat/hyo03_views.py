###############################################################################
### 帳票名：hyo_03市町村別水害被害.xlsx
### ファイル名：P0700EStat/hyo03_views.py
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO03:
    def __init__(self, ):
        self.city_code = city_code
        self.city_name = city_name
        self.ken_code = ken_code
        self.ken_name = ken_name
        
        self.residential_underground_area = residential_underground_area
        self.agricultural_area = agricultural_area
        self.residential_underground_agricultural_area = residential_underground_agricultural_area
        
        self.building_lv00 = building_lv00
        self.building_lv01_49 = building_lv01_49
        self.building_lv50_99 = building_lv50_99
        self.building_lv100 = building_lv100
        self.building_lv01_50_100 = building_lv01_50_100
        self.building_half = building_half
        self.building_full = building_full
        self.building_lv00_01_50_100_half_full = building_lv00_01_50_100_half_full
        
        self.family_lv00 = family_lv00
        self.family_lv01_50_100 = family_lv01_50_100
        self.family_half_full = family_half_full
        
        self.office_lv00_01_50_100_half_full = office_lv00_01_50_100_half_full
        self.employee_lv00_01_50_100_full = employee_lv00_01_50_100_full
        self.farmer_fisher_lv00_01_50_100_full = farmer_fisher_lv00_01_50_100_full
        
        self.ippan_asset_sales_damage = ippan_asset_sales_damage ### 
        self.crop_damage = crop_damage
        self.ippan_damage = ippan_damage ### 
        
        self.kokyo_damage = kokyo_damage ### 
        self.koeki_damage = koeki_damage
        self.ippan_chitan_hojo_koeki_damage = ippan_chitan_hojo_koeki_damage ### 

###############################################################################
### 帳票名：hyo_03市町村別水害被害.xlsx
### 関数名：get_hyo03(ken_code)
### 1 市区町村別_被害額_合計
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo03(ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo03()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo03()関数 ken_code={}'.format(ken_code), 'DEBUG')
        if ken_code in constants.ken_values:
            pass
        else:
            print_log('[WARN] P0700EStat.get_hyo03()関数が警告終了しました。', 'INFO')
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(ken_keys, ken_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo03()関数 STEP 2/3.', 'DEBUG')
        hyo03_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CITY1.city_code, 
                CITY1.city_name, 
                CITY1.ken_code, 
                CITY1.ken_name, 
                
                CASE WHEN (IPPAN01.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN01.residential_underground_area END, 
                CASE WHEN (IPPAN02.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN02.agricultural_area END, 
                CASE WHEN (IPPAN03.residential_underground_agricultural_area) IS NULL THEN 0.00 ELSE IPPAN03.residential_underground_agricultural_area END, 
                
                CASE WHEN (IPPAN04.building_lv00) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00 END, 
                CASE WHEN (IPPAN04.building_lv01_49) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_49 END, 
                CASE WHEN (IPPAN04.building_lv50_99) IS NULL THEN 0.00 ELSE IPPAN04.building_lv50_99 END, 
                CASE WHEN (IPPAN04.building_lv100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv100 END, 
                CASE WHEN (IPPAN04.building_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_50_100 END, 
                CASE WHEN (IPPAN04.building_half) IS NULL THEN 0.00 ELSE IPPAN04.building_half END, 
                CASE WHEN (IPPAN04.building_full) IS NULL THEN 0.00 ELSE IPPAN04.building_full END, 
                CASE WHEN (IPPAN04.building_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00_01_50_100_half_full END, 
                
                CASE WHEN (IPPAN05.family_lv00) IS NULL THEN 0.00 ELSE IPPAN05.family_lv00 END, 
                CASE WHEN (IPPAN05.family_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN05.family_lv01_50_100 END, 
                CASE WHEN (IPPAN05.family_half_full) IS NULL THEN 0.00 ELSE IPPAN05.family_half_full END, 
                
                CASE WHEN (IPPAN06.office_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN06.office_lv00_01_50_100_half_full END, 
                CASE WHEN (IPPAN07.employee_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN07.employee_lv00_01_50_100_full END, 
                CASE WHEN (IPPAN08.farmer_fisher_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN08.farmer_fisher_lv00_01_50_100_full END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END, 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END+ 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END 
                AS ippan_damage, 
                
                CASE WHEN (CHITAN01.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN01.estimated_damage END+ 
                CASE WHEN (HOJO01.determined_damage) IS NULL THEN 0.00 ELSE HOJO01.determined_damage END 
                AS kokyo_damage, 
                
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END+ 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END+ 
                CASE WHEN (CHITAN01.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN01.estimated_damage END+ 
                CASE WHEN (HOJO01.determined_damage) IS NULL THEN 0.00 ELSE HOJO01.determined_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS ippan_chitan_hojo_koeki_damage 
                
            FROM 
            
            -- 市区町村
            (SELECT 
                CT1.city_code, 
                CT1.city_name, 
                CT1.ken_code, 
                KE1.ken_name 
            FROM CITY CT1 
            LEFT JOIN KEN KE1 ON CT1.ken_code=KE1.ken_code 
            WHERE CT1.ken_code=%(KEN_CODE)s 
            ORDER BY CT1.ken_code, CT1.city_code 
            ) CITY1 
            
            -- 水害区域面積_宅地・その他
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+ 
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END) 
                AS residential_underground_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) IPPAN01 
            ON CITY1.city_code=IPPAN01.city_code 

            -- 水害区域面積_農地
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) IPPAN02 
            ON CITY1.city_code=IPPAN02.city_code 

            -- 水害区域面積_合計
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+ 
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END+ 
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS residential_underground_agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) IPPAN03 
            ON CITY1.city_code=IPPAN03.city_code 
            
            -- 被災家屋棟数
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END) 
                AS building_lv00, 
                
                SUM(
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END) 
                AS building_lv01_49, 
                
                SUM(
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END) 
                AS building_lv50_99, 
                
                SUM(
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END) 
                AS building_lv100, 
                
                SUM(
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END) 
                AS building_lv01_50_100, 
                
                SUM(
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END) 
                AS building_half, 
                
                SUM(
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_full, 
                
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END+ 
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END+ 
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END+ 
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) IPPAN04 
            ON CITY1.city_code=IPPAN04.city_code 

            -- 被災世帯数
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END) 
                AS family_lv00, 
                
                SUM(
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+ 
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+ 
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END) 
                AS family_lv01_50_100, 
                
                SUM(
                CASE WHEN (family_half) IS NULL THEN 0.00 ELSE family_half END+ 
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) IPPAN05 
            ON CITY1.city_code=IPPAN05.city_code 

            -- 被災事業所数
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (office_lv00) IS NULL THEN 0.00 ELSE office_lv00 END+ 
                CASE WHEN (office_lv01_49) IS NULL THEN 0.00 ELSE office_lv01_49 END+ 
                CASE WHEN (office_lv50_99) IS NULL THEN 0.00 ELSE office_lv50_99 END+ 
                CASE WHEN (office_lv100) IS NULL THEN 0.00 ELSE office_lv100 END+ 
                CASE WHEN (office_half) IS NULL THEN 0.00 ELSE office_half END+ 
                CASE WHEN (office_full) IS NULL THEN 0.00 ELSE office_full END) 
                AS office_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) IPPAN06 
            ON CITY1.city_code=IPPAN06.city_code 

            -- 被災事業所従業者数
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (employee_lv00) IS NULL THEN 0.00 ELSE employee_lv00 END+ 
                CASE WHEN (employee_lv01_49) IS NULL THEN 0.00 ELSE employee_lv01_49 END+ 
                CASE WHEN (employee_lv50_99) IS NULL THEN 0.00 ELSE employee_lv50_99 END+ 
                CASE WHEN (employee_lv100) IS NULL THEN 0.00 ELSE employee_lv100 END+ 
                CASE WHEN (employee_full) IS NULL THEN 0.00 ELSE employee_full END) 
                AS employee_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) IPPAN07 
            ON CITY1.city_code=IPPAN07.city_code 

            -- 被災農漁家数
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (farmer_fisher_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_lv00 END+ 
                CASE WHEN (farmer_fisher_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_lv01_49 END+ 
                CASE WHEN (farmer_fisher_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_lv50_99 END+ 
                CASE WHEN (farmer_fisher_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_lv100 END+ 
                CASE WHEN (farmer_fisher_full) IS NULL THEN 0.00 ELSE farmer_fisher_full END) 
                AS farmer_fisher_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) IPPAN08 
            ON CITY1.city_code=IPPAN08.city_code 
            
            -- 一般資産_営業停止損失
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END) 
                AS ippan_asset_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) IPPAN09 
            ON CITY1.city_code=IPPAN09.city_code 
            
            -- 一般資産_農作物被害額
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END) 
                AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) IPPAN10 
            ON CITY1.city_code=IPPAN10.city_code 
            
            -- 地方単独事業被害額_合計
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code
            ) CHITAN01 
            ON CITY1.city_code=CHITAN01.city_code 
            
            -- 補助事業被害額_合計
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code 
            ) HOJO01 
            ON CITY1.city_code=HOJO01.city_code 

            -- 公益事業被害額_合計
            LEFT JOIN 
            (SELECT 
                city_code, 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            GROUP BY city_code
            ) KOEKI01 
            ON CITY1.city_code=KOEKI01.city_code 
            
            """, params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo03()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo03()関数が正常終了しました。', 'INFO')
        return True, hyo03_list
    
    except:
        print_log('[ERROR] P0700EStat.get_hyo03()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo03()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo03()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_03市町村別水害被害.xlsx
### 関数名：get_hyo03_ken(ken_code)
### 2 都道府県別_被害額_合計 中間下端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
### TODO TO-DO TO_DO ken_codeを関数の引数にしても良いのでは？他の帳票では引数にしている？46で件数も多くない。
###############################################################################
def get_hyo03_ken(ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo03_ken()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo03_ken()関数 ken_code={}'.format(ken_code), 'DEBUG')
        if ken_code in constants.ken_values:
            pass
        else:
            print_log('[WARN] P0700EStat.get_hyo03_ken()関数が警告終了しました。', 'INFO')
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(ken_keys, ken_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo03_ken()関数 STEP 2/3.', 'DEBUG')
        hyo03_ken_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                KEN1.ken_code, 
                KEN1.ken_name, 
                
                CASE WHEN (IPPAN01.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN01.residential_underground_area END, 
                CASE WHEN (IPPAN02.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN02.agricultural_area END, 
                CASE WHEN (IPPAN03.residential_underground_agricultural_area) IS NULL THEN 0.00 ELSE IPPAN03.residential_underground_agricultural_area END, 
                
                CASE WHEN (IPPAN04.building_lv00) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00 END, 
                CASE WHEN (IPPAN04.building_lv01_49) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_49 END, 
                CASE WHEN (IPPAN04.building_lv50_99) IS NULL THEN 0.00 ELSE IPPAN04.building_lv50_99 END, 
                CASE WHEN (IPPAN04.building_lv100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv100 END, 
                CASE WHEN (IPPAN04.building_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_50_100 END, 
                CASE WHEN (IPPAN04.building_half) IS NULL THEN 0.00 ELSE IPPAN04.building_half END, 
                CASE WHEN (IPPAN04.building_full) IS NULL THEN 0.00 ELSE IPPAN04.building_full END, 
                CASE WHEN (IPPAN04.building_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00_01_50_100_half_full END, 
                
                CASE WHEN (IPPAN05.family_lv00) IS NULL THEN 0.00 ELSE IPPAN05.family_lv00 END, 
                CASE WHEN (IPPAN05.family_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN05.family_lv01_50_100 END, 
                CASE WHEN (IPPAN05.family_half_full) IS NULL THEN 0.00 ELSE IPPAN05.family_half_full END, 
                
                CASE WHEN (IPPAN06.office_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN06.office_lv00_01_50_100_half_full END, 
                CASE WHEN (IPPAN07.employee_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN07.employee_lv00_01_50_100_full END, 
                CASE WHEN (IPPAN08.farmer_fisher_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN08.farmer_fisher_lv00_01_50_100_full END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END, 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END+ 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END 
                AS ippan_damage, 
                
                CASE WHEN (CHITAN01.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN01.estimated_damage END+ 
                CASE WHEN (HOJO01.determined_damage) IS NULL THEN 0.00 ELSE HOJO01.determined_damage END 
                AS kokyo_damage, 
                
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END+ 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END+ 
                CASE WHEN (CHITAN01.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN01.estimated_damage END+ 
                CASE WHEN (HOJO01.determined_damage) IS NULL THEN 0.00 ELSE HOJO01.determined_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS ippan_chitan_hojo_koeki_damage 
                
            FROM 
            
            -- 都道府県
            (SELECT 
                ken_code, 
                ken_name 
            FROM KEN 
            WHERE ken_code=%(KEN_CODE)s 
            ) KEN1, 

            -- 水害区域面積_宅地・その他
            (SELECT 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END) 
                AS residential_underground_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN01, 

            -- 水害区域面積_農地
            (SELECT 
                SUM(
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN02, 

            -- 水害区域面積_合計
            (SELECT 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+ 
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END+
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS residential_underground_agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN03, 
            
            -- 被災家屋棟数
            (SELECT 
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END) 
                AS building_lv00, 
                
                SUM(
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END) 
                AS building_lv01_49, 
                
                SUM(
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END) 
                AS building_lv50_99, 
                
                SUM(
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END) 
                AS building_lv100, 
                
                SUM(
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END) 
                AS building_lv01_50_100, 
                
                SUM(
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END) 
                AS building_half, 
                
                SUM(
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_full, 
                
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END+ 
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END+ 
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END+ 
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN04, 

            -- 被災世帯数
            (SELECT 
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END) 
                AS family_lv00, 
                
                SUM(
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+ 
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+ 
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END) 
                AS family_lv01_50_100, 
                
                SUM(
                CASE WHEN (family_half) IS NULL THEN 0.00 ELSE family_half END+ 
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN05, 

            -- 被災事業所数
            (SELECT 
                SUM(
                CASE WHEN (office_lv00) IS NULL THEN 0.00 ELSE office_lv00 END+ 
                CASE WHEN (office_lv01_49) IS NULL THEN 0.00 ELSE office_lv01_49 END+ 
                CASE WHEN (office_lv50_99) IS NULL THEN 0.00 ELSE office_lv50_99 END+ 
                CASE WHEN (office_lv100) IS NULL THEN 0.00 ELSE office_lv100 END+ 
                CASE WHEN (office_half) IS NULL THEN 0.00 ELSE office_half END+ 
                CASE WHEN (office_full) IS NULL THEN 0.00 ELSE office_full END) 
                AS office_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN06, 

            -- 被災事業所従業者数
            (SELECT 
                SUM(
                CASE WHEN (employee_lv00) IS NULL THEN 0.00 ELSE employee_lv00 END+ 
                CASE WHEN (employee_lv01_49) IS NULL THEN 0.00 ELSE employee_lv01_49 END+ 
                CASE WHEN (employee_lv50_99) IS NULL THEN 0.00 ELSE employee_lv50_99 END+ 
                CASE WHEN (employee_lv100) IS NULL THEN 0.00 ELSE employee_lv100 END+ 
                CASE WHEN (employee_full) IS NULL THEN 0.00 ELSE employee_full END) 
                AS employee_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN07, 

            -- 被災農漁家数
            (SELECT 
                SUM(
                CASE WHEN (farmer_fisher_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_lv00 END+ 
                CASE WHEN (farmer_fisher_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_lv01_49 END+ 
                CASE WHEN (farmer_fisher_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_lv50_99 END+ 
                CASE WHEN (farmer_fisher_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_lv100 END+ 
                CASE WHEN (farmer_fisher_full) IS NULL THEN 0.00 ELSE farmer_fisher_full END) 
                AS farmer_fisher_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN08, 
           
            -- 一般資産_営業停止損失
            (SELECT 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END) 
                AS ippan_asset_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN09, 
            
            -- 一般資産_農作物被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END) 
                AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) IPPAN10, 

            -- 地方単独事業被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) CHITAN01, 

            -- 補助事業被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) HOJO01, 

            -- 公益事業被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND ken_code=%(KEN_CODE)s 
            ) KOEKI01 
            
            """, params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo03_ken()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo03_ken()関数が正常終了しました。', 'INFO')
        return True, hyo03_ken_list
    
    except:
        print_log('[ERROR] P0700EStat.get_hyo03_ken()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo03_ken()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo03_ken()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_03市町村別水害被害.xlsx
### 関数名：get_hyo03_zenkoku()
### 3 全国_被害額_合計 最下端
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo03_zenkoku():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo03_zenkoku()関数 STEP 1/3.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo03_zenkoku()関数 STEP 2/3.', 'DEBUG')
        hyo03_zenkoku_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (IPPAN01.residential_underground_area) IS NULL THEN 0.00 ELSE IPPAN01.residential_underground_area END, 
                CASE WHEN (IPPAN02.agricultural_area) IS NULL THEN 0.00 ELSE IPPAN02.agricultural_area END, 
                CASE WHEN (IPPAN03.residential_underground_agricultural_area) IS NULL THEN 0.00 ELSE IPPAN03.residential_underground_agricultural_area END, 
                
                CASE WHEN (IPPAN04.building_lv00) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00 END, 
                CASE WHEN (IPPAN04.building_lv01_49) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_49 END, 
                CASE WHEN (IPPAN04.building_lv50_99) IS NULL THEN 0.00 ELSE IPPAN04.building_lv50_99 END, 
                CASE WHEN (IPPAN04.building_lv100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv100 END, 
                CASE WHEN (IPPAN04.building_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN04.building_lv01_50_100 END, 
                CASE WHEN (IPPAN04.building_half) IS NULL THEN 0.00 ELSE IPPAN04.building_half END, 
                CASE WHEN (IPPAN04.building_full) IS NULL THEN 0.00 ELSE IPPAN04.building_full END, 
                CASE WHEN (IPPAN04.building_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN04.building_lv00_01_50_100_half_full END, 
                
                CASE WHEN (IPPAN05.family_lv00) IS NULL THEN 0.00 ELSE IPPAN05.family_lv00 END, 
                CASE WHEN (IPPAN05.family_lv01_50_100) IS NULL THEN 0.00 ELSE IPPAN05.family_lv01_50_100 END, 
                CASE WHEN (IPPAN05.family_half_full) IS NULL THEN 0.00 ELSE IPPAN05.family_half_full END, 
                
                CASE WHEN (IPPAN06.office_lv00_01_50_100_half_full) IS NULL THEN 0.00 ELSE IPPAN06.office_lv00_01_50_100_half_full END, 
                CASE WHEN (IPPAN07.employee_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN07.employee_lv00_01_50_100_full END, 
                CASE WHEN (IPPAN08.farmer_fisher_lv00_01_50_100_full) IS NULL THEN 0.00 ELSE IPPAN08.farmer_fisher_lv00_01_50_100_full END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END, 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END+ 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END 
                AS ippan_damage, 
                
                CASE WHEN (CHITAN01.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN01.estimated_damage END+ 
                CASE WHEN (HOJO01.determined_damage) IS NULL THEN 0.00 ELSE HOJO01.determined_damage END 
                AS kokyo_damage, 
                
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END, 
                
                CASE WHEN (IPPAN09.ippan_asset_sales_damage) IS NULL THEN 0.00 ELSE IPPAN09.ippan_asset_sales_damage END+ 
                CASE WHEN (IPPAN10.crop_damage) IS NULL THEN 0.00 ELSE IPPAN10.crop_damage END+ 
                CASE WHEN (CHITAN01.estimated_damage) IS NULL THEN 0.00 ELSE CHITAN01.estimated_damage END+ 
                CASE WHEN (HOJO01.determined_damage) IS NULL THEN 0.00 ELSE HOJO01.determined_damage END+ 
                CASE WHEN (KOEKI01.koeki_damage) IS NULL THEN 0.00 ELSE KOEKI01.koeki_damage END 
                AS ippan_chitan_hojo_koeki_damage 
                
            FROM 
            
            -- 水害区域面積_宅地・その他
            (SELECT 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END) 
                AS residential_underground_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN01, 

            -- 水害区域面積_農地
            (SELECT 
                SUM(
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN02, 

            -- 水害区域面積_合計
            (SELECT 
                SUM(
                CASE WHEN (residential_area) IS NULL THEN 0.00 ELSE residential_area END+
                CASE WHEN (underground_area) IS NULL THEN 0.00 ELSE underground_area END+
                CASE WHEN (agricultural_area) IS NULL THEN 0.00 ELSE agricultural_area END) 
                AS residential_underground_agricultural_area 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN03, 
            
            -- 被災家屋棟数
            (SELECT 
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END) 
                AS building_lv00, 
                
                SUM(
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END) 
                AS building_lv01_49, 
                
                SUM(
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END) 
                AS building_lv50_99, 
                
                SUM(
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END) 
                AS building_lv100, 
                
                SUM(
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END) 
                AS building_lv01_50_100, 
                
                SUM(
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END) 
                AS building_half, 
                
                SUM(
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_full, 
                
                SUM(
                CASE WHEN (building_lv00) IS NULL THEN 0.00 ELSE building_lv00 END+ 
                CASE WHEN (building_lv01_49) IS NULL THEN 0.00 ELSE building_lv01_49 END+ 
                CASE WHEN (building_lv50_99) IS NULL THEN 0.00 ELSE building_lv50_99 END+ 
                CASE WHEN (building_lv100) IS NULL THEN 0.00 ELSE building_lv100 END+ 
                CASE WHEN (building_half) IS NULL THEN 0.00 ELSE building_half END+ 
                CASE WHEN (building_full) IS NULL THEN 0.00 ELSE building_full END) 
                AS building_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN04, 

            -- 被災世帯数
            (SELECT 
                SUM(
                CASE WHEN (family_lv00) IS NULL THEN 0.00 ELSE family_lv00 END) 
                AS family_lv00, 
                
                SUM(
                CASE WHEN (family_lv01_49) IS NULL THEN 0.00 ELSE family_lv01_49 END+ 
                CASE WHEN (family_lv50_99) IS NULL THEN 0.00 ELSE family_lv50_99 END+ 
                CASE WHEN (family_lv100) IS NULL THEN 0.00 ELSE family_lv100 END) 
                AS family_lv01_50_100, 
                
                SUM(
                CASE WHEN (family_half) IS NULL THEN 0.00 ELSE family_half END+ 
                CASE WHEN (family_full) IS NULL THEN 0.00 ELSE family_full END) 
                AS family_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN05, 

            -- 被災事業所数
            (SELECT 
                SUM(
                CASE WHEN (office_lv00) IS NULL THEN 0.00 ELSE office_lv00 END+ 
                CASE WHEN (office_lv01_49) IS NULL THEN 0.00 ELSE office_lv01_49 END+ 
                CASE WHEN (office_lv50_99) IS NULL THEN 0.00 ELSE office_lv50_99 END+ 
                CASE WHEN (office_lv100) IS NULL THEN 0.00 ELSE office_lv100 END+ 
                CASE WHEN (office_half) IS NULL THEN 0.00 ELSE office_half END+ 
                CASE WHEN (office_full) IS NULL THEN 0.00 ELSE office_full END) 
                AS office_lv00_01_50_100_half_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN06, 

            -- 被災事業所従業者数
            (SELECT 
                SUM(
                CASE WHEN (employee_lv00) IS NULL THEN 0.00 ELSE employee_lv00 END+ 
                CASE WHEN (employee_lv01_49) IS NULL THEN 0.00 ELSE employee_lv01_49 END+ 
                CASE WHEN (employee_lv50_99) IS NULL THEN 0.00 ELSE employee_lv50_99 END+ 
                CASE WHEN (employee_lv100) IS NULL THEN 0.00 ELSE employee_lv100 END+ 
                CASE WHEN (employee_full) IS NULL THEN 0.00 ELSE employee_full END) 
                AS employee_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN07, 

            -- 被災農漁家数
            (SELECT 
                SUM(
                CASE WHEN (farmer_fisher_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_lv00 END+ 
                CASE WHEN (farmer_fisher_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_lv01_49 END+ 
                CASE WHEN (farmer_fisher_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_lv50_99 END+ 
                CASE WHEN (farmer_fisher_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_lv100 END+ 
                CASE WHEN (farmer_fisher_full) IS NULL THEN 0.00 ELSE farmer_fisher_full END) 
                AS farmer_fisher_lv00_01_50_100_full 
            FROM IPPAN_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN08, 
            
            -- 一般資産_営業停止損失
            (SELECT 
                SUM(
                CASE WHEN (house_summary_lv00) IS NULL THEN 0.00 ELSE house_summary_lv00 END+ 
                CASE WHEN (house_summary_lv01_49) IS NULL THEN 0.00 ELSE house_summary_lv01_49 END+ 
                CASE WHEN (house_summary_lv50_99) IS NULL THEN 0.00 ELSE house_summary_lv50_99 END+ 
                CASE WHEN (house_summary_lv100) IS NULL THEN 0.00 ELSE house_summary_lv100 END+ 
                CASE WHEN (house_summary_half) IS NULL THEN 0.00 ELSE house_summary_half END+ 
                CASE WHEN (house_summary_full) IS NULL THEN 0.00 ELSE house_summary_full END+ 
                CASE WHEN (household_summary_lv00) IS NULL THEN 0.00 ELSE household_summary_lv00 END+ 
                CASE WHEN (household_summary_lv01_49) IS NULL THEN 0.00 ELSE household_summary_lv01_49 END+ 
                CASE WHEN (household_summary_lv50_99) IS NULL THEN 0.00 ELSE household_summary_lv50_99 END+ 
                CASE WHEN (household_summary_lv100) IS NULL THEN 0.00 ELSE household_summary_lv100 END+ 
                CASE WHEN (household_summary_half) IS NULL THEN 0.00 ELSE household_summary_half END+ 
                CASE WHEN (household_summary_full) IS NULL THEN 0.00 ELSE household_summary_full END+ 
                CASE WHEN (car_summary_lv00) IS NULL THEN 0.00 ELSE car_summary_lv00 END+ 
                CASE WHEN (car_summary_lv01_49) IS NULL THEN 0.00 ELSE car_summary_lv01_49 END+ 
                CASE WHEN (car_summary_lv50_99) IS NULL THEN 0.00 ELSE car_summary_lv50_99 END+ 
                CASE WHEN (car_summary_lv100) IS NULL THEN 0.00 ELSE car_summary_lv100 END+ 
                CASE WHEN (car_summary_half) IS NULL THEN 0.00 ELSE car_summary_half END+ 
                CASE WHEN (car_summary_full) IS NULL THEN 0.00 ELSE car_summary_full END+ 
                CASE WHEN (house_alt_summary_lv00) IS NULL THEN 0.00 ELSE house_alt_summary_lv00 END+ 
                CASE WHEN (house_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE house_alt_summary_lv01_49 END+ 
                CASE WHEN (house_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE house_alt_summary_lv50_99 END+ 
                CASE WHEN (house_alt_summary_lv100) IS NULL THEN 0.00 ELSE house_alt_summary_lv100 END+ 
                CASE WHEN (house_alt_summary_half) IS NULL THEN 0.00 ELSE house_alt_summary_half END+ 
                CASE WHEN (house_alt_summary_full) IS NULL THEN 0.00 ELSE house_alt_summary_full END+ 
                CASE WHEN (house_clean_summary_lv00) IS NULL THEN 0.00 ELSE house_clean_summary_lv00 END+ 
                CASE WHEN (house_clean_summary_lv01_49) IS NULL THEN 0.00 ELSE house_clean_summary_lv01_49 END+ 
                CASE WHEN (house_clean_summary_lv50_99) IS NULL THEN 0.00 ELSE house_clean_summary_lv50_99 END+ 
                CASE WHEN (house_clean_summary_lv100) IS NULL THEN 0.00 ELSE house_clean_summary_lv100 END+ 
                CASE WHEN (house_clean_summary_half) IS NULL THEN 0.00 ELSE house_clean_summary_half END+ 
                CASE WHEN (house_clean_summary_full) IS NULL THEN 0.00 ELSE house_clean_summary_full END+ 
                CASE WHEN (office_dep_summary_lv00) IS NULL THEN 0.00 ELSE office_dep_summary_lv00 END+ 
                CASE WHEN (office_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE office_dep_summary_lv01_49 END+ 
                CASE WHEN (office_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE office_dep_summary_lv50_99 END+ 
                CASE WHEN (office_dep_summary_lv100) IS NULL THEN 0.00 ELSE office_dep_summary_lv100 END+ 
                CASE WHEN (office_dep_summary_full) IS NULL THEN 0.00 ELSE office_dep_summary_full END+ 
                CASE WHEN (office_inv_summary_lv00) IS NULL THEN 0.00 ELSE office_inv_summary_lv00 END+ 
                CASE WHEN (office_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE office_inv_summary_lv01_49 END+ 
                CASE WHEN (office_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE office_inv_summary_lv50_99 END+ 
                CASE WHEN (office_inv_summary_lv100) IS NULL THEN 0.00 ELSE office_inv_summary_lv100 END+ 
                CASE WHEN (office_inv_summary_full) IS NULL THEN 0.00 ELSE office_inv_summary_full END+ 
                CASE WHEN (office_sus_summary_lv00) IS NULL THEN 0.00 ELSE office_sus_summary_lv00 END+ 
                CASE WHEN (office_sus_summary_lv01_49) IS NULL THEN 0.00 ELSE office_sus_summary_lv01_49 END+ 
                CASE WHEN (office_sus_summary_lv50_99) IS NULL THEN 0.00 ELSE office_sus_summary_lv50_99 END+ 
                CASE WHEN (office_sus_summary_lv100) IS NULL THEN 0.00 ELSE office_sus_summary_lv100 END+ 
                CASE WHEN (office_sus_summary_full) IS NULL THEN 0.00 ELSE office_sus_summary_full END+ 
                CASE WHEN (office_stg_summary_lv00) IS NULL THEN 0.00 ELSE office_stg_summary_lv00 END+ 
                CASE WHEN (office_stg_summary_lv01_49) IS NULL THEN 0.00 ELSE office_stg_summary_lv01_49 END+ 
                CASE WHEN (office_stg_summary_lv50_99) IS NULL THEN 0.00 ELSE office_stg_summary_lv50_99 END+ 
                CASE WHEN (office_stg_summary_lv100) IS NULL THEN 0.00 ELSE office_stg_summary_lv100 END+ 
                CASE WHEN (office_stg_summary_full) IS NULL THEN 0.00 ELSE office_stg_summary_full END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_dep_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_dep_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_dep_summary_full END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv00) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv00 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv01_49) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv01_49 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv50_99) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv50_99 END+ 
                CASE WHEN (farmer_fisher_inv_summary_lv100) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_lv100 END+ 
                CASE WHEN (farmer_fisher_inv_summary_full) IS NULL THEN 0.00 ELSE farmer_fisher_inv_summary_full END+ 
                CASE WHEN (office_alt_summary_lv00) IS NULL THEN 0.00 ELSE office_alt_summary_lv00 END+ 
                CASE WHEN (office_alt_summary_lv01_49) IS NULL THEN 0.00 ELSE office_alt_summary_lv01_49 END+ 
                CASE WHEN (office_alt_summary_lv50_99) IS NULL THEN 0.00 ELSE office_alt_summary_lv50_99 END+ 
                CASE WHEN (office_alt_summary_lv100) IS NULL THEN 0.00 ELSE office_alt_summary_lv100 END+ 
                CASE WHEN (office_alt_summary_half) IS NULL THEN 0.00 ELSE office_alt_summary_half END+ 
                CASE WHEN (office_alt_summary_full) IS NULL THEN 0.00 ELSE office_alt_summary_full END) 
                AS ippan_asset_sales_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN09, 
            
            -- 一般資産_農作物被害額
            (SELECT 
                SUM(
                CASE WHEN (crop_damage) IS NULL THEN 0.00 ELSE crop_damage END) 
                AS crop_damage 
            FROM IPPAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) IPPAN10, 
                
            -- 地方単独事業被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END) 
                AS estimated_damage 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) CHITAN01, 
                
            -- 補助事業被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END) 
                AS determined_damage 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) HOJO01, 
                
            -- 公益事業被害額_合計
            (SELECT 
                SUM(
                CASE WHEN (physical_damage) IS NULL THEN 0.00 ELSE physical_damage END+
                CASE WHEN (sales_alt_other_damage) IS NULL THEN 0.00 ELSE sales_alt_other_damage END) 
                AS koeki_damage 
            FROM KOEKI_SUMMARY_VIEW 
            WHERE deleted_at IS NULL 
            ) KOEKI01 
                
            """, [])
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo03_zenkoku()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo03_zenkoku()関数が正常終了しました。', 'INFO')
        return True, hyo03_zenkoku_list
    
    except:
        print_log('[ERROR] P0700EStat.get_hyo03_zenkoku()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo03_zenkoku()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo03_zenkoku()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_03市町村別水害被害.xlsx
### 関数名：hyo03_view(request)
### urlpattern：path('hyo03/', hyo03_views.hyo03_view, name='hyo03_view'),
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo03_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo03_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo03_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo03_view()関数 STEP 1/4.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo03_view()関数 STEP 2/4.', 'DEBUG')
        ### 1 市区町村別_被害額_合計
        city_list = []
        for ken_code in constants.ken_values:
            bool_return, temp_city_list = get_hyo03(ken_code)
            if bool_return == False:
                raise Exception
            
            city_list.append(temp_city_list)

        ### 2 都道府県別_被害額_合計 中間下端
        ken_list = []
        for ken_code in constants.ken_values:
            bool_return, temp_ken_list = get_hyo03_ken(ken_code)
            if bool_return == False:
                raise Exception

            ken_list.append(temp_ken_list)

        ### 3 全国_被害額_合計 最下端
        bool_return, zenkoku_list = get_hyo03_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo02_view()関数 STEP 3/4.', 'DEBUG')
        ### 1 市区町村別_被害額_合計
        for i, temp in enumerate(city_list):
            for j, city in enumerate(temp):
                print('city.city_code={}'.format(city.city_code), flush=True)
                print('city.city_name={}'.format(city.city_name), flush=True)

        ### 2 都道府県別_被害額_合計 中間下端
        for i, temp in enumerate(ken_list):
            for j, ken in enumerate(temp):
                print('ken.ken_code={}'.format(ken.ken_code), flush=True)
                print('ken.ken_name={}'.format(ken.ken_name), flush=True)

        ### 3 全国_被害額_合計 最下端
        for i, zenkoku in enumerate(zenkoku_list):
            print('zenkoku.ippan_damage={}'.format(zenkoku.ippan_damage), flush=True)
            print('zenkoku.kokyo_damage={}'.format(zenkoku.kokyo_damage), flush=True)
            print('zenkoku.koeki_damage={}'.format(zenkoku.koeki_damage), flush=True)

        #######################################################################
        ### レスポンスセット処理(0030)
        ### コンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo03_view()関数 STEP 4/4.', 'DEBUG')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'cat_code': 'hyo03', 
            'ken_values': constants.ken_values, 
            'city_list': city_list, 
            'ken_list': ken_list, 
            'zenkoku_list': zenkoku_list, 
        }
        print_log('[INFO] P0700EStat.hyo03_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0700EStat.hyo03_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo03_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo03_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_03市町村別水害被害.xlsx
### 関数名：hyo03_download_view(request)
### urlpattern：path('download/hyo03/', hyo03_views.hyo03_download_view, name='hyo03_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo03_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo03_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo03_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo03_download_view()関数 STEP 1/5.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo03_download_view()関数 STEP 2/5.', 'DEBUG')
        ### 1 市区町村別_被害額_合計
        city_list = []
        for ken_code in constants.ken_values:
            bool_return, temp_city_list = get_hyo03(ken_code)
            if bool_return == False:
                raise Exception
            
            city_list.append(temp_city_list)

        ### 2 都道府県別_被害額_合計 中間下端
        ken_list = []
        for ken_code in constants.ken_values:
            bool_return, temp_ken_list = get_hyo03_ken(ken_code)
            if bool_return == False:
                raise Exception

            ken_list.append(temp_ken_list)

        ### 3 全国_被害額_合計 最下端
        bool_return, zenkoku_list = get_hyo03_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo03_download_view()関数 STEP 3/5.', 'DEBUG')
        ### 1 市区町村別_被害額_合計
        for i, temp in enumerate(city_list):
            for j, city in enumerate(temp):
                print('city.city_code={}'.format(city.city_code), flush=True)
                print('city.city_name={}'.format(city.city_name), flush=True)

        ### 2 都道府県別_被害額_合計 中間下端
        for i, temp in enumerate(ken_list):
            for j, ken in enumerate(temp):
                print('ken.ken_code={}'.format(ken.ken_code), flush=True)
                print('ken.ken_name={}'.format(ken.ken_name), flush=True)

        ### 3 全国_被害額_合計 最下端
        for i, zenkoku in enumerate(zenkoku_list):
            print('zenkoku.ippan_damage={}'.format(zenkoku.ippan_damage), flush=True)
            print('zenkoku.kokyo_damage={}'.format(zenkoku.kokyo_damage), flush=True)
            print('zenkoku.koeki_damage={}'.format(zenkoku.koeki_damage), flush=True)
        
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo03_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo03.xlsx'
        ### download_file_path = 'static/download_hyo03.xlsx'
        template_file_path = 'static/template/template_hyo03.xlsx'
        download_file_path = 'static/tmp/download_hyo03.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo03'
        
        ws.cell(row=1, column=1).value = '表－３　　市区町村別水害被害一覧'
        ws.cell(row=3, column=1).value = '都道府県'
        ws.cell(row=3, column=2).value = '市区町村'
        ws.cell(row=3, column=3).value = '水害区域面積（㎡）'
        ws.cell(row=3, column=6).value = '被　　災　　家　　屋　　棟　　数　（棟）'
        ws.cell(row=3, column=14).value = '被　　　害　　　数'
        ws.cell(row=3, column=20).value = '一般資産等被害（千円）'
        ws.cell(row=3, column=23).value = '公共土木施設被害額計（千円）'
        ws.cell(row=3, column=24).value = '公益事業被害額計（千円）'
        ws.cell(row=3, column=25).value = '被害額合計（千円）'
        
        row_index = 6
        
        for i, ken_code in enumerate(constants.ken_values):

            ### 1 市区町村別_被害額_合計
            for j, city in enumerate(city_list[i]):
                row_index += 1
                
                ws.cell(row=row_index, column=1).value = city.ken_name
                ws.cell(row=row_index, column=2).value = city.city_name
                ws.cell(row=row_index, column=3).value = city.residential_underground_area
                ws.cell(row=row_index, column=4).value = city.agricultural_area
                ws.cell(row=row_index, column=5).value = city.residential_underground_agricultural_area
                ws.cell(row=row_index, column=6).value = city.building_lv00
                ws.cell(row=row_index, column=7).value = city.building_lv01_49
                ws.cell(row=row_index, column=8).value = city.building_lv50_99
                ws.cell(row=row_index, column=9).value = city.building_lv100
                ws.cell(row=row_index, column=10).value = city.building_lv01_50_100
                ws.cell(row=row_index, column=11).value = city.building_half
                ws.cell(row=row_index, column=12).value = city.building_full
                ws.cell(row=row_index, column=13).value = city.building_lv00_01_50_100_half_full
                ws.cell(row=row_index, column=14).value = city.family_lv00
                ws.cell(row=row_index, column=15).value = city.family_lv01_50_100
                ws.cell(row=row_index, column=16).value = city.family_half_full
                ws.cell(row=row_index, column=17).value = city.office_lv00_01_50_100_half_full
                ws.cell(row=row_index, column=18).value = city.employee_lv00_01_50_100_full
                ws.cell(row=row_index, column=19).value = city.farmer_fisher_lv00_01_50_100_full
                ws.cell(row=row_index, column=20).value = city.ippan_asset_sales_damage
                ws.cell(row=row_index, column=21).value = city.crop_damage
                ws.cell(row=row_index, column=22).value = city.ippan_damage
                ws.cell(row=row_index, column=23).value = city.kokyo_damage
                ws.cell(row=row_index, column=24).value = city.koeki_damage
                ws.cell(row=row_index, column=25).value = city.ippan_chitan_hojo_koeki_damage

            ### 2 都道府県別_被害額_合計 中間下端
            for j, ken in enumerate(ken_list[i]):
                row_index += 1
            
                ws.cell(row=row_index, column=1).value = ken.ken_name + '合計'
                ws.cell(row=row_index, column=2).value = ''
                ws.cell(row=row_index, column=3).value = ken.residential_underground_area
                ws.cell(row=row_index, column=4).value = ken.agricultural_area
                ws.cell(row=row_index, column=5).value = ken.residential_underground_agricultural_area
                ws.cell(row=row_index, column=6).value = ken.building_lv00
                ws.cell(row=row_index, column=7).value = ken.building_lv01_49
                ws.cell(row=row_index, column=8).value = ken.building_lv50_99
                ws.cell(row=row_index, column=9).value = ken.building_lv100
                ws.cell(row=row_index, column=10).value = ken.building_lv01_50_100
                ws.cell(row=row_index, column=11).value = ken.building_half
                ws.cell(row=row_index, column=12).value = ken.building_full
                ws.cell(row=row_index, column=13).value = ken.building_lv00_01_50_100_half_full
                ws.cell(row=row_index, column=14).value = ken.family_lv00
                ws.cell(row=row_index, column=15).value = ken.family_lv01_50_100
                ws.cell(row=row_index, column=16).value = ken.family_half_full
                ws.cell(row=row_index, column=17).value = ken.office_lv00_01_50_100_half_full
                ws.cell(row=row_index, column=18).value = ken.employee_lv00_01_50_100_full
                ws.cell(row=row_index, column=19).value = ken.farmer_fisher_lv00_01_50_100_full
                ws.cell(row=row_index, column=20).value = ken.ippan_asset_sales_damage
                ws.cell(row=row_index, column=21).value = ken.crop_damage
                ws.cell(row=row_index, column=22).value = ken.ippan_damage
                ws.cell(row=row_index, column=23).value = ken.kokyo_damage
                ws.cell(row=row_index, column=24).value = ken.koeki_damage
                ws.cell(row=row_index, column=25).value = ken.ippan_chitan_hojo_koeki_damage
            
        ### 3 全国_被害額_合計 最下端
        for i, zenkoku in enumerate(zenkoku_list):
            row_index += 1
            
            ws.cell(row=row_index, column=1).value = '全国計'
            ws.cell(row=row_index, column=2).value = ''
            ws.cell(row=row_index, column=3).value = zenkoku.residential_underground_area
            ws.cell(row=row_index, column=4).value = zenkoku.agricultural_area
            ws.cell(row=row_index, column=5).value = zenkoku.residential_underground_agricultural_area
            ws.cell(row=row_index, column=6).value = zenkoku.building_lv00
            ws.cell(row=row_index, column=7).value = zenkoku.building_lv01_49
            ws.cell(row=row_index, column=8).value = zenkoku.building_lv50_99
            ws.cell(row=row_index, column=9).value = zenkoku.building_lv100
            ws.cell(row=row_index, column=10).value = zenkoku.building_lv01_50_100
            ws.cell(row=row_index, column=11).value = zenkoku.building_half
            ws.cell(row=row_index, column=12).value = zenkoku.building_full
            ws.cell(row=row_index, column=13).value = zenkoku.building_lv00_01_50_100_half_full
            ws.cell(row=row_index, column=14).value = zenkoku.family_lv00
            ws.cell(row=row_index, column=15).value = zenkoku.family_lv01_50_100
            ws.cell(row=row_index, column=16).value = zenkoku.family_half_full
            ws.cell(row=row_index, column=17).value = zenkoku.office_lv00_01_50_100_half_full
            ws.cell(row=row_index, column=18).value = zenkoku.employee_lv00_01_50_100_full
            ws.cell(row=row_index, column=19).value = zenkoku.farmer_fisher_lv00_01_50_100_full
            ws.cell(row=row_index, column=20).value = zenkoku.ippan_asset_sales_damage
            ws.cell(row=row_index, column=21).value = zenkoku.crop_damage
            ws.cell(row=row_index, column=22).value = zenkoku.ippan_damage
            ws.cell(row=row_index, column=23).value = zenkoku.kokyo_damage
            ws.cell(row=row_index, column=24).value = zenkoku.koeki_damage
            ws.cell(row=row_index, column=25).value = zenkoku.ippan_chitan_hojo_koeki_damage
        
        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo03_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo03_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo03.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo03_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo03_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo03_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
