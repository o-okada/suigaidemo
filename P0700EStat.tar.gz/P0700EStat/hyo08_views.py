###############################################################################
### 帳票名：hyo_08事業区分別工種区分別公共土木施設被害額.xlsx
### ファイル名：P0700EStat/hyo08_views.py
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView
from django.shortcuts import redirect

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from . import constants

### SUM_TOTAL_は右端に現れる合計の場合に使用する。
### 合計の名称は各要素の名称を連結したもの、または、各要素の名称の共通部分を抽出したものを使用する。
class HYO08:
    def __init__(self, ):
        pass

###############################################################################
### 帳票名：hyo_08事業区分別工種区分別公共土木施設被害額.xlsx
### 関数名：get_hyo08_ken(ken_code)
### 1 都道府県別_工種区分別_事業区分別_被害額_合計
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo08_ken(ken_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo08_ken()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0700EStat.get_hyo08_ken()関数 ken_code={}'.format(ken_code), 'DEBUG')
        if ken_code in constants.ken_values:
            pass
        else:
            print_log('[WARN] P0700EStat.get_hyo08_ken()関数が警告終了しました。', 'INFO')
            return False, []

        ### key、valueの辞書形式を使用する。
        ### ※['01','02']等のリスト形式を使用すると、複数プレースフォルダへの対応が難しいためである。
        ken_keys = ['KEN_CODE']
        ken_values = [ken_code]
        params = dict(zip(constants.setubi_keys + ken_keys, constants.setubi_values + ken_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo08_ken()関数 STEP 2/3.', 'DEBUG')
        hyo08_ken_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                KEN1.ken_code, 
                KEN1.ken_name, 
                
                CASE WHEN (HOJO01.kasen_determined_cost) IS NULL THEN 0.00 ELSE HOJO01.kasen_determined_cost END, 
                CASE WHEN (HOJO02.kaigan_port_determined_cost) IS NULL THEN 0.00 ELSE HOJO02.kaigan_port_determined_cost END, 
                CASE WHEN (HOJO03.sabou_determined_cost) IS NULL THEN 0.00 ELSE HOJO03.sabou_determined_cost END, 
                CASE WHEN (HOJO04.landslide_determined_cost) IS NULL THEN 0.00 ELSE HOJO04.landslide_determined_cost END, 
                CASE WHEN (HOJO05.steepslope_determined_cost) IS NULL THEN 0.00 ELSE HOJO05.steepslope_determined_cost END, 
                CASE WHEN (HOJO06.road_determined_cost) IS NULL THEN 0.00 ELSE HOJO06.road_determined_cost END, 
                CASE WHEN (HOJO07.bridge_determined_cost) IS NULL THEN 0.00 ELSE HOJO07.bridge_determined_cost END, 
                CASE WHEN (HOJO08.sewer_determined_cost) IS NULL THEN 0.00 ELSE HOJO08.sewer_determined_cost END, 
                CASE WHEN (HOJO09.park_facility_determined_cost) IS NULL THEN 0.00 ELSE HOJO09.park_facility_determined_cost END, 

                CASE WHEN (HOJO01.kasen_determined_cost) IS NULL THEN 0.00 ELSE HOJO01.kasen_determined_cost END+ 
                CASE WHEN (HOJO02.kaigan_port_determined_cost) IS NULL THEN 0.00 ELSE HOJO02.kaigan_port_determined_cost END+ 
                CASE WHEN (HOJO03.sabou_determined_cost) IS NULL THEN 0.00 ELSE HOJO03.sabou_determined_cost END+ 
                CASE WHEN (HOJO04.landslide_determined_cost) IS NULL THEN 0.00 ELSE HOJO04.landslide_determined_cost END+ 
                CASE WHEN (HOJO05.steepslope_determined_cost) IS NULL THEN 0.00 ELSE HOJO05.steepslope_determined_cost END+ 
                CASE WHEN (HOJO06.road_determined_cost) IS NULL THEN 0.00 ELSE HOJO06.road_determined_cost END+ 
                CASE WHEN (HOJO07.bridge_determined_cost) IS NULL THEN 0.00 ELSE HOJO07.bridge_determined_cost END+ 
                CASE WHEN (HOJO08.sewer_determined_cost) IS NULL THEN 0.00 ELSE HOJO08.sewer_determined_cost END+ 
                CASE WHEN (HOJO09.park_facility_determined_cost) IS NULL THEN 0.00 ELSE HOJO09.park_facility_determined_cost END 
                AS hojo_determined_cost, 
                
                CASE WHEN (CHITAN01.kasen_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN01.kasen_estimated_cost END, 
                CASE WHEN (CHITAN02.kaigan_port_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN02.kaigan_port_estimated_cost END, 
                CASE WHEN (CHITAN03.sabou_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN03.sabou_estimated_cost END, 
                CASE WHEN (CHITAN04.landslide_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN04.landslide_estimated_cost END, 
                CASE WHEN (CHITAN05.steepslope_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN05.steepslope_estimated_cost END, 
                CASE WHEN (CHITAN06.road_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN06.road_estimated_cost END, 
                CASE WHEN (CHITAN07.bridge_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN07.bridge_estimated_cost END, 
                CASE WHEN (CHITAN08.sewer_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN08.sewer_estimated_cost END, 
                CASE WHEN (CHITAN09.park_facility_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN09.park_facility_estimated_cost END, 
                
                CASE WHEN (CHITAN01.kasen_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN01.kasen_estimated_cost END+ 
                CASE WHEN (CHITAN02.kaigan_port_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN02.kaigan_port_estimated_cost END+ 
                CASE WHEN (CHITAN03.sabou_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN03.sabou_estimated_cost END+ 
                CASE WHEN (CHITAN04.landslide_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN04.landslide_estimated_cost END+ 
                CASE WHEN (CHITAN05.steepslope_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN05.steepslope_estimated_cost END+ 
                CASE WHEN (CHITAN06.road_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN06.road_estimated_cost END+ 
                CASE WHEN (CHITAN07.bridge_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN07.bridge_estimated_cost END+ 
                CASE WHEN (CHITAN08.sewer_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN08.sewer_estimated_cost END+ 
                CASE WHEN (CHITAN09.park_facility_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN09.park_facility_estimated_cost END
                AS chitan_estimated_cost, 
                
                CASE WHEN (HOJO01.kasen_determined_cost) IS NULL THEN 0.00 ELSE HOJO01.kasen_determined_cost END+ 
                CASE WHEN (CHITAN01.kasen_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN01.kasen_estimated_cost END 
                AS kasen_cost, 

                CASE WHEN (HOJO02.kaigan_port_determined_cost) IS NULL THEN 0.00 ELSE HOJO02.kaigan_port_determined_cost END+ 
                CASE WHEN (CHITAN02.kaigan_port_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN02.kaigan_port_estimated_cost END 
                AS kaigan_port_cost, 

                CASE WHEN (HOJO03.sabou_determined_cost) IS NULL THEN 0.00 ELSE HOJO03.sabou_determined_cost END+ 
                CASE WHEN (CHITAN03.sabou_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN03.sabou_estimated_cost END 
                AS sabou_cost, 

                CASE WHEN (HOJO04.landslide_determined_cost) IS NULL THEN 0.00 ELSE HOJO04.landslide_determined_cost END+ 
                CASE WHEN (CHITAN04.landslide_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN04.landslide_estimated_cost END 
                AS landslide_cost, 

                CASE WHEN (HOJO05.steepslope_determined_cost) IS NULL THEN 0.00 ELSE HOJO05.steepslope_determined_cost END+ 
                CASE WHEN (CHITAN05.steepslope_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN05.steepslope_estimated_cost END 
                AS steepslope_cost, 

                CASE WHEN (HOJO06.road_determined_cost) IS NULL THEN 0.00 ELSE HOJO06.road_determined_cost END+ 
                CASE WHEN (CHITAN06.road_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN06.road_estimated_cost END 
                AS road_cost, 

                CASE WHEN (HOJO07.bridge_determined_cost) IS NULL THEN 0.00 ELSE HOJO07.bridge_determined_cost END+ 
                CASE WHEN (CHITAN07.bridge_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN07.bridge_estimated_cost END 
                AS bridge_cost, 

                CASE WHEN (HOJO08.sewer_determined_cost) IS NULL THEN 0.00 ELSE HOJO08.sewer_determined_cost END+ 
                CASE WHEN (CHITAN08.sewer_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN08.sewer_estimated_cost END 
                AS sewer_cost, 

                CASE WHEN (HOJO09.park_facility_determined_cost) IS NULL THEN 0.00 ELSE HOJO09.park_facility_determined_cost END+ 
                CASE WHEN (CHITAN09.park_facility_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN09.park_facility_estimated_cost END 
                AS park_facility_code, 

                CASE WHEN (HOJO01.kasen_determined_cost) IS NULL THEN 0.00 ELSE HOJO01.kasen_determined_cost END+ 
                CASE WHEN (HOJO02.kaigan_port_determined_cost) IS NULL THEN 0.00 ELSE HOJO02.kaigan_port_determined_cost END+ 
                CASE WHEN (HOJO03.sabou_determined_cost) IS NULL THEN 0.00 ELSE HOJO03.sabou_determined_cost END+ 
                CASE WHEN (HOJO04.landslide_determined_cost) IS NULL THEN 0.00 ELSE HOJO04.landslide_determined_cost END+ 
                CASE WHEN (HOJO05.steepslope_determined_cost) IS NULL THEN 0.00 ELSE HOJO05.steepslope_determined_cost END+ 
                CASE WHEN (HOJO06.road_determined_cost) IS NULL THEN 0.00 ELSE HOJO06.road_determined_cost END+ 
                CASE WHEN (HOJO07.bridge_determined_cost) IS NULL THEN 0.00 ELSE HOJO07.bridge_determined_cost END+ 
                CASE WHEN (HOJO08.sewer_determined_cost) IS NULL THEN 0.00 ELSE HOJO08.sewer_determined_cost END+ 
                CASE WHEN (HOJO09.park_facility_determined_cost) IS NULL THEN 0.00 ELSE HOJO09.park_facility_determined_cost END+ 
                CASE WHEN (CHITAN01.kasen_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN01.kasen_estimated_cost END+ 
                CASE WHEN (CHITAN02.kaigan_port_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN02.kaigan_port_estimated_cost END+ 
                CASE WHEN (CHITAN03.sabou_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN03.sabou_estimated_cost END+ 
                CASE WHEN (CHITAN04.landslide_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN04.landslide_estimated_cost END+ 
                CASE WHEN (CHITAN05.steepslope_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN05.steepslope_estimated_cost END+ 
                CASE WHEN (CHITAN06.road_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN06.road_estimated_cost END+ 
                CASE WHEN (CHITAN07.bridge_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN07.bridge_estimated_cost END+ 
                CASE WHEN (CHITAN08.sewer_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN08.sewer_estimated_cost END+ 
                CASE WHEN (CHITAN09.park_facility_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN09.park_facility_estimated_cost END
                AS hojo_chitan_cost 
                
            FROM 

            -- 都道府県
            (SELECT 
                ken_code, ken_name 
            FROM KEN 
            WHERE ken_code=%(KEN_CODE)s 
            ) KEN1, 
            
            -- 補助事業_河川
            (SELECT 
                SUM(
                CASE WHEN(determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS kasen_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s AND ken_code=%(KEN_CODE)s 
            ) HOJO01, 
            
            -- 補助事業_海岸・港湾
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS kaigan_port_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) AND ken_code=%(KEN_CODE)s 
            ) HOJO02, 
            
            -- 補助事業_砂防設備
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS sabou_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s AND ken_code=%(KEN_CODE)s 
            ) HOJO03, 
            
            -- 補助事業_地すべり防止施設
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS landslide_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s AND ken_code=%(KEN_CODE)s 
            ) HOJO04, 
            
            -- 補助事業_急傾斜崩壊防止施設
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS steepslope_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s AND ken_code=%(KEN_CODE)s 
            ) HOJO05, 
            
            -- 補助事業_道路
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS road_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s AND ken_code=%(KEN_CODE)s 
            ) HOJO06, 
            
            -- 補助事業_橋梁
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS bridge_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s AND ken_code=%(KEN_CODE)s 
            ) HOJO07, 
            
            -- 補助事業_下水道
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS sewer_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s AND ken_code=%(KEN_CODE)s 
            ) HOJO08, 
            
            -- 補助事業_公園・都市施設
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS park_facility_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) AND ken_code=%(KEN_CODE)s 
            ) HOJO09, 

            -- 地方単独事業_河川
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS kasen_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s AND ken_code=%(KEN_CODE)s 
            ) CHITAN01, 
            
            -- 地方単独事業_海岸・港湾
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS kaigan_port_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) AND ken_code=%(KEN_CODE)s 
            ) CHITAN02, 
            
            -- 地方単独事業_砂防設備
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS sabou_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s AND ken_code=%(KEN_CODE)s 
            ) CHITAN03, 
            
            -- 地方単独事業_地すべり防止施設
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS landslide_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s AND ken_code=%(KEN_CODE)s 
            ) CHITAN04, 
            
            -- 地方単独事業_急傾斜崩壊防止施設
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS steepslope_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s AND ken_code=%(KEN_CODE)s 
            ) CHITAN05, 
            
            -- 地方単独事業_道路
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS road_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s AND ken_code=%(KEN_CODE)s 
            ) CHITAN06, 
            
            -- 地方単独事業_橋梁
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS bridge_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s AND ken_code=%(KEN_CODE)s 
            ) CHITAN07, 
            
            -- 地方単独事業_下水道
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS sewer_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s AND ken_code=%(KEN_CODE)s 
            ) CHITAN08, 
            
            -- 地方単独事業_公園・都市施設
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS park_facility_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) AND ken_code=%(KEN_CODE)s 
            ) CHITAN09 

            """, params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo08_ken()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo08_ken()関数が正常終了しました。', 'INFO')
        return True, hyo08_ken_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo08_ken()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo08_ken()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo08_ken()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_08事業区分別工種区分別公共土木施設被害額.xlsx
### 関数名：get_hyo08_zenkoku()
### 2 全国_工種区分別_事業区分別_被害額_合計
### ※行をTEMPLATE、EXCELの最外側のFORループ処理としているため、行を1番目の要素としてコメントする。
###############################################################################
def get_hyo08_zenkoku():
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo08_zenkoku()関数 STEP 1/3.', 'DEBUG')
        params = dict(zip(constants.setubi_keys, constants.setubi_values))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo06_zenkoku()関数 STEP 2/3.', 'DEBUG')
        hyo08_zenkoku_list = IPPAN.objects.raw("""
            SELECT 
                0 AS ippan_id, 
                
                CASE WHEN (HOJO01.kasen_determined_cost) IS NULL THEN 0.00 ELSE HOJO01.kasen_determined_cost END, 
                CASE WHEN (HOJO02.kaigan_port_determined_cost) IS NULL THEN 0.00 ELSE HOJO02.kaigan_port_determined_cost END, 
                CASE WHEN (HOJO03.sabou_determined_cost) IS NULL THEN 0.00 ELSE HOJO03.sabou_determined_cost END, 
                CASE WHEN (HOJO04.landslide_determined_cost) IS NULL THEN 0.00 ELSE HOJO04.landslide_determined_cost END, 
                CASE WHEN (HOJO05.steepslope_determined_cost) IS NULL THEN 0.00 ELSE HOJO05.steepslope_determined_cost END, 
                CASE WHEN (HOJO06.road_determined_cost) IS NULL THEN 0.00 ELSE HOJO06.road_determined_cost END, 
                CASE WHEN (HOJO07.bridge_determined_cost) IS NULL THEN 0.00 ELSE HOJO07.bridge_determined_cost END, 
                CASE WHEN (HOJO08.sewer_determined_cost) IS NULL THEN 0.00 ELSE HOJO08.sewer_determined_cost END, 
                CASE WHEN (HOJO09.park_facility_determined_cost) IS NULL THEN 0.00 ELSE HOJO09.park_facility_determined_cost END, 

                CASE WHEN (HOJO01.kasen_determined_cost) IS NULL THEN 0.00 ELSE HOJO01.kasen_determined_cost END+ 
                CASE WHEN (HOJO02.kaigan_port_determined_cost) IS NULL THEN 0.00 ELSE HOJO02.kaigan_port_determined_cost END+ 
                CASE WHEN (HOJO03.sabou_determined_cost) IS NULL THEN 0.00 ELSE HOJO03.sabou_determined_cost END+ 
                CASE WHEN (HOJO04.landslide_determined_cost) IS NULL THEN 0.00 ELSE HOJO04.landslide_determined_cost END+ 
                CASE WHEN (HOJO05.steepslope_determined_cost) IS NULL THEN 0.00 ELSE HOJO05.steepslope_determined_cost END+ 
                CASE WHEN (HOJO06.road_determined_cost) IS NULL THEN 0.00 ELSE HOJO06.road_determined_cost END+ 
                CASE WHEN (HOJO07.bridge_determined_cost) IS NULL THEN 0.00 ELSE HOJO07.bridge_determined_cost END+ 
                CASE WHEN (HOJO08.sewer_determined_cost) IS NULL THEN 0.00 ELSE HOJO08.sewer_determined_cost END+ 
                CASE WHEN (HOJO09.park_facility_determined_cost) IS NULL THEN 0.00 ELSE HOJO09.park_facility_determined_cost END 
                AS hojo_determined_cost, 
                
                CASE WHEN (CHITAN01.kasen_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN01.kasen_estimated_cost END, 
                CASE WHEN (CHITAN02.kaigan_port_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN02.kaigan_port_estimated_cost END, 
                CASE WHEN (CHITAN03.sabou_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN03.sabou_estimated_cost END, 
                CASE WHEN (CHITAN04.landslide_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN04.landslide_estimated_cost END, 
                CASE WHEN (CHITAN05.steepslope_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN05.steepslope_estimated_cost END, 
                CASE WHEN (CHITAN06.road_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN06.road_estimated_cost END, 
                CASE WHEN (CHITAN07.bridge_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN07.bridge_estimated_cost END, 
                CASE WHEN (CHITAN08.sewer_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN08.sewer_estimated_cost END, 
                CASE WHEN (CHITAN09.park_facility_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN09.park_facility_estimated_cost END, 
                
                CASE WHEN (CHITAN01.kasen_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN01.kasen_estimated_cost END+ 
                CASE WHEN (CHITAN02.kaigan_port_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN02.kaigan_port_estimated_cost END+ 
                CASE WHEN (CHITAN03.sabou_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN03.sabou_estimated_cost END+ 
                CASE WHEN (CHITAN04.landslide_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN04.landslide_estimated_cost END+ 
                CASE WHEN (CHITAN05.steepslope_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN05.steepslope_estimated_cost END+ 
                CASE WHEN (CHITAN06.road_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN06.road_estimated_cost END+ 
                CASE WHEN (CHITAN07.bridge_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN07.bridge_estimated_cost END+ 
                CASE WHEN (CHITAN08.sewer_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN08.sewer_estimated_cost END+ 
                CASE WHEN (CHITAN09.park_facility_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN09.park_facility_estimated_cost END
                AS chitan_estimated_cost, 
                
                CASE WHEN (HOJO01.kasen_determined_cost) IS NULL THEN 0.00 ELSE HOJO01.kasen_determined_cost END+ 
                CASE WHEN (CHITAN01.kasen_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN01.kasen_estimated_cost END 
                AS kasen_cost, 

                CASE WHEN (HOJO02.kaigan_port_determined_cost) IS NULL THEN 0.00 ELSE HOJO02.kaigan_port_determined_cost END+ 
                CASE WHEN (CHITAN02.kaigan_port_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN02.kaigan_port_estimated_cost END 
                AS kaigan_port_cost, 

                CASE WHEN (HOJO03.sabou_determined_cost) IS NULL THEN 0.00 ELSE HOJO03.sabou_determined_cost END+ 
                CASE WHEN (CHITAN03.sabou_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN03.sabou_estimated_cost END 
                AS sabou_cost, 

                CASE WHEN (HOJO04.landslide_determined_cost) IS NULL THEN 0.00 ELSE HOJO04.landslide_determined_cost END+ 
                CASE WHEN (CHITAN04.landslide_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN04.landslide_estimated_cost END 
                AS landslide_cost, 

                CASE WHEN (HOJO05.steepslope_determined_cost) IS NULL THEN 0.00 ELSE HOJO05.steepslope_determined_cost END+ 
                CASE WHEN (CHITAN05.steepslope_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN05.steepslope_estimated_cost END 
                AS steepslope_cost, 

                CASE WHEN (HOJO06.road_determined_cost) IS NULL THEN 0.00 ELSE HOJO06.road_determined_cost END+ 
                CASE WHEN (CHITAN06.road_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN06.road_estimated_cost END 
                AS road_cost, 

                CASE WHEN (HOJO07.bridge_determined_cost) IS NULL THEN 0.00 ELSE HOJO07.bridge_determined_cost END+ 
                CASE WHEN (CHITAN07.bridge_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN07.bridge_estimated_cost END 
                AS bridge_cost, 

                CASE WHEN (HOJO08.sewer_determined_cost) IS NULL THEN 0.00 ELSE HOJO08.sewer_determined_cost END+ 
                CASE WHEN (CHITAN08.sewer_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN08.sewer_estimated_cost END 
                AS sewer_cost, 

                CASE WHEN (HOJO09.park_facility_determined_cost) IS NULL THEN 0.00 ELSE HOJO09.park_facility_determined_cost END+ 
                CASE WHEN (CHITAN09.park_facility_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN09.park_facility_estimated_cost END 
                AS park_facility_code, 

                CASE WHEN (HOJO01.kasen_determined_cost) IS NULL THEN 0.00 ELSE HOJO01.kasen_determined_cost END+ 
                CASE WHEN (HOJO02.kaigan_port_determined_cost) IS NULL THEN 0.00 ELSE HOJO02.kaigan_port_determined_cost END+ 
                CASE WHEN (HOJO03.sabou_determined_cost) IS NULL THEN 0.00 ELSE HOJO03.sabou_determined_cost END+ 
                CASE WHEN (HOJO04.landslide_determined_cost) IS NULL THEN 0.00 ELSE HOJO04.landslide_determined_cost END+ 
                CASE WHEN (HOJO05.steepslope_determined_cost) IS NULL THEN 0.00 ELSE HOJO05.steepslope_determined_cost END+ 
                CASE WHEN (HOJO06.road_determined_cost) IS NULL THEN 0.00 ELSE HOJO06.road_determined_cost END+ 
                CASE WHEN (HOJO07.bridge_determined_cost) IS NULL THEN 0.00 ELSE HOJO07.bridge_determined_cost END+ 
                CASE WHEN (HOJO08.sewer_determined_cost) IS NULL THEN 0.00 ELSE HOJO08.sewer_determined_cost END+ 
                CASE WHEN (HOJO09.park_facility_determined_cost) IS NULL THEN 0.00 ELSE HOJO09.park_facility_determined_cost END+ 
                CASE WHEN (CHITAN01.kasen_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN01.kasen_estimated_cost END+ 
                CASE WHEN (CHITAN02.kaigan_port_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN02.kaigan_port_estimated_cost END+ 
                CASE WHEN (CHITAN03.sabou_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN03.sabou_estimated_cost END+ 
                CASE WHEN (CHITAN04.landslide_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN04.landslide_estimated_cost END+ 
                CASE WHEN (CHITAN05.steepslope_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN05.steepslope_estimated_cost END+ 
                CASE WHEN (CHITAN06.road_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN06.road_estimated_cost END+ 
                CASE WHEN (CHITAN07.bridge_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN07.bridge_estimated_cost END+ 
                CASE WHEN (CHITAN08.sewer_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN08.sewer_estimated_cost END+ 
                CASE WHEN (CHITAN09.park_facility_estimated_cost) IS NULL THEN 0.00 ELSE CHITAN09.park_facility_estimated_cost END
                AS hojo_chitan_cost 
                
            FROM 
            
            -- 補助事業_河川
            (SELECT 
                SUM(
                CASE WHEN(determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS kasen_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s 
            ) HOJO01, 
            
            -- 補助事業_海岸・港湾
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS kaigan_port_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) HOJO02, 
            
            -- 補助事業_砂防設備
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS sabou_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s 
            ) HOJO03, 
            
            -- 補助事業_地すべり防止施設
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS landslide_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s 
            ) HOJO04, 
            
            -- 補助事業_急傾斜崩壊防止施設
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS steepslope_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) HOJO05, 
            
            -- 補助事業_道路
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS road_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s 
            ) HOJO06, 
            
            -- 補助事業_橋梁
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS bridge_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s 
            ) HOJO07, 
            
            -- 補助事業_下水道
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS sewer_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s 
            ) HOJO08, 
            
            -- 補助事業_公園・都市施設
            (SELECT 
                SUM(
                CASE WHEN (determined_cost) IS NULL THEN 0.00 ELSE determined_cost END 
                ) AS park_facility_determined_cost 
            FROM HOJO_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) HOJO09, 

            -- 地方単独事業_河川
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS kasen_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(KASEN)s 
            ) CHITAN01, 
            
            -- 地方単独事業_海岸・港湾
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS kaigan_port_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(KAIGAN)s,%(PORT)s) 
            ) CHITAN02, 
            
            -- 地方単独事業_砂防設備
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS sabou_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SABOU)s 
            ) CHITAN03, 
            
            -- 地方単独事業_地すべり防止施設
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS landslide_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(LANDSLIDE)s 
            ) CHITAN04, 
            
            -- 地方単独事業_急傾斜崩壊防止施設
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS steepslope_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(STEEPSLOPE)s 
            ) CHITAN05, 
            
            -- 地方単独事業_道路
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS road_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(ROAD)s 
            ) CHITAN06, 
            
            -- 地方単独事業_橋梁
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS bridge_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(BRIDGE)s 
            ) CHITAN07, 
            
            -- 地方単独事業_下水道
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS sewer_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code=%(SEWER)s 
            ) CHITAN08, 
            
            -- 地方単独事業_公園・都市施設
            (SELECT 
                SUM(
                CASE WHEN (estimated_cost) IS NULL THEN 0.00 ELSE estimated_cost END 
                ) AS park_facility_estimated_cost 
            FROM CHITAN_SUMMARY_VIEW 
            WHERE deleted_at IS NULL AND kasen_setubi_code IN (%(PARK)s,%(FACILITY)s) 
            ) CHITAN09 

            """, params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.get_hyo08_zenkoku()関数 STEP 3/3.', 'DEBUG')
        print_log('[INFO] P0700EStat.get_hyo08_zenkoku()関数が正常終了しました。', 'INFO')
        return True, hyo08_zenkoku_list
    except:
        print_log('[ERROR] P0700EStat.get_hyo08_zenkoku()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo08_zenkoku()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.get_hyo08_zenkoku()関数が異常終了しました。', 'ERROR')
        return False, []

###############################################################################
### 帳票名：hyo_08事業区分別工種区分別公共土木施設被害額.xlsx
### 関数名：hyo08_view(request)
### urlpattern：path('hyo08/', hyo08_views.hyo08_view, name='hyo08_view'),
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo08_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo08_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo08_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo08_view()関数 STEP 1/4.', 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo08_view()関数 STEP 2/4.', 'DEBUG')
        ### 1 都道府県別_工種区分別_事業区分別_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo08_view()関数 STEP 2_1/4.', 'DEBUG')
        ken_list = []
        for ken_code in constants.ken_values:
            bool_return, temp = get_hyo08_ken(ken_code)
            if bool_return == False:
                raise Exception
                
            ken_list.append(temp)

        ### 2 全国_工種区分別_事業区分別_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo08_view()関数 STEP 2_2/4.', 'DEBUG')
        bool_retur, zenkoku_list = get_hyo08_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo08_view()関数 STEP 3/4.', 'DEBUG')
        ### 1 都道府県別_工種区分別_事業区分別_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo08_view()関数 STEP 3_1/4.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, ken in enumerate(ken_list[i]):
                print('i={} j={} ken.ken_code={}'.format(i, j, ken.ken_code), flush=True)

        ### 2 全国_工種区分別_事業区分別_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo08_view()関数 STEP 3_2/4.', 'DEBUG')
        for i, zenkoku in enumerate(zenkoku_list):
            print('i={} zenkoku.kasen_determined_cost={}'.format(i, zenkoku.kasen_determined_cost), flush=True)

        #######################################################################
        ### レスポンスセット処理(0030)
        ### コンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo08_view()関数 STEP 4/4.', 'DEBUG')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'cat_code': 'hyo08', 
            'ken_list': ken_list,
            'zenkoku_list': zenkoku_list, 
        }
        print_log('[INFO] P0700EStat.hyo08_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0700EStat.hyo08_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo08_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo08_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 帳票名：hyo_08事業区分別工種区分別公共土木施設被害額.xlsx
### 関数名：hyo08_download_view(request)
### urlpattern：path('download/hyo08/', hyo08_views.hyo08_download_view, name='hyo08_download_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def hyo08_download_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0700EStat.hyo08_download_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0700EStat.hyo08_download_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0700EStat.hyo08_download_view()関数 STEP 1/5.', 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo08_download_view()関数 STEP 2/5.', 'DEBUG')
        ### 1 都道府県別_工種区分別_事業区分別_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo08_download_view()関数 STEP 2_1/5.', 'DEBUG')
        ken_list = []
        for ken_code in constants.ken_values:
            bool_return, temp = get_hyo08_ken(ken_code)
            if bool_return == False:
                raise Exception
                
            ken_list.append(temp)

        ### 2 全国_工種区分別_事業区分別_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo08_download_view()関数 STEP 2_2/5.', 'DEBUG')
        bool_retur, zenkoku_list = get_hyo08_zenkoku()
        if bool_return == False:
            raise Exception

        #######################################################################
        ### 計算処理(0020)
        ### 計算して局所変数に値をセットする。
        ### DBから取得したデータの構造が直感的にわかりにくく、ソースコード修正後にバグが発生しやすいため、データの一部を表示する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo08_download_view()関数 STEP 3/5.', 'DEBUG')
        ### 1 都道府県別_工種区分別_事業区分別_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo08_download_view()関数 STEP 3_1/5.', 'DEBUG')
        for i, ken_code in enumerate(constants.ken_values):
            for j, ken in enumerate(ken_list[i]):
                print('i={} j={} ken.ken_code={}'.format(i, j, ken.ken_code), flush=True)

        ### 2 全国_工種区分別_事業区分別_被害額_合計
        print_log('[DEBUG] P0700EStat.hyo08_download_view()関数 STEP 3_2/5.', 'DEBUG')
        for i, zenkoku in enumerate(zenkoku_list):
            print('i={} zenkoku.kasen_determined_cost={}'.format(i, zenkoku.kasen_determined_cost), flush=True)
        
        #######################################################################
        ### EXCEL入出力処理(0030)
        ### (1)テンプレート用のEXCELファイルを読み込む。
        ### (2)セルにデータをセットして、ダウンロード用のEXCELファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo08_download_view()関数 STEP 4/5.', 'DEBUG')
        ### template_file_path = 'static/template_hyo08.xlsx'
        ### download_file_path = 'static/download_hyo08.xlsx'
        template_file_path = 'static/template/template_hyo08.xlsx'
        download_file_path = 'static/tmp/download_hyo08.xlsx'
        wb = openpyxl.load_workbook(template_file_path)
        ws = wb.active
        ws.title = 'hyo08'
        
        ws.cell(row=1, column=1).value = '表－８　事業区分別工種区分別公共土木施設被害額'
        ws.cell(row=3, column=12).value = '（単位：千円）'
        ws.cell(row=4, column=1).value = '都　道'
        ws.cell(row=4, column=2).value = '事業区分'
        ws.cell(row=4, column=3).value = '河　川'
        ws.cell(row=4, column=4).value = '海岸・港湾'
        ws.cell(row=4, column=5).value = '砂防設備'
        ws.cell(row=4, column=6).value = '地すべり'
        ws.cell(row=4, column=7).value = '急傾斜崩壊'
        ws.cell(row=4, column=8).value = '道　路'
        ws.cell(row=4, column=9).value = '橋　梁'
        ws.cell(row=4, column=10).value = '下水道'
        ws.cell(row=4, column=11).value = '公園・都市施設'
        ws.cell(row=4, column=12).value = '計'
        ws.cell(row=5, column=1).value = '府県名'
        ws.cell(row=5, column=6).value = '防止施設'
        ws.cell(row=5, column=7).value = '防止施設'
        
        row_index = 5 
        
        ### 1 都道府県別_工種区分別_事業区分別_被害額_合計
        for i, ken_code in enumerate(constants.ken_values):
            for j, ken in enumerate(ken_list[i]):
                ### 県別_直轄事業
                row_index += 1
                ws.cell(row=row_index, column=1).value = ken.ken_name
                ws.cell(row=row_index, column=2).value = '直轄事業'
                ws.cell(row=row_index, column=3).value = ''
                ws.cell(row=row_index, column=4).value = ''
                ws.cell(row=row_index, column=5).value = ''
                ws.cell(row=row_index, column=6).value = ''
                ws.cell(row=row_index, column=7).value = ''
                ws.cell(row=row_index, column=8).value = ''
                ws.cell(row=row_index, column=9).value = ''
                ws.cell(row=row_index, column=10).value = ''
                ws.cell(row=row_index, column=11).value = ''
                ws.cell(row=row_index, column=12).value = ''

                ### 県別_補助事業
                row_index += 1
                ws.cell(row=row_index, column=2).value = '補助事業'
                ws.cell(row=row_index, column=3).value = ken.kasen_determined_cost
                ws.cell(row=row_index, column=4).value = ken.kaigan_port_determined_cost
                ws.cell(row=row_index, column=5).value = ken.sabou_determined_cost
                ws.cell(row=row_index, column=6).value = ken.landslide_determined_cost
                ws.cell(row=row_index, column=7).value = ken.steepslope_determined_cost
                ws.cell(row=row_index, column=8).value = ken.road_determined_cost
                ws.cell(row=row_index, column=9).value = ken.bridge_determined_cost
                ws.cell(row=row_index, column=10).value = ken.sewer_determined_cost
                ws.cell(row=row_index, column=11).value = ken.park_facility_determined_cost
                ws.cell(row=row_index, column=12).value = ken.hojo_determined_cost

                ### 県別_地方単独事業
                row_index += 1
                ws.cell(row=row_index, column=2).value = '地方単独事業'
                ws.cell(row=row_index, column=3).value = ken.kasen_estimated_cost
                ws.cell(row=row_index, column=4).value = ken.kaigan_port_estimated_cost
                ws.cell(row=row_index, column=5).value = ken.sabou_estimated_cost
                ws.cell(row=row_index, column=6).value = ken.landslide_estimated_cost
                ws.cell(row=row_index, column=7).value = ken.steepslope_estimated_cost
                ws.cell(row=row_index, column=8).value = ken.road_estimated_cost
                ws.cell(row=row_index, column=9).value = ken.bridge_estimated_cost
                ws.cell(row=row_index, column=10).value = ken.sewer_estimated_cost
                ws.cell(row=row_index, column=11).value = ken.park_facility_estimated_cost
                ws.cell(row=row_index, column=12).value = ken.chitan_estimated_cost

                ### 県別_計
                row_index += 1
                ws.cell(row=row_index, column=2).value = '計'
                ws.cell(row=row_index, column=3).value = ken.kasen_cost
                ws.cell(row=row_index, column=4).value = ken.kaigan_port_cost
                ws.cell(row=row_index, column=5).value = ken.sabou_cost
                ws.cell(row=row_index, column=6).value = ken.landslide_cost
                ws.cell(row=row_index, column=7).value = ken.steepslope_cost
                ws.cell(row=row_index, column=8).value = ken.road_cost
                ws.cell(row=row_index, column=9).value = ken.bridge_cost
                ws.cell(row=row_index, column=10).value = ken.sewer_cost
                ws.cell(row=row_index, column=11).value = ken.park_facility_code
                ws.cell(row=row_index, column=12).value = ken.hojo_chitan_cost

        ### 2 全国_工種区分別_事業区分別_被害額_合計
        for i, zenkoku in enumerate(zenkoku_list):
            ### 全国_直轄事業
            row_index += 1
            ws.cell(row=row_index, column=1).value = '全国'
            ws.cell(row=row_index, column=2).value = '直轄事業'
            ws.cell(row=row_index, column=3).value = ''
            ws.cell(row=row_index, column=4).value = ''
            ws.cell(row=row_index, column=5).value = ''
            ws.cell(row=row_index, column=6).value = ''
            ws.cell(row=row_index, column=7).value = ''
            ws.cell(row=row_index, column=8).value = ''
            ws.cell(row=row_index, column=9).value = ''
            ws.cell(row=row_index, column=10).value = ''
            ws.cell(row=row_index, column=11).value = ''
            ws.cell(row=row_index, column=12).value = ''

            ### 全国_補助事業
            row_index += 1
            ws.cell(row=row_index, column=2).value = '補助事業'
            ws.cell(row=row_index, column=3).value = ken.kasen_determined_cost
            ws.cell(row=row_index, column=4).value = ken.kaigan_port_determined_cost
            ws.cell(row=row_index, column=5).value = ken.sabou_determined_cost
            ws.cell(row=row_index, column=6).value = ken.landslide_determined_cost
            ws.cell(row=row_index, column=7).value = ken.steepslope_determined_cost
            ws.cell(row=row_index, column=8).value = ken.road_determined_cost
            ws.cell(row=row_index, column=9).value = ken.bridge_determined_cost
            ws.cell(row=row_index, column=10).value = ken.sewer_determined_cost
            ws.cell(row=row_index, column=11).value = ken.park_facility_determined_cost
            ws.cell(row=row_index, column=12).value = ken.hojo_determined_cost

            ### 全国_地方単独事業
            row_index += 1
            ws.cell(row=row_index, column=2).value = '地方単独事業'
            ws.cell(row=row_index, column=3).value = ken.kasen_estimated_cost
            ws.cell(row=row_index, column=4).value = ken.kaigan_port_estimated_cost
            ws.cell(row=row_index, column=5).value = ken.sabou_estimated_cost
            ws.cell(row=row_index, column=6).value = ken.landslide_estimated_cost
            ws.cell(row=row_index, column=7).value = ken.steepslope_estimated_cost
            ws.cell(row=row_index, column=8).value = ken.road_estimated_cost
            ws.cell(row=row_index, column=9).value = ken.bridge_estimated_cost
            ws.cell(row=row_index, column=10).value = ken.sewer_estimated_cost
            ws.cell(row=row_index, column=11).value = ken.park_facility_estimated_cost
            ws.cell(row=row_index, column=12).value = ken.chitan_estimated_cost

            ### 全国_計
            row_index += 1
            ws.cell(row=row_index, column=2).value = '計'
            ws.cell(row=row_index, column=3).value = ken.kasen_cost
            ws.cell(row=row_index, column=4).value = ken.kaigan_port_cost
            ws.cell(row=row_index, column=5).value = ken.sabou_cost
            ws.cell(row=row_index, column=6).value = ken.landslide_cost
            ws.cell(row=row_index, column=7).value = ken.steepslope_cost
            ws.cell(row=row_index, column=8).value = ken.road_cost
            ws.cell(row=row_index, column=9).value = ken.bridge_cost
            ws.cell(row=row_index, column=10).value = ken.sewer_cost
            ws.cell(row=row_index, column=11).value = ken.park_facility_code
            ws.cell(row=row_index, column=12).value = ken.hojo_chitan_cost
        
        wb.save(download_file_path)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0700EStat.hyo08_download_view()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0700EStat.hyo08_download_view()関数が正常終了しました。', 'INFO')
        response = HttpResponse(content=save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="hyo08.xlsx"'
        return response
        
    except:
        print_log('[ERROR] P0700EStat.hyo08_download_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo08_download_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0700EStat.hyo08_download_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0700EStat/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
