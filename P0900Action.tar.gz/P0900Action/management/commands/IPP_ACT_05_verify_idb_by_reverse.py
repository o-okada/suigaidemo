###############################################################################
### ファイル名：P0900Action/management/commands/action_A05_verify_idb_by_reverse.py
### 自動集計・自動検証_逆計算による検証
###############################################################################

from django.core.management.base import BaseCommand

import sys
from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from MessageQueue.views import get_message 
from MessageQueue.views import publish_message 
from MessageQueue.views import publish_consume_message 
from MessageQueue.views import consume_message 
from MessageQueue.views import delete_message 

_A03 = 'A03'
_A04 = 'A04'
_A05 = 'A05'
_A06 = 'A06'
_A07 = 'A07'
_A08 = 'A08'
_A09 = 'A09'
_A10 = 'A10'
_A99 = 'A99'

_WAITING = 'WAITING'
_RUNNING = 'RUNNING'
_SUCCESS = 'SUCCESS'
_FAILURE = 'FAILURE'
_CANCEL = 'CANCEL'

###############################################################################
### クラス名：Command(BaseCommand)
### (1)家屋被害額 = 延床面積 x 家屋評価額 x 浸水または土砂ごとの勾配差による被害率
### (2)家庭用品自動車以外被害額 = 世帯数 x 浸水または土砂ごとの家庭用品被害率 x 家庭用品自動車以外所有額
### (3)家庭用品自動車被害額 = 世帯数 x 自動車被害率 x 家庭用品自動車所有額
### (4)家庭応急対策費 = (世帯数 x 活動費) + (世帯数 x 清掃日数 x 清掃労働単価)
### (5)事業所被害額 = 従業者数 x 産業分類ごとの償却資産 x 浸水または土砂ごとの被害率 + 
### 　　　　　　　　　従業者数 x 産業分類ごとの在庫資産 x 浸水または土砂ごとの被害率
### (6)事業所営業損失額 = 従業者数 x (営業停止日数 + 停滞日数/2) x 付加価値額
### (7)農漁家被害額 = 農漁家戸数 x 農漁家の償却資産 x 浸水または土砂ごとの被害率 + 
###                   農漁家戸数 x 農漁家の在庫資産 x 浸水または土砂ごとの被害率
### (8)事業所応急対策費 = 事業所数 x 代替活動費
###############################################################################
class Command(BaseCommand):
    
    ###########################################################################
    ### 関数名：handle(self, *args, **options)
    ### チェックOKの場合、トリガーの状態を成功に更新、消費日時をカレントに更新、新たなトリガーを生成する。
    ### チェックNGの場合、トリガーの状態を失敗に更新、消費日時をカレントに更新する。
    ### チェックNGの場合、当該水害IDについて、以降の処理を止めて、手動？で再実行、または、入力データから再登録するイメージである。
    ### 上記は、このアプリの共通の考え方とする。
    ###########################################################################
    def handle(self, *args, **options):
        try:
            ###################################################################
            ### 引数チェック処理(0000)
            ### コマンドラインからの引数をチェックする。
            ###################################################################
            reset_log()
            print_log('[INFO] action_A05_verify_idb_by_reverse.handle()関数が開始しました。', 'INFO')
            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 STEP 1/8.', 'DEBUG')
    
            ###################################################################
            ### DBアクセス処理(0010)
            ### メッセージキューから当該アクションが対象とするメッセージを取得する。
            ### ※ネストを浅くするため、メッセージが発行されていなければ、処理を終了する。
            ###################################################################
            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 STEP 2/8.', 'DEBUG')
            metadata = dict({
                'action_code': _A05, 
                'status_code': ''
            })
            bool_return, ippan_trigger_list = get_message(metadata=metadata)
            if bool_return == False:
                print_log('[WARN] get_message()関数が警告終了しました。', 'WARN')
                return 4

            if bool(ippan_trigger_list) == False:
                print_log('[INFO] action_A05_verify_idb_by_reverse.handle()関数が正常終了しました。', 'INFO')
                return 0

            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 ippan_trigger_list[0].ippan_trigger_id={}'.format(ippan_trigger_list[0].ippan_trigger_id), 'DEBUG')
            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 ippan_trigger_list[0].ippan_header_id={}'.format(ippan_trigger_list[0].ippan_header_id), 'DEBUG')
            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 ippan_trigger_list[0].city_code={}'.format(ippan_trigger_list[0].city_code), 'DEBUG')
            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 ippan_trigger_list[0].ken_code={}'.format(ippan_trigger_list[0].ken_code), 'DEBUG')
            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 ippan_trigger_list[0].download_file_path={}'.format(ippan_trigger_list[0].download_file_path), 'DEBUG')
            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 ippan_trigger_list[0].download_file_name={}'.format(ippan_trigger_list[0].download_file_name), 'DEBUG')
            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 ippan_trigger_list[0].upload_file_path={}'.format(ippan_trigger_list[0].upload_file_path), 'DEBUG')
            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 ippan_trigger_list[0].upload_file_name={}'.format(ippan_trigger_list[0].upload_file_name), 'DEBUG')
            
            ###################################################################
            ### DBアクセス処理(0020)
            ### (1)IPPAN_VIEWテーブルにアクセスして、按分計算結果から被害建物棟数等の逆計算結果を取得する。
            ### (2)被害建物の延床面積(入力DB)から逆計算により被害建物棟数を求めた結果
            ### (3)被災世帯数(入力DB)から逆計算により被害建物棟数を求めた結果
            ### (4)被災事業所数(入力DB)から逆計算により被害建物棟数を求めた結果
            ### トリガメッセージにアクションが発行されていなければ、処理を終了する。
            ### ※ネストを浅くするために、処理対象外の場合、処理を終了させる。
            ###################################################################
            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 STEP 3/8.', 'DEBUG')
            params = dict({
                'IPPAN_HEADER_ID': ippan_trigger_list[0].ippan_header_id
            })
            ippan_reverse_list = IPPAN_VIEW.objects.raw("""
                SELECT 
                    IV1.ippan_id, 
                    IV1.ippan_name, 
                    IV1.ippan_header_id, 
                    IV1.ippan_header_name, 
                    IV1.ken_code, 
                    -- IV1.ken_name, 
                    IV1.city_code, 
                    -- IV1.city_name, 
                    TO_CHAR(timezone('JST', IV1.begin_date::timestamptz), 'yyyy/mm/dd') AS begin_date, 
                    TO_CHAR(timezone('JST', IV1.end_date::timestamptz), 'yyyy/mm/dd') AS end_date, 
                    IV1.cause_1_code, 
                    -- IV1.cause_1_name, 
                    IV1.cause_2_code, 
                    -- IV1.cause_2_name, 
                    IV1.cause_3_code, 
                    -- IV1.cause_3_name, 
                    IV1.area_id, 
                    -- IV1.area_name, 
                    IV1.suikei_code, 
                    -- IV1.suikei_name, 
                    IV1.suikei_type_code, 
                    -- IV1.suikei_type_name, 
                    IV1.kasen_code, 
                    -- IV1.kasen_name, 
                    IV1.kasen_type_code, 
                    -- IV1.kasen_type_name, 
                    IV1.gradient_code, 
                    -- IV1.gradient_name, 
                    CASE WHEN (IV1.residential_area) IS NULL THEN 0 ELSE CAST(IV1.residential_area AS NUMERIC(20,10)) END AS residential_area, 
                    CASE WHEN (IV1.agricultural_area) IS NULL THEN 0 ELSE CAST(IV1.agricultural_area AS NUMERIC(20,10)) END AS agricultural_area, 
                    CASE WHEN (IV1.underground_area) IS NULL THEN 0 ELSE CAST(IV1.underground_area AS NUMERIC(20,10)) END AS underground_area, 
                    IV1.kasen_kaigan_code, 
                    -- IV1.kasen_kaigan_name, 
                    CASE WHEN (IV1.crop_damage) IS NULL THEN 0 ELSE CAST(IV1.crop_damage AS NUMERIC(20,10)) END AS crop_damage, 
                    IV1.weather_id, 
                    -- IV1.weather_name, 
                    -- IV1.upload_file_path, 
                    -- IV1.upload_file_name, 
                    -- IV1.summary_file_path, 
                    -- IV1.summary_file_name, 
                    IV1.building_code, 
                    -- IV1.building_name, 
                    IV1.underground_code, 
                    -- IV1.underground_name, 
                    IV1.flood_sediment_code, 
                    -- IV1.flood_sediment_name, 
                    CASE WHEN (IV1.building_lv00) IS NULL THEN 0 ELSE CAST(IV1.building_lv00 AS NUMERIC(20,10)) END AS building_lv00, 
                    CASE WHEN (IV1.building_lv01_49) IS NULL THEN 0 ELSE CAST(IV1.building_lv01_49 AS NUMERIC(20,10)) END AS building_lv01_49, 
                    CASE WHEN (IV1.building_lv50_99) IS NULL THEN 0 ELSE CAST(IV1.building_lv50_99 AS NUMERIC(20,10)) END AS building_lv50_99, 
                    CASE WHEN (IV1.building_lv100) IS NULL THEN 0 ELSE CAST(IV1.building_lv100 AS NUMERIC(20,10)) END AS building_lv100, 
                    CASE WHEN (IV1.building_half) IS NULL THEN 0 ELSE CAST(IV1.building_half AS NUMERIC(20,10)) END AS building_half, 
                    CASE WHEN (IV1.building_full) IS NULL THEN 0 ELSE CAST(IV1.building_full AS NUMERIC(20,10)) END AS building_full, 
                    CASE WHEN (IV1.building_total) IS NULL THEN 0 ELSE CAST(IV1.building_total AS NUMERIC(20,10)) END AS building_total, 
                    CASE WHEN (IV1.floor_area) IS NULL THEN 0 ELSE CAST(IV1.floor_area AS NUMERIC(20,10)) END AS floor_area, 
                    CASE WHEN (IV1.family) IS NULL THEN 0 ELSE CAST(IV1.family AS NUMERIC(20,10)) END AS family, 
                    CASE WHEN (IV1.office) IS NULL THEN 0 ELSE CAST(IV1.office AS NUMERIC(20,10)) END AS office, 
                    CASE WHEN (IV1.floor_area_lv00) IS NULL THEN 0 ELSE CAST(IV1.floor_area_lv00 AS NUMERIC(20,10)) END AS floor_area_lv00, 
                    CASE WHEN (IV1.floor_area_lv01_49) IS NULL THEN 0 ELSE CAST(IV1.floor_area_lv01_49 AS NUMERIC(20,10)) END AS floor_area_lv01_49, 
                    CASE WHEN (IV1.floor_area_lv50_99) IS NULL THEN 0 ELSE CAST(IV1.floor_area_lv50_99 AS NUMERIC(20,10)) END AS floor_area_lv50_99, 
                    CASE WHEN (IV1.floor_area_lv100) IS NULL THEN 0 ELSE CAST(IV1.floor_area_lv100 AS NUMERIC(20,10)) END AS floor_area_lv100, 
                    CASE WHEN (IV1.floor_area_half) IS NULL THEN 0 ELSE CAST(IV1.floor_area_half AS NUMERIC(20,10)) END AS floor_area_half, 
                    CASE WHEN (IV1.floor_area_full) IS NULL THEN 0 ELSE CAST(IV1.floor_area_full AS NUMERIC(20,10)) END AS floor_area_full, 
                    CASE WHEN (IV1.floor_area_total) IS NULL THEN 0 ELSE CAST(IV1.floor_area_total AS NUMERIC(20,10)) END AS floor_area_total, 
                    CASE WHEN (IV1.family_lv00) IS NULL THEN 0 ELSE CAST(IV1.family_lv00 AS NUMERIC(20,10)) END AS family_lv00, 
                    CASE WHEN (IV1.family_lv01_49) IS NULL THEN 0 ELSE CAST(IV1.family_lv01_49 AS NUMERIC(20,10)) END AS family_lv01_49, 
                    CASE WHEN (IV1.family_lv50_99) IS NULL THEN 0 ELSE CAST(IV1.family_lv50_99 AS NUMERIC(20,10)) END AS family_lv50_99, 
                    CASE WHEN (IV1.family_lv100) IS NULL THEN 0 ELSE CAST(IV1.family_lv100 AS NUMERIC(20,10)) END AS family_lv100, 
                    CASE WHEN (IV1.family_half) IS NULL THEN 0 ELSE CAST(IV1.family_half AS NUMERIC(20,10)) END AS family_half, 
                    CASE WHEN (IV1.family_full) IS NULL THEN 0 ELSE CAST(IV1.family_full AS NUMERIC(20,10)) END AS family_full, 
                    CASE WHEN (IV1.family_total) IS NULL THEN 0 ELSE CAST(IV1.family_total AS NUMERIC(20,10)) END AS family_total, 
                    CASE WHEN (IV1.office_lv00) IS NULL THEN 0 ELSE CAST(IV1.office_lv00 AS NUMERIC(20,10)) END AS office_lv00, 
                    CASE WHEN (IV1.office_lv01_49) IS NULL THEN 0 ELSE CAST(IV1.office_lv01_49 AS NUMERIC(20,10)) END AS office_lv01_49, 
                    CASE WHEN (IV1.office_lv50_99) IS NULL THEN 0 ELSE CAST(IV1.office_lv50_99 AS NUMERIC(20,10)) END AS office_lv50_99, 
                    CASE WHEN (IV1.office_lv100) IS NULL THEN 0 ELSE CAST(IV1.office_lv100 AS NUMERIC(20,10)) END AS office_lv100, 
                    CASE WHEN (IV1.office_half) IS NULL THEN 0 ELSE CAST(IV1.office_half AS NUMERIC(20,10)) END AS office_half, 
                    CASE WHEN (IV1.office_full) IS NULL THEN 0 ELSE CAST(IV1.office_full AS NUMERIC(20,10)) END AS office_full, 
                    CASE WHEN (IV1.office_total) IS NULL THEN 0 ELSE CAST(IV1.office_total AS NUMERIC(20,10)) END AS office_total, 
                    CASE WHEN (IV1.farmer_fisher_lv00) IS NULL THEN 0 ELSE CAST(IV1.farmer_fisher_lv00 AS NUMERIC(20,10)) END AS farmer_fisher_lv00, 
                    CASE WHEN (IV1.farmer_fisher_lv01_49) IS NULL THEN 0 ELSE CAST(IV1.farmer_fisher_lv01_49 AS NUMERIC(20,10)) END AS farmer_fisher_lv01_49, 
                    CASE WHEN (IV1.farmer_fisher_lv50_99) IS NULL THEN 0 ELSE CAST(IV1.farmer_fisher_lv50_99 AS NUMERIC(20,10)) END AS farmer_fisher_lv50_99, 
                    CASE WHEN (IV1.farmer_fisher_lv100) IS NULL THEN 0 ELSE CAST(IV1.farmer_fisher_lv100 AS NUMERIC(20,10)) END AS farmer_fisher_lv100, 
                    -- CASE WHEN (IV1.farmer_fisher_half) IS NULL THEN 0 ELSE CAST(IV1.farmer_fisher_half AS NUMERIC(20,10)) END AS farmer_fisher_half, 
                    CASE WHEN (IV1.farmer_fisher_full) IS NULL THEN 0 ELSE CAST(IV1.farmer_fisher_full AS NUMERIC(20,10)) END AS farmer_fisher_full, 
                    CASE WHEN (IV1.farmer_fisher_total) IS NULL THEN 0 ELSE CAST(IV1.farmer_fisher_total AS NUMERIC(20,10)) END AS farmer_fisher_total, 
                    CASE WHEN (IV1.employee_lv00) IS NULL THEN 0 ELSE CAST(IV1.employee_lv00 AS NUMERIC(20,10)) END AS employee_lv00, 
                    CASE WHEN (IV1.employee_lv01_49) IS NULL THEN 0 ELSE CAST(IV1.employee_lv01_49 AS NUMERIC(20,10)) END AS employee_lv01_49, 
                    CASE WHEN (IV1.employee_lv50_99) IS NULL THEN 0 ELSE CAST(IV1.employee_lv50_99 AS NUMERIC(20,10)) END AS employee_lv50_99, 
                    CASE WHEN (IV1.employee_lv100) IS NULL THEN 0 ELSE CAST(IV1.employee_lv100 AS NUMERIC(20,10)) END AS employee_lv100, 
                    -- CASE WHEN (IV1.employee_half) IS NULL THEN 0 ELSE CAST(IV1.employee_half AS NUMERIC(20,10)) END AS employee_half, 
                    CASE WHEN (IV1.employee_full) IS NULL THEN 0 ELSE CAST(IV1.employee_full AS NUMERIC(20,10)) END AS employee_full,
                    CASE WHEN (IV1.employee_total) IS NULL THEN 0 ELSE CAST(IV1.employee_total AS NUMERIC(20,10)) END AS employee_total, 
                    IV1.industry_code, 
                    -- IV1.industry_name, 
                    IV1.usage_code,
                    -- IV1.usage_name, 
                    IV1.comment, 
                    TO_CHAR(timezone('JST', IV1.committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                    TO_CHAR(timezone('JST', IV1.deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at, 
                    -- 被害建物の延床面積(入力DB)から逆計算により被害建物棟数を求めた結果
                    CASE WHEN ABS(IV1.floor_area_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.floor_area_lv00 / IV1.floor_area_total AS NUMERIC(20,10)) END AS building_lv00_reverse_floor_area, 
                    CASE WHEN ABS(IV1.floor_area_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.floor_area_lv01_49 / IV1.floor_area_total AS NUMERIC(20,10)) END AS building_lv01_49_reverse_floor_area, 
                    CASE WHEN ABS(IV1.floor_area_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.floor_area_lv50_99 / IV1.floor_area_total AS NUMERIC(20,10)) END AS building_lv50_99_reverse_floor_area, 
                    CASE WHEN ABS(IV1.floor_area_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.floor_area_lv100 / IV1.floor_area_total AS NUMERIC(20,10)) END AS building_lv100_reverse_floor_area, 
                    CASE WHEN ABS(IV1.floor_area_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.floor_area_half / IV1.floor_area_total AS NUMERIC(20,10)) END AS building_half_reverse_floor_area, 
                    CASE WHEN ABS(IV1.floor_area_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.floor_area_full / IV1.floor_area_total AS NUMERIC(20,10)) END AS building_full_reverse_floor_area, 
                    -- 被災世帯数(入力DB)から逆計算により被害建物棟数を求めた結果
                    CASE WHEN ABS(IV1.family_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.family_lv00 / IV1.family_total AS NUMERIC(20,10)) END AS building_lv00_reverse_family, 
                    CASE WHEN ABS(IV1.family_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.family_lv01_49 / IV1.family_total AS NUMERIC(20,10)) END AS building_lv01_49_reverse_family, 
                    CASE WHEN ABS(IV1.family_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.family_lv50_99 / IV1.family_total AS NUMERIC(20,10)) END AS building_lv50_99_reverse_family, 
                    CASE WHEN ABS(IV1.family_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.family_lv100 / IV1.family_total AS NUMERIC(20,10)) END AS building_lv100_reverse_family, 
                    CASE WHEN ABS(IV1.family_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.family_half / IV1.family_total AS NUMERIC(20,10)) END AS building_half_reverse_family, 
                    CASE WHEN ABS(IV1.family_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.family_full / IV1.family_total AS NUMERIC(20,10)) END AS building_full_reverse_family, 
                    -- 被災事業所数(入力DB)から逆計算により被害建物棟数を求めた結果
                    CASE WHEN ABS(IV1.office_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.office_lv00 / IV1.office_total AS NUMERIC(20,10)) END AS building_lv00_reverse_office, 
                    CASE WHEN ABS(IV1.office_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.office_lv01_49 / IV1.office_total AS NUMERIC(20,10)) END AS building_lv01_49_reverse_office, 
                    CASE WHEN ABS(IV1.office_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.office_lv50_99 / IV1.office_total AS NUMERIC(20,10)) END AS building_lv50_99_reverse_office, 
                    CASE WHEN ABS(IV1.office_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.office_lv100 / IV1.office_total AS NUMERIC(20,10)) END AS building_lv100_reverse_office, 
                    CASE WHEN ABS(IV1.office_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.office_half / IV1.office_total AS NUMERIC(20,10)) END AS building_half_reverse_office, 
                    CASE WHEN ABS(IV1.office_total) <= 0.0000001 THEN 0 ELSE CAST(IV1.building_total * IV1.office_full / IV1.office_total AS NUMERIC(20,10)) END AS building_full_reverse_office 
                FROM IPPAN_VIEW IV1 
                WHERE 
                    IV1.ippan_header_id=%(IPPAN_HEADER_ID)s AND 
                    IV1.deleted_at IS NULL 
                ORDER BY 
                    CAST(IV1.ippan_id AS INTEGER)""", params)

            if bool(ippan_reverse_list) == False:
                print_log('[WARN] action_A05_verify_idb_by_reverse.handle()関数が警告終了しました。', 'WARN')
                return 4
    
            ###################################################################
            ### 検証処理(0030)
            ### 成功、失敗の行数、レコード数をカウントする。
            ### 成功:按分計算結果から逆計算した結果と入力DBに登録されている被害建物棟数が同じ場合、成功とする。
            ### 失敗:按分計算結果から逆計算した結果と入力DBに登録されている被害建物棟数が異なる場合、失敗とする。
            ### 検証の心臓部
            ###################################################################
            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 STEP 4/8.', 'DEBUG')
            info_count = 0
            warn_count = 0
                
            for ippan in ippan_reverse_list:
                ###############################################################
                ### 検証処理(0040)
                ### 被害建物の延床面積(入力DB)から逆計算により被害建物棟数を求めた結果
                ###############################################################
                print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 STEP 4_1/8.', 'DEBUG')
                if (bool(str(ippan.building_lv00_reverse_floor_area)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv00_reverse_floor_area={}'.format(ippan.building_lv00_reverse_floor_area), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv00={}'.format(ippan.building_lv00), 'DEBUG')
                    ### print_log('abs(float(ippan.building_lv00_reverse_floor_area) - float(ippan.building_lv00))={}'.format(abs(float(ippan.building_lv00_reverse_floor_area) - float(ippan.building_lv00))), 'DEBUG')
                    if abs(float(ippan.building_lv00_reverse_floor_area) - float(ippan.building_lv00)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_lv00 {0} {1}'.format(ippan.building_lv00_reverse_floor_area, ippan.building_lv00), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_lv01_49_reverse_floor_area)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv01_49_reverse_floor_area={}'.format(ippan.building_lv01_49_reverse_floor_area), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv01_49={}'.format(ippan.building_lv01_49), 'DEBUG')
                    ### print_log('abs(float(ippan.building_lv01_49_reverse_floor_area) - float(ippan.building_lv01_49))={}'.format(abs(float(ippan.building_lv01_49_reverse_floor_area) - float(ippan.building_lv01_49))), 'DEBUG')
                    if abs(float(ippan.building_lv01_49_reverse_floor_area) - float(ippan.building_lv01_49)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_lv01_49 {0} {1}'.format(ippan.building_lv01_49_reverse_floor_area, ippan.building_lv01_49), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_lv50_99_reverse_floor_area)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv50_99_reverse_floor_area={}'.format(ippan.building_lv50_99_reverse_floor_area), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv50_99={}'.format(ippan.building_lv50_99), 'DEBUG')
                    ### print_log('abs(float(ippan.building_lv50_99_reverse_floor_area) - float(ippan.building_lv50_99))={}'.format(abs(float(ippan.building_lv50_99_reverse_floor_area) - float(ippan.building_lv50_99))), 'DEBUG')
                    if abs(float(ippan.building_lv50_99_reverse_floor_area) - float(ippan.building_lv50_99)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_lv50_99 {0} {1}'.format(ippan.building_lv50_99_reverse_floor_area, ippan.building_lv50_99), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_lv100_reverse_floor_area)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv100_reverse_floor_area={}'.format(ippan.building_lv100_reverse_floor_area), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv100={}'.format(ippan.building_lv100), 'DEBUG')
                    ### print_log('abs(float(ippan.building_lv100_reverse_floor_area) - float(ippan.building_lv100))={}'.format(abs(float(ippan.building_lv100_reverse_floor_area) - float(ippan.building_lv100))), 'DEBUG')
                    if abs(float(ippan.building_lv100_reverse_floor_area) - float(ippan.building_lv100)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_lv100 {0} {1}'.format(ippan.building_lv100_reverse_floor_area, ippan.building_lv100), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_half_reverse_floor_area)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_half_reverse_floor_area={}'.format(ippan.building_half_reverse_floor_area), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_half={}'.format(ippan.building_half), 'DEBUG')
                    ### print_log('abs(float(ippan.building_half_reverse_floor_area) - float(ippan.building_half))={}'.format(abs(float(ippan.building_half_reverse_floor_area) - float(ippan.building_half))), 'DEBUG')
                    if abs(float(ippan.building_half_reverse_floor_area) - float(ippan.building_half)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_half {0} {1}'.format(ippan.building_half_reverse_floor_area, ippan.building_half), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_full_reverse_floor_area)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_full_reverse_floor_area={}'.format(ippan.building_full_reverse_floor_area), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_full={}'.format(ippan.building_full), 'DEBUG')
                    ### print_log('abs(float(ippan.building_full_reverse_floor_area) - float(ippan.building_full))={}'.format(abs(float(ippan.building_full_reverse_floor_area) - float(ippan.building_full))), 'DEBUG')
                    if abs(float(ippan.building_full_reverse_floor_area) - float(ippan.building_full)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_full {0} {1}'.format(ippan.building_full_reverse_floor_area, ippan.building_full), 'WARN')
                        warn_count += 1

                ###############################################################
                ### 検証処理(0050)
                ### 被災世帯数(入力DB)から逆計算により被害建物棟数を求めた結果
                ###############################################################
                print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 STEP 4_2/8.', 'DEBUG')
                if (bool(str(ippan.building_lv00_reverse_family)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv00_reverse_family={}'.format(ippan.building_lv00_reverse_family), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv00={}'.format(ippan.building_lv00), 'DEBUG')
                    ### print_log('abs(float(ippan.building_lv00_reverse_family) - float(ippan.building_lv00))={}'.format(abs(float(ippan.building_lv00_reverse_family) - float(ippan.building_lv00))), 'DEBUG')
                    if abs(float(ippan.building_lv00_reverse_family) - float(ippan.building_lv00)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_lv00 {0} {1}'.format(ippan.building_lv00_reverse_family, ippan.building_lv00), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_lv01_49_reverse_family)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv01_49_reverse_family={}'.format(ippan.building_lv01_49_reverse_family), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv01_49={}'.format(ippan.building_lv01_49), 'DEBUG')
                    ### print_log('abs(float(ippan.building_lv01_49_reverse_family) - float(ippan.building_lv01_49))={}'.format(abs(float(ippan.building_lv01_49_reverse_family) - float(ippan.building_lv01_49))), 'DEBUG')
                    if abs(float(ippan.building_lv01_49_reverse_family) - float(ippan.building_lv01_49)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_lv01_49 {0} {1}'.format(ippan.building_lv01_49_reverse_family, ippan.building_lv01_49), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_lv50_99_reverse_family)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv50_99_reverse_family={}'.format(ippan.building_lv50_99_reverse_family), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv50_99={}'.format(ippan.building_lv50_99), 'DEBUG')
                    ### print_log('abs(float(ippan.building_lv50_99_reverse_family) - float(ippan.building_lv50_99))={}'.format(abs(float(ippan.building_lv50_99_reverse_family) - float(ippan.building_lv50_99))), 'DEBUG')
                    if abs(float(ippan.building_lv50_99_reverse_family) - float(ippan.building_lv50_99)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_lv50_99 {0} {1}'.format(ippan.building_lv50_99_reverse_family, ippan.building_lv50_99), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_lv100_reverse_family)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv100_reverse_family={}'.format(ippan.building_lv100_reverse_family), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv100={}'.format(ippan.building_lv100), 'DEBUG')
                    ### print_log('abs(float(ippan.building_lv100_reverse_family) - float(ippan.building_lv100))={}'.format(abs(float(ippan.building_lv100_reverse_family) - float(ippan.building_lv100))), 'DEBUG')
                    if abs(float(ippan.building_lv100_reverse_family) - float(ippan.building_lv100)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_lv100 {0} {1}'.format(ippan.building_lv100_reverse_family, ippan.building_lv100), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_half_reverse_family)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_half_reverse_family={}'.format(ippan.building_half_reverse_family), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_half={}'.format(ippan.building_half), 'DEBUG')
                    ### print_log('abs(float(ippan.building_half_reverse_family) - float(ippan.building_half))={}'.format(abs(float(ippan.building_half_reverse_family) - float(ippan.building_half))), 'DEBUG')
                    if abs(float(ippan.building_half_reverse_family) - float(ippan.building_half)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_half {0} {1}'.format(ippan.building_half_reverse_family, ippan.building_half), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_full_reverse_family)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_full_reverse_family={}'.format(ippan.building_full_reverse_family), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_full={}'.format(ippan.building_full), 'DEBUG')
                    ### print_log('abs(float(ippan.building_full_reverse_family) - float(ippan.building_full))={}'.format(abs(float(ippan.building_full_reverse_family) - float(ippan.building_full))), 'DEBUG')
                    if abs(float(ippan.building_full_reverse_family) - float(ippan.building_full)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_full {0} {1}'.format(ippan.building_full_reverse_family, ippan.building_full), 'WARN')
                        warn_count += 1

                ###############################################################
                ### 検証処理(0060)
                ### 被災事業所数(入力DB)から逆計算により被害建物棟数を求めた結果
                ###############################################################
                print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 STEP 4_3/8.', 'DEBUG')
                if (bool(str(ippan.building_lv00_reverse_office)) == True): 
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv00_reverse_office={}'.format(ippan.building_lv00_reverse_office), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv00={}'.format(ippan.building_lv00), 'DEBUG')
                    ### print_log('abs(float(ippan.building_lv00_reverse_office) - float(ippan.building_lv00))={}'.format(abs(float(ippan.building_lv00_reverse_office) - float(ippan.building_lv00))), 'DEBUG')
                    if abs(float(ippan.building_lv00_reverse_office) - float(ippan.building_lv00)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_lv00 {0} {1}'.format(ippan.building_lv00_reverse_office, ippan.building_lv00), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_lv01_49_reverse_office)) == True): 
                    ### print_log('[DEBUG] P0900Action.action_A05_verify_idb_by_reverse.handle()関数 building_lv01_49_reverse_office={}'.format(ippan.building_lv01_49_reverse_office), 'DEBUG')
                    ### print_log('[DEBUG] P0900Action.action_A05_verify_idb_by_reverse.handle()関数 building_lv01_49={}'.format(ippan.building_lv01_49), 'DEBUG')
                    ### print_log('abs(float(ippan.building_lv01_49_reverse_office) - float(ippan.building_lv01_49))={}'.format(abs(float(ippan.building_lv01_49_reverse_office) - float(ippan.building_lv01_49))), 'DEBUG')
                    if abs(float(ippan.building_lv01_49_reverse_office) - float(ippan.building_lv01_49)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_lv01_49 {0} {1}'.format(ippan.building_lv01_49_reverse_office, ippan.building_lv01_49), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_lv50_99_reverse_office)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv50_99_reverse_office={}'.format(ippan.building_lv50_99_reverse_office), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv50_99={}'.format(ippan.building_lv50_99), 'DEBUG')
                    ### print_log('abs(float(ippan.building_lv50_99_reverse_office) - float(ippan.building_lv50_99))={}'.format(abs(float(ippan.building_lv50_99_reverse_office) - float(ippan.building_lv50_99))), 'DEBUG')
                    if abs(float(ippan.building_lv50_99_reverse_office) - float(ippan.building_lv50_99)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_lv50_99 {0} {1}'.format(ippan.building_lv50_99_reverse_office, ippan.building_lv50_99), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_lv100_reverse_office)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv100_reverse_office={}'.format(ippan.building_lv100_reverse_office), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_lv100={}'.format(ippan.building_lv100), 'DEBUG')
                    ### print_log('abs(float(ippan.building_lv100_reverse_office) - float(ippan.building_lv100))={}'.format(abs(float(ippan.building_lv100_reverse_office) - float(ippan.building_lv100))), 'DEBUG')
                    if abs(float(ippan.building_lv100_reverse_office) - float(ippan.building_lv100)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_lv100 {0} {1}'.format(ippan.building_lv100_reverse_office, ippan.building_lv100), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_half_reverse_office)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_half_reverse_office={}'.format(ippan.building_half_reverse_office), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_half={}'.format(ippan.building_half), 'DEBUG')
                    ### print_log('abs(float(ippan.building_half_reverse_office) - float(ippan.building_half))={}'.format(abs(float(ippan.building_half_reverse_office) - float(ippan.building_half))), 'DEBUG')
                    if abs(float(ippan.building_half_reverse_office) - float(ippan.building_half)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_half {0} {1}'.format(ippan.building_half_reverse_office, ippan.building_half), 'WARN')
                        warn_count += 1
                        
                if (bool(str(ippan.building_full_reverse_office)) == True):
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_full_reverse_office={}'.format(ippan.building_full_reverse_office), 'DEBUG')
                    ### print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 building_full={}'.format(ippan.building_full), 'DEBUG')
                    ### print_log('abs(float(ippan.building_full_reverse_office) - float(ippan.building_full))={}'.format(abs(float(ippan.building_full_reverse_office) - float(ippan.building_full))), 'DEBUG')
                    if abs(float(ippan.building_full_reverse_office) - float(ippan.building_full)) <= 1e-7:
                        info_count += 1
                    else:
                        print_log('[WARN] building_full {0} {1}'.format(ippan.building_full_reverse_office, ippan.building_full), 'WARN')
                        warn_count += 1

            ################################################################### 
            ### DBアクセス処理(0070)
            ### 当該トリガーの実行が終了したため、当該トリガーの状態、成功数、失敗数等を更新する。
            ################################################################### 
            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 STEP 5/8.', 'DEBUG')
            ### 成功
            ### if warn_count == 0:
            ###     print_log('[INFO] info_count={}'.format(info_count), 'INFO')
            ###     print_log('[INFO] warn_count={}'.format(warn_count), 'INFO')
            ### 失敗
            ### else:
            ###     print_log('[WARN] info_count={}'.format(info_count), 'WARN')
            ###     print_log('[WARN] warn_count={}'.format(warn_count), 'WARN')

            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")
                
                ###############################################################
                ### DBアクセス処理(0070)
                ### トリガーデータを更新する。
                ###############################################################
                print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 STEP 6/8.', 'DEBUG')
                ### 成功
                if warn_count == 0:
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'trigger_id': ippan_trigger_list[0].ippan_trigger_id, 
                        'action_code': _A05, 
                        'status_code': _SUCCESS, 
                        'info_count': info_count, 
                        'warn_count': warn_count, 
                        'info_log': get_info_log(), 
                        'warn_log': get_warn_log()
                    })
                    bool_return = consume_message(metadata=metadata)
                    if bool_return == False:
                        print_log('[WARN] consume_message()関数が警告終了しました。', 'WARN')
                        connection_cursor.execute("""ROLLBACK""")
                        return 4
                        
                ### 失敗
                else:
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'trigger_id': ippan_trigger_list[0].ippan_trigger_id, 
                        'action_code': _A05, 
                        'status_code': _FAILURE, 
                        'info_count': info_count, 
                        'warn_count': warn_count, 
                        'info_log': get_info_log(), 
                        'warn_log': get_warn_log()
                    })
                    bool_return = consume_message(metadata=metadata)
                    if bool_return == False:
                        print_log('[WARN] consume_message()関数が警告終了しました。', 'WARN')
                        connection_cursor.execute("""ROLLBACK""")
                        return 4
    
                ###############################################################
                ### DBアクセス処理(0080)
                ### (1)成功の場合は、次のトリガーを発行する。
                ### (2)失敗の場合は、次のトリガーを発行しない。
                ###############################################################
                print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 STEP 7/9.', 'DEBUG')
                ### 成功
                if warn_count == 0:
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'header_id': ippan_trigger_list[0].ippan_header_id, 
                        'ken_code': ippan_trigger_list[0].ken_code, 
                        'city_code': ippan_trigger_list[0].city_code, 
                        'action_code': _A06, 
                        'upload_file_path': ippan_trigger_list[0].upload_file_path, 
                        'upload_file_name' ippan_trigger_list[0].upload_file_name
                    })
                    bool_return = publish_message(metadata=metadata)
                    if bool_return == False:
                        print_log('[WARN] publish_message()関数が警告終了しました。', 'WARN')
                        connection_cursor.execute("""ROLLBACK""")
                        return 4
                        
                connection_cursor.execute("""COMMIT""")
                
            except:
                print_log('[ERROR] action_A05_verify_idb_by_reverse.handle()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] action_A05_verify_idb_by_reverse.handle()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
                print_log('[ERROR] action_A05_verify_idb_by_reverse.handle()関数が異常終了しました。', 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
                return 8
                
            finally:
                ### try except finallyのtry文中でreturnを発生させた場合、
                ### finally文中のconnection_cursor.close()が実行されて、
                ### その後に関数を抜ける。
                ### したがって、finally文中でreturnする必要はない。
                connection_cursor.close()
                
            ###################################################################
            ### 戻り値セット処理(0090)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] action_A05_verify_idb_by_reverse.handle()関数 STEP 8/8.', 'DEBUG')
            print_log('[INFO] action_A05_verify_idb_by_reverse.handle()関数が正常終了しました。', 'INFO')
            return 0
        
        except:
            print_log('[ERROR] action_A05_verify_idb_by_reverse.handle()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] action_A05_verify_idb_by_reverse.handle()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] action_A05_verify_idb_by_reverse.handle()関数が異常終了しました。', 'ERROR')
            return 8
            