###############################################################################
### ファイル名：P0900Action/management/commands/action_A03_verify_idb_by_diff.py
### 自動集計・自動検証_差分検証
###############################################################################

from django.core.management.base import BaseCommand

import sys
from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from MessageQueue.views import get_message 
from MessageQueue.views import publish_message 
from MessageQueue.views import publish_consume_message 
from MessageQueue.views import consume_message 
from MessageQueue.views import delete_message 

_A03 = 'A03'
_A04 = 'A04'
_A05 = 'A05'
_A06 = 'A06'
_A07 = 'A07'
_A08 = 'A08'
_A09 = 'A09'
_A10 = 'A10'
_A99 = 'A99'

_WAITING = 'WAITING'
_RUNNING = 'RUNNING'
_SUCCESS = 'SUCCESS'
_FAILURE = 'FAILURE'
_CANCEL = 'CANCEL'

class Command(BaseCommand):
    
    ###########################################################################
    ### 関数名：handle(self, *args, **options)
    ### チェックOKの場合、トリガーの状態を成功に更新、消費日時をカレントに更新、新たなトリガーを生成する。
    ### チェックNGの場合、トリガーの状態を失敗に更新、消費日時をカレントに更新する。
    ### チェックNGの場合、当該水害IDについて、以降の処理を止めて、手動？で再実行、または、入力データから再登録するイメージである。
    ### 上記は、このアプリの共通の考え方とする。
    ###########################################################################
    def handle(self, *args, **options):
        try:
            ###################################################################
            ### 引数チェック処理(0000)
            ### コマンドラインからの引数をチェックする。
            ###################################################################
            reset_log()
            print_log('[INFO] action_A03_verify_idb_by_diff.handle()関数が開始しました。', 'INFO')
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 1/14.', 'DEBUG')

            ###################################################################
            ### DBアクセス処理(0010)
            ### メッセージキューから当該アクションが対象とするメッセージを取得する。
            ### ※ネストを浅くするため、メッセージが発行されていなければ、処理を終了する。
            ###################################################################
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 2/14.', 'DEBUG')
            metadata = dict({
                'action_code': _A03, 
                'status_code': ''
            })
            bool_return, ippan_trigger_list = get_message(metadata=metadata)
            if bool_return == False:
                print_log('[WARN] get_message()関数が警告終了しました。', 'WARN')
                return 4

            if bool(ippan_trigger_list) == False:
                print_log('[INFO] action_A03_verify_idb_by_diff.handle()関数が正常終了しました。', 'INFO')
                return 0

            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ippan_trigger_list[0].ippan_trigger_id={}'.format(ippan_trigger_list[0].ippan_trigger_id), 'DEBUG')
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ippan_trigger_list[0].ippan_header_id={}'.format(ippan_trigger_list[0].ippan_header_id), 'DEBUG')
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ippan_trigger_list[0].city_code={}'.format(ippan_trigger_list[0].city_code), 'DEBUG')
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ippan_trigger_list[0].ken_code={}'.format(ippan_trigger_list[0].ken_code), 'DEBUG')
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ippan_trigger_list[0].download_file_path={}'.format(ippan_trigger_list[0].download_file_path), 'DEBUG')
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ippan_trigger_list[0].download_file_name={}'.format(ippan_trigger_list[0].download_file_name), 'DEBUG')
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ippan_trigger_list[0].upload_file_path={}'.format(ippan_trigger_list[0].upload_file_path), 'DEBUG')
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ippan_trigger_list[0].upload_file_name={}'.format(ippan_trigger_list[0].upload_file_name), 'DEBUG')

            ###################################################################
            ### DBアクセス処理(0020)
            ### DBからヘッダ部分のデータを取得する。
            ###################################################################
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 3/14.', 'DEBUG')
            params = dict({
                'IPPAN_HEADER_ID': ippan_trigger_list[0].ippan_header_id
            })
            ippan_header_list = IPPAN_HEADER.objects.raw("""
                SELECT 
                    SG1.ippan_header_id,
                    SG1.ippan_header_name,
                    SG1.ken_code, 
                    KE1.ken_name,
                    SG1.city_code,
                    CI1.city_name,
                    TO_CHAR(timezone('JST', SG1.begin_date::timestamptz), 'yyyy/mm/dd') AS begin_date,
                    TO_CHAR(timezone('JST', SG1.end_date::timestamptz), 'yyyy/mm/dd') AS end_date,
                    SG1.cause_1_code,
                    CA1.cause_name AS cause_1_name,
                    SG1.cause_2_code,
                    CA2.cause_name AS cause_2_name,
                    SG1.cause_3_code,
                    CA3.cause_name AS cause_3_name,
                    SG1.area_id,
                    AR1.area_name,
                    SG1.suikei_code,
                    SK1.suikei_name,
                    SKT1.suikei_type_code,
                    SKT1.suikei_type_name,
                    SG1.kasen_code,
                    KA1.kasen_name,
                    KAT1.kasen_type_code,
                    KAT1.kasen_type_name,
                    SG1.gradient_code,
                    GR1.gradient_name,
                    CASE WHEN (SG1.residential_area) IS NULL THEN NULL ELSE CAST(SG1.residential_area AS NUMERIC(20,10)) END AS residential_area,
                    CASE WHEN (SG1.agricultural_area) IS NULL THEN NULL ELSE CAST(SG1.agricultural_area AS NUMERIC(20,10)) END AS agricultural_area,
                    CASE WHEN (SG1.underground_area) IS NULL THEN NULL ELSE CAST(SG1.underground_area AS NUMERIC(20,10)) END AS underground_area,
                    SG1.kasen_kaigan_code,
                    KK1.kasen_kaigan_name,
                    CASE WHEN (SG1.crop_damage) IS NULL THEN NULL ELSE CAST(SG1.crop_damage AS NUMERIC(20,10)) END AS crop_damage,
                    SG1.weather_id,
                    WE1.weather_name, 
                    TO_CHAR(timezone('JST', SG1.committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                    TO_CHAR(timezone('JST', SG1.deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at, 
                    SG1.upload_file_path, 
                    SG1.upload_file_name, 
                    SG1.summary_file_path, 
                    SG1.summary_file_name 
                FROM IPPAN_HEADER SG1 
                LEFT JOIN KEN KE1 ON SG1.ken_code=KE1.ken_code 
                LEFT JOIN CITY CI1 ON SG1.city_code=CI1.city_code 
                LEFT JOIN CAUSE CA1 ON SG1.cause_1_code=CA1.cause_code 
                LEFT JOIN CAUSE CA2 ON SG1.cause_2_code=CA2.cause_code 
                LEFT JOIN CAUSE CA3 ON SG1.cause_3_code=CA3.cause_code 
                LEFT JOIN AREA AR1 ON SG1.area_id=AR1.area_id 
                LEFT JOIN SUIKEI SK1 ON SG1.suikei_code=SK1.suikei_code 
                LEFT JOIN SUIKEI_TYPE SKT1 ON SK1.suikei_type_code=SKT1.suikei_type_code 
                LEFT JOIN KASEN KA1 ON SG1.kasen_code=KA1.kasen_code 
                LEFT JOIN KASEN_TYPE KAT1 ON KA1.kasen_type_code=KAT1.kasen_type_code 
                LEFT JOIN GRADIENT GR1 ON SG1.gradient_code=GR1.gradient_code 
                LEFT JOIN KASEN_KAIGAN KK1 ON SG1.kasen_kaigan_code=KK1.kasen_kaigan_code 
                LEFT JOIN WEATHER WE1 ON SG1.weather_id=WE1.weather_id 
                WHERE 
                    SG1.ippan_header_id=%(IPPAN_HEADER_ID)s""", params)

            if bool(ippan_header_list) == False:
                print_log('[WARN] action_A05_verify_idb_by_reverse.handle()関数が警告終了しました。', 'WARN')
                return 4

            ###################################################################
            ### DBアクセス処理(0030)
            ### DBから一覧表部分のデータを取得する。
            ###################################################################
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 4/14.', 'DEBUG')
            params = dict({
                'IPPAN_HEADER_ID': ippan_trigger_list[0].ippan_header_id
            })
            ippan_list = IPPAN.objects.raw("""
                SELECT 
                    IV1.ippan_id, 
                    IV1.ippan_name, 
                    IV1.ippan_header_id, 
                    IV1.ippan_header_name, 
                    IV1.ken_code, 
                    -- IV1.ken_name, 
                    IV1.city_code, 
                    -- IV1.city_name, 
                    TO_CHAR(timezone('JST', IV1.begin_date::timestamptz), 'yyyy/mm/dd') AS begin_date, 
                    TO_CHAR(timezone('JST', IV1.end_date::timestamptz), 'yyyy/mm/dd') AS end_date, 
                    IV1.cause_1_code, 
                    -- IV1.cause_1_name, 
                    IV1.cause_2_code, 
                    -- IV1.cause_2_name, 
                    IV1.cause_3_code, 
                    -- IV1.cause_3_name, 
                    IV1.area_id, 
                    -- IV1.area_name, 
                    IV1.suikei_code, 
                    -- IV1.suikei_name, 
                    IV1.suikei_type_code, 
                    -- IV1.suikei_type_name, 
                    IV1.kasen_code, 
                    -- IV1.kasen_name, 
                    IV1.kasen_type_code, 
                    -- IV1.kasen_type_name, 
                    IV1.gradient_code, 
                    -- IV1.gradient_name, 
                    CASE WHEN (IV1.residential_area) IS NULL THEN NULL ELSE CAST(IV1.residential_area AS NUMERIC(20,10)) END AS residential_area, 
                    CASE WHEN (IV1.agricultural_area) IS NULL THEN NULL ELSE CAST(IV1.agricultural_area AS NUMERIC(20,10)) END AS agricultural_area, 
                    CASE WHEN (IV1.underground_area) IS NULL THEN NULL ELSE CAST(IV1.underground_area AS NUMERIC(20,10)) END AS underground_area, 
                    IV1.kasen_kaigan_code, 
                    -- IV1.kasen_kaigan_name, 
                    CASE WHEN (IV1.crop_damage) IS NULL THEN NULL ELSE CAST(IV1.crop_damage AS NUMERIC(20,10)) END AS crop_damage, 
                    IV1.weather_id, 
                    -- IV1.weather_name, 
                    -- IV1.upload_file_path, 
                    -- IV1.upload_file_name, 
                    -- IV1.summary_file_path, 
                    -- IV1.summary_file_name, 
                    IV1.building_code, 
                    -- IV1.building_name, 
                    IV1.underground_code, 
                    -- IV1.underground_name, 
                    IV1.flood_sediment_code, 
                    -- IV1.flood_sediment_name, 
                    CASE WHEN (IV1.building_lv00) IS NULL THEN NULL ELSE CAST(IV1.building_lv00 AS NUMERIC(20,10)) END AS building_lv00, 
                    CASE WHEN (IV1.building_lv01_49) IS NULL THEN NULL ELSE CAST(IV1.building_lv01_49 AS NUMERIC(20,10)) END AS building_lv01_49, 
                    CASE WHEN (IV1.building_lv50_99) IS NULL THEN NULL ELSE CAST(IV1.building_lv50_99 AS NUMERIC(20,10)) END AS building_lv50_99, 
                    CASE WHEN (IV1.building_lv100) IS NULL THEN NULL ELSE CAST(IV1.building_lv100 AS NUMERIC(20,10)) END AS building_lv100, 
                    CASE WHEN (IV1.building_half) IS NULL THEN NULL ELSE CAST(IV1.building_half AS NUMERIC(20,10)) END AS building_half, 
                    CASE WHEN (IV1.building_full) IS NULL THEN NULL ELSE CAST(IV1.building_full AS NUMERIC(20,10)) END AS building_full, 
                    CASE WHEN (IV1.floor_area) IS NULL THEN NULL ELSE CAST(IV1.floor_area AS NUMERIC(20,10)) END AS floor_area, 
                    CASE WHEN (IV1.family) IS NULL THEN NULL ELSE CAST(IV1.family AS NUMERIC(20,10)) END AS family, 
                    CASE WHEN (IV1.office) IS NULL THEN NULL ELSE CAST(IV1.office AS NUMERIC(20,10)) END AS office, 
                    CASE WHEN (IV1.floor_area_lv00) IS NULL THEN NULL ELSE CAST(IV1.floor_area_lv00 AS NUMERIC(20,10)) END AS floor_area_lv00, 
                    CASE WHEN (IV1.floor_area_lv01_49) IS NULL THEN NULL ELSE CAST(IV1.floor_area_lv01_49 AS NUMERIC(20,10)) END AS floor_area_lv01_49, 
                    CASE WHEN (IV1.floor_area_lv50_99) IS NULL THEN NULL ELSE CAST(IV1.floor_area_lv50_99 AS NUMERIC(20,10)) END AS floor_area_lv50_99, 
                    CASE WHEN (IV1.floor_area_lv100) IS NULL THEN NULL ELSE CAST(IV1.floor_area_lv100 AS NUMERIC(20,10)) END AS floor_area_lv100, 
                    CASE WHEN (IV1.floor_area_half) IS NULL THEN NULL ELSE CAST(IV1.floor_area_half AS NUMERIC(20,10)) END AS floor_area_half, 
                    CASE WHEN (IV1.floor_area_full) IS NULL THEN NULL ELSE CAST(IV1.floor_area_full AS NUMERIC(20,10)) END AS floor_area_full, 
                    CASE WHEN (IV1.family_lv00) IS NULL THEN NULL ELSE CAST(IV1.family_lv00 AS NUMERIC(20,10)) END AS family_lv00, 
                    CASE WHEN (IV1.family_lv01_49) IS NULL THEN NULL ELSE CAST(IV1.family_lv01_49 AS NUMERIC(20,10)) END AS family_lv01_49, 
                    CASE WHEN (IV1.family_lv50_99) IS NULL THEN NULL ELSE CAST(IV1.family_lv50_99 AS NUMERIC(20,10)) END AS family_lv50_99, 
                    CASE WHEN (IV1.family_lv100) IS NULL THEN NULL ELSE CAST(IV1.family_lv100 AS NUMERIC(20,10)) END AS family_lv100, 
                    CASE WHEN (IV1.family_half) IS NULL THEN NULL ELSE CAST(IV1.family_half AS NUMERIC(20,10)) END AS family_half, 
                    CASE WHEN (IV1.family_full) IS NULL THEN NULL ELSE CAST(IV1.family_full AS NUMERIC(20,10)) END AS family_full, 
                    CASE WHEN (IV1.office_lv00) IS NULL THEN NULL ELSE CAST(IV1.office_lv00 AS NUMERIC(20,10)) END AS office_lv00, 
                    CASE WHEN (IV1.office_lv01_49) IS NULL THEN NULL ELSE CAST(IV1.office_lv01_49 AS NUMERIC(20,10)) END AS office_lv01_49, 
                    CASE WHEN (IV1.office_lv50_99) IS NULL THEN NULL ELSE CAST(IV1.office_lv50_99 AS NUMERIC(20,10)) END AS office_lv50_99, 
                    CASE WHEN (IV1.office_lv100) IS NULL THEN NULL ELSE CAST(IV1.office_lv100 AS NUMERIC(20,10)) END AS office_lv100, 
                    CASE WHEN (IV1.office_half) IS NULL THEN NULL ELSE CAST(IV1.office_half AS NUMERIC(20,10)) END AS office_half, 
                    CASE WHEN (IV1.office_full) IS NULL THEN NULL ELSE CAST(IV1.office_full AS NUMERIC(20,10)) END AS office_full, 
                    CASE WHEN (IV1.farmer_fisher_lv00) IS NULL THEN NULL ELSE CAST(IV1.farmer_fisher_lv00 AS NUMERIC(20,10)) END AS farmer_fisher_lv00, 
                    CASE WHEN (IV1.farmer_fisher_lv01_49) IS NULL THEN NULL ELSE CAST(IV1.farmer_fisher_lv01_49 AS NUMERIC(20,10)) END AS farmer_fisher_lv01_49, 
                    CASE WHEN (IV1.farmer_fisher_lv50_99) IS NULL THEN NULL ELSE CAST(IV1.farmer_fisher_lv50_99 AS NUMERIC(20,10)) END AS farmer_fisher_lv50_99, 
                    CASE WHEN (IV1.farmer_fisher_lv100) IS NULL THEN NULL ELSE CAST(IV1.farmer_fisher_lv100 AS NUMERIC(20,10)) END AS farmer_fisher_lv100, 
                    CASE WHEN (IV1.farmer_fisher_full) IS NULL THEN NULL ELSE CAST(IV1.farmer_fisher_full AS NUMERIC(20,10)) END AS farmer_fisher_full, 
                    CASE WHEN (IV1.employee_lv00) IS NULL THEN NULL ELSE CAST(IV1.employee_lv00 AS NUMERIC(20,10)) END AS employee_lv00, 
                    CASE WHEN (IV1.employee_lv01_49) IS NULL THEN NULL ELSE CAST(IV1.employee_lv01_49 AS NUMERIC(20,10)) END AS employee_lv01_49, 
                    CASE WHEN (IV1.employee_lv50_99) IS NULL THEN NULL ELSE CAST(IV1.employee_lv50_99 AS NUMERIC(20,10)) END AS employee_lv50_99, 
                    CASE WHEN (IV1.employee_lv100) IS NULL THEN NULL ELSE CAST(IV1.employee_lv100 AS NUMERIC(20,10)) END AS employee_lv100, 
                    CASE WHEN (IV1.employee_full) IS NULL THEN NULL ELSE CAST(IV1.employee_full AS NUMERIC(20,10)) END AS employee_full, 
                    IV1.industry_code, 
                    -- IV1.industry_name, 
                    IV1.usage_code, 
                    -- IV1.usage_name, 
                    IV1.comment, 
                    TO_CHAR(timezone('JST', IV1.committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                    TO_CHAR(timezone('JST', IV1.deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
                FROM IPPAN_VIEW IV1 
                WHERE 
                    IV1.ippan_header_id=%(IPPAN_HEADER_ID)s
                ORDER BY 
                    CAST (IV1.ippan_id AS INTEGER)""", params)

            if bool(ippan_list) == False:
                print_log('[WARN] action_A05_verify_idb_by_reverse.handle()関数が警告終了しました。', 'WARN')
                return 4

            ###################################################################
            ### EXCEL入出力処理(0040)
            ### ファイルパスを計算して、局所変数に値をセットする。
            ###################################################################
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 5/14.', 'DEBUG')
            upload_file_path = ippan_trigger_list[0].upload_file_path
            output_file_path = ippan_trigger_list[0].upload_file_path + '_output'
            template_file_path = 'static/template_ippan_chosa.xlsx'
            
            wb_input = openpyxl.load_workbook(upload_file_path)
            wb_output = openpyxl.load_workbook(template_file_path, keep_vba=False)
            
            ws_output = wb_output["IPPAN"]
            ws_output.title = ippan_header_list[0].ippan_header_name

            ###############################################################
            ### EXCEL入出力処理(0050)
            ### EXCELのヘッダ部のセルに、DBから取得したヘッダ部分の値を埋め込む。
            ### 0の場合、bool(0)=False、bool(str(0))=Trueとなるため、bool(str())としている。
            ### 改行文字\が美しくないため、改行のために括弧を使用している。
            ###############################################################
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 6/14.', 'DEBUG')
            if bool(ippan_header_list) == True:
                if (bool(str(ippan_header_list[0].ken_name)) == True and 
                    bool(str(ippan_header_list[0].ken_code)) == True):
                    ws_output.cell(row=7, column=2).value = (
                        str(ippan_header_list[0].ken_name) + ":" + 
                        str(ippan_header_list[0].ken_code)
                    )

                if (bool(str(ippan_header_list[0].city_name)) == True and 
                    bool(str(ippan_header_list[0].city_code)) == True):
                    ws_output.cell(row=7, column=3).value = (
                        str(ippan_header_list[0].city_name) + ":" + 
                        str(ippan_header_list[0].city_code)
                    )

                if (bool(str(ippan_header_list[0].begin_date)) == True):
                    ws_output.cell(row=7, column=4).value = (
                        str(ippan_header_list[0].begin_date)
                    )

                if (bool(str(ippan_header_list[0].end_date)) == True):
                    ws_output.cell(row=7, column=5).value = (
                        str(ippan_header_list[0].end_date)
                    )

                if (bool(str(ippan_header_list[0].cause_1_name)) == True and 
                    bool(str(ippan_header_list[0].cause_1_code)) == True):
                    ws_output.cell(row=7, column=6).value = (
                        str(ippan_header_list[0].cause_1_name) + ":" + 
                        str(ippan_header_list[0].cause_1_code)
                    )

                if (bool(str(ippan_header_list[0].cause_2_name)) == True and 
                    bool(str(ippan_header_list[0].cause_2_code)) == True):
                    ws_output.cell(row=7, column=7).value = (
                        str(ippan_header_list[0].cause_2_name) + ":" + 
                        str(ippan_header_list[0].cause_2_code)
                    )

                if (bool(str(ippan_header_list[0].cause_3_name)) == True and 
                    bool(str(ippan_header_list[0].cause_3_code)) == True):
                    ws_output.cell(row=7, column=8).value = (
                        str(ippan_header_list[0].cause_3_name) + ":" + 
                        str(ippan_header_list[0].cause_3_code)
                    )

                if (bool(str(ippan_header_list[0].area_name)) == True and 
                    bool(str(ippan_header_list[0].area_id)) == True):
                    ws_output.cell(row=7, column=9).value = (
                        str(ippan_header_list[0].area_name) + ":" + 
                        str(ippan_header_list[0].area_id)
                    )

                if (bool(str(ippan_header_list[0].suikei_name)) == True and 
                    bool(str(ippan_header_list[0].suikei_code)) == True):
                    ws_output.cell(row=10, column=2).value = (
                        str(ippan_header_list[0].suikei_name) + ":" + 
                        str(ippan_header_list[0].suikei_code)
                    )

                if (bool(str(ippan_header_list[0].suikei_type_name)) == True and 
                    bool(str(ippan_header_list[0].suikei_type_code)) == True):
                    ws_output.cell(row=10, column=3).value = (
                        str(ippan_header_list[0].suikei_type_name) + ":" + 
                        str(ippan_header_list[0].suikei_type_code)
                    )

                if (bool(str(ippan_header_list[0].kasen_name)) == True and 
                    bool(str(ippan_header_list[0].kasen_code)) == True):
                    ws_output.cell(row=10, column=4).value = (
                        str(ippan_header_list[0].kasen_name) + ":" + 
                        str(ippan_header_list[0].kasen_code)
                    )

                if (bool(str(ippan_header_list[0].kasen_type_name)) == True and 
                    bool(str(ippan_header_list[0].kasen_type_code)) == True):
                    ws_output.cell(row=10, column=5).value = (
                        str(ippan_header_list[0].kasen_type_name) + ":" + 
                        str(ippan_header_list[0].kasen_type_code)
                    )

                if (bool(str(ippan_header_list[0].gradient_name)) == True and 
                    bool(str(ippan_header_list[0].gradient_code)) == True):
                    ws_output.cell(row=10, column=6).value = (
                        str(ippan_header_list[0].gradient_name) + ":" + 
                        str(ippan_header_list[0].gradient_code)
                    )

                if (bool(str(ippan_header_list[0].residential_area)) == True):
                    ws_output.cell(row=14, column=2).value = (
                        str(ippan_header_list[0].residential_area)
                    )

                if (bool(str(ippan_header_list[0].agricultural_area)) == True):
                    ws_output.cell(row=14, column=3).value = (
                        str(ippan_header_list[0].agricultural_area)
                    )

                if (bool(str(ippan_header_list[0].underground_area)) == True):
                    ws_output.cell(row=14, column=4).value = (
                        str(ippan_header_list[0].underground_area)
                    )

                if (bool(str(ippan_header_list[0].kasen_kaigan_name)) == True and 
                    bool(str(ippan_header_list[0].kasen_kaigan_code)) == True):
                    ws_output.cell(row=14, column=6).value = (
                        str(ippan_header_list[0].kasen_kaigan_name) + ":" + 
                        str(ippan_header_list[0].kasen_kaigan_code)
                    )

                if (bool(str(ippan_header_list[0].crop_damage)) == True):
                    ws_output.cell(row=14, column=8).value = (
                        str(ippan_header_list[0].crop_damage)
                    )

                if (bool(str(ippan_header_list[0].weather_name)) == True and 
                    bool(str(ippan_header_list[0].weather_id)) == True):
                    ws_output.cell(row=14, column=10).value = (
                        str(ippan_header_list[0].weather_name) + ":" + 
                        str(ippan_header_list[0].weather_id)
                    )

                if (bool(str(ippan_header_list[0].ippan_header_id)) == True):
                    ws_output.cell(row=3, column=28).value = (
                        ippan_header_list[0].ippan_header_id
                    )
                    
            ###############################################################
            ### EXCEL入出力処理(0060)
            ### EXCELの一覧部のセルに、DBから取得した一覧表部分の値を埋め込む。
            ###############################################################
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 7/14.', 'DEBUG')
            if bool(ippan_list) == True:
                for i, ippan in enumerate(ippan_list):
                    if (bool(str(ippan.ippan_name)) == True):
                        ws_output.cell(row=i+20, column=2).value = (
                            str(ippan.ippan_name)
                        )
                    
                    if (bool(str(ippan.building_name)) == True and 
                        bool(str(ippan.building_code)) == True):
                        ws_output.cell(row=i+20, column=3).value = (
                            str(ippan.building_name) + ":" + 
                            str(ippan.building_code)
                        )
                        
                    if (bool(str(ippan.underground_name)) == True and 
                        bool(str(ippan.underground_code)) == True):
                        ws_output.cell(row=i+20, column=4).value = (
                            str(ippan.underground_name) + ":" + 
                            str(ippan.underground_code)
                        )
                        
                    if (bool(str(ippan.flood_sediment_name)) == True and 
                        bool(str(ippan.flood_sediment_code)) == True):
                        ws_output.cell(row=i+20, column=5).value = (
                            str(ippan.flood_sediment_name) + ":" + 
                            str(ippan.flood_sediment_code)
                        )
                        
                    if (bool(str(ippan.building_lv00)) == True):
                        ws_output.cell(row=i+20, column=6).value = (
                            ippan.building_lv00
                        )

                    if (bool(str(ippan.building_lv01_49)) == True):
                        ws_output.cell(row=i+20, column=7).value = (
                            ippan.building_lv01_49
                        )
                    
                    if (bool(str(ippan.building_lv50_99)) == True):
                        ws_output.cell(row=i+20, column=8).value = (
                            ippan.building_lv50_99
                        )

                    if (bool(str(ippan.building_lv100)) == True):
                        ws_output.cell(row=i+20, column=9).value = (
                            ippan.building_lv100
                        )

                    if (bool(str(ippan.building_half)) == True):
                        ws_output.cell(row=i+20, column=10).value = (
                            ippan.building_half
                        )

                    if (bool(str(ippan.building_full)) == True):
                        ws_output.cell(row=i+20, column=11).value = (
                            ippan.building_full
                        )
                    
                    if (bool(str(ippan.floor_area)) == True):
                        ws_output.cell(row=i+20, column=12).value = (
                            ippan.floor_area
                        )
                    
                    if (bool(str(ippan.family)) == True):
                        ws_output.cell(row=i+20, column=13).value = (
                            ippan.family
                        )

                    if (bool(str(ippan.office)) == True):
                        ws_output.cell(row=i+20, column=14).value = (
                            ippan.office
                        )

                    if (bool(str(ippan.farmer_fisher_lv00)) == True):
                        ws_output.cell(row=i+20, column=15).value = (
                            ippan.farmer_fisher_lv00
                        )

                    if (bool(str(ippan.farmer_fisher_lv01_49)) == True):
                        ws_output.cell(row=i+20, column=16).value = (
                            ippan.farmer_fisher_lv01_49
                        )
                    
                    if (bool(str(ippan.farmer_fisher_lv50_99)) == True):
                        ws_output.cell(row=i+20, column=17).value = (
                            ippan.farmer_fisher_lv50_99
                        )

                    if (bool(str(ippan.farmer_fisher_lv100)) == True):
                        ws_output.cell(row=i+20, column=18).value = (
                            ippan.farmer_fisher_lv100
                        )

                    if (bool(str(ippan.farmer_fisher_full)) == True):
                        ws_output.cell(row=i+20, column=19).value = (
                            ippan.farmer_fisher_full
                        )

                    if (bool(str(ippan.employee_lv00)) == True):
                        ws_output.cell(row=i+20, column=20).value = (
                            ippan.employee_lv00
                        )
                    
                    if (bool(str(ippan.employee_lv01_49)) == True):
                        ws_output.cell(row=i+20, column=21).value = (
                            ippan.employee_lv01_49
                        )
                    
                    if (bool(str(ippan.employee_lv50_99)) == True):
                        ws_output.cell(row=i+20, column=22).value = (
                            ippan.employee_lv50_99
                        )
                    
                    if (bool(str(ippan.employee_lv100)) == True):
                        ws_output.cell(row=i+20, column=23).value = (
                            ippan.employee_lv100
                        )
                    
                    if (bool(str(ippan.employee_full)) == True):
                        ws_output.cell(row=i+20, column=24).value = (
                            ippan.employee_full
                        )
                    
                    if (bool(str(ippan.industry_name)) == True and 
                        bool(str(ippan.industry_code)) == True):
                        ws_output.cell(row=i+20, column=25).value = (
                            str(ippan.industry_name) + ":" + 
                            str(ippan.industry_code)
                        )
                        
                    if (bool(str(ippan.usage_name)) == True and 
                        bool(str(ippan.usage_code)) == True):
                        ws_output.cell(row=i+20, column=26).value = (
                            str(ippan.usage_name) + ":" + 
                            str(ippan.usage_code)
                        )
                        
                    if (bool(str(ippan.comment)) == True):
                        ws_output.cell(row=i+20, column=27).value = (
                            ippan.comment
                        )

                    if (bool(str(ippan.ippan_id)) == True):
                        ws_output.cell(row=i+20, column=28).value = (
                            ippan.ippan_id
                        )

            ###################################################################
            ### EXCEL入出力処理(0070)
            ### 検証用のEXCELファイルを保存する。
            ###################################################################
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 8/14.', 'DEBUG')
            wb_output.save(output_file_path)
    
            ###################################################################
            ### EXCEL入出力処理(0080)
            ### 該当するワークシートを探索して、局所変数に値をセットする。
            ### 最大行を探索して、局所変数に値をセットする。
            ###################################################################
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 9/14.', 'DEBUG')
            ### 該当するワークシートを探索して、局所変数に値をセットする。
            ws_input = None
            for ws_temp in wb_input.worksheets:
                if str(ws_temp.title) == str(ippan_header_list[0].ippan_header_name):
                    ws_input = ws_temp
                    break
                
            if ws_input is None:
                print_log('[WARN] action_A03_verify_idb_by_diff.handle()関数 ws_input is None', 'WARN')
                print_log('[WARN] action_A03_verify_idb_by_diff.handle()関数が警告終了しました。', 'WARN')
                return 4

            ### 最大行を探索して、局所変数に値をセットする。
            max_row_temp = 1
            for i in range(ws_input.max_row+1, 1, -1):
                if ws_input.cell(row=i, column=2).value is None:
                    pass
                else:
                    max_row_temp = i
                    break
                    
            ws_max_row_input = max_row_temp
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_max_row_input={}'.format(ws_max_row_input), 'DEBUG')

            max_row_temp = 1
            for i in range(ws_output.max_row+1, 1, -1):
                if ws_output.cell(row=i, column=2).value is None:
                    pass
                else:
                    max_row_temp = i
                    break
                    
            ws_max_row_output = max_row_temp
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_max_row_output={}'.format(ws_max_row_output), 'DEBUG')
            
            if ws_max_row_input > ws_max_row_output:
                ws_max_row = ws_max_row_input
            else:
                ws_max_row = ws_max_row_output

            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_max_row={}'.format(ws_max_row), 'DEBUG')

            if ws_max_row < 20:
                print_log('[WARN] action_A03_verify_idb_by_diff.handle()関数 ws_max_row={}'.format(ws_max_row), 'WARN')
                print_log('[WARN] action_A03_verify_idb_by_diff.handle()関数が警告終了しました。', 'WARN')
                return 4

            ###################################################################
            ### 検証処理(0090)
            ### 検証の心臓部
            ###################################################################
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 10/14.', 'DEBUG')
            info_count = 0
            warn_count = 0
            
            ### 7行目
            for i in [2, 3, 4, 5, 6, 7, 8, 9]:
                ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_input.cell.value={}'.format(ws_input.cell(row=7, column=i).value), 'DEBUG')
                ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_output.cell.value={}'.format(ws_output.cell(row=7, column=i).value), 'DEBUG')
                if str(ws_input.cell(row=7, column=i).value) != str(ws_output.cell(row=7, column=i).value):
                    print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                        ws_input.title, 
                        ws_output.title, 
                        7, 
                        i, 
                        ws_input.cell(row=7, column=i).value, 
                        ws_output.cell(row=7, column=i).value
                        ), 'WARN')
                    warn_count += 1
                else:
                    info_count += 1
            
            ### 10行目
            for i in [2, 3, 4, 5, 6]:
                ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_input.cell.value={}'.format(ws_input.cell(row=10, column=i).value), 'DEBUG')
                ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_output.cell.value={}'.format(ws_output.cell(row=10, column=i).value), 'DEBUG')
                if str(ws_input.cell(row=10, column=i).value) != str(ws_output.cell(row=10, column=i).value):
                    print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                        ws_input.title, 
                        ws_output.title, 
                        10, 
                        i, 
                        ws_input.cell(row=10, column=i).value, 
                        ws_output.cell(row=10, column=i).value
                        ), 'WARN')
                    warn_count += 1
                else:
                    info_count += 1

            ### 14行目
            for i in [2, 3, 4, 8]:
                ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_input.cell.value={}'.format(ws_input.cell(row=14, column=i).value), 'DEBUG')
                ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_output.cell.value={}'.format(ws_output.cell(row=14, column=i).value), 'DEBUG')
                if (ws_input.cell(row=14, column=i).value == None and 
                    ws_output.cell(row=14, column=i).value == None):
                    info_count += 1
                elif (ws_input.cell(row=14, column=i).value == None and 
                    ws_output.cell(row=14, column=i).value != None):
                    print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                        ws_input.title, 
                        ws_output.title, 
                        14, 
                        i, 
                        ws_input.cell(row=14, column=i).value, 
                        ws_output.cell(row=14, column=i).value
                        ), 'WARN')
                    warn_count += 1
                elif (ws_input.cell(row=14, column=i).value != None and 
                    ws_output.cell(row=14, column=i).value == None):
                    print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                        ws_input.title, 
                        ws_output.title, 
                        14, 
                        i, 
                        ws_input.cell(row=14, column=i).value, 
                        ws_output.cell(row=14, column=i).value
                        ), 'WARN')
                    warn_count += 1
                else:
                    if abs(float(ws_input.cell(row=14, column=i).value)-float(ws_output.cell(row=14, column=i).value)) > 1e-5:
                        print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                            ws_input.title, 
                            ws_output.title, 
                            14, 
                            i, 
                            ws_input.cell(row=14, column=i).value, 
                            ws_output.cell(row=14, column=i).value
                            ), 'WARN')
                        warn_count += 1
                    else:
                        info_count += 1

            for i in [6, 10]:
                ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_input.cell.value={}'.format(ws_input.cell(row=14, column=i).value), 'DEBUG')
                ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_output.cell.value={}'.format(ws_output.cell(row=14, column=i).value), 'DEBUG')
                if str(ws_input.cell(row=14, column=i).value) != str(ws_output.cell(row=14, column=i).value):
                    print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                        ws_input.title, 
                        ws_output.title, 
                        14, 
                        i, 
                        ws_input.cell(row=14, column=i).value, 
                        ws_output.cell(row=14, column=i).value
                        ), 'WARN')
                    warn_count += 1
                else:
                    info_count += 1

            ### 20行目            
            ### TO-DO TODO TO_DO
            for j in range(20, ws_max_row + 1):
                for k in range(1, 6):
                    ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_input.cell.value={}'.format(ws_input.cell(row=j, column=k).value), 'DEBUG')
                    ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_output.cell.value={}'.format(ws_output.cell(row=j, column=k).value), 'DEBUG')
                    if str(ws_input.cell(row=j, column=k).value) != str(ws_output.cell(row=j, column=k).value):
                        print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                            ws_input.title, 
                            ws_output.title, 
                            j, 
                            k, 
                            ws_input.cell(row=j, column=k).value, 
                            ws_output.cell(row=j, column=k).value
                            ), 'WARN')
                        warn_count += 1
                    else:
                        info_count += 1

                for k in range(6, 26):
                    ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_input.cell.value={}'.format(ws_input.cell(row=j, column=k).value), 'DEBUG')
                    ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_output.cell.value={}'.format(ws_output.cell(row=j, column=k).value), 'DEBUG')
                    if (ws_input.cell(row=j, column=k).value == None and 
                        ws_output.cell(row=j, column=k).value == None):
                        info_count += 1
                    elif (ws_input.cell(row=j, column=k).value == None and 
                        ws_output.cell(row=j, column=k).value != None):
                        print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                            ws_input.title, 
                            ws_output.title, 
                            j, 
                            k, 
                            ws_input.cell(row=j, column=k).value, 
                            ws_output.cell(row=j, column=k).value
                            ), 'WARN')
                        warn_count += 1
                    elif (ws_input.cell(row=j, column=k).value != None and 
                        ws_output.cell(row=j, column=k).value == None):
                        print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                            ws_input.title, 
                            ws_output.title, 
                            j, 
                            k, 
                            ws_input.cell(row=j, column=k).value, 
                            ws_output.cell(row=j, column=k).value
                            ), 'WARN')
                        warn_count += 1
                    else:
                        print_log('[DEBUG] 55_2_4 TO-DO COMMENT OUT BELOW LINE, BUT ERROR OCCURRED 情報通信業:5', 'DEBUG')
                        ### if abs(float(ws_input.cell(row=j, column=k).value) - float(ws_output.cell(row=j, column=k).value)) > 1e-5:
                        ###     print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(ws_input.title, ws_output.title, j, k, ws_input.cell(row=j, column=k).value, ws_output.cell(row=j, column=k).value), 'WARN')
                        ###     warn_count += 1
                        ### else:
                        ###     info_count += 1

                for k in range(26, 28):
                    ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_input.cell.value={}'.format(ws_input.cell(row=j, column=k).value), 'DEBUG')
                    ### print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 ws_output.cell.value={}'.format(ws_output.cell(row=j, column=k).value), 'DEBUG')
                    if str(ws_input.cell(row=j, column=k).value) != str(ws_output.cell(row=j, column=k).value):
                        print_log('[WARN] {0} {1} {2} {3} {4} {5}'.format(
                            ws_input.title, 
                            ws_output.title, 
                            j, 
                            k, 
                            ws_input.cell(row=j, column=k).value, 
                            ws_output.cell(row=j, column=k).value
                            ), 'WARN')
                        warn_count += 1
                    else:
                        info_count += 1

            ################################################################### 
            ### DBアクセス処理(0100)
            ### 当該トリガーの実行が終了したため、当該トリガーの状態、成功数、失敗数等を更新する。
            ################################################################### 
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 11/14.', 'DEBUG')
            ### 成功
            ### if warn_count == 0:
            ###     print_log('[INFO] info_count={}'.format(info_count), 'INFO')
            ###     print_log('[INFO] warn_count={}'.format(warn_count), 'INFO')
            ### 失敗
            ### else:
            ###     print_log('[WARN] info_count={}'.format(info_count), 'WARN')
            ###     print_log('[WARN] warn_count={}'.format(warn_count), 'WARN')

            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")
                
                ###############################################################
                ### DBアクセス処理(0110)
                ### トリガーデータを更新する。
                ###############################################################
                print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 12/14.', 'DEBUG')
                ### 成功
                if warn_count == 0:
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'trigger_id': ippan_trigger_list[0].ippan_trigger_id, 
                        'action_code': _A03, 
                        'status_code': _SUCCESS, 
                        'info_count': info_count, 
                        'warn_count': warn_count, 
                        'info_log': get_info_log(), 
                        'warn_log': get_warn_log()
                    })
                    bool_return = consume_message(metadata=metadata)
                    if bool_return == False:
                        print_log('[WARN] consume_message()関数が警告終了しました。', 'WARN')
                        connection_cursor.execute("""ROLLBACK""")
                        return 4
                        
                ### 失敗
                else:
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'trigger_id': ippan_trigger_list[0].ippan_trigger_id, 
                        'action_code': _A03, 
                        'status_code': _FAILURE, 
                        'info_count': info_count, 
                        'warn_count': warn_count, 
                        'info_log': get_info_log(), 
                        'warn_log': get_warn_log() 
                    })
                    bool_return = consume_message(metadata=metadata)
                    if bool_return == False:
                        print_log('[WARN] consume_message()関数が警告終了しました。', 'WARN')
                        connection_cursor.execute("""ROLLBACK""")
                        return 4
    
                ###############################################################
                ### DBアクセス処理(0120)
                ### (1)成功の場合は、次のトリガーを発行する。
                ### (2)失敗の場合は、次のトリガーを発行しない。
                ############################################################### 
                print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 13/14.', 'DEBUG')
                ### 成功
                if warn_count == 0:
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'header_id': ippan_trigger_list[0].ippan_header_id, 
                        'ken_code': ippan_trigger_list[0].ken_code, 
                        'city_code': ippan_trigger_list[0].city_code, 
                        'action_code': _A04, 
                        'upload_file_path': ippan_trigger_list[0].upload_file_path, 
                        'upload_file_name': ippan_trigger_list[0].upload_file_name 
                    })
                    bool_return = publish_message(metadata=metadata)
                    if bool_return == False:
                        print_log('[WARN] publish_message()関数が警告終了しました。', 'WARN')
                        connection_cursor.execute("""ROLLBACK""")
                        return 4
                    
                connection_cursor.execute("""COMMIT""")
                
            except:
                print_log('[ERROR] action_A03_verify_idb_by_diff.handle()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] action_A03_verify_idb_by_diff.handle()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
                print_log('[ERROR] action_A03_verify_idb_by_diff.handle()関数が異常終了しました。', 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
                return 8
                
            finally:
                ### try except finallyのtry文中でreturnを発生させた場合、
                ### finally文中のconnection_cursor.close()が実行されて、
                ### その後に関数を抜ける。
                ### したがって、finally文中でreturnする必要はない。
                connection_cursor.close()

            ###################################################################
            ### 戻り値セット処理(0130)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] action_A03_verify_idb_by_diff.handle()関数 STEP 14/14.', 'DEBUG')
            print_log('[INFO] action_A03_verify_idb_by_diff.handle()関数が正常終了しました。', 'INFO')
            return 0
        
        except:
            print_log('[ERROR] action_A03_verify_idb_by_diff.handle()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] action_A03_verify_idb_by_diff.handle()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] action_A03_verify_idb_by_diff.handle()関数が異常終了しました。', 'ERROR')
            return 8
            