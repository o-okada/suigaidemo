###############################################################################
### ファイル名：P0900Action/management/commands/CITY_ACT_01_city_bucket.py
### 市区町村バケット情報更新処理
###############################################################################

from django.core.management.base import BaseCommand

import subprocess ### ADD 2023/03/02
import sys

from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView

from decimal import Decimal

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.models import KEN_BUCKET              ### 99999: バケットデータ_都道府県
from P0000Common.models import CITY_BUCKET             ### 99999: バケットデータ_市区町村

from P0000Common.common import get_alert_log
from P0000Common.common import get_info_log
from P0000Common.common import get_warn_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from MessageQueue.views import get_message 
from MessageQueue.views import publish_message 
from MessageQueue.views import publish_consume_message 
from MessageQueue.views import consume_message 
from MessageQueue.views import delete_message 

### ACTIONテーブル.ACTION_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_CITY_ACT_01 = 'CITY_ACT_01'

_KEN_CODES = ['01','02','03','04','05','06','07','08','09','10',
             '11','12','13','14','15','16','17','18','19','20',
             '21','22','23','24','25','26','27','28','29','30',
             '31','32','33','34','35','36','37','38','39','40',
             '41','42','43','44','45','46','47']

###############################################################################
### クラス名：Command(BaseCommand)
###############################################################################
class Command(BaseCommand):
    
    ###########################################################################
    ### 関数名：handle(self, *args, **options)
    ###########################################################################
    def handle(self, *args, **options):
        try:
            ###################################################################
            ### 引数チェック処理(0000)
            ### コマンドラインからの引数をチェックする。
            ###################################################################
            reset_log()
            print_log('[INFO] CITY_ACT_01.handle()関数が開始しました。', 'INFO')
            print_log('[DEBUG] CITY_ACT_01.handle()関数 STEP 1/3.', 'DEBUG')

            ###################################################################
            ### DBアクセス処理(0010)
            ### DBにアクセスして、データを取得する。
            ###################################################################
            print_log('[DEBUG] CITY_ACT_01.handle()関数 STEP 2/3.', 'DEBUG')
            connection_cursor = connection.cursor()
            try:
                for ken_code in [
                        '01','02','03','04','05','06','07','08','09','10',
                        '11','12','13','14','15','16','17','18','19','20',
                        '21','22','23','24','25','26','27','28','29','30',
                        '31','32','33','34','35','36','37','38','39','40',
                        '41','42','43','44','45','46','47']:
                    print_log('ken_code={}'.format(ken_code), 'DEBUG')
                    params = dict({
                        'KEN_CODE': ken_code
                    })
                    city_bucket_list = CITY_BUCKET.objects.raw("""
                        SELECT 
                            CITY_CODE 
                        FROM CITY_BUCKET 
                        WHERE 
                            KEN_CODE=%(KEN_CODE)s""", params)

                    if city_bucket_list:                    
                        for city_bucket in city_bucket_list:
                            print_log('city_code={}'.format(city_bucket.city_code), 'DEBUG')
                            du_cmd = ["du", "-s", "static/upload/{ken_code}/{city_code}/".format(ken_code=ken_code, city_code=city_bucket.city_code)]
                            du_str1 = subprocess.check_output(du_cmd)
                            du_str2 = du_str1.decode()
                            du_str3 = du_str2.split()
                            print(ken_code, du_str3[0])
                            
                            find_cmd = ["find", "static/upload/{ken_code}/{city_code}/".format(ken_code=ken_code, city_code=city_bucket.city_code), "-type", "f"]
                            find_str1 = subprocess.check_output(find_cmd)
                            ### find_str2 = find_str1.decode()
                            ### find_str3 = find_str2.split()
                            ### print(ken_code, find_str3[0])
                            
                            wc_cmd = ["wc", "-l"]
                            wc_str1 = subprocess.check_output(wc_cmd, input=find_str1)
                            wc_str2 = wc_str1.decode()
                            wc_str3 = wc_str2.split()
                            ### print(ken_code, wc_str3[0])
                            
                            params = dict({
                                'CITY_CODE': city_bucket.city_code, 
                                'USAGE': du_str3[0], 
                                'FILES': wc_str3[0]
                            })
                            return_update = connection_cursor.execute("""
                                UPDATE CITY_BUCKET SET 
                                    USAGE=%(USAGE)s, 
                                    FILES=%(FILES)s
                                WHERE 
                                    CITY_CODE=%(CITY_CODE)s""", params)
                            print(return_update)
                    
            finally:
                connection_cursor.close()
    
            ###################################################################
            ### 戻り値セット処理(0020)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] CITY_ACT_01.handle()関数 STEP 3/3.', 'DEBUG')
            print_log('[INFO] CITY_ACT_01.handle()関数が正常終了しました。', 'INFO')
            return 0
        
        except:
            print_log('[ERROR] CITY_ACT_01.handle()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] CITY_ACT_01.handle()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] CITY_ACT_01.handle()関数が異常終了しました。', 'ERROR')
            return 8
