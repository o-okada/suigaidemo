###############################################################################
### ファイル名：P0900Action/management/commands/action_Z04_download_chitan.py
### ダウンロード_公共土木施設調査票_地方単独事業
###############################################################################

from django.core.management.base import BaseCommand

import sys
from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from decimal import Decimal

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: 家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: 家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from MessageQueue.views import get_message 
from MessageQueue.views import publish_message 
from MessageQueue.views import publish_consume_message 
from MessageQueue.views import consume_message 
from MessageQueue.views import delete_message 

VLOOK_VALUE = [
    'B', 'G', 'L', 'Q', 'V', 'AA', 'AF', 'AK', 'AP', 'AU', 
    'AZ', 'BE', 'BJ', 'BO', 'BT', 'BY', 'CD', 'CI', 'CN', 'CS', 
    'CX', 'DC', 'DH', 'DM', 'DR', 'DW', 'EB', 'EG', 'EL', 'EQ', 
    'EV', 'FA', 'FF', 'FK', 'FP', 'FU', 'FZ', 'GE', 'GJ', 'GO', 
    'GT', 'GY', 'HD', 'HI', 'HN', 'HS', 'HX', 'IC', 'IH', 'IM', 
    'IR', 'IW', 'JB', 'JG', 'JL', 'JQ', 'JV', 'KA', 'KF', 'KK', 
    'KP', 'KU', 'KZ', 'LE', 'LJ', 'LO', 'LT', 'LY', 'MD', 'MI', 
    'MN', 'MS', 'MX', 'NC', 'NH', 'NM', 'NR', 'NW', 'OB', 'OG', 
    'OL', 'OQ', 'OV', 'PA', 'PF', 'PK', 'PP', 'PU', 'PZ', 'QE', 
    'QJ', 'QO', 'QT', 'QY', 'RD', 'RI', 'RN', 'RS', 'RX', 'SC', 
    'SH', 'SM', 'SR', 'SW', 'TB', 'TG', 'TL', 'TQ', 'TV', 'UA', 
    'UF', 'UK', 'UP', 'UU', 'UZ', 'VE', 'VJ', 'VO', 'VT', 'VY', 
    'WD', 'WI', 'WN', 'WS', 'WX', 'XC', 'XH', 'XM', 'XR', 'XW', 
    'YB', 'YG', 'YL', 'YQ', 'YV', 'ZA', 'ZF', 'ZK', 'ZP', 'ZU', 
    'ZZ', 'AAE', 'AAJ', 'AAO', 'AAT', 'AAY', 'ABD', 'ABI', 'ABN', 'ABS', 
    'ABX', 'ACC', 'ACH', 'ACM', 'ACR', 'ACW', 'ADB', 'ADG', 'ADL', 'ADQ', 
    'ADV', 'AEA', 'AEF', 'AEK', 'AEP', 'AEU', 'AEZ', 'AFE', 'AFJ', 'AFO', 
    'AFT', 'AFY', 'AGD', 'AGI', 'AGN', 'AGS', 'AGX', 'AHC', 'AHH', 'AHM', 
    'AHR', 'AHW', 'AIB', 'AIG', 'AIL', 'AIQ', 'AIV', 'AJA', 'AJF', 'AJK', 
    'AJP', 'AJU', 'AJZ', 'AKE', 'AKJ', 'AKO', 'AKT', 'AKY', 'ALD', 'ALI', 
    'ALN', 'ALS', 'ALX', 'AMC', 'AMH', 'AMM', 'AMR', 'AMW', 'ANB', 'ANG', 
    'ANL', 'ANQ', 'ANV', 'AOA', 'AOF', 'AOK', 'AOP', 'AOU', 'AOZ', 'APE', 
    'APJ', 'APO', 'APT', 'APY', 'AQD', 'AQI', 'AQN', 'AQS', 'AQX', 'ARC', 
    'ARH', 'ARM', 'ARR', 'ARW', 'ASB', 'ASG', 'ASL', 'ASQ', 'ASV', 'ATA', 
    'ATF', 'ATK', 'ATP', 'ATU', 'ATZ', 'AUE', 'AUJ', 'AUO', 'AUT', 'AUY', 
    'AVD', 'AVI', 'AVN', 'AVS', 'AVX', 'AWC', 'AWH', 'AWM', 'AWR', 'AWW', 
    'AXB', 'AXG', 'AXL', 'AXQ', 'AXV', 'AYA', 'AYF', 'AYK', 'AYP', 'AYU', 
    'AYZ', 'AZE', 'AZJ', 'AZO', 'AZT', 'AZY'
    ]

_Z01 = 'Z01'
_Z02 = 'Z02'
_Z03 = 'Z03'
_Z04 = 'Z04'
_Z05 = 'Z05'
_Z06 = 'Z06'
_Z07 = 'Z07'
_Z08 = 'Z08'
_Z09 = 'Z09'
_Z10 = 'Z10'
_Z99 = 'Z99'

_WAITING = 'WAITING'
_RUNNING = 'RUNNING'
_SUCCESS = 'SUCCESS'
_FAILURE = 'FAILURE'
_CANCEL = 'CANCEL'

###############################################################################
### クラス名：Command(BaseCommand)
###############################################################################
class Command(BaseCommand):
    
    ###########################################################################
    ### 関数名：handle(self, *args, **options)
    ###########################################################################
    def handle(self, *args, **options):
        try:
            ###################################################################
            ### 引数チェック処理(0000)
            ### コマンドラインからの引数をチェックする。
            ###################################################################
            reset_log()
            print_log('[INFO] action_Z04_download_chitan.handle()関数が開始しました。', 'INFO')
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 STEP 1/14.', 'DEBUG')

            ###################################################################
            ### DBアクセス処理(0010)
            ### メッセージキューから当該アクションが対象とするメッセージを取得する。
            ### ※ネストを浅くするため、メッセージが発行されていなければ、処理を終了する。
            ###################################################################
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 STEP 2/14.', 'DEBUG')
            metadata = dict({
                'action_code': _Z04, 
                'status_code': ''
            })
            bool_return, chitan_trigger_list = get_message(metadata=metadata)
            if bool_return == False:
                print_log('[WARN] get_message()関数が警告終了しました。', 'WARN')
                return 4
            
            if bool(chitan_trigger_list) == False:
                print_log('[INFO] action_Z04_download_chitan.handle()関数が正常終了しました。', 'INFO')
                return 0
            
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 chitan_trigger_list[0].chitan_trigger_id={}'.format(chitan_trigger_list[0].chitan_trigger_id), 'DEBUG')
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 chitan_trigger_list[0].chitan_header_id={}'.format(chitan_trigger_list[0].chitan_header_id), 'DEBUG')
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 chitan_trigger_list[0].city_code={}'.format(chitan_trigger_list[0].city_code), 'DEBUG')
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 chitan_trigger_list[0].ken_code={}'.format(chitan_trigger_list[0].ken_code), 'DEBUG')
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 chitan_trigger_list[0].download_file_path={}'.format(chitan_trigger_list[0].download_file_path), 'DEBUG')
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 chitan_trigger_list[0].download_file_name={}'.format(chitan_trigger_list[0].download_file_name), 'DEBUG')
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 chitan_trigger_list[0].upload_file_path={}'.format(chitan_trigger_list[0].upload_file_path), 'DEBUG')
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 chitan_trigger_list[0].upload_file_name={}'.format(chitan_trigger_list[0].upload_file_name), 'DEBUG')
    
            ###################################################################
            ### DBアクセス処理(0020)
            ### マスタデータを取得する。
            ###################################################################
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 STEP 3/14.', 'DEBUG')
            cities_list = []
            ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(ken_code AS INTEGER)""", [])
            if ken_list:
                for i, ken in enumerate(ken_list):
                    params = dict({
                        'KEN_CODE': ken.ken_code
                    })
                    cities_list.append(CITY.objects.raw("""
                        SELECT 
                            * 
                        FROM CITY 
                        WHERE 
                            ken_code=%(KEN_CODE)s 
                        ORDER BY 
                            CAST(city_code AS INTEGER)""", params))
    
            kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(kasen_kaigan_code AS INTEGER)""")
            suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(suikei_code AS INTEGER)""")
            suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(suikei_type_code AS INTEGER)""")
    
            kasens_list = []
            suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(suikei_code AS INTEGER)""")
            if suikei_list:
                for i, suikei in enumerate(suikei_list):
                    params = dict({
                        'SUIKEI_CODE': suikei.suikei_code
                    })
                    kasens_list.append(KASEN.objects.raw("""
                        SELECT 
                            * 
                        FROM KASEN 
                        WHERE 
                            suikei_code=%(SUIKEI_CODE)s 
                        ORDER BY 
                            CAST(kasen_code AS INTEGER)""", params))
    
            kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(kasen_type_code AS INTEGER)""")
            weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(weather_id AS INTEGER)""")
            chitan_header_list = CHITAN_HEADER.objects.raw("""SELECT * FROM CHITAN_HEADER ORDER BY CAST(chitan_header_id AS INTEGER)""")
            
            ###################################################################
            ### EXCEL入出力処理(0030)
            ### ダウンロード用ファイルパスをセットする。
            ###################################################################
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 STEP 4/14.', 'DEBUG')
            template_file_path = 'static/template_chitan.xlsx'

            ###################################################################
            ### EXCEL入出力処理(0040)
            ### ワークシートを局所変数にセットする。
            ###################################################################
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 STEP 5/14.', 'DEBUG')
            wb = openpyxl.load_workbook(template_file_path, keep_vba=False)
            ws_ken = wb["KEN"]
            ws_city = wb["CITY"]
            ws_kasen_kaigan = wb["KASEN_KAIGAN"]
            ws_suikei = wb["SUIKEI"]
            ws_suikei_type = wb["SUIKEI_TYPE"]
            ws_kasen = wb["KASEN"]
            ws_kasen_type = wb["KASEN_TYPE"]
            ws_weather = wb["WEATHER"]
            ws_chitan_header = wb["CHITAN_HEADER"]
            ws_city_vlook = wb["CITY_VLOOK"]
            ws_kasen_vlook = wb["KASEN_VLOOK"]
            ws_chitan = wb["CHITAN"]

            ###################################################################
            ### EXCEL入出力処理(0050)
            ### 各EXCELシートで枠線を表示しないにセットする。
            ###################################################################
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 STEP 6/14.', 'DEBUG')
            ws_ken.sheet_view.showGridLines = False
            ws_city.sheet_view.showGridLines = False
            ws_kasen_kaigan.sheet_view.showGridLines = False
            ws_suikei.sheet_view.showGridLines = False
            ws_suikei_type.sheet_view.showGridLines = False
            ws_kasen.sheet_view.showGridLines = False
            ws_kasen_type.sheet_view.showGridLines = False
            ws_weather.sheet_view.showGridLines = False
            ws_chitan_header.sheet_view.showGridLines = False
            ws_city_vlook.sheet_view.showGridLines = False
            ws_kasen_vlook.sheet_view.showGridLines = False
            ws_chitan.sheet_view.showGridLines = False

            ###################################################################
            ### EXCEL入出力処理(0060)
            ### マスタ用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 STEP 7/14.', 'DEBUG')
            ### 1010: 都道府県シート
            print("handle_7_1", flush=True)
            if ken_list:
                for i, ken in enumerate(ken_list):
                    ws_ken.cell(row=i+1, column=1).value = ken.ken_code
                    ws_ken.cell(row=i+1, column=2).value = str(ken.ken_name) + ":" + str(ken.ken_code)
                    ### ws_city_vlook.cell(row=j+1, column=1).value = str(ken.ken_name) + ":" + str(ken.ken_code)

            ### 1020: 市区町村シート
            print("handle_7_2", flush=True)
            cities_list = []
            if ken_list:
                for i, ken in enumerate(ken_list):
                    params = dict({
                        'KEN_CODE': ken.ken_code
                    })
                    cities_list.append(CITY.objects.raw("""
                        SELECT 
                            * 
                        FROM CITY 
                        WHERE 
                            ken_code=%(KEN_CODE)s 
                        ORDER BY 
                            CAST(city_code AS INTEGER)""", params))
    
            print("handle_7_3", flush=True)
            if cities_list:
                for i, cities in enumerate(cities_list):
                    if cities:
                        for j, city in enumerate(cities):
                            ws_city.cell(row=j+1, column=i*5+1).value = city.city_code
                            ws_city.cell(row=j+1, column=i*5+2).value = str(city.city_name) + ":" + str(city.city_code)
                            ws_city.cell(row=j+1, column=i*5+3).value = city.ken_code
                            ws_city.cell(row=j+1, column=i*5+4).value = city.city_population
                            ws_city.cell(row=j+1, column=i*5+5).value = city.city_area

            ### 1030: 水害発生地点工種（河川海岸区分）
            print("handle_7_4", flush=True)
            if kasen_kaigan_list:
                for i, kasen_kaigan in enumerate(kasen_kaigan_list):
                    ws_kasen_kaigan.cell(row=i+1, column=1).value = kasen_kaigan.kasen_kaigan_code
                    ws_kasen_kaigan.cell(row=i+1, column=2).value = str(kasen_kaigan.kasen_kaigan_name) + ":" + str(kasen_kaigan.kasen_kaigan_code)

            ### 1040: 水系（水系・沿岸）
            print("handle_7_5", flush=True)
            if suikei_list:
                for i, suikei in enumerate(suikei_list):
                    ws_suikei.cell(row=i+1, column=1).value = suikei.suikei_code
                    ws_suikei.cell(row=i+1, column=2).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
                    ws_suikei.cell(row=i+1, column=3).value = suikei.suikei_type_code

            ### 1050: 水系種別（水系・沿岸種別）
            print("handle_7_6", flush=True)
            if suikei_type_list:
                for i, suikei_type in enumerate(suikei_type_list):
                    ws_suikei_type.cell(row=i+1, column=1).value = suikei_type.suikei_type_code
                    ws_suikei_type.cell(row=i+1, column=2).value = str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code)

            ### 1060: 河川（河川・海岸）、連動プルダウン用
            print("handle_7_7", flush=True)
            kasens_list = []
            if suikei_list:
                for i, suikei in enumerate(suikei_list):
                    params = dict({
                        'SUIKEI_CODE': suikei.suikei_code
                    })
                    kasens_list.append(KASEN.objects.raw("""
                        SELECT 
                            * 
                        FROM KASEN 
                        WHERE 
                            suikei_code=%(SUIKEI_CODE)s 
                        ORDER BY 
                            CAST(kasen_code AS INTEGER)""", params))
    
            print("handle_7_8", flush=True)
            if kasens_list:
                for i, kasens in enumerate(kasens_list):
                    if kasens:
                        for j, kasen in enumerate(kasens):
                            ws_kasen.cell(row=j+1, column=i*5+1).value = kasen.kasen_code
                            ws_kasen.cell(row=j+1, column=i*5+2).value = str(kasen.kasen_name) + ":" + str(kasen.kasen_code)
                            ws_kasen.cell(row=j+1, column=i*5+3).value = kasen.kasen_type_code
                            ws_kasen.cell(row=j+1, column=i*5+4).value = kasen.suikei_code

            ### 1070: 河川種別（河川・海岸種別）
            print("handle_7_9", flush=True)
            if kasen_type_list:
                for i, kasen_type in enumerate(kasen_type_list):
                    ws_kasen_type.cell(row=i+1, column=1).value = kasen_type.kasen_type_code
                    ws_kasen_type.cell(row=i+1, column=2).value = str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code)

            ### 7010: 入力データ_異常気象
            print("handle_7_10", flush=True)
            if weather_list:
                for i, weather in enumerate(weather_list):
                    ws_weather.cell(row=i+1, column=1).value = weather.weather_id
                    ws_weather.cell(row=i+1, column=2).value = str(weather.weather_name) + ":" + str(weather.weather_id)

            ###################################################################
            ### EXCEL入出力処理(0070)
            ### VLOOKUP用のシートに値をセットする。
            ###################################################################
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 STEP 8/14.', 'DEBUG')
            ### 1020: 市区町村VLOOKUP
            print("handle_8_1", flush=True)
            if ken_list and cities_list:
                for i, ken in enumerate(ken_list):
                    ws_city_vlook.cell(row=i+1, column=1).value = str(ken.ken_name) + ":" + str(ken.ken_code)
        
                for i, cities in enumerate(cities_list):
                    ws_city_vlook.cell(row=i+1, column=2).value = 'CITY!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(cities)
    
            ### 1060: 河川（河川・海岸）VLOOKUP
            print("handle_8_2", flush=True)
            if suikei_list and kasens_list:
                for i, suikei in enumerate(suikei_list):
                    ws_kasen_vlook.cell(row=i+1, column=1).value = str(suikei.suikei_name) + ":" + str(suikei.suikei_code)
    
                for i, kasens in enumerate(kasens_list):
                    ws_kasen_vlook.cell(row=i+1, column=2).value = 'KASEN!$' + VLOOK_VALUE[i] + '$1:$' + VLOOK_VALUE[i] + '$%d' % len(kasens)

            ###################################################################
            ### EXCEL入出力処理(0080)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 STEP 9/14.', 'DEBUG')
            ### ws_chitan.cell(row=6, column=1).value = 'NO.'
            ### ws_chitan.cell(row=6, column=2).value = '水系・沿岸名[全角]'
            ### ws_chitan.cell(row=6, column=3).value = '水系種別[全角]'
            ### ws_chitan.cell(row=6, column=4).value = '河川・海岸名[全角]'
            ### ws_chitan.cell(row=6, column=5).value = '河川種別[全角]'
            ### ws_chitan.cell(row=6, column=6).value = '代表被災地区名[全角]'
            ### ws_chitan.cell(row=6, column=7).value = '都道府県名[全角]'
            ### ws_chitan.cell(row=6, column=8).value = '市区町村名[全角]'
            ### ws_chitan.cell(row=6, column=9).value = '都道府県コード'
            ### ws_chitan.cell(row=6, column=10).value = ''
            ### ws_chitan.cell(row=6, column=11).value = '異常気象コード'
            ### ws_chitan.cell(row=6, column=12).value = '水害発生'
            ### ws_chitan.cell(row=6, column=13).value = ''
            ### ws_chitan.cell(row=6, column=14).value = ''
            ### ws_chitan.cell(row=6, column=15).value = ''
            ### ws_chitan.cell(row=6, column=16).value = '工種区分'
            ### ws_chitan.cell(row=6, column=17).value = ''
            ### ws_chitan.cell(row=6, column=18).value = '市区町村コード'
            ### ws_chitan.cell(row=6, column=19).value = '災害復旧'
            ### ws_chitan.cell(row=6, column=20).value = ''
            ### ws_chitan.cell(row=6, column=21).value = '備考'
            ### ws_chitan.cell(row=7, column=1).value = ''
            ### ws_chitan.cell(row=7, column=2).value = ''
            ### ws_chitan.cell(row=7, column=3).value = ''
            ### ws_chitan.cell(row=7, column=4).value = ''
            ### ws_chitan.cell(row=7, column=5).value = ''
            ### ws_chitan.cell(row=7, column=6).value = ''
            ### ws_chitan.cell(row=7, column=7).value = ''
            ### ws_chitan.cell(row=7, column=8).value = ''
            ### ws_chitan.cell(row=7, column=9).value = ''
            ### ws_chitan.cell(row=7, column=10).value = ''
            ### ws_chitan.cell(row=7, column=11).value = ''
            ### ws_chitan.cell(row=7, column=12).value = '月'
            ### ws_chitan.cell(row=7, column=13).value = '日'
            ### ws_chitan.cell(row=7, column=14).value = '月'
            ### ws_chitan.cell(row=7, column=15).value = '日'
            ### ws_chitan.cell(row=7, column=16).value = ''
            ### ws_chitan.cell(row=7, column=17).value = ''
            ### ws_chitan.cell(row=7, column=18).value = ''
            ### ws_chitan.cell(row=7, column=19).value = '箇所'
            ### ws_chitan.cell(row=7, column=20).value = '査定額(千円)'
            ### ws_chitan.cell(row=7, column=21).value = ''
            ### ws_chitan.protection.enable()
            green_fill = PatternFill(fgColor='CCFFCC', patternType='solid')

            ###################################################################
            ### EXCEL入出力処理(0090)
            ### EXCELのセルに、値を埋め込む。
            ###################################################################
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 STEP 10/14.', 'DEBUG')
            params = dict({
                'KEN_CODE': trigger_list[0].ken_code
            })
            chitan_list = CHITAN.objects.raw("""
                SELECT 
                    CH1.chitan_id,
                    CH1.chitan_name,
                    CH1.chitan_header_id, 
                    CH1.chitan_header_name, 
                    CH1.ken_code, 
                    KE1.ken_name, 
                    CH1.city_code, 
                    CT1.city_name, 
                    CF1.upload_file_path, 
                    CF1.upload_file_name, 
                    CF1.summary_file_path, 
                    CF1.summary_file_name, 
                    CH1.suikei_code, 
                    SK1.suikei_name, 
                    SK1.suikei_type_code, 
                    ST1.suikei_type_name, 
                    CH1.kasen_code, 
                    KA1.kasen_name, 
                    KA1.kasen_type_code, 
                    KT1.kasen_type_name, 
                    CH1.weather_id, 
                    WE1.weather_name, 
                    TO_CHAR(timezone('JST', CH1.begin_date::timestamptz), 'mm') AS begin_month, 
                    TO_CHAR(timezone('JST', CH1.begin_date::timestamptz), 'dd') AS begin_day, 
                    TO_CHAR(timezone('JST', CH1.end_date::timestamptz), 'mm') AS end_month, 
                    TO_CHAR(timezone('JST', CH1.end_date::timestamptz), 'dd') AS end_day, 
                    CH1.kasen_kaigan_code,
                    KK1.kasen_kaigan_name,  
                    CH1.point,
                    CAST(CH1.assessment AS NUMERIC(20,10)) AS assessment, 
                    CH1.comment as comment, 
                    TO_CHAR(timezone('JST', CH1.committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                    TO_CHAR(timezone('JST', CH1.deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
                FROM CHITAN CH1 
                LEFT JOIN CHITAN_FILE CF1 ON CH1.chitan_file_id=CF1.chitan_file_id 
                LEFT JOIN SUIKEI SK1 ON CH1.suikei_code=SK1.suikei_code 
                LEFT JOIN KASEN KA1 ON CH1.kasen_code=KA1.kasen_code 
                LEFT JOIN KEN KE1 ON CH1.ken_code=KE1.ken_code 
                LEFT JOIN CITY CT1 ON CH1.city_code=CT1.city_code 
                LEFT JOIN WEATHER WE1 ON CH1.weather_id=WE1.weather_id 
                LEFT JOIN KASEN_KAIGAN KK1 ON CH1.kasen_kaigan_code=KK1.kasen_kaigan_code 
                LEFT JOIN SUIKEI_TYPE ST1 ON SK1.suikei_type_code=ST1.suikei_type_code 
                LEFT JOIN KASEN_TYPE KT1 ON KA1.kasen_type_code=KT1.kasen_type_code 
                WHERE 
                    CH1.ken_code=%(KEN_CODE)s AND 
                    CH1.deleted_at IS NULL 
                ORDER BY 
                    CAST(CH1.city_code AS INTEGER), 
                    CAST(CH1.chitan_file_id AS INTEGER), 
                    CAST(CH1.chitan_id AS INTEGER)""", params)
    
            ###################################################################
            ### EXCEL入出力処理(0100)
            ### 入力データ用EXCELシートのキャプションに値をセットする。
            ###################################################################
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 STEP 11/14.', 'DEBUG')
            if bool(chitan_list) == True:
                for i, chitan in enumerate(chitan_list):
                    if (bool(str(chitan.chitan_id) == True):
                        ws_chitan.cell(row=8+i, column=1).value = (
                            str(chitan.chitan_id)
                        )
                        ws_chitan.cell(row=8+i, column=1).fill = green_fill
                    
                    if (bool(str(chitan.suikei_name)) == True and 
                        bool(str(chitan.suikei_code)) == True):
                        ws_chitan.cell(row=8+i, column=2).value = (
                            str(chitan.suikei_name) + ":" + 
                            str(chitan.suikei_code)
                        )

                    if (bool(str(chitan.suikei_type_name)) == True and 
                        bool(str(chitan.suikei_type_code)) == True):
                        ws_chitan.cell(row=8+i, column=3).value = (
                            str(chitan.suikei_type_name) + ":" + 
                            str(chitan.suikei_type_code)
                        )
                    
                    if (bool(str(chitan.kasen_name)) == True and 
                        bool(str(chitan.kasen_code)) == True):
                        ws_chitan.cell(row=8+i, column=4).value = (
                            str(chitan.kasen_name) + ":" + 
                            str(chitan.kasen_code)
                        )
                        
                    if (bool(str(chitan.kasen_type_name)) == True and 
                        bool(str(chitan.kasen_type_code)) == True):
                        ws_chitan.cell(row=8+i, column=5).value = (
                            str(chitan.kasen_type_name) + ":" + 
                            str(chitan.kasen_type_code)
                        )
                    
                    if (bool(str(chitan.chitan_name)) == True):
                        ws_chitan.cell(row=8+i, column=6).value = (
                            str(chitan.chitan_name)
                        )
                        
                    if (bool(str(chitan.ken_name)) == True and 
                        bool(str(chitan.ken_code)) == True):
                        ws_chitan.cell(row=8+i, column=7).value = (
                            str(chitan.ken_name) + ":" + 
                            str(chitan.ken_code)
                        )
                    
                    if (bool(str(chitan.city_name)) == True and 
                        bool(str(chitan.city_code)) == True):
                        ws_chitan.cell(row=8+i, column=8).value = (
                            str(chitan.city_name) + ":" + 
                            str(chitan.city_code)
                        )
                    
                    if (bool(str(chitan.ken_code)) == True):
                        ws_chitan.cell(row=8+i, column=9).value = (
                            str(chitan.ken_code)
                        )

                    ws_chitan.cell(row=8+i, column=10).value = ""
                    
                    if (bool(str(chitan.weather_name)) == True and 
                        bool(str(chitan.weather_id)) == True):
                        ws_chitan.cell(row=8+i, column=11).value = (
                            str(chitan.weather_name) + ":" + 
                            str(chitan.weather_id)
                        )
                        
                    if (bool(str(chitan.begin_month)) == True):
                        ws_chitan.cell(row=8+i, column=12).value = (
                            str(chitan.begin_month)
                        )

                    if (bool(str(chitan.begin_day)) == True):
                        ws_chitan.cell(row=8+i, column=13).value = (
                            str(chitan.begin_day)
                        )
                    
                    if (bool(str(chitan.end_month)) == True):
                        ws_chitan.cell(row=8+i, column=14).value = (
                            str(chitan.end_month)
                        )
                    
                    if (bool(str(chitan.end_day)) == True):
                        ws_chitan.cell(row=8+i, column=15).value = (
                            str(chitan.end_day)
                        )
                        
                    if (bool(str(chitan.kasen_kaigan_name)) == True and 
                        bool(str(chitan.kasen_kaigan_code)) == True):
                        ws_chitan.cell(row=8+i, column=16).value = (
                            str(chitan.kasen_kaigan_name) + ":" + 
                            str(chitan.kasen_kaigan_code)
                        )

                    ws_chitan.cell(row=8+i, column=17).value = ""
                        
                    if (bool(str(chitan.city_code)) == True):
                        ws_chitan.cell(row=8+i, column=18).value = (
                            str(chitan.city_code)
                        )
                        
                    if (bool(str(chitan.point)) == True):
                        ws_chitan.cell(row=8+i, column=19).value = (
                            str(chitan.point)
                        )
                        
                    if (bool(str(chitan.assessment)) == True):
                        ws_chitan.cell(row=8+i, column=20).value = (
                            str(chitan.assessment)
                        )
                    
                    if (bool(str(chitan.comment)) == True):
                        ws_chitan.cell(row=8+i, column=21).value = (
                            str(chitan.comment)
                        )

            ###################################################################
            ### EXCEL入出力処理(0110)
            ### ダウンロード用のEXCELファイルを保存する。
            ###################################################################
            print_log('[DEBUG] action_Z04_download_chitan()関数 STEP 12/14.', 'DEBUG')
            wb.save(chitan_trigger_list[0].download_file_path)

            ###################################################################
            ### DBアクセス処理(0120)
            ### トリガーデータを更新する。
            ###################################################################
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 STEP 13/14.', 'DEBUG')
            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")
                
                ###############################################################
                ### DBアクセス処理(0130)
                ### トリガーデータを更新する。
                ###############################################################
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'trigger_id': chitan_trigger_list[0].chitan_trigger_id, 
                    'action_code': _Z04, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': get_info_log(), 
                    'warn_log': get_warn_log()
                })
                bool_return = consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[WARN] consume_message()関数が警告終了しました。', 'WARN')
                    return 4
                
                connection_cursor.execute("""COMMIT""")
                
            except:
                print_log('[ERROR] action_Z04_download_chitan.handle()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] action_Z04_download_chitan.handle()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
                print_log('[ERROR] action_Z04_download_chitan.handle()関数が異常終了しました。', 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
                return 8
                
            finally:
                ### try except finallyのtry文中でreturnを発生させた場合、
                ### finally文中のconnection_cursor.close()が実行されて、
                ### その後に関数を抜ける。
                ### したがって、finally文中でreturnする必要はない。
                connection_cursor.close()
                
            ###################################################################
            ### 戻り値セット処理(0140)
            ### 戻り値を戻す。
            ###################################################################
            print_log('[DEBUG] action_Z04_download_chitan.handle()関数 STEP 14/14.', 'DEBUG')
            print_log('[INFO] action_Z04_download_chitan.handle()関数が正常終了しました。', 'INFO')
            return 0
        
        except:
            print_log('[ERROR] action_Z04_download_chitan.handle()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] action_Z04_download_chitan.handle()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] action_Z04_download_chitan.handle()関数が異常終了しました。', 'ERROR')
            return 8
            