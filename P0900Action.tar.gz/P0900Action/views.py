###############################################################################
### ファイル名：P0900Action/views.py
### 自動実行・自動検証
###############################################################################

import sys
from django.contrib.auth.decorators import login_required
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic.base import TemplateView

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

###############################################################################
### 関数名：get_ippan_trigger_list(action_code, status_code)
###############################################################################
def get_ippan_trigger_list(action_code, status_code):
    params = dict({
        'ACTION_CODE': action_code, 
        'STATUS_CODE': status_code
    })
    ippan_trigger_list = IPPAN_TRIGGER.objects.raw("""
        SELECT 
            TR1.ippan_trigger_id, 
            TR1.ippan_header_id, 
            SG1.ippan_header_name, 
            TR1.ken_code, 
            KE1.ken_name, 
            TR1.city_code, 
            CT1.city_name, 
            TR1.action_code, 
            AC1.action_name, 
            TR1.status_code, 
            ST1.status_name, 
            TR1.info_count, 
            TR1.warn_count, 
            TO_CHAR(timezone('JST', TR1.published_at::timestamptz), 'mm/dd HH24:MI') AS published_at, 
            TO_CHAR(timezone('JST', TR1.consumed_at::timestamptz), 'mm/dd HH24:MI') AS consumed_at, 
            TO_CHAR(timezone('JST', TR1.deleted_at::timestamptz), 'mm/dd HH24:MI') AS deleted_at, 
            TR1.download_file_path, 
            TR1.download_file_name, 
            TR1.upload_file_path, 
            TR1.upload_file_name 
        FROM IPPAN_TRIGGER TR1 
        LEFT JOIN IPPAN_HEADER SG1 ON TR1.ippan_header_id=SG1.ippan_header_id 
        LEFT JOIN KEN KE1 ON TR1.ken_code=KE1.ken_code 
        LEFT JOIN CITY CT1 ON TR1.city_code=CT1.city_code 
        LEFT JOIN ACTION AC1 ON TR1.action_code=AC1.action_code 
        LEFT JOIN STATUS ST1 ON TR1.status_code=ST1.status_code 
        WHERE 
            TR1.action_code=%(ACTION_CODE)s AND 
            TR1.status_code=%(STATUS_CODE)s AND 
            TR1.deleted_at IS NULL 
        ORDER BY 
            CAST(TR1.ken_code AS INTEGER), CAST(TR1.city_code AS INTEGER), CAST(TR1.ippan_trigger_id AS INTEGER)""", params)
    return ippan_trigger_list

###############################################################################
### 関数名：get_chitan_trigger_list
###############################################################################
def get_chitan_trigger_list(action_code, status_code):
    params = dict({
        'ACTION_CODE': action_code, 
        'STATUS_CODE': status_code
    })
    chitan_trigger_list = CHITAN_TRIGGER.objects.raw("""
        SELECT 
            TR1.chitan_trigger_id, 
            TR1.chitan_header_id, 
            SG1.chitan_header_name, 
            TR1.ken_code, 
            KE1.ken_name, 
            TR1.city_code, 
            CT1.city_name, 
            TR1.action_code, 
            AC1.action_name, 
            TR1.status_code, 
            ST1.status_name, 
            TR1.info_count, 
            TR1.warn_count, 
            TO_CHAR(timezone('JST', TR1.published_at::timestamptz), 'mm/dd HH24:MI') AS published_at, 
            TO_CHAR(timezone('JST', TR1.consumed_at::timestamptz), 'mm/dd HH24:MI') AS consumed_at, 
            TO_CHAR(timezone('JST', TR1.deleted_at::timestamptz), 'mm/dd HH24:MI') AS deleted_at, 
            TR1.download_file_path, 
            TR1.download_file_name, 
            TR1.upload_file_path, 
            TR1.upload_file_name 
        FROM CHITAN_TRIGGER TR1 
        LEFT JOIN CHITAN_HEADER SG1 ON TR1.chitan_header_id=SG1.chitan_header_id 
        LEFT JOIN KEN KE1 ON TR1.ken_code=KE1.ken_code 
        LEFT JOIN CITY CT1 ON TR1.city_code=CT1.city_code 
        LEFT JOIN ACTION AC1 ON TR1.action_code=AC1.action_code 
        LEFT JOIN STATUS ST1 ON TR1.status_code=ST1.status_code 
        WHERE 
            TR1.action_code=%(ACTION_CODE)s AND 
            TR1.status_code=%(STATUS_CODE)s AND 
            TR1.deleted_at IS NULL 
        ORDER BY 
            CAST(TR1.ken_code AS INTEGER), CAST(TR1.city_code AS INTEGER), CAST(TR1.chitan_trigger_id AS INTEGER)""", params)
    return chitan_trigger_list

###############################################################################
### 関数名：get_hojo_trigger_list
###############################################################################
def get_hojo_trigger_list(action_code, status_code):
    params = dict({
        'ACTION_CODE': action_code, 
        'STATUS_CODE': status_code
    })
    hojo_trigger_list = HOJO_TRIGGER.objects.raw("""
        SELECT 
            TR1.hojo_trigger_id, 
            TR1.hojo_header_id, 
            SG1.hojo_header_name, 
            TR1.ken_code, 
            KE1.ken_name, 
            TR1.city_code, 
            CT1.city_name, 
            TR1.action_code, 
            AC1.action_name, 
            TR1.status_code, 
            ST1.status_name, 
            TR1.info_count, 
            TR1.warn_count, 
            TO_CHAR(timezone('JST', TR1.published_at::timestamptz), 'mm/dd HH24:MI') AS published_at, 
            TO_CHAR(timezone('JST', TR1.consumed_at::timestamptz), 'mm/dd HH24:MI') AS consumed_at, 
            TO_CHAR(timezone('JST', TR1.deleted_at::timestamptz), 'mm/dd HH24:MI') AS deleted_at, 
            TR1.download_file_path, 
            TR1.download_file_name, 
            TR1.upload_file_path, 
            TR1.upload_file_name 
        FROM HOJO_TRIGGER TR1 
        LEFT JOIN HOJO_HEADER SG1 ON TR1.hojo_header_id=SG1.hojo_header_id 
        LEFT JOIN KEN KE1 ON TR1.ken_code=KE1.ken_code 
        LEFT JOIN CITY CT1 ON TR1.city_code=CT1.city_code 
        LEFT JOIN ACTION AC1 ON TR1.action_code=AC1.action_code 
        LEFT JOIN STATUS ST1 ON TR1.status_code=ST1.status_code 
        WHERE 
            TR1.action_code=%(ACTION_CODE)s AND 
            TR1.status_code=%(STATUS_CODE)s AND 
            TR1.deleted_at IS NULL 
        ORDER BY 
            CAST(TR1.ken_code AS INTEGER), CAST(TR1.city_code AS INTEGER), CAST(TR1.hojo_trigger_id AS INTEGER)""", params)
    return hojo_trigger_list

###############################################################################
### 関数名：get_koeki_trigger_list
###############################################################################
def get_koeki_trigger_list(action_code, status_code):
    params = dict({
        'ACTION_CODE': action_code, 
        'STATUS_CODE': status_code
    })
    koeki_trigger_list = KOEKI_TRIGGER.objects.raw("""
        SELECT 
            TR1.koeki_trigger_id, 
            TR1.koeki_header_id, 
            SG1.koeki_header_name, 
            TR1.ken_code, 
            KE1.ken_name, 
            TR1.city_code, 
            CT1.city_name, 
            TR1.action_code, 
            AC1.action_name, 
            TR1.status_code, 
            ST1.status_name, 
            TR1.info_count, 
            TR1.warn_count, 
            TO_CHAR(timezone('JST', TR1.published_at::timestamptz), 'mm/dd HH24:MI') AS published_at, 
            TO_CHAR(timezone('JST', TR1.consumed_at::timestamptz), 'mm/dd HH24:MI') AS consumed_at, 
            TO_CHAR(timezone('JST', TR1.deleted_at::timestamptz), 'mm/dd HH24:MI') AS deleted_at, 
            TR1.download_file_path, 
            TR1.download_file_name, 
            TR1.upload_file_path, 
            TR1.upload_file_name 
        FROM KOEKI_TRIGGER TR1 
        LEFT JOIN KOEKI_HEADER SG1 ON TR1.koeki_header_id=SG1.koeki_header_id 
        LEFT JOIN KEN KE1 ON TR1.ken_code=KE1.ken_code 
        LEFT JOIN CITY CT1 ON TR1.city_code=CT1.city_code 
        LEFT JOIN ACTION AC1 ON TR1.action_code=AC1.action_code 
        LEFT JOIN STATUS ST1 ON TR1.status_code=ST1.status_code 
        WHERE 
            TR1.action_code=%(ACTION_CODE)s AND 
            TR1.status_code=%(STATUS_CODE)s AND 
            TR1.deleted_at IS NULL 
        ORDER BY 
            CAST(TR1.ken_code AS INTEGER), CAST(TR1.city_code AS INTEGER), CAST(TR1.koeki_trigger_id AS INTEGER)""", params)
    return koeki_trigger_list

###############################################################################
### 関数名：get_ippan_trigger_count
###############################################################################
def get_ippan_trigger_count(action_code, status_code):
    params = dict({
        'ACTION_CODE': action_code, 
        'STATUS_CODE': status_code
    })
    ippan_trigger_list = IPPAN_TRIGGER.objects.raw("""
        SELECT 
            * 
        FROM IPPAN_TRIGGER 
        WHERE 
            action_code=%(ACTION_CODE)s AND 
            status_code=%(STATUS_CODE)s AND 
            deleted_at IS NULL""", params)

    if ippan_trigger_list:
        return str(len(ippan_trigger_list))
    else:
        return str(0)

###############################################################################
### 関数名：get_chitan_trigger_count
###############################################################################
def get_chitan_trigger_count(action_code, status_code):
    params = dict({
        'ACTION_CODE': action_code, 
        'STATUS_CODE': status_code
    })
    chitan_trigger_list = CHITAN_TRIGGER.objects.raw("""
        SELECT 
            * 
        FROM CHITAN_TRIGGER 
        WHERE 
            action_code=%(ACTION_CODE)s AND 
            status_code=%(STATUS_CODE)s AND 
            deleted_at IS NULL""", params)

    if chitan_trigger_list:
        return str(len(chitan_trigger_list))
    else:
        return str(0)

###############################################################################
### 関数名：get_hojo_trigger_count
###############################################################################
def get_hojo_trigger_count(action_code, status_code):
    params = dict({
        'ACTION_CODE': action_code, 
        'STATUS_CODE': status_code
    })
    hojo_trigger_list = HOJO_TRIGGER.objects.raw("""
        SELECT 
            * 
        FROM HOJO_TRIGGER 
        WHERE 
            action_code=%(ACTION_CODE)s AND 
            status_code=%(STATUS_CODE)s AND 
            deleted_at IS NULL""", params)

    if hojo_trigger_list:
        return str(len(hojo_trigger_list))
    else:
        return str(0)

###############################################################################
### 関数名：get_koeki_trigger_count
###############################################################################
def get_koeki_trigger_count(action_code, status_code):
    params = dict({
        'ACTION_CODE': action_code, 
        'STATUS_CODE': status_code
    })
    koeki_trigger_list = KOEKI_TRIGGER.objects.raw("""
        SELECT 
            * 
        FROM KOEKI_TRIGGER 
        WHERE 
            action_code=%(ACTION_CODE)s AND 
            status_code=%(STATUS_CODE)s AND 
            deleted_at IS NULL""", params)

    if koeki_trigger_list:
        return str(len(koeki_trigger_list))
    else:
        return str(0)

###############################################################################
### 関数名：index_view
### urlpatterns：path('', views.index_view, name='index_view')       
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0900Action.index_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0900Action.index_view()関数 STEP 1/12.', 'DEBUG')
        print_log('[DEBUG] P0900Action.index_view()関数 request={}'.format(request.method), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0900Action.index_view()関数 STEP 2/12.', 'DEBUG')
        trigger_A01_running_list = get_ippan_trigger_list(action_code='A01', status_code='RUNNING')
        trigger_A02_running_list = get_ippan_trigger_list(action_code='A02', status_code='RUNNING')
        trigger_A03_running_list = get_ippan_trigger_list(action_code='A03', status_code='RUNNING')
        trigger_A04_running_list = get_ippan_trigger_list(action_code='A04', status_code='RUNNING')
        trigger_A05_running_list = get_ippan_trigger_list(action_code='A05', status_code='RUNNING')
        trigger_A06_running_list = get_ippan_trigger_list(action_code='A06', status_code='RUNNING')
        trigger_A07_running_list = get_ippan_trigger_list(action_code='A07', status_code='RUNNING')
        trigger_A99_running_list = get_ippan_trigger_list(action_code='A99', status_code='RUNNING')
        trigger_N01_running_list = get_ippan_trigger_list(action_code='N01', status_code='RUNNING')
        trigger_O01_running_list = get_ippan_trigger_list(action_code='O01', status_code='RUNNING')
        trigger_P01_running_list = get_ippan_trigger_list(action_code='P01', status_code='RUNNING')

        trigger_A01_cancel_list = get_ippan_trigger_list(action_code='A01', status_code='CANCEL')
        trigger_A02_cancel_list = get_ippan_trigger_list(action_code='A02', status_code='CANCEL')
        trigger_A03_cancel_list = get_ippan_trigger_list(action_code='A03', status_code='CANCEL')
        trigger_A04_cancel_list = get_ippan_trigger_list(action_code='A04', status_code='CANCEL')
        trigger_A05_cancel_list = get_ippan_trigger_list(action_code='A05', status_code='CANCEL')
        trigger_A06_cancel_list = get_ippan_trigger_list(action_code='A06', status_code='CANCEL')
        trigger_A07_cancel_list = get_ippan_trigger_list(action_code='A07', status_code='CANCEL')
        trigger_A99_cancel_list = get_ippan_trigger_list(action_code='A99', status_code='CANCEL')
        trigger_N01_cancel_list = get_ippan_trigger_list(action_code='N01', status_code='CANCEL')
        trigger_O01_cancel_list = get_ippan_trigger_list(action_code='O01', status_code='CANCEL')
        trigger_P01_cancel_list = get_ippan_trigger_list(action_code='P01', status_code='CANCEL')

        trigger_A01_success_list = get_ippan_trigger_list(action_code='A01', status_code='SUCCESS')
        trigger_A02_success_list = get_ippan_trigger_list(action_code='A02', status_code='SUCCESS')
        trigger_A03_success_list = get_ippan_trigger_list(action_code='A03', status_code='SUCCESS')
        trigger_A04_success_list = get_ippan_trigger_list(action_code='A04', status_code='SUCCESS')
        trigger_A05_success_list = get_ippan_trigger_list(action_code='A05', status_code='SUCCESS')
        trigger_A06_success_list = get_ippan_trigger_list(action_code='A06', status_code='SUCCESS')
        trigger_A07_success_list = get_ippan_trigger_list(action_code='A07', status_code='SUCCESS')
        trigger_A99_success_list = get_ippan_trigger_list(action_code='A99', status_code='SUCCESS')
        trigger_N01_success_list = get_ippan_trigger_list(action_code='N01', status_code='SUCCESS')
        trigger_O01_success_list = get_ippan_trigger_list(action_code='O01', status_code='SUCCESS')
        trigger_P01_success_list = get_ippan_trigger_list(action_code='P01', status_code='SUCCESS')
        
        trigger_A01_failure_list = get_ippan_trigger_list(action_code='A01', status_code='FAILURE')
        trigger_A02_failure_list = get_ippan_trigger_list(action_code='A02', status_code='FAILURE')
        trigger_A03_failure_list = get_ippan_trigger_list(action_code='A03', status_code='FAILURE')
        trigger_A04_failure_list = get_ippan_trigger_list(action_code='A04', status_code='FAILURE')
        trigger_A05_failure_list = get_ippan_trigger_list(action_code='A05', status_code='FAILURE')
        trigger_A06_failure_list = get_ippan_trigger_list(action_code='A06', status_code='FAILURE')
        trigger_A07_failure_list = get_ippan_trigger_list(action_code='A07', status_code='FAILURE')
        trigger_A99_failure_list = get_ippan_trigger_list(action_code='A99', status_code='FAILURE')
        trigger_N01_failure_list = get_ippan_trigger_list(action_code='N01', status_code='FAILURE')
        trigger_O01_failure_list = get_ippan_trigger_list(action_code='O01', status_code='FAILURE')
        trigger_P01_failure_list = get_ippan_trigger_list(action_code='P01', status_code='FAILURE')

        trigger_A01_waiting_list = get_ippan_trigger_list(action_code='A01', status_code='WAITING')
        trigger_A02_waiting_list = get_ippan_trigger_list(action_code='A02', status_code='WAITING')
        trigger_A03_waiting_list = get_ippan_trigger_list(action_code='A03', status_code='WAITING')
        trigger_A04_waiting_list = get_ippan_trigger_list(action_code='A04', status_code='WAITING')
        trigger_A05_waiting_list = get_ippan_trigger_list(action_code='A05', status_code='WAITING')
        trigger_A06_waiting_list = get_ippan_trigger_list(action_code='A06', status_code='WAITING')
        trigger_A07_waiting_list = get_ippan_trigger_list(action_code='A07', status_code='WAITING')
        trigger_A99_waiting_list = get_ippan_trigger_list(action_code='A99', status_code='WAITING')
        trigger_N01_waiting_list = get_ippan_trigger_list(action_code='N01', status_code='WAITING')
        trigger_O01_waiting_list = get_ippan_trigger_list(action_code='O01', status_code='WAITING')
        trigger_P01_waiting_list = get_ippan_trigger_list(action_code='P01', status_code='WAITING')

        #######################################################################
        ### DBアクセス処理(0020)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0900Action.index_view()関数 STEP 3/12.', 'DEBUG')
        ### trigger_B01_running_list = get_area_trigger_list(action_code='B01', status_code='RUNNING')
        ### trigger_B02_running_list = get_area_trigger_list(action_code='B02', status_code='RUNNING')
        ### trigger_B03_running_list = get_area_trigger_list(action_code='B03', status_code='RUNNING')
        ### trigger_B04_running_list = get_area_trigger_list(action_code='B04', status_code='RUNNING')
        ### trigger_B99_running_list = get_area_trigger_list(action_code='B99', status_code='RUNNING')

        ### trigger_B01_cancel_list = get_area_trigger_list(action_code='B01', status_code='CANCEL')
        ### trigger_B02_cancel_list = get_area_trigger_list(action_code='B02', status_code='CANCEL')
        ### trigger_B03_cancel_list = get_area_trigger_list(action_code='B03', status_code='CANCEL')
        ### trigger_B04_cancel_list = get_area_trigger_list(action_code='B04', status_code='CANCEL')
        ### trigger_B99_cancel_list = get_area_trigger_list(action_code='B99', status_code='CANCEL')

        ### trigger_B01_success_list = get_area_trigger_list(action_code='B01', status_code='SUCCESS')
        ### trigger_B02_success_list = get_area_trigger_list(action_code='B02', status_code='SUCCESS')
        ### trigger_B03_success_list = get_area_trigger_list(action_code='B03', status_code='SUCCESS')
        ### trigger_B04_success_list = get_area_trigger_list(action_code='B04', status_code='SUCCESS')
        ### trigger_B99_success_list = get_area_trigger_list(action_code='B99', status_code='SUCCESS')
        
        ### trigger_B01_failure_list = get_area_trigger_list(action_code='B01', status_code='FAILURE')
        ### trigger_B02_failure_list = get_area_trigger_list(action_code='B02', status_code='FAILURE')
        ### trigger_B03_failure_list = get_area_trigger_list(action_code='B03', status_code='FAILURE')
        ### trigger_B04_failure_list = get_area_trigger_list(action_code='B04', status_code='FAILURE')
        ### trigger_B99_failure_list = get_area_trigger_list(action_code='B99', status_code='FAILURE')

        ### trigger_B01_waiting_list = get_area_trigger_list(action_code='B01', status_code='WAITING')
        ### trigger_B02_waiting_list = get_area_trigger_list(action_code='B02', status_code='WAITING')
        ### trigger_B03_waiting_list = get_area_trigger_list(action_code='B03', status_code='WAITING')
        ### trigger_B04_waiting_list = get_area_trigger_list(action_code='B04', status_code='WAITING')
        ### trigger_B99_waiting_list = get_area_trigger_list(action_code='B99', status_code='WAITING')

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0900Action.index_view()関数 STEP 4/12.', 'DEBUG')
        trigger_C01_running_list = get_chitan_trigger_list(action_code='C01', status_code='RUNNING')
        trigger_C02_running_list = get_chitan_trigger_list(action_code='C02', status_code='RUNNING')
        trigger_C03_running_list = get_chitan_trigger_list(action_code='C03', status_code='RUNNING')
        trigger_C04_running_list = get_chitan_trigger_list(action_code='C04', status_code='RUNNING')
        trigger_C05_running_list = get_chitan_trigger_list(action_code='C05', status_code='RUNNING')
        trigger_C06_running_list = get_chitan_trigger_list(action_code='C06', status_code='RUNNING')
        trigger_C07_running_list = get_chitan_trigger_list(action_code='C07', status_code='RUNNING')
        trigger_C99_running_list = get_chitan_trigger_list(action_code='C99', status_code='RUNNING')
        trigger_Q01_running_list = get_chitan_trigger_list(action_code='Q01', status_code='RUNNING')

        trigger_C01_cancel_list = get_chitan_trigger_list(action_code='C01', status_code='CANCEL')
        trigger_C02_cancel_list = get_chitan_trigger_list(action_code='C02', status_code='CANCEL')
        trigger_C03_cancel_list = get_chitan_trigger_list(action_code='C03', status_code='CANCEL')
        trigger_C04_cancel_list = get_chitan_trigger_list(action_code='C04', status_code='CANCEL')
        trigger_C05_cancel_list = get_chitan_trigger_list(action_code='C05', status_code='CANCEL')
        trigger_C06_cancel_list = get_chitan_trigger_list(action_code='C06', status_code='CANCEL')
        trigger_C07_cancel_list = get_chitan_trigger_list(action_code='C07', status_code='CANCEL')
        trigger_C99_cancel_list = get_chitan_trigger_list(action_code='C99', status_code='CANCEL')
        trigger_Q01_cancel_list = get_chitan_trigger_list(action_code='Q01', status_code='CANCEL')

        trigger_C01_success_list = get_chitan_trigger_list(action_code='C01', status_code='SUCCESS')
        trigger_C02_success_list = get_chitan_trigger_list(action_code='C02', status_code='SUCCESS')
        trigger_C03_success_list = get_chitan_trigger_list(action_code='C03', status_code='SUCCESS')
        trigger_C04_success_list = get_chitan_trigger_list(action_code='C04', status_code='SUCCESS')
        trigger_C05_success_list = get_chitan_trigger_list(action_code='C05', status_code='SUCCESS')
        trigger_C06_success_list = get_chitan_trigger_list(action_code='C06', status_code='SUCCESS')
        trigger_C07_success_list = get_chitan_trigger_list(action_code='C07', status_code='SUCCESS')
        trigger_C99_success_list = get_chitan_trigger_list(action_code='C99', status_code='SUCCESS')
        trigger_Q01_success_list = get_chitan_trigger_list(action_code='Q01', status_code='SUCCESS')
        
        trigger_C01_failure_list = get_chitan_trigger_list(action_code='C01', status_code='FAILURE')
        trigger_C02_failure_list = get_chitan_trigger_list(action_code='C02', status_code='FAILURE')
        trigger_C03_failure_list = get_chitan_trigger_list(action_code='C03', status_code='FAILURE')
        trigger_C04_failure_list = get_chitan_trigger_list(action_code='C04', status_code='FAILURE')
        trigger_C05_failure_list = get_chitan_trigger_list(action_code='C05', status_code='FAILURE')
        trigger_C06_failure_list = get_chitan_trigger_list(action_code='C06', status_code='FAILURE')
        trigger_C07_failure_list = get_chitan_trigger_list(action_code='C07', status_code='FAILURE')
        trigger_C99_failure_list = get_chitan_trigger_list(action_code='C99', status_code='FAILURE')
        trigger_Q01_failure_list = get_chitan_trigger_list(action_code='Q01', status_code='FAILURE')

        trigger_C01_waiting_list = get_chitan_trigger_list(action_code='C01', status_code='WAITING')
        trigger_C02_waiting_list = get_chitan_trigger_list(action_code='C02', status_code='WAITING')
        trigger_C03_waiting_list = get_chitan_trigger_list(action_code='C03', status_code='WAITING')
        trigger_C04_waiting_list = get_chitan_trigger_list(action_code='C04', status_code='WAITING')
        trigger_C05_waiting_list = get_chitan_trigger_list(action_code='C05', status_code='WAITING')
        trigger_C06_waiting_list = get_chitan_trigger_list(action_code='C06', status_code='WAITING')
        trigger_C07_waiting_list = get_chitan_trigger_list(action_code='C07', status_code='WAITING')
        trigger_C99_waiting_list = get_chitan_trigger_list(action_code='C99', status_code='WAITING')
        trigger_Q01_waiting_list = get_chitan_trigger_list(action_code='Q01', status_code='WAITING')

        #######################################################################
        ### DBアクセス処理(0040)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0900Action.index_view()関数 STEP 5/12.', 'DEBUG')
        trigger_D01_running_list = get_hojo_trigger_list(action_code='D01', status_code='RUNNING')
        trigger_D02_running_list = get_hojo_trigger_list(action_code='D02', status_code='RUNNING')
        trigger_D03_running_list = get_hojo_trigger_list(action_code='D03', status_code='RUNNING')
        trigger_D04_running_list = get_hojo_trigger_list(action_code='D04', status_code='RUNNING')
        trigger_D05_running_list = get_hojo_trigger_list(action_code='D05', status_code='RUNNING')
        trigger_D06_running_list = get_hojo_trigger_list(action_code='D06', status_code='RUNNING')
        trigger_D07_running_list = get_hojo_trigger_list(action_code='D07', status_code='RUNNING')
        trigger_D99_running_list = get_hojo_trigger_list(action_code='D99', status_code='RUNNING')
        trigger_R01_running_list = get_hojo_trigger_list(action_code='R01', status_code='RUNNING')

        trigger_D01_cancel_list = get_hojo_trigger_list(action_code='D01', status_code='CANCEL')
        trigger_D02_cancel_list = get_hojo_trigger_list(action_code='D02', status_code='CANCEL')
        trigger_D03_cancel_list = get_hojo_trigger_list(action_code='D03', status_code='CANCEL')
        trigger_D04_cancel_list = get_hojo_trigger_list(action_code='D04', status_code='CANCEL')
        trigger_D05_cancel_list = get_hojo_trigger_list(action_code='D05', status_code='CANCEL')
        trigger_D06_cancel_list = get_hojo_trigger_list(action_code='D06', status_code='CANCEL')
        trigger_D07_cancel_list = get_hojo_trigger_list(action_code='D07', status_code='CANCEL')
        trigger_D99_cancel_list = get_hojo_trigger_list(action_code='D99', status_code='CANCEL')
        trigger_R01_cancel_list = get_hojo_trigger_list(action_code='R01', status_code='CANCEL')

        trigger_D01_success_list = get_hojo_trigger_list(action_code='D01', status_code='SUCCESS')
        trigger_D02_success_list = get_hojo_trigger_list(action_code='D02', status_code='SUCCESS')
        trigger_D03_success_list = get_hojo_trigger_list(action_code='D03', status_code='SUCCESS')
        trigger_D04_success_list = get_hojo_trigger_list(action_code='D04', status_code='SUCCESS')
        trigger_D05_success_list = get_hojo_trigger_list(action_code='D05', status_code='SUCCESS')
        trigger_D06_success_list = get_hojo_trigger_list(action_code='D06', status_code='SUCCESS')
        trigger_D07_success_list = get_hojo_trigger_list(action_code='D07', status_code='SUCCESS')
        trigger_D99_success_list = get_hojo_trigger_list(action_code='D99', status_code='SUCCESS')
        trigger_R01_success_list = get_hojo_trigger_list(action_code='R01', status_code='SUCCESS')
        
        trigger_D01_failure_list = get_hojo_trigger_list(action_code='D01', status_code='FAILURE')
        trigger_D02_failure_list = get_hojo_trigger_list(action_code='D02', status_code='FAILURE')
        trigger_D03_failure_list = get_hojo_trigger_list(action_code='D03', status_code='FAILURE')
        trigger_D04_failure_list = get_hojo_trigger_list(action_code='D04', status_code='FAILURE')
        trigger_D05_failure_list = get_hojo_trigger_list(action_code='D05', status_code='FAILURE')
        trigger_D06_failure_list = get_hojo_trigger_list(action_code='D06', status_code='FAILURE')
        trigger_D07_failure_list = get_hojo_trigger_list(action_code='D07', status_code='FAILURE')
        trigger_D99_failure_list = get_hojo_trigger_list(action_code='D99', status_code='FAILURE')
        trigger_R01_failure_list = get_hojo_trigger_list(action_code='R01', status_code='FAILURE')

        trigger_D01_waiting_list = get_hojo_trigger_list(action_code='D01', status_code='WAITING')
        trigger_D02_waiting_list = get_hojo_trigger_list(action_code='D02', status_code='WAITING')
        trigger_D03_waiting_list = get_hojo_trigger_list(action_code='D03', status_code='WAITING')
        trigger_D04_waiting_list = get_hojo_trigger_list(action_code='D04', status_code='WAITING')
        trigger_D05_waiting_list = get_hojo_trigger_list(action_code='D05', status_code='WAITING')
        trigger_D06_waiting_list = get_hojo_trigger_list(action_code='D06', status_code='WAITING')
        trigger_D07_waiting_list = get_hojo_trigger_list(action_code='D07', status_code='WAITING')
        trigger_D99_waiting_list = get_hojo_trigger_list(action_code='D99', status_code='WAITING')
        trigger_R01_waiting_list = get_hojo_trigger_list(action_code='R01', status_code='WAITING')

        #######################################################################
        ### DBアクセス処理(0050)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0900Action.index_view()関数 STEP 6/12.', 'DEBUG')
        trigger_E01_running_list = get_koeki_trigger_list(action_code='E01', status_code='RUNNING')
        trigger_E02_running_list = get_koeki_trigger_list(action_code='E02', status_code='RUNNING')
        trigger_E03_running_list = get_koeki_trigger_list(action_code='E03', status_code='RUNNING')
        trigger_E04_running_list = get_koeki_trigger_list(action_code='E04', status_code='RUNNING')
        trigger_E05_running_list = get_koeki_trigger_list(action_code='E05', status_code='RUNNING')
        trigger_E06_running_list = get_koeki_trigger_list(action_code='E06', status_code='RUNNING')
        trigger_E07_running_list = get_koeki_trigger_list(action_code='E07', status_code='RUNNING')
        trigger_E99_running_list = get_koeki_trigger_list(action_code='E99', status_code='RUNNING')
        trigger_S01_running_list = get_koeki_trigger_list(action_code='S01', status_code='RUNNING')

        trigger_E01_cancel_list = get_koeki_trigger_list(action_code='E01', status_code='CANCEL')
        trigger_E02_cancel_list = get_koeki_trigger_list(action_code='E02', status_code='CANCEL')
        trigger_E03_cancel_list = get_koeki_trigger_list(action_code='E03', status_code='CANCEL')
        trigger_E04_cancel_list = get_koeki_trigger_list(action_code='E04', status_code='CANCEL')
        trigger_E05_cancel_list = get_koeki_trigger_list(action_code='E05', status_code='CANCEL')
        trigger_E06_cancel_list = get_koeki_trigger_list(action_code='E06', status_code='CANCEL')
        trigger_E07_cancel_list = get_koeki_trigger_list(action_code='E07', status_code='CANCEL')
        trigger_E99_cancel_list = get_koeki_trigger_list(action_code='E99', status_code='CANCEL')
        trigger_S01_cancel_list = get_koeki_trigger_list(action_code='S01', status_code='CANCEL')

        trigger_E01_success_list = get_koeki_trigger_list(action_code='E01', status_code='SUCCESS')
        trigger_E02_success_list = get_koeki_trigger_list(action_code='E02', status_code='SUCCESS')
        trigger_E03_success_list = get_koeki_trigger_list(action_code='E03', status_code='SUCCESS')
        trigger_E04_success_list = get_koeki_trigger_list(action_code='E04', status_code='SUCCESS')
        trigger_E05_success_list = get_koeki_trigger_list(action_code='E05', status_code='SUCCESS')
        trigger_E06_success_list = get_koeki_trigger_list(action_code='E06', status_code='SUCCESS')
        trigger_E07_success_list = get_koeki_trigger_list(action_code='E07', status_code='SUCCESS')
        trigger_E99_success_list = get_koeki_trigger_list(action_code='E99', status_code='SUCCESS')
        trigger_S01_success_list = get_koeki_trigger_list(action_code='S01', status_code='SUCCESS')
        
        trigger_E01_failure_list = get_koeki_trigger_list(action_code='E01', status_code='FAILURE')
        trigger_E02_failure_list = get_koeki_trigger_list(action_code='E02', status_code='FAILURE')
        trigger_E03_failure_list = get_koeki_trigger_list(action_code='E03', status_code='FAILURE')
        trigger_E04_failure_list = get_koeki_trigger_list(action_code='E04', status_code='FAILURE')
        trigger_E05_failure_list = get_koeki_trigger_list(action_code='E05', status_code='FAILURE')
        trigger_E06_failure_list = get_koeki_trigger_list(action_code='E06', status_code='FAILURE')
        trigger_E07_failure_list = get_koeki_trigger_list(action_code='E07', status_code='FAILURE')
        trigger_E99_failure_list = get_koeki_trigger_list(action_code='E99', status_code='FAILURE')
        trigger_S01_failure_list = get_koeki_trigger_list(action_code='S01', status_code='FAILURE')

        trigger_E01_waiting_list = get_koeki_trigger_list(action_code='E01', status_code='WAITING')
        trigger_E02_waiting_list = get_koeki_trigger_list(action_code='E02', status_code='WAITING')
        trigger_E03_waiting_list = get_koeki_trigger_list(action_code='E03', status_code='WAITING')
        trigger_E04_waiting_list = get_koeki_trigger_list(action_code='E04', status_code='WAITING')
        trigger_E05_waiting_list = get_koeki_trigger_list(action_code='E05', status_code='WAITING')
        trigger_E06_waiting_list = get_koeki_trigger_list(action_code='E06', status_code='WAITING')
        trigger_E07_waiting_list = get_koeki_trigger_list(action_code='E07', status_code='WAITING')
        trigger_E99_waiting_list = get_koeki_trigger_list(action_code='E99', status_code='WAITING')
        trigger_S01_waiting_list = get_koeki_trigger_list(action_code='S01', status_code='WAITING')

        #######################################################################
        ### DBアクセス処理(0060)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0900Action.index_view()関数 STEP 7/12.', 'DEBUG')
        trigger_A01_running_count = get_ippan_trigger_count(action_code='A01', status_code='RUNNING')
        trigger_A02_running_count = get_ippan_trigger_count(action_code='A02', status_code='RUNNING')
        trigger_A03_running_count = get_ippan_trigger_count(action_code='A03', status_code='RUNNING')
        trigger_A04_running_count = get_ippan_trigger_count(action_code='A04', status_code='RUNNING')
        trigger_A05_running_count = get_ippan_trigger_count(action_code='A05', status_code='RUNNING')
        trigger_A06_running_count = get_ippan_trigger_count(action_code='A06', status_code='RUNNING')
        trigger_A07_running_count = get_ippan_trigger_count(action_code='A07', status_code='RUNNING')
        trigger_A99_running_count = get_ippan_trigger_count(action_code='A99', status_code='RUNNING')
        trigger_N01_running_count = get_ippan_trigger_count(action_code='N01', status_code='RUNNING')
        trigger_O01_running_count = get_ippan_trigger_count(action_code='O01', status_code='RUNNING')
        trigger_P01_running_count = get_ippan_trigger_count(action_code='P01', status_code='RUNNING')

        trigger_A01_cancel_count = get_ippan_trigger_count(action_code='A01', status_code='CANCEL')
        trigger_A02_cancel_count = get_ippan_trigger_count(action_code='A02', status_code='CANCEL')
        trigger_A03_cancel_count = get_ippan_trigger_count(action_code='A03', status_code='CANCEL')
        trigger_A04_cancel_count = get_ippan_trigger_count(action_code='A04', status_code='CANCEL')
        trigger_A05_cancel_count = get_ippan_trigger_count(action_code='A05', status_code='CANCEL')
        trigger_A06_cancel_count = get_ippan_trigger_count(action_code='A06', status_code='CANCEL')
        trigger_A07_cancel_count = get_ippan_trigger_count(action_code='A07', status_code='CANCEL')
        trigger_A99_cancel_count = get_ippan_trigger_count(action_code='A99', status_code='CANCEL')
        trigger_N01_cancel_count = get_ippan_trigger_count(action_code='N01', status_code='CANCEL')
        trigger_O01_cancel_count = get_ippan_trigger_count(action_code='O01', status_code='CANCEL')
        trigger_P01_cancel_count = get_ippan_trigger_count(action_code='P01', status_code='CANCEL')

        trigger_A01_info_count = get_ippan_trigger_count(action_code='A01', status_code='SUCCESS')
        trigger_A02_info_count = get_ippan_trigger_count(action_code='A02', status_code='SUCCESS')
        trigger_A03_info_count = get_ippan_trigger_count(action_code='A03', status_code='SUCCESS')
        trigger_A04_info_count = get_ippan_trigger_count(action_code='A04', status_code='SUCCESS')
        trigger_A05_info_count = get_ippan_trigger_count(action_code='A05', status_code='SUCCESS')
        trigger_A06_info_count = get_ippan_trigger_count(action_code='A06', status_code='SUCCESS')
        trigger_A07_info_count = get_ippan_trigger_count(action_code='A07', status_code='SUCCESS')
        trigger_A99_info_count = get_ippan_trigger_count(action_code='A99', status_code='SUCCESS')
        trigger_N01_info_count = get_ippan_trigger_count(action_code='N01', status_code='SUCCESS')
        trigger_O01_info_count = get_ippan_trigger_count(action_code='O01', status_code='SUCCESS')
        trigger_P01_info_count = get_ippan_trigger_count(action_code='P01', status_code='SUCCESS')
        
        trigger_A01_warn_count = get_ippan_trigger_count(action_code='A01', status_code='FAILURE')
        trigger_A02_warn_count = get_ippan_trigger_count(action_code='A02', status_code='FAILURE')
        trigger_A03_warn_count = get_ippan_trigger_count(action_code='A03', status_code='FAILURE')
        trigger_A04_warn_count = get_ippan_trigger_count(action_code='A04', status_code='FAILURE')
        trigger_A05_warn_count = get_ippan_trigger_count(action_code='A05', status_code='FAILURE')
        trigger_A06_warn_count = get_ippan_trigger_count(action_code='A06', status_code='FAILURE')
        trigger_A07_warn_count = get_ippan_trigger_count(action_code='A07', status_code='FAILURE')
        trigger_A99_warn_count = get_ippan_trigger_count(action_code='A99', status_code='FAILURE')
        trigger_N01_warn_count = get_ippan_trigger_count(action_code='N01', status_code='FAILURE')
        trigger_O01_warn_count = get_ippan_trigger_count(action_code='O01', status_code='FAILURE')
        trigger_P01_warn_count = get_ippan_trigger_count(action_code='P01', status_code='FAILURE')

        trigger_A01_waiting_count = get_ippan_trigger_count(action_code='A01', status_code='WAITING')
        trigger_A02_waiting_count = get_ippan_trigger_count(action_code='A02', status_code='WAITING')
        trigger_A03_waiting_count = get_ippan_trigger_count(action_code='A03', status_code='WAITING')
        trigger_A04_waiting_count = get_ippan_trigger_count(action_code='A04', status_code='WAITING')
        trigger_A05_waiting_count = get_ippan_trigger_count(action_code='A05', status_code='WAITING')
        trigger_A06_waiting_count = get_ippan_trigger_count(action_code='A06', status_code='WAITING')
        trigger_A07_waiting_count = get_ippan_trigger_count(action_code='A07', status_code='WAITING')
        trigger_A99_waiting_count = get_ippan_trigger_count(action_code='A99', status_code='WAITING')
        trigger_N01_waiting_count = get_ippan_trigger_count(action_code='N01', status_code='WAITING')
        trigger_O01_waiting_count = get_ippan_trigger_count(action_code='O01', status_code='WAITING')
        trigger_P01_waiting_count = get_ippan_trigger_count(action_code='P01', status_code='WAITING')

        #######################################################################
        ### DBアクセス処理(0070)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0900Action.index_view()関数 STEP 8/12.', 'DEBUG')
        ### trigger_B01_running_count = get_area_trigger_count(action_code='B01', status_code='RUNNING')
        ### trigger_B02_running_count = get_area_trigger_count(action_code='B02', status_code='RUNNING')
        ### trigger_B03_running_count = get_area_trigger_count(action_code='B03', status_code='RUNNING')
        ### trigger_B04_running_count = get_area_trigger_count(action_code='B04', status_code='RUNNING')
        ### trigger_B99_running_count = get_area_trigger_count(action_code='B99', status_code='RUNNING')

        ### trigger_B01_cancel_count = get_area_trigger_count(action_code='B01', status_code='CANCEL')
        ### trigger_B02_cancel_count = get_area_trigger_count(action_code='B02', status_code='CANCEL')
        ### trigger_B03_cancel_count = get_area_trigger_count(action_code='B03', status_code='CANCEL')
        ### trigger_B04_cancel_count = get_area_trigger_count(action_code='B04', status_code='CANCEL')
        ### trigger_B99_cancel_count = get_area_trigger_count(action_code='B99', status_code='CANCEL')

        ### trigger_B01_info_count = get_area_trigger_count(action_code='B01', status_code='SUCCESS')
        ### trigger_B02_info_count = get_area_trigger_count(action_code='B02', status_code='SUCCESS')
        ### trigger_B03_info_count = get_area_trigger_count(action_code='B03', status_code='SUCCESS')
        ### trigger_B04_info_count = get_area_trigger_count(action_code='B04', status_code='SUCCESS')
        ### trigger_B99_info_count = get_area_trigger_count(action_code='B99', status_code='SUCCESS')
        
        ### trigger_B01_warn_count = get_area_trigger_count(action_code='B01', status_code='FAILURE')
        ### trigger_B02_warn_count = get_area_trigger_count(action_code='B02', status_code='FAILURE')
        ### trigger_B03_warn_count = get_area_trigger_count(action_code='B03', status_code='FAILURE')
        ### trigger_B04_warn_count = get_area_trigger_count(action_code='B04', status_code='FAILURE')
        ### trigger_B99_warn_count = get_area_trigger_count(action_code='B99', status_code='FAILURE')

        ### trigger_B01_waiting_count = get_area_trigger_count(action_code='B01', status_code='WAITING')
        ### trigger_B02_waiting_count = get_area_trigger_count(action_code='B02', status_code='WAITING')
        ### trigger_B03_waiting_count = get_area_trigger_count(action_code='B03', status_code='WAITING')
        ### trigger_B04_waiting_count = get_area_trigger_count(action_code='B04', status_code='WAITING')
        ### trigger_B99_waiting_count = get_area_trigger_count(action_code='B99', status_code='WAITING')

        #######################################################################
        ### DBアクセス処理(0080)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0900Action.index_view()関数 STEP 9/12.', 'DEBUG')
        trigger_C01_running_count = get_chitan_trigger_count(action_code='C01', status_code='RUNNING')
        trigger_C02_running_count = get_chitan_trigger_count(action_code='C02', status_code='RUNNING')
        trigger_C03_running_count = get_chitan_trigger_count(action_code='C03', status_code='RUNNING')
        trigger_C04_running_count = get_chitan_trigger_count(action_code='C04', status_code='RUNNING')
        trigger_C05_running_count = get_chitan_trigger_count(action_code='C05', status_code='RUNNING')
        trigger_C06_running_count = get_chitan_trigger_count(action_code='C06', status_code='RUNNING')
        trigger_C07_running_count = get_chitan_trigger_count(action_code='C07', status_code='RUNNING')
        trigger_C99_running_count = get_chitan_trigger_count(action_code='C99', status_code='RUNNING')
        trigger_Q01_running_count = get_chitan_trigger_count(action_code='Q01', status_code='RUNNING')

        trigger_C01_cancel_count = get_chitan_trigger_count(action_code='C01', status_code='CANCEL')
        trigger_C02_cancel_count = get_chitan_trigger_count(action_code='C02', status_code='CANCEL')
        trigger_C03_cancel_count = get_chitan_trigger_count(action_code='C03', status_code='CANCEL')
        trigger_C04_cancel_count = get_chitan_trigger_count(action_code='C04', status_code='CANCEL')
        trigger_C05_cancel_count = get_chitan_trigger_count(action_code='C05', status_code='CANCEL')
        trigger_C06_cancel_count = get_chitan_trigger_count(action_code='C06', status_code='CANCEL')
        trigger_C07_cancel_count = get_chitan_trigger_count(action_code='C07', status_code='CANCEL')
        trigger_C99_cancel_count = get_chitan_trigger_count(action_code='C99', status_code='CANCEL')
        trigger_Q01_cancel_count = get_chitan_trigger_count(action_code='Q01', status_code='CANCEL')

        trigger_C01_info_count = get_chitan_trigger_count(action_code='C01', status_code='SUCCESS')
        trigger_C02_info_count = get_chitan_trigger_count(action_code='C02', status_code='SUCCESS')
        trigger_C03_info_count = get_chitan_trigger_count(action_code='C03', status_code='SUCCESS')
        trigger_C04_info_count = get_chitan_trigger_count(action_code='C04', status_code='SUCCESS')
        trigger_C05_info_count = get_chitan_trigger_count(action_code='C05', status_code='SUCCESS')
        trigger_C06_info_count = get_chitan_trigger_count(action_code='C06', status_code='SUCCESS')
        trigger_C07_info_count = get_chitan_trigger_count(action_code='C07', status_code='SUCCESS')
        trigger_C99_info_count = get_chitan_trigger_count(action_code='C99', status_code='SUCCESS')
        trigger_Q01_info_count = get_chitan_trigger_count(action_code='Q01', status_code='SUCCESS')
        
        trigger_C01_warn_count = get_chitan_trigger_count(action_code='C01', status_code='FAILURE')
        trigger_C02_warn_count = get_chitan_trigger_count(action_code='C02', status_code='FAILURE')
        trigger_C03_warn_count = get_chitan_trigger_count(action_code='C03', status_code='FAILURE')
        trigger_C04_warn_count = get_chitan_trigger_count(action_code='C04', status_code='FAILURE')
        trigger_C05_warn_count = get_chitan_trigger_count(action_code='C05', status_code='FAILURE')
        trigger_C06_warn_count = get_chitan_trigger_count(action_code='C06', status_code='FAILURE')
        trigger_C07_warn_count = get_chitan_trigger_count(action_code='C07', status_code='FAILURE')
        trigger_C99_warn_count = get_chitan_trigger_count(action_code='C99', status_code='FAILURE')
        trigger_Q01_warn_count = get_chitan_trigger_count(action_code='Q01', status_code='FAILURE')

        trigger_C01_waiting_count = get_chitan_trigger_count(action_code='C01', status_code='WAITING')
        trigger_C02_waiting_count = get_chitan_trigger_count(action_code='C02', status_code='WAITING')
        trigger_C03_waiting_count = get_chitan_trigger_count(action_code='C03', status_code='WAITING')
        trigger_C04_waiting_count = get_chitan_trigger_count(action_code='C04', status_code='WAITING')
        trigger_C05_waiting_count = get_chitan_trigger_count(action_code='C05', status_code='WAITING')
        trigger_C06_waiting_count = get_chitan_trigger_count(action_code='C06', status_code='WAITING')
        trigger_C07_waiting_count = get_chitan_trigger_count(action_code='C07', status_code='WAITING')
        trigger_C99_waiting_count = get_chitan_trigger_count(action_code='C99', status_code='WAITING')
        trigger_Q01_waiting_count = get_chitan_trigger_count(action_code='Q01', status_code='WAITING')

        #######################################################################
        ### DBアクセス処理(0090)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0900Action.index_view()関数 STEP 10/12.', 'DEBUG')
        trigger_D01_running_count = get_hojo_trigger_count(action_code='D01', status_code='RUNNING')
        trigger_D02_running_count = get_hojo_trigger_count(action_code='D02', status_code='RUNNING')
        trigger_D03_running_count = get_hojo_trigger_count(action_code='D03', status_code='RUNNING')
        trigger_D04_running_count = get_hojo_trigger_count(action_code='D04', status_code='RUNNING')
        trigger_D05_running_count = get_hojo_trigger_count(action_code='D05', status_code='RUNNING')
        trigger_D06_running_count = get_hojo_trigger_count(action_code='D06', status_code='RUNNING')
        trigger_D07_running_count = get_hojo_trigger_count(action_code='D07', status_code='RUNNING')
        trigger_D99_running_count = get_hojo_trigger_count(action_code='D99', status_code='RUNNING')
        trigger_R01_running_count = get_hojo_trigger_count(action_code='R01', status_code='RUNNING')

        trigger_D01_cancel_count = get_hojo_trigger_count(action_code='D01', status_code='CANCEL')
        trigger_D02_cancel_count = get_hojo_trigger_count(action_code='D02', status_code='CANCEL')
        trigger_D03_cancel_count = get_hojo_trigger_count(action_code='D03', status_code='CANCEL')
        trigger_D04_cancel_count = get_hojo_trigger_count(action_code='D04', status_code='CANCEL')
        trigger_D05_cancel_count = get_hojo_trigger_count(action_code='D05', status_code='CANCEL')
        trigger_D06_cancel_count = get_hojo_trigger_count(action_code='D06', status_code='CANCEL')
        trigger_D07_cancel_count = get_hojo_trigger_count(action_code='D07', status_code='CANCEL')
        trigger_D99_cancel_count = get_hojo_trigger_count(action_code='D99', status_code='CANCEL')
        trigger_R01_cancel_count = get_hojo_trigger_count(action_code='R01', status_code='CANCEL')

        trigger_D01_info_count = get_hojo_trigger_count(action_code='D01', status_code='SUCCESS')
        trigger_D02_info_count = get_hojo_trigger_count(action_code='D02', status_code='SUCCESS')
        trigger_D03_info_count = get_hojo_trigger_count(action_code='D03', status_code='SUCCESS')
        trigger_D04_info_count = get_hojo_trigger_count(action_code='D04', status_code='SUCCESS')
        trigger_D05_info_count = get_hojo_trigger_count(action_code='D05', status_code='SUCCESS')
        trigger_D06_info_count = get_hojo_trigger_count(action_code='D06', status_code='SUCCESS')
        trigger_D07_info_count = get_hojo_trigger_count(action_code='D07', status_code='SUCCESS')
        trigger_D99_info_count = get_hojo_trigger_count(action_code='D99', status_code='SUCCESS')
        trigger_R01_info_count = get_hojo_trigger_count(action_code='R01', status_code='SUCCESS')
        
        trigger_D01_warn_count = get_hojo_trigger_count(action_code='D01', status_code='FAILURE')
        trigger_D02_warn_count = get_hojo_trigger_count(action_code='D02', status_code='FAILURE')
        trigger_D03_warn_count = get_hojo_trigger_count(action_code='D03', status_code='FAILURE')
        trigger_D04_warn_count = get_hojo_trigger_count(action_code='D04', status_code='FAILURE')
        trigger_D05_warn_count = get_hojo_trigger_count(action_code='D05', status_code='FAILURE')
        trigger_D06_warn_count = get_hojo_trigger_count(action_code='D06', status_code='FAILURE')
        trigger_D07_warn_count = get_hojo_trigger_count(action_code='D07', status_code='FAILURE')
        trigger_D99_warn_count = get_hojo_trigger_count(action_code='D99', status_code='FAILURE')
        trigger_R01_warn_count = get_hojo_trigger_count(action_code='R01', status_code='FAILURE')

        trigger_D01_waiting_count = get_hojo_trigger_count(action_code='D01', status_code='WAITING')
        trigger_D02_waiting_count = get_hojo_trigger_count(action_code='D02', status_code='WAITING')
        trigger_D03_waiting_count = get_hojo_trigger_count(action_code='D03', status_code='WAITING')
        trigger_D04_waiting_count = get_hojo_trigger_count(action_code='D04', status_code='WAITING')
        trigger_D05_waiting_count = get_hojo_trigger_count(action_code='D05', status_code='WAITING')
        trigger_D06_waiting_count = get_hojo_trigger_count(action_code='D06', status_code='WAITING')
        trigger_D07_waiting_count = get_hojo_trigger_count(action_code='D07', status_code='WAITING')
        trigger_D99_waiting_count = get_hojo_trigger_count(action_code='D99', status_code='WAITING')
        trigger_R01_waiting_count = get_hojo_trigger_count(action_code='R01', status_code='WAITING')

        #######################################################################
        ### DBアクセス処理(0100)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0900Action.index_view()関数 STEP 11/12.', 'DEBUG')
        trigger_E01_running_count = get_koeki_trigger_count(action_code='E01', status_code='RUNNING')
        trigger_E02_running_count = get_koeki_trigger_count(action_code='E02', status_code='RUNNING')
        trigger_E03_running_count = get_koeki_trigger_count(action_code='E03', status_code='RUNNING')
        trigger_E04_running_count = get_koeki_trigger_count(action_code='E04', status_code='RUNNING')
        trigger_E05_running_count = get_koeki_trigger_count(action_code='E05', status_code='RUNNING')
        trigger_E06_running_count = get_koeki_trigger_count(action_code='E06', status_code='RUNNING')
        trigger_E07_running_count = get_koeki_trigger_count(action_code='E07', status_code='RUNNING')
        trigger_E99_running_count = get_koeki_trigger_count(action_code='E99', status_code='RUNNING')
        trigger_S01_running_count = get_koeki_trigger_count(action_code='S01', status_code='RUNNING')

        trigger_E01_cancel_count = get_koeki_trigger_count(action_code='E01', status_code='CANCEL')
        trigger_E02_cancel_count = get_koeki_trigger_count(action_code='E02', status_code='CANCEL')
        trigger_E03_cancel_count = get_koeki_trigger_count(action_code='E03', status_code='CANCEL')
        trigger_E04_cancel_count = get_koeki_trigger_count(action_code='E04', status_code='CANCEL')
        trigger_E05_cancel_count = get_koeki_trigger_count(action_code='E05', status_code='CANCEL')
        trigger_E06_cancel_count = get_koeki_trigger_count(action_code='E06', status_code='CANCEL')
        trigger_E07_cancel_count = get_koeki_trigger_count(action_code='E07', status_code='CANCEL')
        trigger_E99_cancel_count = get_koeki_trigger_count(action_code='E99', status_code='CANCEL')
        trigger_S01_cancel_count = get_koeki_trigger_count(action_code='S01', status_code='CANCEL')

        trigger_E01_info_count = get_koeki_trigger_count(action_code='E01', status_code='SUCCESS')
        trigger_E02_info_count = get_koeki_trigger_count(action_code='E02', status_code='SUCCESS')
        trigger_E03_info_count = get_koeki_trigger_count(action_code='E03', status_code='SUCCESS')
        trigger_E04_info_count = get_koeki_trigger_count(action_code='E04', status_code='SUCCESS')
        trigger_E05_info_count = get_koeki_trigger_count(action_code='E05', status_code='SUCCESS')
        trigger_E06_info_count = get_koeki_trigger_count(action_code='E06', status_code='SUCCESS')
        trigger_E07_info_count = get_koeki_trigger_count(action_code='E07', status_code='SUCCESS')
        trigger_E99_info_count = get_koeki_trigger_count(action_code='E99', status_code='SUCCESS')
        trigger_S01_info_count = get_koeki_trigger_count(action_code='S01', status_code='SUCCESS')
        
        trigger_E01_warn_count = get_koeki_trigger_count(action_code='E01', status_code='FAILURE')
        trigger_E02_warn_count = get_koeki_trigger_count(action_code='E02', status_code='FAILURE')
        trigger_E03_warn_count = get_koeki_trigger_count(action_code='E03', status_code='FAILURE')
        trigger_E04_warn_count = get_koeki_trigger_count(action_code='E04', status_code='FAILURE')
        trigger_E05_warn_count = get_koeki_trigger_count(action_code='E05', status_code='FAILURE')
        trigger_E06_warn_count = get_koeki_trigger_count(action_code='E06', status_code='FAILURE')
        trigger_E07_warn_count = get_koeki_trigger_count(action_code='E07', status_code='FAILURE')
        trigger_E99_warn_count = get_koeki_trigger_count(action_code='E99', status_code='FAILURE')
        trigger_S01_warn_count = get_koeki_trigger_count(action_code='S01', status_code='FAILURE')

        trigger_E01_waiting_count = get_koeki_trigger_count(action_code='E01', status_code='WAITING')
        trigger_E02_waiting_count = get_koeki_trigger_count(action_code='E02', status_code='WAITING')
        trigger_E03_waiting_count = get_koeki_trigger_count(action_code='E03', status_code='WAITING')
        trigger_E04_waiting_count = get_koeki_trigger_count(action_code='E04', status_code='WAITING')
        trigger_E05_waiting_count = get_koeki_trigger_count(action_code='E05', status_code='WAITING')
        trigger_E06_waiting_count = get_koeki_trigger_count(action_code='E06', status_code='WAITING')
        trigger_E07_waiting_count = get_koeki_trigger_count(action_code='E07', status_code='WAITING')
        trigger_E99_waiting_count = get_koeki_trigger_count(action_code='E99', status_code='WAITING')
        trigger_S01_waiting_count = get_koeki_trigger_count(action_code='S01', status_code='WAITING')

        #######################################################################
        ### レスポンスセット処理(0110)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0900Action.index_view()関数 STEP 12/12.', 'DEBUG')
        template = loader.get_template('P0900Action/index.html')
        context = {
            'trigger_A01_success_list': trigger_A01_success_list, 
            'trigger_A02_success_list': trigger_A02_success_list, 
            'trigger_A03_success_list': trigger_A03_success_list, 
            'trigger_A04_success_list': trigger_A04_success_list, 
            'trigger_A05_success_list': trigger_A05_success_list, 
            'trigger_A06_success_list': trigger_A06_success_list, 
            'trigger_A07_success_list': trigger_A07_success_list, 
            'trigger_A99_success_list': trigger_A99_success_list, 
            'trigger_N01_success_list': trigger_N01_success_list, 
            'trigger_O01_success_list': trigger_O01_success_list, 
            'trigger_P01_success_list': trigger_P01_success_list, 
            
            'trigger_A01_failure_list': trigger_A01_failure_list, 
            'trigger_A02_failure_list': trigger_A02_failure_list, 
            'trigger_A03_failure_list': trigger_A03_failure_list, 
            'trigger_A04_failure_list': trigger_A04_failure_list, 
            'trigger_A05_failure_list': trigger_A05_failure_list, 
            'trigger_A06_failure_list': trigger_A06_failure_list, 
            'trigger_A07_failure_list': trigger_A07_failure_list, 
            'trigger_A99_failure_list': trigger_A99_failure_list, 
            'trigger_N01_failure_list': trigger_N01_failure_list, 
            'trigger_O01_failure_list': trigger_O01_failure_list, 
            'trigger_P01_failure_list': trigger_P01_failure_list, 

            'trigger_A01_waiting_list': trigger_A01_waiting_list, 
            'trigger_A02_waiting_list': trigger_A02_waiting_list, 
            'trigger_A03_waiting_list': trigger_A03_waiting_list, 
            'trigger_A04_waiting_list': trigger_A04_waiting_list, 
            'trigger_A05_waiting_list': trigger_A05_waiting_list, 
            'trigger_A06_waiting_list': trigger_A06_waiting_list, 
            'trigger_A07_waiting_list': trigger_A07_waiting_list, 
            'trigger_A99_waiting_list': trigger_A99_waiting_list, 
            'trigger_N01_waiting_list': trigger_N01_waiting_list, 
            'trigger_O01_waiting_list': trigger_O01_waiting_list, 
            'trigger_P01_waiting_list': trigger_P01_waiting_list, 
            
            'trigger_A01_info_count': trigger_A01_info_count, 
            'trigger_A02_info_count': trigger_A02_info_count, 
            'trigger_A03_info_count': trigger_A03_info_count, 
            'trigger_A04_info_count': trigger_A04_info_count, 
            'trigger_A05_info_count': trigger_A05_info_count, 
            'trigger_A06_info_count': trigger_A06_info_count, 
            'trigger_A07_info_count': trigger_A07_info_count, 
            'trigger_A99_info_count': trigger_A99_info_count, 
            'trigger_N01_info_count': trigger_N01_info_count, 
            'trigger_O01_info_count': trigger_O01_info_count, 
            'trigger_P01_info_count': trigger_P01_info_count, 
            
            'trigger_A01_warn_count': trigger_A01_warn_count, 
            'trigger_A02_warn_count': trigger_A02_warn_count, 
            'trigger_A03_warn_count': trigger_A03_warn_count, 
            'trigger_A04_warn_count': trigger_A04_warn_count, 
            'trigger_A05_warn_count': trigger_A05_warn_count, 
            'trigger_A06_warn_count': trigger_A06_warn_count, 
            'trigger_A07_warn_count': trigger_A07_warn_count, 
            'trigger_A99_warn_count': trigger_A99_warn_count, 
            'trigger_N01_warn_count': trigger_N01_warn_count, 
            'trigger_O01_warn_count': trigger_O01_warn_count, 
            'trigger_P01_warn_count': trigger_P01_warn_count, 

            'trigger_A01_waiting_count': trigger_A01_waiting_count, 
            'trigger_A02_waiting_count': trigger_A02_waiting_count, 
            'trigger_A03_waiting_count': trigger_A03_waiting_count, 
            'trigger_A04_waiting_count': trigger_A04_waiting_count, 
            'trigger_A05_waiting_count': trigger_A05_waiting_count, 
            'trigger_A06_waiting_count': trigger_A06_waiting_count, 
            'trigger_A07_waiting_count': trigger_A07_waiting_count, 
            'trigger_A99_waiting_count': trigger_A99_waiting_count, 
            'trigger_N01_waiting_count': trigger_N01_waiting_count, 
            'trigger_O01_waiting_count': trigger_O01_waiting_count, 
            'trigger_P01_waiting_count': trigger_P01_waiting_count 
        }
        print_log('[INFO] P0900Action.index_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0900Action.index_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0900Action.index_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0900Action.index_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0900Action/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 関数名：trigger_view
### urlpatterns：path('trigger/<slug:trigger_id>/', views.trigger_view, name='trigger_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def trigger_view(request, trigger_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0900Action.trigger_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0900Action.trigger_view()関数 STEP 1/3.', 'DEBUG')
        print_log('[DEBUG] P0900Action.trigger_view()関数 request={}'.format(request.method), 'DEBUG')
        print_log('[DEBUG] P0900Action.trigger_view()関数 trigger_id={}'.format(trigger_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0900Action.trigger_view()関数 STEP 2/3.', 'DEBUG')
        params = dict({
            'TRIGGER_ID': trigger_id
        })
        trigger = TRIGGER.objects.raw("""
            SELECT 
                TR1.trigger_id, 
                TR1.header_id, 
                SG1.header_name, 
                TR1.ken_code, 
                KE1.ken_name, 
                TR1.city_code, 
                CT1.city_name, 
                TR1.action_code, 
                AC1.action_name, 
                TR1.status_code, 
                ST1.status_name, 
                TR1.info_count, 
                TR1.warn_count, 
                TO_CHAR(timezone('JST', TR1.published_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS published_at, 
                TO_CHAR(timezone('JST', TR1.consumed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS consumed_at, 
                TO_CHAR(timezone('JST', TR1.deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at, 
                TR1.info_log, 
                TR1.warn_log, 
                TR1.download_file_path, 
                TR1.download_file_name, 
                TR1.upload_file_path, 
                TR1.upload_file_name 
            FROM TRIGGER TR1 
            LEFT JOIN HEADER SG1 ON TR1.header_id=SG1.header_id 
            LEFT JOIN KEN KE1 ON TR1.ken_code=KE1.ken_code 
            LEFT JOIN CITY CT1 ON TR1.city_code=CT1.city_code 
            LEFT JOIN ACTION AC1 ON TR1.action_code=AC1.action_code 
            LEFT JOIN STATUS ST1 ON TR1.status_code=ST1.status_code 
            WHERE 
                trigger_id=%(TRIGGER_ID)s""", params)
    
        #######################################################################
        ### レスポンスセット処理(0020)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0900Action.trigger_view()関数 STEP 3/3.', 'DEBUG')
        template = loader.get_template('P0900Action/trigger.html')
        context = {
            'trigger': trigger 
        }
        print_log('[INFO] P0900Action.trigger_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0900Action.trigger_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0900Action.trigger_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0900Action.trigger_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0900Action/trigger.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
