from django.urls import path
from . import views

app_name = 'P0900Action'
urlpatterns = [
    path('', views.index_view, name='index_view'), ### 自動実行進捗状況一覧表示画面
    path('trigger/<slug:trigger_id>/', views.trigger_view, name='trigger_view'), ### 自動実行進捗状況詳細表示画面
]
