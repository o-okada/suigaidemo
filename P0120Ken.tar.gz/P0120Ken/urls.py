from django.urls import path
from . import views

app_name = 'P0120Ken'
urlpatterns = [
    path('', views.index_view, name='index_view'),                                                                     ### /P0120Ken/ => /P0120Ken/bucket/ redirect用
    path('bucket/', views.bucket_view, name='bucket_view'),                                                            ### 都道府県用バケット Add 2023/01/27
    
    path('browser/', views.browser_view, name='browser_view'),                                                         ### 都道府県用オブジェクトブラウザ都アップロードファイル Add 2023/01/27
    path('browser/city/<slug:city_code>/', views.browser_city_code_view, name='browser_city_code_view'),               ### 都道府県用オブジェクトブラウザ市アップロードファイル Add 2023/01/27

    path('slide/ippan/header/<slug:header_id>/', views.slide_ippan_header_id_view, name='slide_ippan_header_id_view'),    ### 都道府県用アクション情報表示市アップロードファイル Add 2023/01/27
    path('slide/area/header/<slug:header_id>/', views.slide_area_header_id_view, name='slide_area_header_id_view'),       ### 都道府県用アクション情報表示市アップロードファイル Add 2023/01/27
    path('slide/chitan/header/<slug:header_id>/', views.slide_chitan_header_id_view, name='slide_chitan_header_id_view'), ### 都道府県用アクション情報表示都アップロードファイル Add 2023/01/27
    path('slide/hojo/header/<slug:header_id>/', views.slide_hojo_header_id_view, name='slide_hojo_header_id_view'),       ### 都道府県用アクション情報表示都アップロードファイル Add 2023/01/27
    path('slide/koeki/header/<slug:header_id>/', views.slide_koeki_header_id_view, name='slide_koeki_header_id_view'),    ### 都道府県用アクション情報表示都アップロードファイル Add 2023/01/27

    path('delete/ippan/header/<slug:header_id>/', views.delete_ippan_header_id_view, name='delete_ippan_header_id_view'),    ### 都道府県用一般資産調査票ファイル削除 Add 2023/02/16
    path('delete/area/header/<slug:header_id>/', views.delete_area_header_id_view, name='delete_area_header_id_view'),       ### 都道府県用水害区域図ファイル削除 Add 2023/02/16
    path('delete/chitan/header/<slug:header_id>/', views.delete_chitan_header_id_view, name='delete_chitan_header_id_view'), ### 都道府県用地方単独事業調査票ファイル削除 Add 2023/02/16
    path('delete/hojo/header/<slug:header_id>/', views.delete_hojo_header_id_view, name='delete_hojo_header_id_view'),       ### 都道府県用補助事業調査票ファイル削除 Add 2023/02/16
    path('delete/koeki/header/<slug:header_id>/', views.delete_koeki_header_id_view, name='delete_koeki_header_id_view'),    ### 都道府県用公益事業調査票ファイル削除 Add 2023/02/16

    path('download/ippan/chosa/excel/header/<slug:header_id>/', views.download_ippan_chosa_excel_header_id_view, name='download_ippan_chosa_excel_header_id_view'), 
    path('download/ippan/chosa/csv/header/<slug:header_id>/', views.download_ippan_chosa_csv_header_id_view, name='download_ippan_chosa_csv_header_id_view'), 
    path('download/ippan/summary/excel/header/<slug:header_id>/', views.download_ippan_summary_excel_header_id_view, name='download_ippan_summary_excel_header_id_view'), 
    path('download/ippan/summary/csv/header/<slug:header_id>/', views.download_ippan_summary_csv_header_id_view, name='download_ippan_summary_csv_header_id_view'), 
    path('download/area/pdf/header/<slug:header_id>/', views.download_area_pdf_header_id_view, name='download_area_pdf_header_id_view'), 
    path('download/area/kml/header/<slug:header_id>/', views.download_area_kml_header_id_view, name='download_area_kml_header_id_view'), 
    path('download/chitan/chosa/excel/header/<slug:header_id>/', views.download_chitan_chosa_excel_header_id_view, name='download_chitan_chosa_excel_header_id_view'), 
    path('download/chitan/chosa/csv/header/<slug:header_id>/', views.download_chitan_chosa_csv_header_id_view, name='download_chitan_chosa_csv_header_id_view'), 
    path('download/chitan/summary/excel/header/<slug:header_id>/', views.download_chitan_summary_excel_header_id_view, name='download_chitan_summary_excel_header_id_view'), 
    path('download/chitan/summary/csv/header/<slug:header_id>/', views.download_chitan_summary_csv_header_id_view, name='download_chitan_summary_csv_header_id_view'), 
    path('download/hojo/chosa/excel/header/<slug:header_id>/', views.download_hojo_chosa_excel_header_id_view, name='download_hojo_chosa_excel_header_id_view'), 
    path('download/hojo/chosa/csv/header/<slug:header_id>/', views.download_hojo_chosa_csv_header_id_view, name='download_hojo_chosa_csv_header_id_view'), 
    path('download/hojo/summary/excel/header/<slug:header_id>/', views.download_hojo_summary_excel_header_id_view, name='download_hojo_summary_excel_header_id_view'), 
    path('download/hojo/summary/csv/header/<slug:header_id>/', views.download_hojo_summary_csv_header_id_view, name='download_hojo_summary_csv_header_id_view'), 
    path('download/koeki/chosa/excel/header/<slug:header_id>/', views.download_koeki_chosa_excel_header_id_view, name='download_koeki_chosa_excel_header_id_view'), 
    path('download/koeki/chosa/csv/header/<slug:header_id>/', views.download_koeki_chosa_csv_header_id_view, name='download_koeki_chosa_csv_header_id_view'), 
    path('download/koeki/summary/excel/header/<slug:header_id>/', views.download_koeki_summary_excel_header_id_view, name='download_koeki_summary_excel_header_id_view'), 
    path('download/koeki/summary/csv/header/<slug:header_id>/', views.download_koeki_summary_csv_header_id_view, name='download_koeki_summary_csv_header_id_view'), 
]
