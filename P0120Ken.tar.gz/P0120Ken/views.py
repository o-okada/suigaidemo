###############################################################################
### ファイル名：P0120Ken/views.py
### ファイル管理
###############################################################################

import json                                            ### ADD 2023/02/06
import os                                              ### ADD 2023/02/21
import sys

from datetime import date, datetime                    ### ADD 2023/02/21
from datetime import timedelta, timezone               ### ADD 2023/02/21

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import connection                       ### ADD 2023/02/21
from django.db import transaction                      ### ADD 2023/02/21
from django.db.models import Max                       ### ADD 2023/02/21
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.http import HttpResponseNotFound           ### ADD 2023/02/17
from django.http.response import JsonResponse          ### ADD 2023/02/06
from django.shortcuts import redirect                  ### ADD 2023/02/10
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic.base import TemplateView

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査員調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査員調査票_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査員調査票_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.models import KEN_BUCKET              ### 99999: バケットデータ_都道府県
from P0000Common.models import CITY_BUCKET             ### 99999: バケットデータ_市区町村

from P0000Common.common import get_alert_log
from P0000Common.common import get_info_log
from P0000Common.common import get_warn_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from P0000Common.common import split_name_code
from P0000Common.common import isdate
from P0000Common.common import convert_empty_to_none
### from P0000Common.common import add_comment ### DELETE 2023/02/24

from P0000Common.services import get_ippan_chosa_csv_excel     ### ADD 2023/03/09
from P0000Common.services import get_ippan_summary_csv_excel   ### ADD 2023/03/09
from P0000Common.services import get_area_kml_pdf              ### ADD 2023/03/09
from P0000Common.services import get_chitan_chosa_csv_excel    ### ADD 2023/03/09
from P0000Common.services import get_chitan_summary_csv_excel  ### ADD 2023/03/09
from P0000Common.services import get_hojo_chosa_csv_excel      ### ADD 2023/03/09
from P0000Common.services import get_koeki_chosa_csv_excel     ### ADD 2023/03/09
from P0000Common.services import get_koeki_summary_csv_excel   ### ADD 2023/03/09

from P0000Common.services import create_ippan_chosa_excel      ### ADD 2023/03/09
from P0000Common.services import create_chitan_chosa_excel     ### ADD 2023/03/09
from P0000Common.services import create_hojo_chosa_excel       ### ADD 2023/03/09
from P0000Common.services import create_koeki_chosa_excel      ### ADD 2023/03/09

from . import constants

from .forms import UploadChitanForm
from .forms import UploadHojoForm
from .forms import UploadKoekiForm

from MessageQueue.views import get_message 
from MessageQueue.views import publish_message 
from MessageQueue.views import publish_consume_message 
from MessageQueue.views import consume_message 
from MessageQueue.views import delete_message 

### USER_PROXYテーブル.ROLE_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_ROLE_CITY = 'ROLE_CITY'
_ROLE_KEN = 'ROLE_KEN'
_ROLE_MANAGE = 'ROLE_MANAGE'

### ACTIONテーブル.ACTION_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_IPP_ACT_01 = 'IPP_ACT_01'
_IPP_ACT_02 = 'IPP_ACT_02'
_IPP_ACT_03 = 'IPP_ACT_03'
_IPP_ACT_04 = 'IPP_ACT_04'
_IPP_ACT_05 = 'IPP_ACT_05'
_IPP_ACT_06 = 'IPP_ACT_06'
_IPP_ACT_07 = 'IPP_ACT_07'

_CHI_ACT_01 = 'CHI_ACT_01'
_CHI_ACT_02 = 'CHI_ACT_02'
_CHI_ACT_03 = 'CHI_ACT_03'
_CHI_ACT_04 = 'CHI_ACT_04'
_CHI_ACT_05 = 'CHI_ACT_05'
_CHI_ACT_06 = 'CHI_ACT_06'
_CHI_ACT_07 = 'CHI_ACT_07'

_HOJ_ACT_01 = 'HOJ_ACT_01'
_HOJ_ACT_02 = 'HOJ_ACT_02'
_HOJ_ACT_03 = 'HOJ_ACT_03'
_HOJ_ACT_04 = 'HOJ_ACT_04'
_HOJ_ACT_05 = 'HOJ_ACT_05'
_HOJ_ACT_06 = 'HOJ_ACT_06'
_HOJ_ACT_07 = 'HOJ_ACT_07'

_KOE_ACT_01 = 'KOE_ACT_01'
_KOE_ACT_02 = 'KOE_ACT_02'
_KOE_ACT_03 = 'KOE_ACT_03'
_KOE_ACT_04 = 'KOE_ACT_04'
_KOE_ACT_05 = 'KOE_ACT_05'
_KOE_ACT_06 = 'KOE_ACT_06'
_KOE_ACT_07 = 'KOE_ACT_07'

_ARE_ACT_01 = 'ARE_ACT_01'
_ARE_ACT_02 = 'ARE_ACT_02'
_ARE_ACT_03 = 'ARE_ACT_03'
_ARE_ACT_04 = 'ARE_ACT_04'
_ARE_ACT_05 = 'ARE_ACT_05'
_ARE_ACT_06 = 'ARE_ACT_06'
_ARE_ACT_07 = 'ARE_ACT_07'

### STATUSテーブル.STATUS_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_WAITING = 'WAITING'
_RUNNING = 'RUNNING'
_SUCCESS = 'SUCCESS'
_FAILURE = 'FAILURE'
_CANCEL = 'CANCEL'

### 局所定数 ※DELETE関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP = 'IPP'
_ARE = 'ARE'
_CHI = 'CHI'
_HOJ = 'HOJ'
_KOE = 'KOE'

### 局所定数 ※DOWNLOAD関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP_CHO_EXC = 'IPP_CHO_EXC'
_IPP_CHO_CSV = 'IPP_CHO_CSV'
_IPP_SUM_EXC = 'IPP_SUM_EXC'
_IPP_SUM_CSV = 'IPP_SUM_CSV'
_CHI_CHO_EXC = 'CHI_CHO_EXC'
_CHI_CHO_CSV = 'CHI_CHO_CSV'
_CHI_SUM_EXC = 'CHI_SUM_EXC'
_CHI_SUM_CSV = 'CHI_SUM_CSV'
_HOJ_CHO_EXC = 'HOJ_CHO_EXC'
_HOJ_CHO_CSV = 'HOJ_CHO_CSV'
_HOJ_SUM_EXC = 'HOJ_SUM_EXC'
_HOJ_SUM_CSV = 'HOJ_SUM_CSV'
_KOE_CHO_EXC = 'KOE_CHO_EXC'
_KOE_CHO_CSV = 'KOE_CHO_CSV'
_KOE_SUM_EXC = 'KOE_SUM_EXC'
_KOE_SUM_CSV = 'KOE_SUM_CSV'
_ARE_PDF = 'ARE_PDF'
_ARE_KML = 'ARE_KML'

###############################################################################
### 関数名：add_comment(ws, ws_result, row, column, fill, message_id, message)
### ※調査票の種類に応じてエラーメッセージが異なるため、共通化せずに、個々のviews.pyに記述する。
###############################################################################
def add_comment(ws, ws_result, row, column, fill, message_id, message):
    ws.cell(row=row, column=column).fill = fill
    ws_result.cell(row=row, column=column).fill = fill
    
    msg_str = message[message_id][3] + message[message_id][4]

    if ws.cell(row=row, column=column).comment is None:
        ws.cell(row=row, column=column).comment = Comment(msg_str, '')
    else:
        ws.cell(row=row, column=column).comment = Comment(str(ws.cell(row=row, column=column).comment.text) + msg_str, '')
        
    if ws_result.cell(row=row, column=column).comment is None:
        ws_result.cell(row=row, column=column).comment = Comment(msg_str, '')
    else:
        ws_result.cell(row=row, column=column).comment = Comment(str(ws_result.cell(row=row, column=column).comment.text) + msg_str, '')
        
    return True

###############################################################################
### /P0120Ken/ => /P0120Ken/bucket/ リダイレクト用【済】
### 関数名：index_view(request)
### urlpattern：path('', views.index_view, name='index_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_view(request):
    return redirect('bucket/')

###############################################################################
### 都道府県用バケット【済】
### 関数名：bucket_view(request)
### urlpattern：path('bucket/', views.bucket_view, name='bucket_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def bucket_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.bucket_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.bucket_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.bucket_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.bucket_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.bucket_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
        
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.bucket_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.bucket_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/bucket/bucket.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.bucket_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/bucket/bucket.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.bucket_view()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'KEN_CODE': user_proxy_list[0].ken_code 
        })
        ken_bucket_list = KEN_BUCKET.objects.raw("""
            SELECT 
                KEN_CODE, 
                KEN_NAME, 
                USAGE, 
                FILES 
            FROM KEN_BUCKET 
            WHERE 
                KEN_CODE=%(KEN_CODE)s""", params)
        
        print_log('{}'.format(ken_bucket_list), 'DEBUG')
        print_log('{}'.format(len(ken_bucket_list)), 'DEBUG')
        print_log('{}'.format(ken_bucket_list[0]), 'DEBUG')
        print_log('{}'.format(ken_bucket_list[0].ken_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.bucket_view()関数 STEP 5/6.', 'DEBUG')
        if ken_bucket_list == False:
            print_log('[WARN] P0120Ken.bucket_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/bucket/bucket.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.bucket_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.bucket_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0120Ken/bucket/bucket.html')
        context = {
            'ken_bucket_list': ken_bucket_list, 
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0120Ken.bucket_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.bucket_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.bucket_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0120Ken/bucket/bucket.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 都道府県用ブラウザ都アップロードファイル【済】
### 関数名：browser_view(request)
### urlpattern：path('browser/', views.browser_view, name='browser_view')
### (1)GETの場合、ファイル管理画面を表示する。
### (2)POSTの場合、アップロードされた地方単独事業調査票、補助事業調査票、公益事業調査票ファイルをチェックして、正常ケースの場合、DBに登録する。
### ※複数EXCELシート未対応版
### ※DELEGATE処理のため、関数からの戻り値のbool_returnを処理しない。
### ※except、異常処理は関数からの戻り値のresponseに含めること。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def browser_view(request):
    if request.method == 'GET':
        bool_return, response = browser_get(request)
        return response
    elif request.method == 'POST':
        if 'upload_chitan_button' in request.POST:
            bool_return, response = browser_post_chitan(request)
            return response
        elif 'upload_hojo_button' in request.POST:
            bool_return, response = browser_post_hojo(request)
            return response
        elif 'upload_koeki_button' in request.POST:
            bool_return, response = browser_post_koeki(request)
            return response
        else:
            return redirect('/P0120Ken/browser/')
    else:
        return redirect('/P0120Ken/browser/')

###############################################################################
### 都道府県用ブラウザ市アップロードファイル【済】
### 関数名：browser_city_code_view(request, city_code)
### urlpattern：path('browser/city/<slug:city_code>/', views.browser_city_code_view, name='browser_city_code_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def browser_city_code_view(request, city_code):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.browser_city_code_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 city_code={}'.format(city_code), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.browser_city_code_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser_city_code.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.browser_city_code_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser_city_code.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'KEN_CODE': user_proxy_list[0].ken_code, 
            'CITY_CODE': city_code
        })
        ### HTMLタイトル部分表示用
        city_bucket_list = CITY_BUCKET.objects.raw("""
            SELECT 
                CITY_CODE, 
                CITY_NAME, 
                KEN_CODE, 
                USAGE, 
                FILES 
            FROM CITY_BUCKET 
            WHERE 
                KEN_CODE=%(KEN_CODE)s AND 
                CITY_CODE=%(CITY_CODE)s""", params)
        
        print_log('{}'.format(city_bucket_list), 'DEBUG')
        print_log('{}'.format(len(city_bucket_list)), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0]), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0].city_code), 'DEBUG')
        
        ### HTML一覧部分表示用
        ippan_header_list = IPPAN_HEADER.objects.raw("""
            SELECT 
                IPPAN_HEADER_ID, 
                IPPAN_HEADER_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT 
            FROM IPPAN_HEADER 
            WHERE 
                KEN_CODE=%(KEN_CODE)s AND 
                CITY_CODE=%(CITY_CODE)s AND 
                DELETED_AT IS NULL""", params)
        
        print_log('{}'.format(ippan_header_list), 'DEBUG')
        print_log('{}'.format(len(ippan_header_list)), 'DEBUG')

        ### HTML一覧部分表示用
        area_list = AREA.objects.raw("""
            SELECT 
                AREA_ID, 
                AREA_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                TO_CHAR(TIMEZONE('JST', COMMITTED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS COMMITTED_AT, 
                TO_CHAR(TIMEZONE('JST', DELETED_AT::TIMESTAMPTZ), 'YYYY/MM/DD HH24:MI') AS DELETED_AT 
            FROM AREA 
            WHERE 
                KEN_CODE=%(KEN_CODE)s AND 
                CITY_CODE=%(CITY_CODE)s AND 
                DELETED_AT IS NULL""", params)
        
        print_log('{}'.format(area_list), 'DEBUG')
        print_log('{}'.format(len(area_list)), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 STEP 5/6.', 'DEBUG')
        if city_bucket_list == False:
            print_log('[WARN] P0120Ken.browser_city_code_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser_city_code.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        ### 一般資産調査員調査票ファイルの0件は正常であるため、チェックしない。
        ### 水害区域図ファイルの0件は正常であるため、チェックしない。

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_city_code_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.browser_city_code_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0120Ken/browser/browser_city_code.html')
        context = {
            'area_list': area_list,
            'city_bucket_list': city_bucket_list, 
            'ippan_header_list': ippan_header_list, 
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0120Ken.browser_city_code_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_city_code_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_city_code_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0120Ken/browser/browser_city_code.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 都道府県用一般資産調査員調査票右スライドメニュー表示【済】
### 関数名：slide_ippan_header_id_view(request, header_id)
### urlpattern：path('slide/ippan/header/<slug:header_id>/', views.slide_ippan_header_id_view, name='slide_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def slide_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.slide_ippan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.slide_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.slide_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'KEN_CODE': user_proxy_list[0].ken_code, 
            'IPPAN_HEADER_ID': header_id, 
            'IPP_ACT_01': _IPP_ACT_01,
            'IPP_ACT_02': _IPP_ACT_02,
            'IPP_ACT_03': _IPP_ACT_03,
            'IPP_ACT_04': _IPP_ACT_04,
            'IPP_ACT_05': _IPP_ACT_05,
            'IPP_ACT_06': _IPP_ACT_06,
            'IPP_ACT_07': _IPP_ACT_07,
        })
        ippan_header_list = IPPAN_HEADER.objects.raw("""
            SELECT 
                IPPAN_HEADER_ID, 
                IPPAN_HEADER_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM IPPAN_HEADER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s""", params)
        
        print_log('{}'.format(ippan_header_list), 'DEBUG')
        print_log('{}'.format(len(ippan_header_list)), 'DEBUG')
        print_log('{}'.format(ippan_header_list[0]), 'DEBUG')
        print_log('{}'.format(ippan_header_list[0].ippan_header_id), 'DEBUG')

        ippan_trigger_act_01_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_01)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        ippan_trigger_act_02_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_02)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        ippan_trigger_act_03_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_03)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        ippan_trigger_act_04_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_04)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        ippan_trigger_act_05_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_05)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        ippan_trigger_act_06_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_06)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        ippan_trigger_act_07_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_07)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)
        
        print_log('{}'.format(ippan_trigger_act_01_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_01_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_01_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_01_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_02_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_02_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_02_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_02_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_03_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_03_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_03_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_03_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_04_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_04_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_04_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_04_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_05_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_05_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_05_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_05_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_06_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_06_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_06_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_06_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_07_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_07_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_07_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_07_list[0].ippan_trigger_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 STEP 5/6.', 'DEBUG')
        if ippan_header_list == False:
            print_log('[WARN] P0120Ken.slide_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        ### if ippan_trigger_act_01_list == False:
        ###     print_log('[WARN] P0120Ken.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_02_list == False:
        ###     print_log('[WARN] P0120Ken.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_03_list == False:
        ###     print_log('[WARN] P0120Ken.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_04_list == False:
        ###     print_log('[WARN] P0120Ken.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_05_list == False:
        ###     print_log('[WARN] P0120Ken.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_06_list == False:
        ###     print_log('[WARN] P0120Ken.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_07_list == False:
        ###     print_log('[WARN] P0120Ken.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_ippan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.slide_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
            'ippan_header_id': ippan_header_list[0].ippan_header_id, 
            'ippan_header_name': ippan_header_list[0].ippan_header_name, 
            'ken_code': ippan_header_list[0].ken_code, 
            'city_code': ippan_header_list[0].city_code, 
            'upload_file_path': ippan_header_list[0].upload_file_path, 
            'upload_file_name': ippan_header_list[0].upload_file_name, 
            'upload_file_size': ippan_header_list[0].upload_file_size, 
            'summary_file_path': ippan_header_list[0].summary_file_path, 
            'summary_file_name': ippan_header_list[0].summary_file_name, 
            'summary_file_size': ippan_header_list[0].summary_file_size, 
            'committed_at': ippan_header_list[0].committed_at, 
            'deleted_at': ippan_header_list[0].deleted_at, 
        }
        if ippan_trigger_act_01_list:
            data01 = {
                'act_01_status_code': ippan_trigger_act_01_list[0].status_code, 
                'act_01_published_at': ippan_trigger_act_01_list[0].published_at, 
                'act_01_consumed_at': ippan_trigger_act_01_list[0].consumed_at, 
                'act_01_deleted_at': ippan_trigger_act_01_list[0].deleted_at, 
            }
        else:
            data01 = {
                'act_01_status_code': None, 
                'act_01_published_at': None, 
                'act_01_consumed_at': None, 
                'act_01_deleted_at': None, 
            }
        if ippan_trigger_act_02_list:
            data02 = {
                'act_02_status_code': ippan_trigger_act_02_list[0].status_code, 
                'act_02_published_at': ippan_trigger_act_02_list[0].published_at, 
                'act_02_consumed_at': ippan_trigger_act_02_list[0].consumed_at, 
                'act_02_deleted_at': ippan_trigger_act_02_list[0].deleted_at, 
            }
        else:
            data02 = {
                'act_02_status_code': None, 
                'act_02_published_at': None, 
                'act_02_consumed_at': None, 
                'act_02_deleted_at': None, 
            }
        if ippan_trigger_act_03_list:
            data03 = {
                'act_03_status_code': ippan_trigger_act_03_list[0].status_code, 
                'act_03_published_at': ippan_trigger_act_03_list[0].published_at, 
                'act_03_consumed_at': ippan_trigger_act_03_list[0].consumed_at, 
                'act_03_deleted_at': ippan_trigger_act_03_list[0].deleted_at, 
            }
        else:
            data03 = {
                'act_03_status_code': None, 
                'act_03_published_at': None, 
                'act_03_consumed_at': None, 
                'act_03_deleted_at': None, 
            }
        if ippan_trigger_act_04_list:
            data04 = {
                'act_04_status_code': ippan_trigger_act_04_list[0].status_code, 
                'act_04_published_at': ippan_trigger_act_04_list[0].published_at, 
                'act_04_consumed_at': ippan_trigger_act_04_list[0].consumed_at, 
                'act_04_deleted_at': ippan_trigger_act_04_list[0].deleted_at, 
            }
        else:
            data04 = {
                'act_04_status_code': None, 
                'act_04_published_at': None, 
                'act_04_consumed_at': None, 
                'act_04_deleted_at': None, 
            }
        if ippan_trigger_act_05_list:
            data05 = {
                'act_05_status_code': ippan_trigger_act_05_list[0].status_code, 
                'act_05_published_at': ippan_trigger_act_05_list[0].published_at, 
                'act_05_consumed_at': ippan_trigger_act_05_list[0].consumed_at, 
                'act_05_deleted_at': ippan_trigger_act_05_list[0].deleted_at, 
            }
        else:
            data05 = {
                'act_05_status_code': None, 
                'act_05_published_at': None, 
                'act_05_consumed_at': None, 
                'act_05_deleted_at': None, 
            }
        if ippan_trigger_act_06_list:
            data06 = {
                'act_06_status_code': ippan_trigger_act_06_list[0].status_code, 
                'act_06_published_at': ippan_trigger_act_06_list[0].published_at, 
                'act_06_consumed_at': ippan_trigger_act_06_list[0].consumed_at, 
                'act_06_deleted_at': ippan_trigger_act_06_list[0].deleted_at, 
            }
        else:
            data06 = {
                'act_06_status_code': None, 
                'act_06_published_at': None, 
                'act_06_consumed_at': None, 
                'act_06_deleted_at': None, 
            }
        if ippan_trigger_act_07_list:
            data07 = {
                'act_07_status_code': ippan_trigger_act_07_list[0].status_code, 
                'act_07_published_at': ippan_trigger_act_07_list[0].published_at, 
                'act_07_consumed_at': ippan_trigger_act_07_list[0].consumed_at, 
                'act_07_deleted_at': ippan_trigger_act_07_list[0].deleted_at, 
            }
        else:
            data07 = {
                'act_07_status_code': None, 
                'act_07_published_at': None, 
                'act_07_consumed_at': None, 
                'act_07_deleted_at': None, 
            }
        data.update(data01)
        data.update(data02)
        data.update(data03)
        data.update(data04)
        data.update(data05)
        data.update(data06)
        data.update(data07)
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.slide_ippan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_ippan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用水害区域図右スライドメニュー表示【済】
### 関数名：slide_area_header_id_view(request, header_id)
### urlpattern：path('slide/area/header/<slug:header_id>/', views.slide_area_header_id_view, name='slide_area_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def slide_area_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.slide_area_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.slide_area_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_area_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_area_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_area_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_area_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_area_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.slide_area_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.slide_area_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_area_header_id_view()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'AREA_ID': str(header_id), 
            'KEN_CODE': user_proxy_list[0].ken_code, 
        })
        area_list = AREA.objects.raw("""
            SELECT 
                AREA_ID, 
                AREA_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM AREA 
            WHERE 
                AREA_ID=%(AREA_ID)s AND 
                KEN_CODE=%(KEN_CODE)s""", params)
        
        print_log('{}'.format(area_list), 'DEBUG')
        print_log('{}'.format(len(area_list)), 'DEBUG')
        print_log('{}'.format(area_list[0]), 'DEBUG')
        print_log('{}'.format(area_list[0].area_id), 'DEBUG')

        ### bool_return, area_trigger_list = area_trigger_objects_raw(params)
        ### area_trigger_list = AREA_TRIGGER.objects.raw("""
        ###     """, params)
        ### if bool_return == False:
        ###     raise Exception
        ### print_log('{}'.format(area_trigger_list), 'DEBUG')
        ### print_log('{}'.format(len(area_trigger_list)), 'DEBUG')
        ### print_log('{}'.format(area_trigger_list[0]), 'DEBUG')
        ### print_log('{}'.format(area_trigger_list[0].area_trigger_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_area_header_id_view()関数 STEP 5/6.', 'DEBUG')
        if area_list == False:
            print_log('[WARN] P0120Ken.slide_area_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        ### if area_trigger_list == False:
        ###     print_log('[WARN] P0120Ken.slide_area_header_id_view()関数が警告終了しました。', 'WARN')
        ###     data = {
        ###         'return_code': ["FALSE"], 
        ###     }
        ###     response = JsonResponse(data)
        ###     response['Access-Control-Allow-Origin'] = 'localhost:8000'
        ###     response['Access-Control-Allow-Credentials'] = 'true'
        ###     response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        ###     response['Access-Control-Allow-Methods'] = 'GET'
        ###     return response

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_area_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.slide_area_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
            'area_id': area_list[0].area_id, 
            'area_name': area_list[0].area_name,
            'ken_code': area_list[0].ken_code,
            'city_code': area_list[0].city_code,
            'upload_file_path': area_list[0].upload_file_path, 
            'upload_file_name': area_list[0].upload_file_name, 
            'upload_file_size': area_list[0].upload_file_size, 
            'committed_at': area_list[0].committed_at, 
            'deleted_at': area_list[0].deleted_at, 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.slide_area_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_area_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_area_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用地方単独事業調査票右スライドメニュー表示【済】
### 関数名：slide_chitan_header_id_view(request, header_id)
### urlpattern：path('slide/chitan/header/<slug:header_id>/', views.slide_chitan_header_id_view, name='slide_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def slide_chitan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.slide_chitan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.slide_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.slide_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'KEN_CODE': user_proxy_list[0].ken_code, 
            'CHITAN_HEADER_ID': header_id, 
            'CHI_ACT_01': _CHI_ACT_01,
            'CHI_ACT_02': _CHI_ACT_02,
            'CHI_ACT_03': _CHI_ACT_03,
            'CHI_ACT_04': _CHI_ACT_04,
            'CHI_ACT_05': _CHI_ACT_05,
            'CHI_ACT_06': _CHI_ACT_06,
            'CHI_ACT_07': _CHI_ACT_07,
        })
        chitan_header_list = CHITAN_HEADER.objects.raw("""
            SELECT 
                CHITAN_HEADER_ID, 
                CHITAN_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM CHITAN_HEADER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s""", params)
        
        print_log('{}'.format(chitan_header_list), 'DEBUG')
        print_log('{}'.format(len(chitan_header_list)), 'DEBUG')
        print_log('{}'.format(chitan_header_list[0]), 'DEBUG')
        print_log('{}'.format(chitan_header_list[0].chitan_header_id), 'DEBUG')

        chitan_trigger_act_01_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(CHI_ACT_01)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        chitan_trigger_act_02_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(CHI_ACT_02)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        chitan_trigger_act_03_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(CHI_ACT_03)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        chitan_trigger_act_04_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(CHI_ACT_04)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        chitan_trigger_act_05_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(CHI_ACT_05)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        chitan_trigger_act_06_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(CHI_ACT_06)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        chitan_trigger_act_07_list = CHITAN_TRIGGER.objects.raw("""
            SELECT 
                CHITAN_TRIGGER_ID, 
                CHITAN_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM CHITAN_TRIGGER 
            WHERE 
                CHITAN_HEADER_ID=%(CHITAN_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(CHI_ACT_07)s 
            ORDER BY CHITAN_TRIGGER_ID LIMIT 1""", params)

        print_log('{}'.format(chitan_trigger_act_01_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_01_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_01_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_01_list[0].chitan_trigger_id), 'DEBUG')

        print_log('{}'.format(chitan_trigger_act_02_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_02_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_02_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_02_list[0].chitan_trigger_id), 'DEBUG')

        print_log('{}'.format(chitan_trigger_act_03_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_03_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_03_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_03_list[0].chitan_trigger_id), 'DEBUG')

        print_log('{}'.format(chitan_trigger_act_04_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_04_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_04_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_04_list[0].chitan_trigger_id), 'DEBUG')

        print_log('{}'.format(chitan_trigger_act_05_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_05_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_05_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_05_list[0].chitan_trigger_id), 'DEBUG')

        print_log('{}'.format(chitan_trigger_act_06_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_06_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_06_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_06_list[0].chitan_trigger_id), 'DEBUG')

        print_log('{}'.format(chitan_trigger_act_07_list), 'DEBUG')
        print_log('{}'.format(len(chitan_trigger_act_07_list)), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_07_list[0]), 'DEBUG')
        ### print_log('{}'.format(chitan_trigger_act_07_list[0].chitan_trigger_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 STEP 5/6.', 'DEBUG')
        if chitan_header_list == False:
            print_log('[WARN] P0120Ken.slide_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        ### if chitan_trigger_act_01_list == False:
        ###     print_log('[WARN] P0120Ken.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        ### if chitan_trigger_act_02_list == False:
        ###     print_log('[WARN] P0120Ken.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        ### if chitan_trigger_act_03_list == False:
        ###     print_log('[WARN] P0120Ken.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        ### if chitan_trigger_act_04_list == False:
        ###     print_log('[WARN] P0120Ken.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        ### if chitan_trigger_act_05_list == False:
        ###     print_log('[WARN] P0120Ken.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        ### if chitan_trigger_act_06_list == False:
        ###     print_log('[WARN] P0120Ken.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        ### if chitan_trigger_act_07_list == False:
        ###     print_log('[WARN] P0120Ken.slide_chitan_header_id()関数が警告終了しました。', 'WARN')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_chitan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.slide_chitan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
            'chitan_header_id': chitan_header_list[0].chitan_header_id, 
            'chitan_header_name': chitan_header_list[0].chitan_header_name, 
            'ken_code': chitan_header_list[0].ken_code, 
            'upload_file_path': chitan_header_list[0].upload_file_path, 
            'upload_file_name': chitan_header_list[0].upload_file_name, 
            'upload_file_size': chitan_header_list[0].upload_file_size, 
            'summary_file_path': chitan_header_list[0].summary_file_path, 
            'summary_file_name': chitan_header_list[0].summary_file_name, 
            'summary_file_size': chitan_header_list[0].summary_file_size, 
            'committed_at': chitan_header_list[0].committed_at, 
            'deleted_at': chitan_header_list[0].deleted_at, 
        }
        if chitan_trigger_act_01_list:
            data01 = {
                'act_01_status_code': chitan_trigger_act_01_list[0].status_code, 
                'act_01_published_at': chitan_trigger_act_01_list[0].published_at, 
                'act_01_consumed_at': chitan_trigger_act_01_list[0].consumed_at, 
                'act_01_deleted_at': chitan_trigger_act_01_list[0].deleted_at, 
            }
        else:
            data01 = {
                'act_01_status_code': None, 
                'act_01_published_at': None, 
                'act_01_consumed_at': None, 
                'act_01_deleted_at': None, 
            }
        if chitan_trigger_act_02_list:
            data02 = {
                'act_02_status_code': chitan_trigger_act_02_list[0].status_code, 
                'act_02_published_at': chitan_trigger_act_02_list[0].published_at, 
                'act_02_consumed_at': chitan_trigger_act_02_list[0].consumed_at, 
                'act_02_deleted_at': chitan_trigger_act_02_list[0].deleted_at, 
            }
        else:
            data02 = {
                'act_02_status_code': None, 
                'act_02_published_at': None, 
                'act_02_consumed_at': None, 
                'act_02_deleted_at': None, 
            }
        if chitan_trigger_act_03_list:
            data03 = {
                'act_03_status_code': chitan_trigger_act_03_list[0].status_code, 
                'act_03_published_at': chitan_trigger_act_03_list[0].published_at, 
                'act_03_consumed_at': chitan_trigger_act_03_list[0].consumed_at, 
                'act_03_deleted_at': chitan_trigger_act_03_list[0].deleted_at, 
            }
        else:
            data03 = {
                'act_03_status_code': None, 
                'act_03_published_at': None, 
                'act_03_consumed_at': None, 
                'act_03_deleted_at': None, 
            }
        if chitan_trigger_act_04_list:
            data04 = {
                'act_04_status_code': chitan_trigger_act_04_list[0].status_code, 
                'act_04_published_at': chitan_trigger_act_04_list[0].published_at, 
                'act_04_consumed_at': chitan_trigger_act_04_list[0].consumed_at, 
                'act_04_deleted_at': chitan_trigger_act_04_list[0].deleted_at, 
            }
        else:
            data04 = {
                'act_04_status_code': None, 
                'act_04_published_at': None, 
                'act_04_consumed_at': None, 
                'act_04_deleted_at': None, 
            }
        if chitan_trigger_act_05_list:
            data05 = {
                'act_05_status_code': chitan_trigger_act_05_list[0].status_code, 
                'act_05_published_at': chitan_trigger_act_05_list[0].published_at, 
                'act_05_consumed_at': chitan_trigger_act_05_list[0].consumed_at, 
                'act_05_deleted_at': chitan_trigger_act_05_list[0].deleted_at, 
            }
        else:
            data05 = {
                'act_05_status_code': None, 
                'act_05_published_at': None, 
                'act_05_consumed_at': None, 
                'act_05_deleted_at': None, 
            }
        if chitan_trigger_act_06_list:
            data06 = {
                'act_06_status_code': chitan_trigger_act_06_list[0].status_code, 
                'act_06_published_at': chitan_trigger_act_06_list[0].published_at, 
                'act_06_consumed_at': chitan_trigger_act_06_list[0].consumed_at, 
                'act_06_deleted_at': chitan_trigger_act_06_list[0].deleted_at, 
            }
        else:
            data06 = {
                'act_06_status_code': None, 
                'act_06_published_at': None, 
                'act_06_consumed_at': None, 
                'act_06_deleted_at': None, 
            }
        if chitan_trigger_act_07_list:
            data07 = {
                'act_07_status_code': chitan_trigger_act_07_list[0].status_code, 
                'act_07_published_at': chitan_trigger_act_07_list[0].published_at, 
                'act_07_consumed_at': chitan_trigger_act_07_list[0].consumed_at, 
                'act_07_deleted_at': chitan_trigger_act_07_list[0].deleted_at, 
            }
        else:
            data07 = {
                'act_07_status_code': None, 
                'act_07_published_at': None, 
                'act_07_consumed_at': None, 
                'act_07_deleted_at': None, 
            }
        data.update(data01)
        data.update(data02)
        data.update(data03)
        data.update(data04)
        data.update(data05)
        data.update(data06)
        data.update(data07)
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.slide_chitan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_chitan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用補助事業調査票右スライドメニュー表示【済】
### 関数名：slide_hojo_header_id_view(request, header_id)
### urlpattern：path('slide/hojo/header/<slug:header_id>/', views.slide_hojo_header_id_view, name='slide_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def slide_hojo_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.slide_hojo_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.slide_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_coee': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.slide_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'KEN_CODE': user_proxy_list[0].ken_code, 
            'HOJO_HEADER_ID': header_id, 
            'HOJ_ACT_01': _HOJ_ACT_01,
            'HOJ_ACT_02': _HOJ_ACT_02,
            'HOJ_ACT_03': _HOJ_ACT_03,
            'HOJ_ACT_04': _HOJ_ACT_04,
            'HOJ_ACT_05': _HOJ_ACT_05,
            'HOJ_ACT_06': _HOJ_ACT_06,
            'HOJ_ACT_07': _HOJ_ACT_07,
        })
        hojo_header_list = HOJO_HEADER.objects.raw("""
            SELECT 
                HOJO_HEADER_ID, 
                HOJO_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM HOJO_HEADER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s""", params)
        
        print_log('{}'.format(hojo_header_list), 'DEBUG')
        print_log('{}'.format(len(hojo_header_list)), 'DEBUG')
        print_log('{}'.format(hojo_header_list[0]), 'DEBUG')
        print_log('{}'.format(hojo_header_list[0].hojo_header_id), 'DEBUG')

        hojo_trigger_act_01_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(HOJ_ACT_01)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        hojo_trigger_act_02_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(HOJ_ACT_02)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        hojo_trigger_act_03_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(HOJ_ACT_03)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        hojo_trigger_act_04_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(HOJ_ACT_04)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        hojo_trigger_act_05_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(HOJ_ACT_05)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        hojo_trigger_act_06_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(HOJ_ACT_06)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        hojo_trigger_act_07_list = HOJO_TRIGGER.objects.raw("""
            SELECT 
                HOJO_TRIGGER_ID, 
                HOJO_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM HOJO_TRIGGER 
            WHERE 
                HOJO_HEADER_ID=%(HOJO_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(HOJ_ACT_07)s 
            ORDER BY HOJO_TRIGGER_ID LIMIT 1""", params)

        print_log('{}'.format(hojo_trigger_act_01_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_01_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_01_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_01_list[0].hojo_trigger_id), 'DEBUG')

        print_log('{}'.format(hojo_trigger_act_02_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_02_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_02_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_02_list[0].hojo_trigger_id), 'DEBUG')

        print_log('{}'.format(hojo_trigger_act_03_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_03_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_03_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_03_list[0].hojo_trigger_id), 'DEBUG')

        print_log('{}'.format(hojo_trigger_act_04_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_04_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_04_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_04_list[0].hojo_trigger_id), 'DEBUG')

        print_log('{}'.format(hojo_trigger_act_05_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_05_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_05_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_05_list[0].hojo_trigger_id), 'DEBUG')

        print_log('{}'.format(hojo_trigger_act_06_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_06_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_06_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_06_list[0].hojo_trigger_id), 'DEBUG')

        print_log('{}'.format(hojo_trigger_act_07_list), 'DEBUG')
        print_log('{}'.format(len(hojo_trigger_act_07_list)), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_07_list[0]), 'DEBUG')
        ### print_log('{}'.format(hojo_trigger_act_07_list[0].hojo_trigger_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 STEP 5/6.', 'DEBUG')
        if hojo_header_list == False:
            print_log('[WARN] P0120Ken.slide_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        ### if hojo_trigger_act_01_list == False:
        ###     print_log('[WARN] P0120Ken.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        ### if hojo_trigger_act_02_list == False:
        ###     print_log('[WARN] P0120Ken.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        ### if hojo_trigger_act_03_list == False:
        ###     print_log('[WARN] P0120Ken.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        ### if hojo_trigger_act_04_list == False:
        ###     print_log('[WARN] P0120Ken.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        ### if hojo_trigger_act_05_list == False:
        ###     print_log('[WARN] P0120Ken.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        ### if hojo_trigger_act_06_list == False:
        ###     print_log('[WARN] P0120Ken.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        ### if hojo_trigger_act_07_list == False:
        ###     print_log('[WARN] P0120Ken.slide_hojo_header_id()関数が警告終了しました。', 'WARN')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_hojo_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.slide_hojo_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
            'hojo_header_id': hojo_header_list[0].hojo_header_id, 
            'hojo_header_name': hojo_header_list[0].hojo_header_name, 
            'ken_code': hojo_header_list[0].ken_code, 
            'upload_file_path': hojo_header_list[0].upload_file_path, 
            'upload_file_name': hojo_header_list[0].upload_file_name, 
            'upload_file_size': hojo_header_list[0].upload_file_size, 
            'summary_file_path': hojo_header_list[0].summary_file_path, 
            'summary_file_name': hojo_header_list[0].summary_file_name, 
            'summary_file_size': hojo_header_list[0].summary_file_size, 
            'committed_at': hojo_header_list[0].committed_at, 
            'deleted_at': hojo_header_list[0].deleted_at, 
        }
        if hojo_trigger_act_01_list:
            data01 = {
                'act_01_status_code': hojo_trigger_act_01_list[0].status_code, 
                'act_01_published_at': hojo_trigger_act_01_list[0].published_at, 
                'act_01_consumed_at': hojo_trigger_act_01_list[0].consumed_at, 
                'act_01_deleted_at': hojo_trigger_act_01_list[0].deleted_at, 
            }
        else:
            data01 = {
                'act_01_status_code': None, 
                'act_01_published_at': None, 
                'act_01_consumed_at': None, 
                'act_01_deleted_at': None, 
            }
        if hojo_trigger_act_02_list:
            data02 = {
                'act_02_status_code': hojo_trigger_act_02_list[0].status_code, 
                'act_02_published_at': hojo_trigger_act_02_list[0].published_at, 
                'act_02_consumed_at': hojo_trigger_act_02_list[0].consumed_at, 
                'act_02_deleted_at': hojo_trigger_act_02_list[0].deleted_at, 
            }
        else:
            data02 = {
                'act_02_status_code': None, 
                'act_02_published_at': None, 
                'act_02_consumed_at': None, 
                'act_02_deleted_at': None, 
            }
        if hojo_trigger_act_03_list:
            data03 = {
                'act_03_status_code': hojo_trigger_act_03_list[0].status_code, 
                'act_03_published_at': hojo_trigger_act_03_list[0].published_at, 
                'act_03_consumed_at': hojo_trigger_act_03_list[0].consumed_at, 
                'act_03_deleted_at': hojo_trigger_act_03_list[0].deleted_at, 
            }
        else:
            data03 = {
                'act_03_status_code': None, 
                'act_03_published_at': None, 
                'act_03_consumed_at': None, 
                'act_03_deleted_at': None, 
            }
        if hojo_trigger_act_04_list:
            data04 = {
                'act_04_status_code': hojo_trigger_act_04_list[0].status_code, 
                'act_04_published_at': hojo_trigger_act_04_list[0].published_at, 
                'act_04_consumed_at': hojo_trigger_act_04_list[0].consumed_at, 
                'act_04_deleted_at': hojo_trigger_act_04_list[0].deleted_at, 
            }
        else:
            data04 = {
                'act_04_status_code': None, 
                'act_04_published_at': None, 
                'act_04_consumed_at': None, 
                'act_04_deleted_at': None, 
            }
        if hojo_trigger_act_05_list:
            data05 = {
                'act_05_status_code': hojo_trigger_act_05_list[0].status_code, 
                'act_05_published_at': hojo_trigger_act_05_list[0].published_at, 
                'act_05_consumed_at': hojo_trigger_act_05_list[0].consumed_at, 
                'act_05_deleted_at': hojo_trigger_act_05_list[0].deleted_at, 
            }
        else:
            data05 = {
                'act_05_status_code': None, 
                'act_05_published_at': None, 
                'act_05_consumed_at': None, 
                'act_05_deleted_at': None, 
            }
        if hojo_trigger_act_06_list:
            data06 = {
                'act_06_status_code': hojo_trigger_act_06_list[0].status_code, 
                'act_06_published_at': hojo_trigger_act_06_list[0].published_at, 
                'act_06_consumed_at': hojo_trigger_act_06_list[0].consumed_at, 
                'act_06_deleted_at': hojo_trigger_act_06_list[0].deleted_at, 
            }
        else:
            data06 = {
                'act_06_status_code': None, 
                'act_06_published_at': None, 
                'act_06_consumed_at': None, 
                'act_06_deleted_at': None, 
            }
        if hojo_trigger_act_07_list:
            data07 = {
                'act_07_status_code': hojo_trigger_act_07_list[0].status_code, 
                'act_07_published_at': hojo_trigger_act_07_list[0].published_at, 
                'act_07_consumed_at': hojo_trigger_act_07_list[0].consumed_at, 
                'act_07_deleted_at': hojo_trigger_act_07_list[0].deleted_at, 
            }
        else:
            data07 = {
                'act_07_status_code': None, 
                'act_07_published_at': None, 
                'act_07_consumed_at': None, 
                'act_07_deleted_at': None, 
            }
        data.update(data01)
        data.update(data02)
        data.update(data03)
        data.update(data04)
        data.update(data05)
        data.update(data06)
        data.update(data07)
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.slide_hojo_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_hojo_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用公益事業調査票右スライドメニュー表示【済】
### 関数名：slide_koeki_header_id_view(request, header_id)
### urlpattern：path('slide/koeki/header/<slug:header_id>/', views.slide_koeki_header_id_view, name='slide_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def slide_koeki_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.slide_koeki_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.slide_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.slide_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'KEN_CODE': user_proxy_list[0].ken_code, 
            'KOEKI_HEADER_ID': header_id, 
            'KOE_ACT_01': _KOE_ACT_01,
            'KOE_ACT_02': _KOE_ACT_02,
            'KOE_ACT_03': _KOE_ACT_03,
            'KOE_ACT_04': _KOE_ACT_04,
            'KOE_ACT_05': _KOE_ACT_05,
            'KOE_ACT_06': _KOE_ACT_06,
            'KOE_ACT_07': _KOE_ACT_07,
        })
        koeki_header_list = KOEKI_HEADER.objects.raw("""
            SELECT 
                KOEKI_HEADER_ID, 
                KOEKI_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM KOEKI_HEADER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s""", params)
        
        print_log('{}'.format(koeki_header_list), 'DEBUG')
        print_log('{}'.format(len(koeki_header_list)), 'DEBUG')
        print_log('{}'.format(koeki_header_list[0]), 'DEBUG')
        print_log('{}'.format(koeki_header_list[0].koeki_header_id), 'DEBUG')

        koeki_trigger_act_01_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(KOE_ACT_01)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        koeki_trigger_act_02_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(KOE_ACT_02)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        koeki_trigger_act_03_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(KOE_ACT_03)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        koeki_trigger_act_04_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(KOE_ACT_04)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        koeki_trigger_act_05_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(KOE_ACT_05)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        koeki_trigger_act_06_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(KOE_ACT_06)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        koeki_trigger_act_07_list = KOEKI_TRIGGER.objects.raw("""
            SELECT 
                KOEKI_TRIGGER_ID, 
                KOEKI_HEADER_ID, 
                KEN_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM KOEKI_TRIGGER 
            WHERE 
                KOEKI_HEADER_ID=%(KOEKI_HEADER_ID)s AND 
                KEN_CODE=%(KEN_CODE)s AND 
                ACTION_CODE=%(KOE_ACT_07)s 
            ORDER BY KOEKI_TRIGGER_ID LIMIT 1""", params)

        print_log('{}'.format(koeki_trigger_act_01_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_01_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_01_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_01_list[0].koeki_trigger_id), 'DEBUG')

        print_log('{}'.format(koeki_trigger_act_02_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_02_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_02_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_02_list[0].koeki_trigger_id), 'DEBUG')

        print_log('{}'.format(koeki_trigger_act_03_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_03_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_03_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_03_list[0].koeki_trigger_id), 'DEBUG')

        print_log('{}'.format(koeki_trigger_act_04_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_04_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_04_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_04_list[0].koeki_trigger_id), 'DEBUG')

        print_log('{}'.format(koeki_trigger_act_05_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_05_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_05_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_05_list[0].koeki_trigger_id), 'DEBUG')

        print_log('{}'.format(koeki_trigger_act_06_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_06_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_06_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_06_list[0].koeki_trigger_id), 'DEBUG')

        print_log('{}'.format(koeki_trigger_act_07_list), 'DEBUG')
        print_log('{}'.format(len(koeki_trigger_act_07_list)), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_07_list[0]), 'DEBUG')
        ### print_log('{}'.format(koeki_trigger_act_07_list[0].koeki_trigger_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 STEP 5/6.', 'DEBUG')
        if koeki_header_list == False:
            print_log('[WARN] P0120Ken.slide_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        ### if koeki_trigger_act_01_list == False:
        ###     print_log('[WARN] P0120Ken.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        ### if koeki_trigger_act_02_list == False:
        ###     print_log('[WARN] P0120Ken.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        ### if koeki_trigger_act_03_list == False:
        ###     print_log('[WARN] P0120Ken.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        ### if koeki_trigger_act_04_list == False:
        ###     print_log('[WARN] P0120Ken.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        ### if koeki_trigger_act_05_list == False:
        ###     print_log('[WARN] P0120Ken.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        ### if koeki_trigger_act_06_list == False:
        ###     print_log('[WARN] P0120Ken.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        ### if koeki_trigger_act_07_list == False:
        ###     print_log('[WARN] P0120Ken.slide_koeki_header_id()関数が警告終了しました。', 'WARN')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.slide_koeki_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.slide_koeki_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
            'koeki_header_id': koeki_header_list[0].koeki_header_id, 
            'koeki_header_name': koeki_header_list[0].koeki_header_name, 
            'ken_code': koeki_header_list[0].ken_code, 
            'upload_file_path': koeki_header_list[0].upload_file_path, 
            'upload_file_name': koeki_header_list[0].upload_file_name, 
            'upload_file_size': koeki_header_list[0].upload_file_size, 
            'summary_file_path': koeki_header_list[0].summary_file_path, 
            'summary_file_name': koeki_header_list[0].summary_file_name, 
            'summary_file_size': koeki_header_list[0].summary_file_size, 
            'committed_at': koeki_header_list[0].committed_at, 
            'deleted_at': koeki_header_list[0].deleted_at, 
        }
        if koeki_trigger_act_01_list:
            data01 = {
                'koeki_act_01_status_code': koeki_trigger_act_01_list[0].status_code, 
                'koeki_act_01_published_at': koeki_trigger_act_01_list[0].published_at, 
                'koeki_act_01_consumed_at': koeki_trigger_act_01_list[0].consumed_at, 
                'koeki_act_01_deleted_at': koeki_trigger_act_01_list[0].deleted_at, 
            }
        else:
            data01 = {
                'koeki_act_01_status_code': None, 
                'koeki_act_01_published_at': None, 
                'koeki_act_01_consumed_at': None, 
                'koeki_act_01_deleted_at': None, 
            }
        if koeki_trigger_act_02_list:
            data02 = {
                'koeki_act_02_status_code': koeki_trigger_act_02_list[0].status_code, 
                'koeki_act_02_published_at': koeki_trigger_act_02_list[0].published_at, 
                'koeki_act_02_consumed_at': koeki_trigger_act_02_list[0].consumed_at, 
                'koeki_act_02_deleted_at': koeki_trigger_act_02_list[0].deleted_at, 
            }
        else:
            data02 = {
                'koeki_act_02_status_code': None, 
                'koeki_act_02_published_at': None, 
                'koeki_act_02_consumed_at': None, 
                'koeki_act_02_deleted_at': None, 
            }
        if koeki_trigger_act_03_list:
            data03 = {
                'koeki_act_03_status_code': koeki_trigger_act_03_list[0].status_code, 
                'koeki_act_03_published_at': koeki_trigger_act_03_list[0].published_at, 
                'koeki_act_03_consumed_at': koeki_trigger_act_03_list[0].consumed_at, 
                'koeki_act_03_deleted_at': koeki_trigger_act_03_list[0].deleted_at, 
            }
        else:
            data03 = {
                'koeki_act_03_status_code': None, 
                'koeki_act_03_published_at': None, 
                'koeki_act_03_consumed_at': None, 
                'koeki_act_03_deleted_at': None, 
            }
        if koeki_trigger_act_04_list:
            data04 = {
                'koeki_act_04_status_code': koeki_trigger_act_04_list[0].status_code, 
                'koeki_act_04_published_at': koeki_trigger_act_04_list[0].published_at, 
                'koeki_act_04_consumed_at': koeki_trigger_act_04_list[0].consumed_at, 
                'koeki_act_04_deleted_at': koeki_trigger_act_04_list[0].deleted_at, 
            }
        else:
            data04 = {
                'koeki_act_04_status_code': None, 
                'koeki_act_04_published_at': None, 
                'koeki_act_04_consumed_at': None, 
                'koeki_act_04_deleted_at': None, 
            }
        if koeki_trigger_act_05_list:
            data05 = {
                'koeki_act_05_status_code': koeki_trigger_act_05_list[0].status_code, 
                'koeki_act_05_published_at': koeki_trigger_act_05_list[0].published_at, 
                'koeki_act_05_consumed_at': koeki_trigger_act_05_list[0].consumed_at, 
                'koeki_act_05_deleted_at': koeki_trigger_act_05_list[0].deleted_at, 
            }
        else:
            data05 = {
                'koeki_act_05_status_code': None, 
                'koeki_act_05_published_at': None, 
                'koeki_act_05_consumed_at': None, 
                'koeki_act_05_deleted_at': None, 
            }
        if koeki_trigger_act_06_list:
            data06 = {
                'koeki_act_06_status_code': koeki_trigger_act_06_list[0].status_code, 
                'koeki_act_06_published_at': koeki_trigger_act_06_list[0].published_at, 
                'koeki_act_06_consumed_at': koeki_trigger_act_06_list[0].consumed_at, 
                'koeki_act_06_deleted_at': koeki_trigger_act_06_list[0].deleted_at, 
            }
        else:
            data06 = {
                'koeki_act_06_status_code': None, 
                'koeki_act_06_published_at': None, 
                'koeki_act_06_consumed_at': None, 
                'koeki_act_06_deleted_at': None, 
            }
        if koeki_trigger_act_07_list:
            data07 = {
                'koeki_act_07_status_code': koeki_trigger_act_07_list[0].status_code, 
                'koeki_act_07_published_at': koeki_trigger_act_07_list[0].published_at, 
                'koeki_act_07_consumed_at': koeki_trigger_act_07_list[0].consumed_at, 
                'koeki_act_07_deleted_at': koeki_trigger_act_07_list[0].deleted_at, 
            }
        else:
            data07 = {
                'koeki_act_07_status_code': None, 
                'koeki_act_07_published_at': None, 
                'koeki_act_07_consumed_at': None, 
                'koeki_act_07_deleted_at': None, 
            }
        data.update(data01)
        data.update(data02)
        data.update(data03)
        data.update(data04)
        data.update(data05)
        data.update(data06)
        data.update(data07)
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.slide_koeki_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_koeki_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.slide_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用一般資産調査員調査票EXCELダウンロード【済】
### 関数名：download_ippan_chosa_excel_header_id_view(request, header_id)
### urlpattern：path('download/ippan/chosa/excel/header/<slug:header_id>/', views.download_ippan_chosa_excel_header_id_view, name='download_ippan_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_chosa_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _IPP_CHO_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用一般資産調査員調査票CSVダウンロード【済】
### 関数名：download_ippan_chosa_csv_header_id_view(request, header_id)
### urlpattern：path('download/ippan/chosa/csv/header/<slug:header_id>/', views.download_ippan_chosa_csv_header_id_view, name='download_ippan_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_chosa_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _IPP_CHO_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用一般資産集計結果EXCELダウンロード【済】
### 関数名：download_ippan_summary_excel_header_id_view(request, header_id)
### urlpattern：path('download/ippan/summary/excel/header/<slug:header_id>/', views.download_ippan_summary_excel_header_id_view, name='download_ippan_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_summary_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _IPP_SUM_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用一般資産集計結果CSVダウンロード【済】
### 関数名：download_ippan_summary_csv_header_id_view(request, header_id)
### urlpattern：path('download/ippan/summary/csv/header/<slug:header_id>/', views.download_ippan_summary_csv_header_id_view, name='download_ippan_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_summary_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _IPP_SUM_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用水害区域図PDFダウンロード【済】
### 関数名：download_area_pdf_header_id_view(request, header_id)
### urlpattern：path('download/area/pdf/header/<slug:header_id>/', views.download_area_pdf_header_id_view, name='download_area_pdf_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_area_pdf_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _ARE_PDF)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用水害区域図KMLダウンロード【済】
### 関数名：download_area_kml_header_id_view(request, header_id)
### urlpattern：path('download/area/kml/header/<slug:header_id>/', views.download_area_kml_header_id_view, name='download_area_kml_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_area_kml_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _ARE_KML)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用地方単独事業調査票EXCELダウンロード【済】
### 関数名：download_chitan_chosa_excel_header_id_view(request, header_id)
### urlpattern：path('download/chitan/chosa/excel/header/<slug:header_id>/', views.download_chitan_chosa_excel_header_id_view, name='download_chitan_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_chitan_chosa_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _CHI_CHO_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用地方単独事業調査票CSVダウンロード【済】
### 関数名：download_chitan_chosa_csv_header_id_view(request, header_id)
### urlpattern：path('download/chitan/chosa/csv/header/<slug:header_id>/', views.download_chitan_chosa_csv_header_id_view, name='download_chitan_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_chitan_chosa_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _CHI_CHO_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用地方単独事業集計結果EXCELダウンロード【済】
### 関数名：download_chitan_summary_excel_header_id_view(request, header_id)
### urlpattern：path('download/chitan/summary/excel/header/<slug:header_id>/', views.download_chitan_summary_excel_header_id_view, name='download_chitan_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_chitan_summary_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _CHI_SUM_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用地方単独事業集計結果CSVダウンロード【済】
### 関数名：download_chitan_summary_csv_header_id_view(request, header_id)
### urlpattern：path('download/chitan/summary/csv/header/<slug:header_id>/', views.download_chitan_summary_csv_header_id_view, name='download_chitan_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_chitan_summary_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _CHI_SUM_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用補助事業調査票EXCELダウンロード【済】
### 関数名：download_hojo_chosa_excel_header_id_view(request, header_id)
### urlpattern：path('download/hojo/chosa/excel/header/<slug:header_id>/', views.download_hojo_chosa_excel_header_id_view, name='download_hojo_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_hojo_chosa_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _HOJ_CHO_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用補助事業調査票CSVダウンロード【済】
### 関数名：download_hojo_chosa_csv_header_id_view(request, header_id)
### urlpattern：path('download/hojo/chosa/csv/header/<slug:header_id>/', views.download_hojo_chosa_csv_header_id_view, name='download_hojo_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_hojo_chosa_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _HOJ_CHO_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用補助事業集計結果EXCELダウンロード【済】
### 関数名：download_hojo_summary_excel_header_id_view(request, header_id)
### urlpattern：path('download/hojo/summary/excel/header/<slug:header_id>/', views.download_hojo_summary_excel_header_id_view, name='download_hojo_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_hojo_summary_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _HOJ_SUM_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用補助事業集計結果CSVダウンロード【済】
### 関数名：download_hojo_summary_csv_header_id_view(request, header_id)
### urlpattern：path('download/hojo/summary/csv/header/<slug:header_id>/', views.download_hojo_summary_csv_header_id_view, name='download_hojo_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_hojo_summary_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _HOJ_SUM_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用公益事業調査票EXCELダウンロード【済】
### 関数名：download_koeki_chosa_excel_header_id_view(request, header_id)
### urlpattern：path('download/koeki/chosa/excel/header/<slug:header_id>/', views.download_koeki_chosa_excel_header_id_view, name='download_koeki_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_koeki_chosa_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _KOE_CHO_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用公益事業調査票CSVダウンロード【済】
### 関数名：download_koeki_chosa_csv_header_id_view(request, header_id)
### urlpattern：path('download/koeki/chosa/csv/header/<slug:header_id>/', views.download_koeki_chosa_csv_header_id_view, name='download_koeki_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_koeki_chosa_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _KOE_CHO_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用公益事業集計結果EXCELダウンロード【済】
### 関数名：download_koeki_summary_excel_header_id_view(request, header_id)
### urlpattern：path('download/koeki/summary/excel/header/<slug:header_id>/', views.download_koeki_summary_excel_header_id_view, name='download_koeki_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_koeki_summary_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _KOE_SUM_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用公益事業集計結果CSVダウンロード【済】
### 関数名：download_koeki_summary_csv_header_id_view(request, header_id)
### urlpattern：path('download/koeki/summary/csv/header/<slug:header_id>/', views.download_koeki_summary_csv_header_id_view, name='download_koeki_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_koeki_summary_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _KOE_SUM_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 都道府県用一般資産調査員調査票都道府県承認
### 関数名：approve_ippan_header_id(request, header_id)
### urlpattern：path('approve/ippan/header/<slug:header_id>/', views.approve_ippan_header_id_view, name='approve_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def approve_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.approve_ippan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.approve_ippan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.approve_ippan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.approve_ippan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.approve_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.approve_ippan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.approve_ippan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.approve_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.approve_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.approve_ippan_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.approve_ippan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.approve_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.approve_ippan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.approve_ippan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.approve_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用水害区域図都道府県承認
### 関数名：approve_area_header_id(request, header_id)
### urlpattern：path('approve/area/header/<slug:header_id>/', views.approve_area_header_id_view, name='approve_area_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def approve_area_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.approve_area_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.approve_area_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.approve_area_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.approve_area_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.approve_area_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.approve_area_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.approve_area_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.approve_area_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.approve_area_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.approve_area_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.approve_area_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.approve_area_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.approve_area_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.approve_area_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.approve_area_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用一般資産調査員調査票再チェック
### 関数名：check_ippan_header_id(request, header_id)
### urlpattern：path('check/ippan/header/<slug:header_id>/', views.check_ippan_header_id_view, name='check_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def check_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.check_ippan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.check_ippan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.check_ippan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.check_ippan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.check_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_ippan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_ippan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.check_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.check_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_ippan_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_ippan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.check_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.check_ippan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.check_ippan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.check_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用地方単独事業調査票再チェック
### 関数名：check_chitan_header_id(request, header_id)
### urlpattern：path('check/chitan/header/<slug:header_id>/', views.check_chitan_header_id_view, name='check_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def check_chitan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.check_chitan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.check_chitan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.check_chitan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.check_chitan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.check_chitan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_chitan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_chitan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.check_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.check_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_chitan_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_chitan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.check_chitan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.check_chitan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.check_chitan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.check_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用補助事業調査票再チェック
### 関数名：check_hojo_header_id(request, header_id)
### urlpattern：path('check/hojo/header/<slug:header_id>/', views.check_hojo_header_id_view, name='check_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def check_hojo_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.check_hojo_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.check_hojo_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.check_hojo_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.check_hojo_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.check_hojo_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_hojo_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_hojo_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.check_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.check_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_hojo_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_hojo_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.check_hojo_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.check_hojo_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.check_hojo_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.check_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用公益事業調査票再チェック
### 関数名：check_koeki_header_id(request, header_id)
### urlpattern：path('check/koeki/header/<slug:header_id>/', views.check_koeki_header_id_view, name='check_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def check_koeki_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.check_koeki_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.check_koeki_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.check_koeki_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.check_koeki_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.check_koeki_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_koeki_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_koeki_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.check_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.check_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_koeki_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.check_koeki_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.check_koeki_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.check_koeki_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.check_koeki_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.check_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用一般資産調査員調査票再集計
### 関数名：summarize_ippan_header_id(request, header_id)
### urlpattern：path('summarize/ippan/header/<slug:header_id>/', views.summarize_ippan_header_id_view, name='summarize_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def summarize_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.summarize_ippan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.summarize_ippan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.summarize_ippan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.summarize_ippan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.summarize_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_ippan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_ippan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.summarize_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.summarize_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_ippan_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_ippan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.summarize_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.summarize_ippan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.summarize_ippan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.summarize_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用地方単独事業調査票再集計
### 関数名：summarize_chitan_header_id(request, header_id)
### urlpattern：path('summarize/chitan/header/<slug:header_id>/', views.summarize_chitan_header_id_view, name='summarize_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def summarize_chitan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.summarize_chitan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.summarize_chitan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.summarize_chitan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.summarize_chitan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.summarize_chitan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_chitan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_chitan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.summarize_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.summarize_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_chitan_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_chitan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.summarize_chitan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.summarize_chitan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.summarize_chitan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.summarize_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用補助事業調査票再集計
### 関数名：summarize_hojo_header_id(request, header_id)
### urlpattern：path('summarize/hojo/header/<slug:header_id>/', views.summarize_hojo_header_id_view, name='summarize_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def summarize_hojo_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.summarize_hojo_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.summarize_hojo_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.summarize_hojo_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.summarize_hojo_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.summarize_hojo_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_hojo_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_hojo_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.summarize_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.summarize_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_hojo_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_hojo_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.summarize_hojo_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.summarize_hojo_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.summarize_hojo_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.summarize_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用公益事業調査票再集計
### 関数名：summarize_koeki_header_id(request, header_id)
### urlpattern：path('summarize/koeki/header/<slug:header_id>/', views.summarize_koeki_header_id_view, name='summarize_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def summarize_koeki_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.summarize_koeki_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.summarize_koeki_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.summarize_koeki_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.summarize_koeki_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.summarize_koeki_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_koeki_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_koeki_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.summarize_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.summarize_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_koeki_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.summarize_koeki_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.summarize_koeki_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0120Ken.summarize_koeki_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.summarize_koeki_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.summarize_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用一般資産調査員調査票ファイル削除
### 関数名：delete_ippan_header_id_view(request, header_id)
### urlpattern：path('delete/ippan/header/<slug:header_id>/', views.delete_ippan_header_id_view, name='delete_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def delete_ippan_header_id_view(request, header_id):
    bool_return, response = delete_header_id(request, header_id, _IPP)
    if bool_return == False:
        pass
    return response

###############################################################################
### 都道府県用水害区域図ファイル削除
### 関数名：delete_area_header_id_view(request, header_id)
### urlpattern：path('delete/area/header/<slug:header_id>/', views.delete_area_header_id_view, name='delete_area_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def delete_area_header_id_view(request, header_id):
    bool_return, response = delete_header_id(request, header_id, _ARE)
    if bool_return == False:
        pass
    return response

###############################################################################
### 都道府県用地方単独事業調査票ファイル削除
### 関数名：delete_chitan_header_id_view(request, header_id)
### urlpattern：path('delete/chitan/header/<slug:header_id>/', views.delete_chitan_header_id_view, name='delete_chitan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def delete_chitan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.delete_chitan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.delete_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.delete_chitan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 STEP 4/6.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")
            params = dict({
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'CHITAN_HEADER_ID': header_id, 
            })
            func_params = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': user_proxy_list[0].ken_code, 
                'city_code': None, 
                'action_code': _CHI_ACT_01
            })

            connection_cursor.execute("""
                UPDATE CHITAN_HEADER SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE CHITAN_HEADER_ID IN (
                SELECT 
                    CHITAN_HEADER_ID 
                FROM CHITAN_HEADER 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)""", params)

            connection_cursor.execute("""
                UPDATE CHITAN SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE CHITAN_ID IN (
                SELECT 
                    CHITAN_ID 
                FROM CHITAN_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)""", params)

            connection_cursor.execute("""
                UPDATE CHITAN_SUMMARY SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE CHITAN_ID IN (
                SELECT 
                    CHITAN_ID 
                FROM CHITAN_SUMMARY_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)""", params)

            bool_return = delete_message(metadata=func_params)
            if bool_return == False:
                print_log('[ERROR] delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            connection_cursor.execute("""COMMIT""")
            
        except:
            connection_cursor.execute("""ROLLBACK""")
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 STEP 5/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_chitan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.delete_chitan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.delete_chitan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.delete_chitan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.delete_chitan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用補助事業調査票ファイル削除
### 関数名：delete_hojo_header_id_view(request, header_id)
### urlpattern：path('delete/hojo/header/<slug:header_id>/', views.delete_hojo_header_id_view, name='delete_hojo_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def delete_hojo_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.delete_hojo_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.delete_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.delete_hojo_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 STEP 4/6.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")
            params = dict({
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'HOJO_HEADER_ID': header_id, 
            })
            func_params = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': user_proxy_list[0].ken_code, 
                'city_code': None, 
                'action_code': _HOJ_ACT_01
            })

            connection_cursor.execute("""
                UPDATE HOJO_HEADER SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE HOJO_HEADER_ID IN (
                SELECT 
                    HOJO_HEADER_ID 
                FROM HOJO_HEADER 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)""", params)

            connection_cursor.execute("""
                UPDATE HOJO SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE HOJO_ID IN (
                SELECT 
                    HOJO_ID 
                FROM HOJO_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)""", params)

            connection_cursor.execute("""
                UPDATE HOJO_SUMMARY SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE HOJO_ID IN (
                SELECT 
                    HOJO_ID 
                FROM HOJO_SUMMARY_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)""", params)

            bool_return = delete_message(metadata=func_params)
            if bool_return == False:
                print_log('[ERROR] delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            connection_cursor.execute("""COMMIT""")
            
        except:
            connection_cursor.execute("""ROLLBACK""")
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 STEP 5/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_hojo_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.delete_hojo_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.delete_hojo_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.delete_hojo_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.delete_hojo_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用公益事業調査票ファイル削除
### 関数名：delete_koeki_header_id_view(request, header_id)
### urlpattern：path('delete/koeki/header/<slug:header_id>/', views.delete_koeki_header_id_view, name='delete_koeki_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def delete_koeki_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.delete_koeki_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.delete_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.delete_koeki_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 STEP 4/6.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")
            params = dict({
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'KOEKI_HEADER_ID': header_id, 
            })
            func_params = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': user_proxy_list[0].ken_code, 
                'city_code': None, 
                'action_code': _KOE_ACT_01
            })

            connection_cursor.execute("""
                UPDATE KOEKI_HEADER SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE KOEKI_HEADER_ID IN (
                SELECT 
                    KOEKI_HEADER_ID 
                FROM KOEKI_HEADER 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)""", params)

            connection_cursor.execute("""
                UPDATE KOEKI SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE KOEKI_ID IN (
                SELECT 
                    KOEKI_ID 
                FROM KOEKI_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)""", params)

            connection_cursor.execute("""
                UPDATE KOEKI_SUMMARY SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE KOEKI_ID IN (
                SELECT 
                    KOEKI_ID 
                FROM KOEKI_SUMMARY_VIEW 
                WHERE 
                    KEN_CODE=%(KEN_CODE)s AND 
                    DELETED_AT IS NULL)""", params)

            bool_return = delete_message(metadata=func_params)
            if bool_return == False:
                print_log('[ERROR] delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            connection_cursor.execute("""COMMIT""")
            
        except:
            connection_cursor.execute("""ROLLBACK""")
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 STEP 5/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.delete_koeki_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.delete_koeki_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0120Ken.delete_koeki_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.delete_koeki_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.delete_koeki_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 都道府県用ブラウザ都アップロードファイル
###############################################################################
def browser_get(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.browser_get()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.browser_get()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_get()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        ### 下記の処理でアクセス制御を行う。
        ### ※コンテンツにアクセス可能なユーザは都道府県のみとする。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_get()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_get()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.browser_get()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.browser_get()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_get()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'KEN_CODE': user_proxy_list[0].ken_code
        })
        ### HTMLタイトル部分表示用
        ken_bucket_list = KEN_BUCKET.objects.raw("""
            SELECT 
                KEN_CODE, 
                KEN_NAME, 
                USAGE, 
                FILES 
            FROM KEN_BUCKET 
            WHERE 
                KEN_CODE=%(KEN_CODE)s""", params)

        print_log('{}'.format(ken_bucket_list), 'DEBUG')
        print_log('{}'.format(len(ken_bucket_list)), 'DEBUG')
        print_log('{}'.format(ken_bucket_list[0]), 'DEBUG')
        print_log('{}'.format(ken_bucket_list[0].ken_code), 'DEBUG')

        ### HTML一覧部分表示用
        city_bucket_list = CITY_BUCKET.objects.raw("""
            SELECT 
                CITY_CODE, 
                CITY_NAME, 
                KEN_CODE, 
                USAGE, 
                FILES 
            FROM CITY_BUCKET 
            WHERE 
                KEN_CODE=%(KEN_CODE)s
            ORDER BY 
                CAST(CITY_CODE AS INTEGER)""", params)
        
        print_log('{}'.format(city_bucket_list), 'DEBUG')
        print_log('{}'.format(len(city_bucket_list)), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0]), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0].city_code), 'DEBUG')
        
        ### HTML一覧部分表示用
        chitan_header_list = CHITAN_HEADER.objects.raw("""
            SELECT 
                CHITAN_HEADER_ID, 
                CHITAN_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM CHITAN_HEADER 
            WHERE 
                KEN_CODE=%(KEN_CODE)s AND 
                DELETED_AT IS NULL""", params)
        
        print_log('{}'.format(chitan_header_list), 'DEBUG')
        print_log('{}'.format(len(chitan_header_list)), 'DEBUG')

        ### HTML一覧部分表示用
        hojo_header_list = HOJO_HEADER.objects.raw("""
            SELECT 
                HOJO_HEADER_ID, 
                HOJO_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM HOJO_HEADER 
            WHERE 
                KEN_CODE=%(KEN_CODE)s AND 
                DELETED_AT IS NULL""", params)
        
        print_log('{}'.format(hojo_header_list), 'DEBUG')
        print_log('{}'.format(len(hojo_header_list)), 'DEBUG')

        ### HTML一覧部分表示用
        koeki_header_list = KOEKI_HEADER.objects.raw("""
            SELECT 
                KOEKI_HEADER_ID, 
                KOEKI_HEADER_NAME, 
                KEN_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM KOEKI_HEADER 
            WHERE 
                KEN_CODE=%(KEN_CODE)s AND 
                DELETED_AT IS NULL""", params)
        
        print_log('{}'.format(koeki_header_list), 'DEBUG')
        print_log('{}'.format(len(koeki_header_list)), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_get()関数 STEP 5/6.', 'DEBUG')
        if ken_bucket_list == False:
            print_log('[WARN] P0120Ken.browser_get()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))

        if city_bucket_list == False:
            print_log('[WARN] P0120Ken.browser_get()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
            
        ### 地方単独事業調査票ファイルの0件は正常であるため、チェックしない。
        ### 補助事業事業調査票ファイルの0件は正常であるため、チェックしない。
        ### 公益事業調査票ファイルの0件は正常であるため、チェックしない。
        
        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_get()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0120Ken.browser_get()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'ken_bucket_list': ken_bucket_list, 
            'city_bucket_list': city_bucket_list, 
            'chitan_header_list': chitan_header_list, 
            'hojo_header_list': hojo_header_list, 
            'koeki_header_list': koeki_header_list, 
        }
        return True, HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0120Ken.browser_get()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_get()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_get()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))

###############################################################################
### 都道府県用ブラウザ都アップロードファイル
###############################################################################
def browser_post_chitan(request):

    ###########################################################################
    ### 関数内関数：EXCELセルデータ必須チェック処理
    ###########################################################################
    def check_require():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal require_warn
            nonlocal require_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ必須チェック処理（0000）
            ### (1)セル[8:2]からセル[8:21]について、必須項目に値がセットされていることをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)CHITANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### ※max_rowの8は入力部分の開始EXCEL行番号である。
            ### ※max_rowの8はNO.、水系・沿岸名等のキャプション部分の1つ下のEXCEL行番号である。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan.check_require()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 8:
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=1).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=0, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 1, constants.CHI_REQ_MSG[0][0], constants.CHI_REQ_MSG[0][1], constants.CHI_REQ_MSG[0][2], constants.CHI_REQ_MSG[0][3], constants.CHI_REQ_MSG[0][4]])
                    else:
                        require_info.append([ws[0].title, j, 1, 0])
                        
                    ### セル[8:2]: 水系・沿岸名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=2).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 2, constants.CHI_REQ_MSG[1][0], constants.CHI_REQ_MSG[1][1], constants.CHI_REQ_MSG[1][2], constants.CHI_REQ_MSG[1][3], constants.CHI_REQ_MSG[1][4]])
                    else:
                        require_info.append([ws[0].title, j, 2, 1])
                        
                    ### セル[8:3]: 水系種別[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=3).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 3, constants.CHI_REQ_MSG[2][0], constants.CHI_REQ_MSG[2][1], constants.CHI_REQ_MSG[2][2], constants.CHI_REQ_MSG[2][3], constants.CHI_REQ_MSG[2][4]])
                    else:
                        require_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[8:4]: 河川・海岸名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=4).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 4, constants.CHI_REQ_MSG[3][0], constants.CHI_REQ_MSG[3][1], constants.CHI_REQ_MSG[3][2], constants.CHI_REQ_MSG[3][3], constants.CHI_REQ_MSG[3][4]])
                    else:
                        require_info.append([ws[i].title, j, 4, 3])
                        
                    ### セル[8:5]: 河川種別[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=5).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 5, constants.CHI_REQ_MSG[4][0], constants.CHI_REQ_MSG[4][1], constants.CHI_REQ_MSG[4][2], constants.CHI_REQ_MSG[4][3], constants.CHI_REQ_MSG[4][4]])
                    else:
                        require_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[8:6]: 代表被災地区名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=6).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 6, constants.CHI_REQ_MSG[5][0], constants.CHI_REQ_MSG[5][1], constants.CHI_REQ_MSG[5][2], constants.CHI_REQ_MSG[5][3], constants.CHI_REQ_MSG[5][4]])
                    else:
                        require_info.append([ws[0].title, j, 6, 5])
                    
                    ### セル[8:7]: 都道府県名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=7).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 7, constants.CHI_REQ_MSG[6][0], constants.CHI_REQ_MSG[6][1], constants.CHI_REQ_MSG[6][2], constants.CHI_REQ_MSG[6][3], constants.CHI_REQ_MSG[6][4]])
                    else:
                        require_info.append([ws[0].title, j, 7, 6])
                    
                    ### セル[8:8]: 市区町村名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=8).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 8, constants.CHI_REQ_MSG[7][0], constants.CHI_REQ_MSG[7][1], constants.CHI_REQ_MSG[7][2], constants.CHI_REQ_MSG[7][3], constants.CHI_REQ_MSG[7][4]])
                    else:
                        require_info.append([ws[0].title, j, 8, 7])
                    
                    ### セル[8:9]: 都道府県コードに値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=9).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 9, constants.CHI_REQ_MSG[8][0], constants.CHI_REQ_MSG[8][1], constants.CHI_REQ_MSG[8][2], constants.CHI_REQ_MSG[8][3], constants.CHI_REQ_MSG[8][4]])
                    else:
                        require_info.append([ws[0].title, j, 9, 8])
                    
                    ### セル[8:10]: 
                    ### セル[8:11]: 異常気象コードに値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=11).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 11, constants.CHI_REQ_MSG[10][0], constants.CHI_REQ_MSG[10][1], constants.CHI_REQ_MSG[10][2], constants.CHI_REQ_MSG[10][3], constants.CHI_REQ_MSG[10][4]])
                    else:
                        require_info.append([ws[0].title, j, 11, 10])
                    
                    ### セル[8:12]: 水害発生月に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=12).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=11, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 12, constants.CHI_REQ_MSG[11][0], constants.CHI_REQ_MSG[11][1], constants.CHI_REQ_MSG[11][2], constants.CHI_REQ_MSG[11][3], constants.CHI_REQ_MSG[11][4]])
                    else:
                        require_info.append([ws[0].title, j, 12, 11])
                    
                    ### セル[8:13]: 水害発生日に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=13).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 13, constants.CHI_REQ_MSG[12][0], constants.CHI_REQ_MSG[12][1], constants.CHI_REQ_MSG[12][2], constants.CHI_REQ_MSG[12][3], constants.CHI_REQ_MSG[12][4]])
                    else:
                        require_info.append([ws[0].title, j, 13, 12])
                    
                    ### セル[8:14]: 水害発生月に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=14).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=13, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 14, constants.CHI_REQ_MSG[13][0], constants.CHI_REQ_MSG[13][1], constants.CHI_REQ_MSG[13][2], constants.CHI_REQ_MSG[13][3], constants.CHI_REQ_MSG[13][4]])
                    else:
                        require_info.append([ws[0].title, j, 14, 13])
                    
                    ### セル[8:15]: 水害発生日に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=15).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 15, constants.CHI_REQ_MSG[14][0], constants.CHI_REQ_MSG[14][1], constants.CHI_REQ_MSG[14][2], constants.CHI_REQ_MSG[14][3], constants.CHI_REQ_MSG[14][4]])
                    else:
                        require_info.append([ws[0].title, j, 15, 14])
                    
                    ### セル[8:16]: 工種区分に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=16).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 16, constants.CHI_REQ_MSG[15][0], constants.CHI_REQ_MSG[15][1], constants.CHI_REQ_MSG[15][2], constants.CHI_REQ_MSG[15][3], constants.CHI_REQ_MSG[15][4]])
                    else:
                        require_info.append([ws[0].title, j, 16, 15])
                    
                    ### セル[8:17]: 
                    ### セル[8:18]: 市区町村コードに値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=18).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 18, constants.CHI_REQ_MSG[17][0], constants.CHI_REQ_MSG[17][1], constants.CHI_REQ_MSG[17][2], constants.CHI_REQ_MSG[17][3], constants.CHI_REQ_MSG[17][4]])
                    else:
                        require_info.append([ws[0].title, j, 18, 17])
                    
                    ### セル[8:19]: 災害復旧箇所に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=19).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=18, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 19, constants.CHI_REQ_MSG[18][0], constants.CHI_REQ_MSG[18][1], constants.CHI_REQ_MSG[18][2], constants.CHI_REQ_MSG[18][3], constants.CHI_REQ_MSG[18][4]])
                    else:
                        require_info.append([ws[0].title, j, 19, 18])
                    
                    ### セル[8:20]: 災害復旧査定額千円に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=20).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=19, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 20, constants.CHI_REQ_MSG[19][0], constants.CHI_REQ_MSG[19][1], constants.CHI_REQ_MSG[19][2], constants.CHI_REQ_MSG[19][3], constants.CHI_REQ_MSG[19][4]])
                    else:
                        require_info.append([ws[0].title, j, 20, 19])
                    
                    ### セル[8:21]: 備考に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=21).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=20, message=constants.CHI_REQ_MSG)
                        require_warn.append([ws[0].title, j, 21, constants.CHI_REQ_MSG[20][0], constants.CHI_REQ_MSG[20][1], constants.CHI_REQ_MSG[20][2], constants.CHI_REQ_MSG[20][3], constants.CHI_REQ_MSG[20][4]])
                    else:
                        require_info.append([ws[0].title, j, 21, 20])
            return True
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ形式チェック処理
    ###########################################################################
    def check_format():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal format_warn
            nonlocal format_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ形式チェック処理（0000）
            ### (1)セル[8:2]からセル[8:21]について形式が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)CHITANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 形式チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ### ※max_rowの8は入力部分の開始EXCEL行番号である。
            ### ※max_rowの8はNO.、水系・沿岸名等のキャプション部分の1つ下のEXCEL行番号である。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan.check_format()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 8:
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=1).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=1).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=100)
                            ### format_warn.append([ws[0].title, j, 1, constants.CHI_FOR_MSG[100][0], constants.CHI_FOR_MSG[100][1], constants.CHI_FOR_MSG[100][2], constants.CHI_FOR_MSG[100][3], constants.CHI_FOR_MSG[100][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=0, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 1, constants.CHI_FOR_MSG[0][0], constants.CHI_FOR_MSG[0][1], constants.CHI_FOR_MSG[0][2], constants.CHI_FOR_MSG[0][3], constants.CHI_FOR_MSG[0][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 1, 100])
                            format_info.append([ws[0].title, j, 1, 100])
    
                    ### セル[8:2]: 水系・沿岸名[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=2).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=2).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=101)
                            ### format_warn.append([ws[0].title, j, 2, constants.CHI_FOR_MSG[101][0], constants.CHI_FOR_MSG[101][1], constants.CHI_FOR_MSG[101][2], constants.CHI_FOR_MSG[101][3], constants.CHI_FOR_MSG[101][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 2, constants.CHI_FOR_MSG[1][0], constants.CHI_FOR_MSG[1][1], constants.CHI_FOR_MSG[1][2], constants.CHI_FOR_MSG[1][3], constants.CHI_FOR_MSG[1][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 2, 101])
                            format_info.append([ws[0].title, j, 2, 1])
                        
                    ### セル[8:3]: 水系種別[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=3).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=3).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=102)
                            ### format_warn.append([ws[0].title, j, 3, constants.CHI_FOR_MSG[102][0], constants.CHI_FOR_MSG[102][1], constants.CHI_FOR_MSG[102][2], constants.CHI_FOR_MSG[102][3], constants.CHI_FOR_MSG[102][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 3, constants.CHI_FOR_MSG[2][0], constants.CHI_FOR_MSG[2][1], constants.CHI_FOR_MSG[2][2], constants.CHI_FOR_MSG[2][3], constants.CHI_FOR_MSG[2][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 3, 102])
                            format_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[8:4]: 河川・海岸名[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=4).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=4).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=103)
                            ### format_warn.append([ws[0].title, j, 4, constants.CHI_FOR_MSG[103][0], constants.CHI_FOR_MSG[103][1], constants.CHI_FOR_MSG[103][2], constants.CHI_FOR_MSG[103][3], constants.CHI_FOR_MSG[103][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 4, constants.CHI_FOR_MSG[3][0], constants.CHI_FOR_MSG[3][1], constants.CHI_FOR_MSG[3][2], constants.CHI_FOR_MSG[3][3], constants.CHI_FOR_MSG[3][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 4, 103])
                            format_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[8:5]: 河川種別[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=5).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=5).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=104)
                            ### format_warn.append([ws[0].title, j, 5, constants.CHI_FOR_MSG[104][0], constants.CHI_FOR_MSG[104][1], constants.CHI_FOR_MSG[104][2], constants.CHI_FOR_MSG[104][3], constants.CHI_FOR_MSG[104][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 5, constants.CHI_FOR_MSG[4][0], constants.CHI_FOR_MSG[4][1], constants.CHI_FOR_MSG[4][2], constants.CHI_FOR_MSG[4][3], constants.CHI_FOR_MSG[4][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 5, 104])
                            format_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[8:6]: 代表被災地区名[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=6).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=6).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=6).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=105)
                            ### format_warn.append([ws[0].title, j, 6, constants.CHI_FOR_MSG[105][0], constants.CHI_FOR_MSG[105][1], constants.CHI_FOR_MSG[105][2], constants.CHI_FOR_MSG[105][3], constants.CHI_FOR_MSG[105][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 6, constants.CHI_FOR_MSG[5][0], constants.CHI_FOR_MSG[5][1], constants.CHI_FOR_MSG[5][2], constants.CHI_FOR_MSG[5][3], constants.CHI_FOR_MSG[5][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 6, 105])
                            format_info.append([ws[0].title, j, 6, 5])
                        
                    ### セル[8:7]: 都道府県名[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=7).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=7).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=7).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=106)
                            ### format_warn.append([ws[0].title, j, 7, constants.CHI_FOR_MSG[106][0], constants.CHI_FOR_MSG[106][1], constants.CHI_FOR_MSG[106][2], constants.CHI_FOR_MSG[106][3], constants.CHI_FOR_MSG[106][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 7, constants.CHI_FOR_MSG[6][0], constants.CHI_FOR_MSG[6][1], constants.CHI_FOR_MSG[6][2], constants.CHI_FOR_MSG[6][3], constants.CHI_FOR_MSG[6][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 7, 106])
                            format_info.append([ws[0].title, j, 7, 6])
                        
                    ### セル[8:8]: 市区町村名[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=8).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=8).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=8).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=107)
                            ### format_warn.append([ws[0].title, j, 8, constants.CHI_FOR_MSG[107][0], constants.CHI_FOR_MSG[107][1], constants.CHI_FOR_MSG[107][2], constants.CHI_FOR_MSG[107][3], constants.CHI_FOR_MSG[107][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 8, constants.CHI_FOR_MSG[7][0], constants.CHI_FOR_MSG[7][1], constants.CHI_FOR_MSG[7][2], constants.CHI_FOR_MSG[7][3], constants.CHI_FOR_MSG[7][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 8, 107])
                            format_info.append([ws[0].title, j, 8, 7])
                        
                    ### セル[8:9]: 都道府県コードについて形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=9).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=9).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=9).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=108)
                            ### format_warn.append([ws[0].title, j, 9, constants.CHI_FOR_MSG[108][0], constants.CHI_FOR_MSG[108][1], constants.CHI_FOR_MSG[108][2], constants.CHI_FOR_MSG[108][3], constants.CHI_FOR_MSG[108][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 9, constants.CHI_FOR_MSG[8][0], constants.CHI_FOR_MSG[8][1], constants.CHI_FOR_MSG[8][2], constants.CHI_FOR_MSG[8][3], constants.CHI_FOR_MSG[8][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 9, 108])
                            format_info.append([ws[0].title, j, 9, 8])
                        
                    ### セル[8:10]: 
                    ### セル[8:11]: 異常気象コードについて形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=11).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=11).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=11).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=110)
                            ### format_warn.append([ws[0].title, j, 11, constants.CHI_FOR_MSG[110][0], constants.CHI_FOR_MSG[110][1], constants.CHI_FOR_MSG[110][2], constants.CHI_FOR_MSG[110][3], constants.CHI_FOR_MSG[110][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 11, constants.CHI_FOR_MSG[10][0], constants.CHI_FOR_MSG[10][1], constants.CHI_FOR_MSG[10][2], constants.CHI_FOR_MSG[10][3], constants.CHI_FOR_MSG[10][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 11, 110])
                            format_info.append([ws[0].title, j, 11, 10])
                        
                    ### セル[8:12]: 水害発生月について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=12).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=12).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=12).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=111)
                            ### format_warn.append([ws[0].title, j, 12, constants.CHI_FOR_MSG[111][0], constants.CHI_FOR_MSG[111][1], constants.CHI_FOR_MSG[111][2], constants.CHI_FOR_MSG[111][3], constants.CHI_FOR_MSG[111][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=11, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 12, constants.CHI_FOR_MSG[11][0], constants.CHI_FOR_MSG[11][1], constants.CHI_FOR_MSG[11][2], constants.CHI_FOR_MSG[11][3], constants.CHI_FOR_MSG[11][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 12, 111])
                            format_info.append([ws[0].title, j, 12, 11])
                        
                    ### セル[8:13]: 水害発生日について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=13).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=13).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=13).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=112)
                            ### format_warn.append([ws[0].title, j, 13, constants.CHI_FOR_MSG[112][0], constants.CHI_FOR_MSG[112][1], constants.CHI_FOR_MSG[112][2], constants.CHI_FOR_MSG[112][3], constants.CHI_FOR_MSG[112][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 13, constants.CHI_FOR_MSG[12][0], constants.CHI_FOR_MSG[12][1], constants.CHI_FOR_MSG[12][2], constants.CHI_FOR_MSG[12][3], constants.CHI_FOR_MSG[12][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 13, 112])
                            format_info.append([ws[0].title, j, 13, 12])
                        
                    ### セル[8:14]: 水害発生月について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=14).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=14).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=14).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=113)
                            ### format_warn.append([ws[0].title, j, 14, constants.CHI_FOR_MSG[113][0], constants.CHI_FOR_MSG[113][1], constants.CHI_FOR_MSG[113][2], constants.CHI_FOR_MSG[113][3], constants.CHI_FOR_MSG[113][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 14, constants.CHI_FOR_MSG[13][0], constants.CHI_FOR_MSG[13][1], constants.CHI_FOR_MSG[13][2], constants.CHI_FOR_MSG[13][3], constants.CHI_FOR_MSG[13][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 14, 113])
                            format_info.append([ws[0].title, j, 14, 13])
                        
                    ### セル[8:15]: 水害発生日について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=15).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=15).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=15).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=114)
                            ### format_warn.append([ws[0].title, j, 15, constants.CHI_FOR_MSG[114][0], constants.CHI_FOR_MSG[114][1], constants.CHI_FOR_MSG[114][2], constants.CHI_FOR_MSG[114][3], constants.CHI_FOR_MSG[114][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 15, constants.CHI_FOR_MSG[14][0], constants.CHI_FOR_MSG[14][1], constants.CHI_FOR_MSG[14][2], constants.CHI_FOR_MSG[14][3], constants.CHI_FOR_MSG[14][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 15, 114])
                            format_info.append([ws[0].title, j, 15, 14])
                        
                    ### セル[8:16]: 工種区分について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=16).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=16).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=16).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=115)
                            ### format_warn.append([ws[0].title, j, 16, constants.CHI_FOR_MSG[115][0], constants.CHI_FOR_MSG[115][1], constants.CHI_FOR_MSG[115][2], constants.CHI_FOR_MSG[115][3], constants.CHI_FOR_MSG[115][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 16, constants.CHI_FOR_MSG[15][0], constants.CHI_FOR_MSG[15][1], constants.CHI_FOR_MSG[15][2], constants.CHI_FOR_MSG[15][3], constants.CHI_FOR_MSG[15][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 16, 115])
                            format_info.append([ws[0].title, j, 16, 15])
                        
                    ### セル[8:17]: 
                    ### セル[8:18]: 市区町村コードについて形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=18).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=18).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=18).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=117)
                            ### format_warn.append([ws[0].title, j, 18, constants.CHI_FOR_MSG[117][0], constants.CHI_FOR_MSG[117][1], constants.CHI_FOR_MSG[117][2], constants.CHI_FOR_MSG[117][3], constants.CHI_FOR_MSG[117][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 18, constants.CHI_FOR_MSG[17][0], constants.CHI_FOR_MSG[17][1], constants.CHI_FOR_MSG[17][2], constants.CHI_FOR_MSG[17][3], constants.CHI_FOR_MSG[17][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 18, 117])
                            format_info.append([ws[0].title, j, 18, 17])
                        
                    ### セル[8:19]: 災害復旧箇所について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=19).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=19).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=19).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=118)
                            ### format_warn.append([ws[0].title, j, 19, constants.CHI_FOR_MSG[118][0], constants.CHI_FOR_MSG[118][1], constants.CHI_FOR_MSG[118][2], constants.CHI_FOR_MSG[118][3], constants.CHI_FOR_MSG[118][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=18, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 19, constants.CHI_FOR_MSG[18][0], constants.CHI_FOR_MSG[18][1], constants.CHI_FOR_MSG[18][2], constants.CHI_FOR_MSG[18][3], constants.CHI_FOR_MSG[18][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 19, 118])
                            format_info.append([ws[0].title, j, 19, 18])
                        
                    ### セル[8:20]: 災害復旧査定額千円について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=20).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=20).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=20).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=119)
                            ### format_warn.append([ws[0].title, j, 20, constants.CHI_FOR_MSG[119][0], constants.CHI_FOR_MSG[119][1], constants.CHI_FOR_MSG[119][2], constants.CHI_FOR_MSG[119][3], constants.CHI_FOR_MSG[119][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=19, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 20, constants.CHI_FOR_MSG[19][0], constants.CHI_FOR_MSG[19][1], constants.CHI_FOR_MSG[19][2], constants.CHI_FOR_MSG[19][3], constants.CHI_FOR_MSG[19][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 20, 119])
                            format_info.append([ws[0].title, j, 20, 19])
                        
                    ### セル[8:21]: 備考について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=21).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=21).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=21).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=120)
                            ### format_warn.append([ws[0].title, j, 21, constants.CHI_FOR_MSG[120][0], constants.CHI_FOR_MSG[120][1], constants.CHI_FOR_MSG[120][2], constants.CHI_FOR_MSG[120][3], constants.CHI_FOR_MSG[120][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=20, message=constants.CHI_FOR_MSG)
                            format_warn.append([ws[0].title, j, 21, constants.CHI_FOR_MSG[20][0], constants.CHI_FOR_MSG[20][1], constants.CHI_FOR_MSG[20][2], constants.CHI_FOR_MSG[20][3], constants.CHI_FOR_MSG[20][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 21, 120])
                            format_info.append([ws[0].title, j, 21, 20])
            return True
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ範囲チェック処理
    ###########################################################################
    def check_range():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal range_warn
            nonlocal range_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ範囲チェック処理（0000）
            ### (1)セル[8:2]からセル[8:21]について範囲が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)CHITANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 範囲チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ### 範囲チェックでは、形式が正しい場合のみチェックを行う。
            ### 形式チェックは別途形式チェックで行うためである。
            ### 例えば、面積などの数値について、float()で例外とならないように、int、floatの場合のみチェックする。
            ### 範囲チェックでは、数値の下限と上限のチェックを行う。
            ### 範囲チェックでは、DBとの突合チェックに該当するチェックは行わない。
            ### DBとの突合チェックは別途突合チェックで行うためである。
            ### 範囲チェックの例は値が正であることである。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan.check_range()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 8:
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.について範囲が正しいことをチェックする。
                    ### セル[8:2]: 水系・沿岸名[全角]について範囲が正しいことをチェックする。
                    ### セル[8:3]: 水系種別[全角]について範囲が正しいことをチェックする。
                    ### セル[8:4]: 河川・海岸名[全角]について範囲が正しいことをチェックする。
                    ### セル[8:5]: 河川種別[全角]について範囲が正しいことをチェックする。
                    ### セル[8:6]: 代表被災地区名[全角]について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=6).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=6).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=6).value, float) == True:
                            if float(ws[0].cell(row=j, column=6).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=205)
                                ### range_warn.append([ws[0].title, j, 6, constants.CHI_RAN_MSG[205][0], constants.CHI_RAN_MSG[205][1], constants.CHI_RAN_MSG[205][2], constants.CHI_RAN_MSG[205][3], constants.CHI_RAN_MSG[205][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 6, constants.CHI_RAN_MSG[5][0], constants.CHI_RAN_MSG[5][1], constants.CHI_RAN_MSG[5][2], constants.CHI_RAN_MSG[5][3], constants.CHI_RAN_MSG[5][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 6, 205])
                                range_info.append([ws[0].title, j, 6, 5])
    
                    ### セル[8:7]: 都道府県名[全角]について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=7).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=7).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=7).value, float) == True:
                            if float(ws[0].cell(row=j, column=7).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=206)
                                ### range_warn.append([ws[0].title, j, 7, constants.CHI_RAN_MSG[206][0], constants.CHI_RAN_MSG[206][1], constants.CHI_RAN_MSG[206][2], constants.CHI_RAN_MSG[206][3], constants.CHI_RAN_MSG[206][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 7, constants.CHI_RAN_MSG[6][0], constants.CHI_RAN_MSG[6][1], constants.CHI_RAN_MSG[6][2], constants.CHI_RAN_MSG[6][3], constants.CHI_RAN_MSG[6][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 7, 206])
                                range_info.append([ws[0].title, j, 7, 6])
                    
                    ### セル[8:8]: 市区町村名[全角]について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=8).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=8).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=8).value, float) == True:
                            if float(ws[0].cell(row=j, column=8).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=207)
                                ### range_warn.append([ws[0].title, j, 8, constants.CHI_RAN_MSG[207][0], constants.CHI_RAN_MSG[207][1], constants.CHI_RAN_MSG[207][2], constants.CHI_RAN_MSG[207][3], constants.CHI_RAN_MSG[207][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 8, constants.CHI_RAN_MSG[7][0], constants.CHI_RAN_MSG[7][1], constants.CHI_RAN_MSG[7][2], constants.CHI_RAN_MSG[7][3], constants.CHI_RAN_MSG[7][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 8, 207])
                                range_info.append([ws[0].title, j, 8, 7])
    
                    ### セル[8:9]: 都道府県コードについて範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=9).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=9).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=9).value, float) == True:
                            if float(ws[0].cell(row=j, column=9).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=208)
                                ### range_warn.append([ws[0].title, j, 9, constants.CHI_RAN_MSG[208][0], constants.CHI_RAN_MSG[208][1], constants.CHI_RAN_MSG[208][2], constants.CHI_RAN_MSG[208][3], constants.CHI_RAN_MSG[208][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 9, constants.CHI_RAN_MSG[8][0], constants.CHI_RAN_MSG[8][1], constants.CHI_RAN_MSG[8][2], constants.CHI_RAN_MSG[8][3], constants.CHI_RAN_MSG[8][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 9, 208])
                                range_info.append([ws[0].title, j, 9, 8])
    
                    ### セル[8:10]: 
                    ### セル[8:11]: 異常気象コードについて範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=11).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=11).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=11).value, float) == True:
                            if float(ws[0].cell(row=j, column=11).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=210)
                                ### range_warn.append([ws[0].title, j, 11, constants.CHI_RAN_MSG[210][0], constants.CHI_RAN_MSG[210][1], constants.CHI_RAN_MSG[210][2], constants.CHI_RAN_MSG[210][3], constants.CHI_RAN_MSG[210][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 11, constants.CHI_RAN_MSG[10][0], constants.CHI_RAN_MSG[10][1], constants.CHI_RAN_MSG[10][2], constants.CHI_RAN_MSG[10][3], constants.CHI_RAN_MSG[10][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 11, 210])
                                range_info.append([ws[0].title, j, 11, 10])
    
                    ### セル[8:12]: 水害発生月について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=12).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=12).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=12).value, float) == True:
                            if float(ws[0].cell(row=j, column=12).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=211)
                                ### range_warn.append([ws[0].title, j, 12, constants.CHI_RAN_MSG[211][0], constants.CHI_RAN_MSG[211][1], constants.CHI_RAN_MSG[211][2], constants.CHI_RAN_MSG[211][3], constants.CHI_RAN_MSG[211][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=11, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 12, constants.CHI_RAN_MSG[11][0], constants.CHI_RAN_MSG[11][1], constants.CHI_RAN_MSG[11][2], constants.CHI_RAN_MSG[11][3], constants.CHI_RAN_MSG[11][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 12, 211])
                                range_info.append([ws[0].title, j, 12, 11])
    
                    ### セル[8:13]: 水害発生日について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=13).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=13).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=13).value, float) == True:
                            if float(ws[0].cell(row=j, column=13).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=212)
                                ### range_warn.append([ws[0].title, j, 13, constants.CHI_RAN_MSG[212][0], constants.CHI_RAN_MSG[212][1], constants.CHI_RAN_MSG[212][2], constants.CHI_RAN_MSG[212][3], constants.CHI_RAN_MSG[212][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 13, constants.CHI_RAN_MSG[12][0], constants.CHI_RAN_MSG[12][1], constants.CHI_RAN_MSG[12][2], constants.CHI_RAN_MSG[12][3], constants.CHI_RAN_MSG[12][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 13, 212])
                                range_info.append([ws[0].title, j, 13, 12])
                    
                    ### セル[8:14]: 水害発生月について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=14).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=14).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=14).value, float) == True:
                            if float(ws[0].cell(row=j, column=14).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=213)
                                ### range_warn.append([ws[0].title, j, 14, constants.CHI_RAN_MSG[213][0], constants.CHI_RAN_MSG[213][1], constants.CHI_RAN_MSG[213][2], constants.CHI_RAN_MSG[213][3], constants.CHI_RAN_MSG[213][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 14, constants.CHI_RAN_MSG[13][0], constants.CHI_RAN_MSG[13][1], constants.CHI_RAN_MSG[13][2], constants.CHI_RAN_MSG[13][3], constants.CHI_RAN_MSG[13][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 14, 213])
                                range_info.append([ws[0].title, j, 14, 13])
    
                    ### セル[8:15]: 水害発生日について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=15).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=15).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=15).value, float) == True:
                            if float(ws[0].cell(row=j, column=15).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=214)
                                ### range_warn.append([ws[0].title, j, 15, constants.CHI_RAN_MSG[214][0], constants.CHI_RAN_MSG[214][1], constants.CHI_RAN_MSG[214][2], constants.CHI_RAN_MSG[214][3], constants.CHI_RAN_MSG[214][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 15, constants.CHI_RAN_MSG[14][0], constants.CHI_RAN_MSG[14][1], constants.CHI_RAN_MSG[14][2], constants.CHI_RAN_MSG[14][3], constants.CHI_RAN_MSG[14][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 15, 214])
                                range_info.append([ws[0].title, j, 15, 14])
    
                    ### セル[8:16]: 工種区分について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=16).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=16).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=16).value, float) == True:
                            if float(ws[0].cell(row=j, column=16).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=215)
                                ### range_warn.append([ws[0].title, j, 16, constants.CHI_RAN_MSG[215][0], constants.CHI_RAN_MSG[215][1], constants.CHI_RAN_MSG[215][2], constants.CHI_RAN_MSG[215][3], constants.CHI_RAN_MSG[215][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 16, constants.CHI_RAN_MSG[15][0], constants.CHI_RAN_MSG[15][1], constants.CHI_RAN_MSG[15][2], constants.CHI_RAN_MSG[15][3], constants.CHI_RAN_MSG[15][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 16, 215])
                                range_info.append([ws[0].title, j, 16, 15])
    
                    ### セル[8:17]: 
                    ### セル[8:18]: 市区町村コードについて範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=18).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=18).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=18).value, float) == True:
                            if float(ws[0].cell(row=j, column=18).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=217)
                                ### range_warn.append([ws[0].title, j, 18, constants.CHI_RAN_MSG[217][0], constants.CHI_RAN_MSG[217][1], constants.CHI_RAN_MSG[217][2], constants.CHI_RAN_MSG[217][3], constants.CHI_RAN_MSG[217][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 18, constants.CHI_RAN_MSG[17][0], constants.CHI_RAN_MSG[17][1], constants.CHI_RAN_MSG[17][2], constants.CHI_RAN_MSG[17][3], constants.CHI_RAN_MSG[17][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 18, 217])
                                range_info.append([ws[0].title, j, 18, 17])
    
                    ### セル[8:19]: 災害復旧箇所について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=19).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=19).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=19).value, float) == True:
                            if float(ws[0].cell(row=j, column=19).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=218)
                                ### range_warn.append([ws[0].title, j, 19, constants.CHI_RAN_MSG[218][0], constants.CHI_RAN_MSG[218][1], constants.CHI_RAN_MSG[218][2], constants.CHI_RAN_MSG[218][3], constants.CHI_RAN_MSG[218][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=18, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 19, constants.CHI_RAN_MSG[18][0], constants.CHI_RAN_MSG[18][1], constants.CHI_RAN_MSG[18][2], constants.CHI_RAN_MSG[18][3], constants.CHI_RAN_MSG[18][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 19, 218])
                                range_info.append([ws[0].title, j, 19, 18])
    
                    ### セル[8:20]: 災害復旧査定額千円について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=20).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=20).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=20).value, float) == True:
                            if float(ws[0].cell(row=j, column=20).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=219)
                                ### range_warn.append([ws[0].title, j, 20, constants.CHI_RAN_MSG[219][0], constants.CHI_RAN_MSG[219][1], constants.CHI_RAN_MSG[219][2], constants.CHI_RAN_MSG[219][3], constants.CHI_RAN_MSG[219][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=19, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 20, constants.CHI_RAN_MSG[19][0], constants.CHI_RAN_MSG[19][1], constants.CHI_RAN_MSG[19][2], constants.CHI_RAN_MSG[19][3], constants.CHI_RAN_MSG[19][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 20, 219])
                                range_info.append([ws[0].title, j, 20, 19])
    
                    ### セル[8:21]: 備考について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=21).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=21).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=21).value, float) == True:
                            if float(ws[0].cell(row=j, column=21).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=220)
                                ### range_warn.append([ws[0].title, j, 21, constants.CHI_RAN_MSG[220][0], constants.CHI_RAN_MSG[220][1], constants.CHI_RAN_MSG[220][2], constants.CHI_RAN_MSG[220][3], constants.CHI_RAN_MSG[220][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=20, message=constants.CHI_RAN_MSG)
                                range_warn.append([ws[0].title, j, 21, constants.CHI_RAN_MSG[20][0], constants.CHI_RAN_MSG[20][1], constants.CHI_RAN_MSG[20][2], constants.CHI_RAN_MSG[20][3], constants.CHI_RAN_MSG[20][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 21, 220])
                                range_info.append([ws[0].title, j, 21, 20])
            return True
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ相関チェック処理
    ###########################################################################
    def check_correlate():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal correlate_warn
            nonlocal correlate_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ相関チェック処理（0000）
            ### (1)セル[8,2]からセル[8,21]について他項目との相関関係が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)CHITANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan.check_correlate()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 8:
                for j in range(8, max_row[0]+1):
                    pass
                    ### セル[8:1]: NO.が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:2]: 水系・沿岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:3]: 水系種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:4]: 河川・海岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:5]: 河川種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:6]: 代表被災地区名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:7]: 都道府県名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:8]: 市区町村名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:9]: 都道府県コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:10]
                    ### セル[8:11]: 異常気象コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:12]: 水害発生月が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:13]: 水害発生日が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:14]: 水害発生月が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:15]: 水害発生日が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:16]: 工種区分が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:17]
                    ### セル[8:18]: 市区町村コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:19]: 災害復旧箇所が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:20]: 災害復旧査定額千円が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:21]: 備考が何かの値のときに、相関する他項目は正しく選択されているか。
            return True
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ突合チェック処理
    ###########################################################################
    def check_compare():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal compare_warn
            nonlocal compare_info
            ### nonlocal max_row
            ### nonlocal ken_code_list
            ### nonlocal ken_name_list
            ### nonlocal ken_name_code_list
            ### nonlocal city_code_list
            ### nonlocal city_name_list
            ### nonlocal city_name_code_list
            ### nonlocal suikei_code_list
            ### nonlocal suikei_name_list
            ### nonlocal suikei_name_code_list
            ### nonlocal suikei_type_code_list
            ### nonlocal suikei_type_name_list
            ### nonlocal suikei_type_name_code_list
            ### nonlocal kasen_code_list
            ### nonlocal kasen_name_list
            ### nonlocal kasen_name_code_list
            ### nonlocal kasen_type_code_list
            ### nonlocal kasen_type_name_list
            ### nonlocal kasen_type_name_code_list
            ### nonlocal kasen_kaigan_code_list
            ### nonlocal kasen_kaigan_name_list
            ### nonlocal kasen_kaigan_name_code_list
            ### nonlocal weather_id_list
            ### nonlocal weather_name_list
            ### nonlocal weather_name_id_list
            ### nonlocal business_code_list
            ### nonlocal business_name_list
            ### nonlocal business_name_code_list
            ###################################################################
            ### 関数内関数：EXCELセルデータ突合チェック処理（0000）
            ### (1)セル[8,2]からセル[8,21]についてデータベースに登録されている値と突合せチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)CHITANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan.check_compare()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 8:
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:2]: 水系・沿岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=2).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=2).value not in list(building_code_list) and \
                            ws[0].cell(row=j, column=2).value not in list(building_name_list) and \
                            ws[0].cell(row=j, column=2).value not in list(building_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=401)
                            ### compare_warn.append([ws[0].title, j, 2, constants.CHI_COM_MSG[401][0], constants.CHI_COM_MSG[401][1], constants.CHI_COM_MSG[401][2], constants.CHI_COM_MSG[401][3], constants.CHI_COM_MSG[401][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 2, constants.CHI_COM_MSG[1][0], constants.CHI_COM_MSG[1][1], constants.CHI_COM_MSG[1][2], constants.CHI_COM_MSG[1][3], constants.CHI_COM_MSG[1][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 2, 401])
                            compare_info.append([ws[0].title, j, 2, 1])
                    
                    ### セル[8:3]: 水系種別[全角]についてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=3).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=3).value not in list(building_code_list) and \
                            ws[0].cell(row=j, column=3).value not in list(building_name_list) and \
                            ws[0].cell(row=j, column=3).value not in list(building_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=402)
                            ### compare_warn.append([ws[0].title, j, 3, constants.CHI_COM_MSG[402][0], constants.CHI_COM_MSG[402][1], constants.CHI_COM_MSG[402][2], constants.CHI_COM_MSG[402][3], constants.CHI_COM_MSG[402][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 3, constants.CHI_COM_MSG[2][0], constants.CHI_COM_MSG[2][1], constants.CHI_COM_MSG[2][2], constants.CHI_COM_MSG[2][3], constants.CHI_COM_MSG[2][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 3, 402])
                            compare_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[8:4]: 河川・海岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=4).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=4).value not in list(underground_code_list) and \
                            ws[0].cell(row=j, column=4).value not in list(underground_name_list) and \
                            ws[0].cell(row=j, column=4).value not in list(underground_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=403)
                            ### compare_warn.append([ws[0].title, j, 4, constants.CHI_COM_MSG[403][0], constants.CHI_COM_MSG[403][1], constants.CHI_COM_MSG[403][2], constants.CHI_COM_MSG[403][3], constants.CHI_COM_MSG[403][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 4, constants.CHI_COM_MSG[3][0], constants.CHI_COM_MSG[3][1], constants.CHI_COM_MSG[3][2], constants.CHI_COM_MSG[3][3], constants.CHI_COM_MSG[3][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 4, 403])
                            compare_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[8:5]: 河川種別[全角]についてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=5).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=5).value not in list(flood_sediment_code_list) and \
                            ws[0].cell(row=j, column=5).value not in list(flood_sediment_name_list) and \
                            ws[0].cell(row=j, column=5).value not in list(flood_sediment_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=404)
                            ### compare_warn.append([ws[0].title, j, 5, constants.CHI_COM_MSG[404][0], constants.CHI_COM_MSG[404][1], constants.CHI_COM_MSG[404][2], constants.CHI_COM_MSG[404][3], constants.CHI_COM_MSG[404][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 5, constants.CHI_COM_MSG[4][0], constants.CHI_COM_MSG[4][1], constants.CHI_COM_MSG[4][2], constants.CHI_COM_MSG[4][3], constants.CHI_COM_MSG[4][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 5, 404])
                            compare_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[8:6]: 代表被災地区名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:7]: 都道府県名[全角]についてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=7).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=7).value not in list(flood_sediment_code_list) and \
                            ws[0].cell(row=j, column=7).value not in list(flood_sediment_name_list) and \
                            ws[0].cell(row=j, column=7).value not in list(flood_sediment_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=406)
                            ### compare_warn.append([ws[0].title, j, 7, constants.CHI_COM_MSG[406][0], constants.CHI_COM_MSG[406][1], constants.CHI_COM_MSG[406][2], constants.CHI_COM_MSG[406][3], constants.CHI_COM_MSG[406][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 7, constants.CHI_COM_MSG[6][0], constants.CHI_COM_MSG[6][1], constants.CHI_COM_MSG[6][2], constants.CHI_COM_MSG[6][3], constants.CHI_COM_MSG[6][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 7, 406])
                            compare_info.append([ws[0].title, j, 7, 6])
    
                    ### セル[8:8]: 市区町村名[全角]についてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=8).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=8).value not in list(flood_sediment_code_list) and \
                            ws[0].cell(row=j, column=8).value not in list(flood_sediment_name_list) and \
                            ws[0].cell(row=j, column=8).value not in list(flood_sediment_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=407)
                            ### compare_warn.append([ws[0].title, j, 8, constants.CHI_COM_MSG[407][0], constants.CHI_COM_MSG[407][1], constants.CHI_COM_MSG[407][2], constants.CHI_COM_MSG[407][3], constants.CHI_COM_MSG[407][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 8, constants.CHI_COM_MSG[7][0], constants.CHI_COM_MSG[7][1], constants.CHI_COM_MSG[7][2], constants.CHI_COM_MSG[7][3], constants.CHI_COM_MSG[7][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 8, 407])
                            compare_info.append([ws[0].title, j, 8, 7])
    
                    ### セル[8:9]: 都道府県コードについてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=9).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=9).value not in list(flood_sediment_code_list) and \
                            ws[0].cell(row=j, column=9).value not in list(flood_sediment_name_list) and \
                            ws[0].cell(row=j, column=9).value not in list(flood_sediment_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=408)
                            ### compare_warn.append([ws[0].title, j, 9, constants.CHI_COM_MSG[408][0], constants.CHI_COM_MSG[408][1], constants.CHI_COM_MSG[408][2], constants.CHI_COM_MSG[408][3], constants.CHI_COM_MSG[408][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 9, constants.CHI_COM_MSG[8][0], constants.CHI_COM_MSG[8][1], constants.CHI_COM_MSG[8][2], constants.CHI_COM_MSG[8][3], constants.CHI_COM_MSG[8][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 9, 408])
                            compare_info.append([ws[0].title, j, 9, 8])
    
                    ### セル[8:10]:
                    ### セル[8:11]: 異常気象コードについてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=11).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=11).value not in list(flood_sediment_code_list) and \
                            ws[0].cell(row=j, column=11).value not in list(flood_sediment_name_list) and \
                            ws[0].cell(row=j, column=11).value not in list(flood_sediment_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=410)
                            ### compare_warn.append([ws[0].title, j, 11, constants.CHI_COM_MSG[410][0], constants.CHI_COM_MSG[410][1], constants.CHI_COM_MSG[410][2], constants.CHI_COM_MSG[410][3], constants.CHI_COM_MSG[410][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 11, constants.CHI_COM_MSG[10][0], constants.CHI_COM_MSG[10][1], constants.CHI_COM_MSG[10][2], constants.CHI_COM_MSG[10][3], constants.CHI_COM_MSG[10][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 11, 410])
                            compare_info.append([ws[0].title, j, 11, 10])
    
                    ### セル[8:12]: 水害発生月についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:13]: 水害発生日についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:14]: 水害発生月についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:15]: 水害発生日についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:16]: 工種区分についてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=16).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=16).value not in list(flood_sediment_code_list) and \
                            ws[0].cell(row=j, column=16).value not in list(flood_sediment_name_list) and \
                            ws[0].cell(row=j, column=16).value not in list(flood_sediment_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=415)
                            ### compare_warn.append([ws[0].title, j, 16, constants.CHI_COM_MSG[415][0], constants.CHI_COM_MSG[415][1], constants.CHI_COM_MSG[415][2], constants.CHI_COM_MSG[415][3], constants.CHI_COM_MSG[415][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 16, constants.CHI_COM_MSG[15][0], constants.CHI_COM_MSG[15][1], constants.CHI_COM_MSG[15][2], constants.CHI_COM_MSG[15][3], constants.CHI_COM_MSG[15][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 16, 415])
                            compare_info.append([ws[0].title, j, 16, 15])
    
                    ### セル[8:17]:
                    ### セル[8:18]: 市区町村コードについてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=18).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=18).value not in list(flood_sediment_code_list) and \
                            ws[0].cell(row=j, column=18).value not in list(flood_sediment_name_list) and \
                            ws[0].cell(row=j, column=18).value not in list(flood_sediment_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=417)
                            ### compare_warn.append([ws[0].title, j, 18, constants.CHI_COM_MSG[417][0], constants.CHI_COM_MSG[417][1], constants.CHI_COM_MSG[417][2], constants.CHI_COM_MSG[417][3], constants.CHI_COM_MSG[417][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.CHI_COM_MSG)
                            compare_warn.append([ws[0].title, j, 18, constants.CHI_COM_MSG[17][0], constants.CHI_COM_MSG[17][1], constants.CHI_COM_MSG[17][2], constants.CHI_COM_MSG[17][3], constants.CHI_COM_MSG[17][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 18, 417])
                            compare_info.append([ws[0].title, j, 18, 17])
    
                    ### セル[8:19]: 災害復旧箇所についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:20]: 災害復旧査定額千円についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:21]: 備考についてデータベースに登録されている値と突合せチェックする。
            return True
        except:
            return False

    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.browser_post_chitan()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 1/30.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 2/30.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 3/30.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.browser_post_chitan()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.browser_post_chitan()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
        
        #######################################################################
        ### 局所変数セット処理(0030)
        ### チェック用の局所変数を初期化する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 4/30.', 'DEBUG')
        ### 必須チェック用の局所変数を初期化する。
        require_info = []
        require_warn = []

        ### 形式チェック用の局所変数を初期化する。
        format_info = []
        format_warn = []

        ### 範囲チェック用の局所変数を初期化する。
        range_info = []
        range_warn = []

        ### 相関チェック用の局所変数を初期化する。
        correlate_info = []
        correlate_warn = []

        ### 突合せチェックの結果を格納するために局所変数をセットする。
        compare_info = []
        compare_warn = []

        #######################################################################
        ### 局所変数セット処理(0040)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 5/30.', 'DEBUG')
        form = UploadChitanForm(request.POST, request.FILES)
            
        #######################################################################
        ### フォーム検証処理(0050)
        ### (1)フォームが正しい場合、処理を継続する。
        ### (2)フォームが正しくない場合、ERROR画面を表示して関数を抜ける。
        ### ※ネストを浅くするため。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 6/30.', 'DEBUG')
        if form.is_valid() == False:
            print_log('[WARN] P0120Ken.browser_post_chitan()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
    
        #######################################################################
        ### EXCEL入出力処理(1000)
        ### (1)局所変数に値をセットする。
        ### (2)アップロードされた地方単独事業調査票ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 7/30.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_Ym = datetime.now(JST).strftime('%Y%m')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        
        upload_file_object = request.FILES['file']
        upload_file_name, upload_file_ext = os.path.splitext(request.FILES['file'].name)
        upload_file_name = upload_file_name + '_' + datetime_now_YmdHMS + '.xlsx'
        ### upload_file_path = 'static/repository/' + datetime_now_Ym + '/' + upload_file_name
        upload_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + upload_file_name

        output_file_name, output_file_ext = os.path.splitext(request.FILES['file'].name)
        output_file_name = output_file_name + '_' + datetime_now_YmdHMS + '_output' + '.xlsx'
        ### output_file_path = 'static/repository/' + datetime_now_Ym + '/' + output_file_name
        output_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + output_file_name

        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 upload_file_object={}'.format(upload_file_object), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 upload_file_path={}'.format(upload_file_path), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 upload_file_name={}'.format(upload_file_name), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 output_file_path={}'.format(output_file_path), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 output_file_name={}'.format(output_file_name), 'DEBUG')
        
        with open(upload_file_path, 'wb+') as destination:
            for chunk in upload_file_object.chunks():
                destination.write(chunk)
        
        #######################################################################
        ### EXCEL入出力処理(1010)
        ### (1)アップロードされた地方単独事業調査票ファイルのワークブックを読み込む。
        ### (2)CHITANワークシートをコピーして、チェック結果を格納するCHECK_RESULTワークシートを追加する。
        ### (3)追加したワークシートを2シート目に移動する。
        ### (4)ワークシートの最大行数を局所変数のmax_rowにセットする。
        ### (5)背景赤色の塗りつぶしを局所変数のfillにセットする。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 8/30.', 'DEBUG')
        wb = openpyxl.load_workbook(upload_file_path)
        ws = []
        ws_result = []
        ws_title = []
        for ws_temp in wb.worksheets:
            if 'CHITAN' in ws_temp.title:
                ws.append(ws_temp)
                ws_result.append(wb.copy_worksheet(ws_temp))
                ws_result[-1].title = 'RESULT' + ws_temp.title
                ws_title.append(ws_temp.title)
                
        for ws_temp in wb.worksheets:
            if 'RESULT' in ws_temp.title:
                wb.move_sheet(ws_temp.title, offset=-wb.index(ws_temp))
                wb.move_sheet(ws_temp.title, offset=1)
        
        for ws_temp in wb.worksheets:
            ws_temp.sheet_view.tabSelected = None
            
        wb.active = 1

        #######################################################################
        ### EXCEL入出力処理(1020)
        ### (1)EXCELシート毎に最大行を探索する。
        ### (2)局所変数のmax_rowリストに追加する。
        ### ※max_row_tempの初期値の7はNO.、水系・沿岸名等のキャプション部分のEXCEL行番号である。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 9/30.', 'DEBUG')
        max_row = []
        for ws_temp in ws:
            ### EXCELシート毎に最大行を探索する。
            max_row_temp = 7
            for i in range(ws_temp.max_row+1, 7, -1):
                if ws_temp.cell(row=i, column=2).value is None:
                    pass
                else:
                    max_row_temp = i
                    break
            ### 局所変数のmax_rowリストに追加する。
            max_row.append(max_row_temp)

        #######################################################################
        ### EXCEL入出力処理(1030)
        ### EXCELセルの背景赤色を局所変数のfillに設定する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 10/30.', 'DEBUG')
        fill = openpyxl.styles.PatternFill(patternType='solid', fgColor='FF0000', bgColor='FF0000')

        #######################################################################
        ### DBアクセス処理(2000)
        ### (1)DBから突合せチェック用のデータを取得する。
        ### (2)突合せチェック用のリストを生成する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 11/30.', 'DEBUG')
        ### DBから突合せチェック用のデータを取得する。
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        city_list = CITY.objects.raw("""SELECT * FROM CITY ORDER BY CAST(CITY_CODE AS INTEGER)""")
        ### cause_list
        ### area_list
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_list = KASEN.objects.raw("""SELECT * FROM KASEN ORDER BY CAST(KASEN_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        ### gradient_list
        kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(KASEN_KAIGAN_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")
        ### building_list
        ### underground_list
        ### flood_sediment_list
        ### industry_list
        business_list = BUSINESS.objects.raw("""SELECT * FROM BUSINESS ORDER BY CAST(BUSINESS_CODE AS INTEGER)""")
        ### usage_list
        
        ### 突合せチェック用のリストを生成する。
        ken_code_list = [ken.ken_code for ken in ken_list]
        ken_name_list = [ken.ken_name for ken in ken_list]
        ken_name_code_list = [str(ken.ken_name) + ":" + str(ken.ken_code) for ken in ken_list]
        city_code_list = [city.city_code for city in city_list]
        city_name_list = [city.city_name for city in city_list]
        city_name_code_list = [str(city.city_name) + ":" + str(city.city_code) for city in city_list]
        ### cause_code_list
        ### cause_name_list
        ### cause_name_code_list
        ### area_id_list
        ### area_name_list
        ### area_name_id_list
        suikei_code_list = [suikei.suikei_code for suikei in suikei_list]
        suikei_name_list = [suikei.suikei_name for suikei in suikei_list]
        suikei_name_code_list = [str(suikei.suikei_name) + ":" + str(suikei.suikei_code) for suikei in suikei_list]
        suikei_type_code_list = [suikei_type.suikei_type_code for suikei_type in suikei_type_list]
        suikei_type_name_list = [suikei_type.suikei_type_name for suikei_type in suikei_type_list]
        suikei_type_name_code_list = [str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code) for suikei_type in suikei_type_list]
        kasen_code_list = [kasen.kasen_code for kasen in kasen_list]
        kasen_name_list = [kasen.kasen_name for kasen in kasen_list]
        kasen_name_code_list = [str(kasen.kasen_name) + ":" + str(kasen.kasen_code) for kasen in kasen_list]
        kasen_type_code_list = [kasen_type.kasen_type_code for kasen_type in kasen_type_list]
        kasen_type_name_list = [kasen_type.kasen_type_name for kasen_type in kasen_type_list]
        kasen_type_name_code_list = [str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code) for kasen_type in kasen_type_list]
        ### gradient_code_list
        ### gradient_name_list
        ### gradient_name_code_list
        kasen_kaigan_code_list = [kasen_kaigan.kasen_kaigan_code for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_list = [kasen_kaigan.kasen_kaigan_name for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_code_list = [str(kasen_kaigan.kasen_kaigan_name) + ":" + str(kasen_kaigan.kasen_kaigan_code) for kasen_kaigan in kasen_kaigan_list]
        weather_id_list = [weather.weather_id for weather in weather_list]
        weather_name_list = [weather.weather_name for weather in weather_list]
        weather_name_id_list = [str(weather.weather_name) + ":" + str(weather.weather_id) for weather in weather_list]
        ### building_code_list
        ### building_name_list
        ### building_name_code_list
        ### underground_code_list
        ### underground_name_list
        ### underground_name_code_list
        ### flood_sediment_code_list
        ### flood_sediment_name_list
        ### flood_sediment_name_code_list
        ### industry_code_list
        ### industry_name_list
        ### industry_name_code_list
        business_code_list = [business.business_code for business in business_list]
        business_name_list = [business.business_name for business in business_list]
        business_name_code_list = [str(business.business_name) + ":" + str(business.business_code) for business in business_list]
        ### usage_code_list
        ### usage_name_list
        ### usage_name_code_list

        #######################################################################
        ### 必須、形式、範囲、相関、突合せチェック処理(2010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 12/30.', 'DEBUG')
        bool_return = check_require()
        if bool_return == False:
            print_log('[ERROR] check_require()関数が異常終了しました。', 'ERROR')
            raise Exception
            
        bool_return = check_format()
        if bool_return == False:
            print_log('[ERROR] check_format()関数が異常終了しました。', 'ERROR')
            raise Exception

        bool_return = check_range()
        if bool_return == False:
            print_log('[ERROR] check_range()関数が異常終了しました。', 'ERROR')
            raise Exception

        bool_return = check_correlate()
        if bool_return == False:
            print_log('[ERROR] check_correlate()関数が異常終了しました。', 'ERROR')
            raise Exception

        bool_return = check_compare()
        if bool_return == False:
            print_log('[ERROR] check_compare()関数が異常終了しました。', 'ERROR')
            raise Exception

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(3000)
        ### チェック結果ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 13/30.', 'DEBUG')
        wb.save(output_file_path)

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(3010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 14/30.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 max_row={}'.format(max_row), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(require_warn)={}'.format(len(require_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(format_warn)={}'.format(len(format_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(range_warn)={}'.format(len(range_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(correlate_warn)={}'.format(len(correlate_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(compare_warn)={}'.format(len(compare_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(require_info)={}'.format(len(require_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(format_info)={}'.format(len(format_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(range_info)={}'.format(len(range_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(correlate_info)={}'.format(len(correlate_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 len(compare_info)={}'.format(len(compare_info)), 'DEBUG')
        
        #######################################################################
        ### ファイル入出力処理、ログ出力処理(3020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 15/30.', 'DEBUG')
        info_str = ''
        warn_str = ''
        if len(require_info) > 0:
            for i in range(len(require_info)):
                info_str = info_str + \
                    str(require_info[i][0]) + ',' + \
                    str(require_info[i][1]) + ',' + \
                    str(require_info[i][2]) + ',' + \
                    str(constants.CHI_REQ_MSG[require_info[i][3]][0]) + ',' + \
                    str(constants.CHI_REQ_MSG[require_info[i][3]][1]) + ',' + \
                    str(constants.CHI_REQ_MSG[require_info[i][3]][2]) + '\n'        
        
        if len(format_info) > 0:
            for i in range(len(format_info)):
                info_str = info_str + \
                    str(format_info[i][0]) + ',' + \
                    str(format_info[i][1]) + ',' + \
                    str(format_info[i][2]) + ',' + \
                    str(constants.CHI_FOR_MSG[format_info[i][3]][0]) + ',' + \
                    str(constants.CHI_FOR_MSG[format_info[i][3]][1]) + ',' + \
                    str(constants.CHI_FOR_MSG[format_info[i][3]][2]) + '\n'        

        if len(range_info) > 0:
            for i in range(len(range_info)):
                info_str = info_str + \
                    str(range_info[i][0]) + ',' + \
                    str(range_info[i][1]) + ',' + \
                    str(range_info[i][2]) + ',' + \
                    str(constants.CHI_RAN_MSG[range_info[i][3]][0]) + ',' + \
                    str(constants.CHI_RAN_MSG[range_info[i][3]][1]) + ',' + \
                    str(constants.CHI_RAN_MSG[range_info[i][3]][2]) + '\n'        

        if len(correlate_info) > 0:
            for i in range(len(correlate_info)):
                info_str = info_str + \
                    str(correlate_info[i][0]) + ',' + \
                    str(correlate_info[i][1]) + ',' + \
                    str(correlate_info[i][2]) + ',' + \
                    str(constants.CHI_COR_MSG[correlate_info[i][3]][0]) + ',' + \
                    str(constants.CHI_COR_MSG[correlate_info[i][3]][1]) + ',' + \
                    str(constants.CHI_COR_MSG[correlate_info[i][3]][2]) + '\n'        

        if len(compare_info) > 0:
            for i in range(len(compare_info)):
                info_str = info_str + \
                    str(compare_info[i][0]) + ',' + \
                    str(compare_info[i][1]) + ',' + \
                    str(compare_info[i][2]) + ',' + \
                    str(constants.CHI_COM_MSG[compare_info[i][3]][0]) + ',' + \
                    str(constants.CHI_COM_MSG[compare_info[i][3]][1]) + ',' + \
                    str(constants.CHI_COM_MSG[compare_info[i][3]][2]) + '\n'        

        if len(require_warn) > 0:
            for i in range(len(require_warn)):
                warn_str = warn_str + \
                    str(require_warn[i][0]) + ',' + \
                    str(require_warn[i][1]) + ',' + \
                    str(require_warn[i][2]) + ',' + \
                    str(constants.CHI_REQ_MSG[require_warn[i][3]][0]) + ',' + \
                    str(constants.CHI_REQ_MSG[require_warn[i][3]][1]) + ',' + \
                    str(constants.CHI_REQ_MSG[require_warn[i][3]][2]) + '\n'        
        
        if len(format_warn) > 0:
            for i in range(len(format_warn)):
                warn_str = warn_str + \
                    str(format_warn[i][0]) + ',' + \
                    str(format_warn[i][1]) + ',' + \
                    str(format_warn[i][2]) + ',' + \
                    str(constants.CHI_FOR_MSG[format_warn[i][3]][0]) + ',' + \
                    str(constants.CHI_FOR_MSG[format_warn[i][3]][1]) + ',' + \
                    str(constants.CHI_FOR_MSG[format_warn[i][3]][2]) + '\n'        

        if len(range_warn) > 0:
            for i in range(len(range_warn)):
                warn_str = warn_str + \
                    str(range_warn[i][0]) + ',' + \
                    str(range_warn[i][1]) + ',' + \
                    str(range_warn[i][2]) + ',' + \
                    str(constants.CHI_RAN_MSG[range_warn[i][3]][0]) + ',' + \
                    str(constants.CHI_RAN_MSG[range_warn[i][3]][1]) + ',' + \
                    str(constants.CHI_RAN_MSG[range_warn[i][3]][2]) + '\n'        

        if len(correlate_warn) > 0:
            for i in range(len(correlate_warn)):
                warn_str = warn_str + \
                    str(correlate_warn[i][0]) + ',' + \
                    str(correlate_warn[i][1]) + ',' + \
                    str(correlate_warn[i][2]) + ',' + \
                    str(constants.CHI_COR_MSG[correlate_warn[i][3]][0]) + ',' + \
                    str(constants.CHI_COR_MSG[correlate_warn[i][3]][1]) + ',' + \
                    str(constants.CHI_COR_MSG[correlate_warn[i][3]][2]) + '\n'        

        if len(compare_warn) > 0:
            for i in range(len(compare_warn)):
                warn_str = warn_str + \
                    str(compare_warn[i][0]) + ',' + \
                    str(compare_warn[i][1]) + ',' + \
                    str(compare_warn[i][2]) + ',' + \
                    str(constants.CHI_COM_MSG[compare_warn[i][3]][0]) + ',' + \
                    str(constants.CHI_COM_MSG[compare_warn[i][3]][1]) + ',' + \
                    str(constants.CHI_COM_MSG[compare_warn[i][3]][2]) + '\n'        

        #######################################################################
        ### DBアクセス処理(4000)
        ### ※入力チェックでエラーが発見された場合に処理する。
        ### ※ネストを浅くするために、処理対象外の場合、終了させる。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 16/30.', 'DEBUG')
        if len(require_warn) > 0 or len(format_warn) > 0 or \
            len(range_warn) > 0 or len(correlate_warn) > 0 or \
            len(compare_warn) > 0:

            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")
                
                ###############################################################
                ### DBアクセス処理(4010)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の都道府県のCHITAN_HEADERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 17/30.', 'DEBUG')
                params = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=8, column=9).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE CHITAN_HEADER SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE 
                    chitan_header_id IN (
                    SELECT 
                        chitan_header_id 
                    FROM CHITAN_HEADER 
                    WHERE 
                        ken_code=%(KEN_CODE)s AND 
                        deleted_at IS NULL)""", params)
        
                ###############################################################
                ### DBアクセス処理(4020)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の都道府県のCHITANのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 18/30.', 'DEBUG')
                params = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=8, column=9).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE CHITAN SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE chitan_id IN (
                    SELECT 
                        chitan_id 
                    FROM CHITAN_VIEW 
                    WHERE 
                        ken_code=%(KEN_CODE)s AND 
                        deleted_at IS NULL)""", params)
    
                ###############################################################
                ### DBアクセス処理(4030)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の都道府県のCHITAN_SUMMARYのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 19/30.', 'DEBUG')
                params = dict({
                    'KEN_CODE': split_name_code(ws_ippan[0].cell(row=8, column=9).value)[-1]
                })
                connection_cursor.execute(""" 
                    UPDATE CHITAN_SUMMARY SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE chitan_id IN ( 
                    SELECT 
                        chitan_id 
                    FROM CHITAN_SUMMARY_VIEW 
                    WHERE 
                        ken_code=%(KEN_CODE)s AND 
                        deleted_at IS NULL)""", params)
    
                ###############################################################
                ### DBアクセス処理(4040)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の都道府県のCHITAN_TRIGGERのデータは、削除日時をセットして、削除済の扱いとする。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 20/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'ken_code': split_name_code(ws[0].cell(row=8, column=9).value)[-1], 
                    'action_code': _CHI_ACT_01
                })
                bool_return = delete_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] delete_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
                ###############################################################
                ### DBアクセス処理(4050)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※トリガーテーブルにCHI_ACT_01トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 21/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_corsor, 
                    'header_id': None, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[0].cell(row=8, column=9).value)[-1]),
                    'city_code': None,
                    'action_code': _CHI_ACT_01, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': get_info_log(), 
                    'warn_log': get_warn_log(), 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                    
                ###############################################################
                ### DBアクセス処理(4060)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※トリガーテーブルにCHI_ACT_02トリガーを実行済、失敗として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 22/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': None, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[0].cell(row=8, column=9).value)[-1]), 
                    'city_code': None, 
                    'action_code': _CHI_ACT_02, 
                    'status_code': _FAILURE, 
                    'info_count': 0, 
                    'warn_count': len(ws), 
                    'info_log': info_str, 
                    'warn_log': warn_str, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
                connection_cursor.execute("""COMMIT""")
                
            except:
                print_log('[ERROR] P0120Ken.browser_post_chitan()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] P0120Ken.browser_post_chitan()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
                print_log('[ERROR] P0120Ken.browser_post_chitan()関数が異常終了しました。', 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
            finally:
                connection_cursor.close()
                
            ###################################################################
            ### レスポンスセット処理(4070)
            ### ※入力チェックで警告が発見された場合に処理する。
            ### ※テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 23/30.', 'DEBUG')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'browser_post_chitan_warn': 'browser_post_chitan_warn',
                'require_warn': require_warn,
                'format_warn': format_warn,
                'range_warn': range_warn,
                'correlate_warn': correlate_warn,
                'compare_warn': compare_warn,
                'output_file_path': output_file_path, 
            }
            print_log('[WARN] P0120Ken.browser_post_chitan()関数が警告終了しました。', 'INFO')
            return False, HttpResponse(template.render(context, request))
        
        #######################################################################
        ### DBアクセス処理(5000)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        ### ※入力データ_ヘッダ部分テーブルにデータを登録する。
        ### ※入力データ_一覧票部分テーブルにデータを登録する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 24/30.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")
            
            ###################################################################
            ### DBアクセス処理(5010)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の都道府県のCHITAN_HEADERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 25/30.', 'DEBUG')
            params = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=8, column=9).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE CHITAN_HEADER SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE chitan_header_id IN (
                SELECT 
                    chitan_header_id 
                FROM CHITAN_HEADER 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL)""", params)
    
            ###################################################################
            ### DBアクセス処理(5020)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の都道府県のCHITANのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 26/30.', 'DEBUG')
            params = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=8, column=9).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE CHITAN SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE chitan_id IN (
                SELECT 
                    chitan_id 
                FROM CHITAN_VIEW 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL)""", params)

            ###################################################################
            ### DBアクセス処理(5030)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の都道府県のCHITAN_SUMMARYのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 27/30.', 'DEBUG')
            params = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=8, column=9).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE CHITAN_SUMMARY SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE chitan_id IN (
                SELECT 
                    chitan_id 
                FROM CHITAN_SUMMARY_VIEW 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL)""", params)

            ###################################################################
            ### DBアクセス処理(5040)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の都道府県のCHITAN_TRIGGERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 28/30.', 'DEBUG')
            metadata = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': split_name_code(ws[0].cell(row=8, column=9).value)[-1], 
                'city_code': None, 
                'action_code': _CHI_ACT_01
            })
            bool_return = delete_message(metadata=metadata)
            if bool_return == False:
                print_log('[ERROR] delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            ###################################################################
            ### DBアクセス処理(5050)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※chitan_header_id__max で正しい。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 29/30.', 'DEBUG')
            for i, _ in enumerate(ws):
                chitan_header_id = CHITAN_HEADER.objects.all().aggregate(Max('chitan_header_id'))['chitan_header_id__max']
                if chitan_header_id is None:
                    chitan_header_id = 1
                else:
                    chitan_header_id += 1
                
                ###############################################################
                ### DBアクセス処理(5060)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※地方単独事業調査票_ヘッダ部分テーブルにデータを登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 29_1/30.', 'DEBUG')
                params = dict({
                    'CHITAN_HEADER_ID': chitan_header_id, 
                    'CHITAN_HEADER_NAME': ws_title[i], 
                    'KEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=8, column=9).value)[-1]), 
                    'UPLOAD_FILE_PATH': upload_file_path, 
                    'UPLOAD_FILE_NAME': upload_file_name, 
                    'SUMMARY_FILE_PATH': None, 
                    'SUMMARY_FILE_NAME': None, 
                    'DELETED_AT': None
                })
                connection_cursor.execute("""
                    INSERT INTO CHITAN_HEADER (
                        chitan_header_id, chitan_header_name, ken_code, 
                        upload_file_path, upload_file_name, summary_file_path, summary_file_name, 
                        committed_at, deleted_at 
                    ) VALUES (
                        %(CHITAN_HEADER_ID)s, 
                        %(CHITAN_HEADER_NAME)s, 
                        %(KEN_CODE)s, 
                        %(UPLOAD_FILE_PATH)s, 
                        %(UPLOAD_FILE_NAME)s, 
                        %(SUMMARY_FILE_PATH)s, 
                        %(SUMMARY_FILE_NAME)s, 
                        CURRENT_TIMESTAMP,  -- committed_at 
                        %(DELETED_AT)s)""", params)
                    
                ###############################################################
                ### DBアクセス処理(5070)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※地方単独事業調査票_一覧表部分テーブルにデータを登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 29_2/30.', 'DEBUG')
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 max_row[i]={}'.format(max_row[i]), 'DEBUG')
                if max_row[i] >= 8:
                    for j in range(8, max_row[i]+1):
                        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 j={}'.format(j), 'DEBUG')
                        params = dict({
                            'CHITAN_NAME': convert_empty_to_none(ws[i].cell(row=j, column=6).value), 
                            'CHITAN_HEADER_ID': chitan_header_id, 
                            'CITY_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=10).value)[-1]), 
                            'BEGIN_DATE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=12).value)[-1]), 
                            'END_DATE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=14).value)[-1]), 
                            'SUIKEI_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=2).value)[-1]), 
                            'SUIKEI_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=3).value)[-1]), 
                            'KASEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=4).value)[-1]), 
                            'KASEN_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=5).value)[-1]), 
                            'KASEN_KAIGAN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=16).value)[-1]), 
                            'WEATHER_ID': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=11).value)[-1]), 
                            'DISASTER_POINT': convert_empty_to_none(ws[i].cell(row=j, column=19).value), 
                            'ESTIMATED_COST': convert_empty_to_none(ws[i].cell(row=j, column=20).value), 
                            'COMMENT': convert_empty_to_none(ws[i].cell(row=j, column=21).value), 
                            'DELETED_AT': None
                        })
                        connection_cursor.execute(""" 
                            INSERT INTO CHITAN (
                                chitan_id, chitan_name, chitan_header_id, 
                                city_code, begin_date, end_date, 
                                suikei_code, suikei_type_code, kasen_code, kasen_type_code, kasen_kaigan_code, weather_id, 
                                disaster_point, estimated_cost, comment, 
                                committed_at, deleted_at 
                            ) VALUES (
                                (SELECT CASE WHEN (MAX(chitan_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(chitan_id+1) AS INTEGER) END AS chitan_id FROM CHITAN), -- chitan_id 
                                %(CHITAN_NAME)s, 
                                %(CHITAN_HEADER_ID)s, 
                                %(CITY_CODE)s, 
                                TO_DATE(%(BEGIN_DATE)s, 'YYYY/MM/DD'), 
                                TO_DATE(%(END_DATE)s, 'YYYY/MM/DD'), 
                                %(SUIKEI_CODE)s, 
                                %(SUIKEI_TYPE_CODE)s, 
                                %(KASEN_CODE)s, 
                                %(KASEN_TYPE_CODE)s, 
                                %(KASEN_KAIGAN_CODE)s, 
                                %(WEATHER_ID)s, 
                                %(DISATER_POINT)s, 
                                %(ESTIMATED_COST)s, 
                                %(COMMENT)s, 
                                CURRENT_TIMESTAMP, -- committed_at 
                                %(DELETED_AT)s)""", params)

                ###############################################################
                ### DBアクセス処理(5080)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにCHI_ACT_01トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 29_3/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': chitan_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[0].cell(row=8, column=9).value)[-1]), 
                    'city_code': None, 
                    'action_code': _CHI_ACT_01, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': get_info_log(), 
                    'warn_log': get_warn_log(), 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception

                ###############################################################
                ### DBアクセス処理(5090)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにCHI_ACT_02トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 29_4/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': chitan_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[i].cell(row=8, column=9).value)[-1]), 
                    'city_code': None, 
                    'action_code': _CHI_ACT_02, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': info_str, 
                    'warn_log': warn_str, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
            
                ###############################################################
                ### DBアクセス処理(5100)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにCHI_ACT_03トリガーを未実行＝次回実行対象として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 29_5/30.', 'DEBUG')
                metadata = ({
                    'connection_cursor': connection_cursor, 
                    'header_id': chitan_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[i].cell(row=8, column=9).value)[-1]), 
                    'city_code': None, 
                    'action_code': _CHI_ACT_03, 
                    'status_code': _RUNNING, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
            connection_cursor.execute("""COMMIT""")     
            
        except:
            print_log('[ERROR] P0120Ken.browser_post_chitan()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0120Ken.browser_post_chitan()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0120Ken.browser_post_chitan()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
        
        finally:
            connection_cursor.close()
        
        #######################################################################
        ### レスポンスセット処理(5110)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        ### ※テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_chitan()関数 STEP 30/30.', 'DEBUG')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'browser_post_chitan_info': 'browser_post_chitan_info',
            'require_info': require_info, 
            'format_info': format_info,
            'range_info': range_info,
            'correlate_info': correlate_info,
            'compare_info': compare_info,
        }
        print_log('[INFO] P0120Ken.browser_post_chitan()関数が正常終了しました。', 'INFO')
        return True, HttpResponse(template.render(context, request))
        
    except:
        print_log('[ERROR] P0120Ken.browser_post_chitan()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_post_chitan()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_post_chitan()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))

###############################################################################
### 都道府県用ブラウザ都アップロードファイル
###############################################################################
def browser_post_hojo(request):

    ###########################################################################
    ### 関数内関数：EXCELセルデータ必須チェック処理
    ###########################################################################
    def check_require():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal require_warn
            nonlocal require_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ必須チェック処理（0000）
            ### (1)セル[8:2]からセル[8:17]について、必須項目に値がセットされていることをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)HOJOワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### ※max_rowの8は入力部分の開始EXCEL行番号である。
            ### ※max_rowの8はNO.、水系・沿岸名等のキャプション部分の1つ下のEXCEL行番号である。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo.check_require()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 8:
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=1).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=0, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 1, constants.HOJ_REQ_MSG[0][0], constants.HOJ_REQ_MSG[0][1], constants.HOJ_REQ_MSG[0][2], constants.HOJ_REQ_MSG[0][3], constants.HOJ_REQ_MSG[0][4]])
                    else:
                        require_info.append([ws[0].title, j, 1, 0])
    
                    ### セル[8:2]: 水系・沿岸名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=2).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 2, constants.HOJ_REQ_MSG[1][0], constants.HOJ_REQ_MSG[1][1], constants.HOJ_REQ_MSG[1][2], constants.HOJ_REQ_MSG[1][3], constants.HOJ_REQ_MSG[1][4]])
                    else:
                        require_info.append([ws[0].title, j, 2, 1])
                        
                    ### セル[8:3]: 水系種別[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=3).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 3, constants.HOJ_REQ_MSG[2][0], constants.HOJ_REQ_MSG[2][1], constants.HOJ_REQ_MSG[2][2], constants.HOJ_REQ_MSG[2][3], constants.HOJ_REQ_MSG[2][4]])
                    else:
                        require_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[8:4]: 河川・海岸名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=4).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 4, constants.HOJ_REQ_MSG[3][0], constants.HOJ_REQ_MSG[3][1], constants.HOJ_REQ_MSG[3][2], constants.HOJ_REQ_MSG[3][3], constants.HOJ_REQ_MSG[3][4]])
                    else:
                        require_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[8:5]: 河川種別[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=5).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 5, constants.HOJ_REQ_MSG[4][0], constants.HOJ_REQ_MSG[4][1], constants.HOJ_REQ_MSG[4][2], constants.HOJ_REQ_MSG[4][3], constants.HOJ_REQ_MSG[4][4]])
                    else:
                        require_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[8:6]: 都道府県コードに値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=6).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 6, constants.HOJ_REQ_MSG[5][0], constants.HOJ_REQ_MSG[5][1], constants.HOJ_REQ_MSG[5][2], constants.HOJ_REQ_MSG[5][3], constants.HOJ_REQ_MSG[5][4]])
                    else:
                        require_info.append([ws[0].title, j, 6, 5])
    
                    ### セル[8:7]: 工事番号に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=7).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 7, constants.HOJ_REQ_MSG[6][0], constants.HOJ_REQ_MSG[6][1], constants.HOJ_REQ_MSG[6][2], constants.HOJ_REQ_MSG[6][3], constants.HOJ_REQ_MSG[6][4]])
                    else:
                        require_info.append([ws[0].title, j, 7, 6])
    
                    ### セル[8:8]: 枝番に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=8).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 8, constants.HOJ_REQ_MSG[7][0], constants.HOJ_REQ_MSG[7][1], constants.HOJ_REQ_MSG[7][2], constants.HOJ_REQ_MSG[7][3], constants.HOJ_REQ_MSG[7][4]])
                    else:
                        require_info.append([ws[0].title, j, 8, 7])
    
                    ### セル[8:9]: 工事区分に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=9).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 9, constants.HOJ_REQ_MSG[8][0], constants.HOJ_REQ_MSG[8][1], constants.HOJ_REQ_MSG[8][2], constants.HOJ_REQ_MSG[8][3], constants.HOJ_REQ_MSG[8][4]])
                    else:
                        require_info.append([ws[0].title, j, 9, 8])
    
                    ### セル[8:10]: 市区町村コードに値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=10).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=9, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 10, constants.HOJ_REQ_MSG[9][0], constants.HOJ_REQ_MSG[9][1], constants.HOJ_REQ_MSG[9][2], constants.HOJ_REQ_MSG[9][3], constants.HOJ_REQ_MSG[9][4]])
                    else:
                        require_info.append([ws[0].title, j, 10, 9])
    
                    ### セル[8:11]: 工種区分に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=11).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 11, constants.HOJ_REQ_MSG[10][0], constants.HOJ_REQ_MSG[10][1], constants.HOJ_REQ_MSG[10][2], constants.HOJ_REQ_MSG[10][3], constants.HOJ_REQ_MSG[10][4]])
                    else:
                        require_info.append([ws[0].title, j, 11, 10])
    
                    ### セル[8:12]: 
                    ### セル[8:13]: 異常気象コードに値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=13).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 13, constants.HOJ_REQ_MSG[12][0], constants.HOJ_REQ_MSG[12][1], constants.HOJ_REQ_MSG[12][2], constants.HOJ_REQ_MSG[12][3], constants.HOJ_REQ_MSG[12][4]])
                    else:
                        require_info.append([ws[0].title, j, 13, 12])
    
                    ### セル[8:14]: 水害発生月に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=14).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 14, constants.HOJ_REQ_MSG[13][0], constants.HOJ_REQ_MSG[13][1], constants.HOJ_REQ_MSG[13][2], constants.HOJ_REQ_MSG[13][3], constants.HOJ_REQ_MSG[13][4]])
                    else:
                        require_info.append([ws[0].title, j, 14, 13])
    
                    ### セル[8:15]: 水害発生日に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=15).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 15, constants.HOJ_REQ_MSG[14][0], constants.HOJ_REQ_MSG[14][1], constants.HOJ_REQ_MSG[14][2], constants.HOJ_REQ_MSG[14][3], constants.HOJ_REQ_MSG[14][4]])
                    else:
                        require_info.append([ws[0].title, j, 15, 14])
    
                    ### セル[8:16]: 決定額(千円)に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=16).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 16, constants.HOJ_REQ_MSG[15][0], constants.HOJ_REQ_MSG[15][1], constants.HOJ_REQ_MSG[15][2], constants.HOJ_REQ_MSG[15][3], constants.HOJ_REQ_MSG[15][4]])
                    else:
                        require_info.append([ws[0].title, j, 16, 15])
    
                    ### セル[8:17]: 備考に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=17).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=16, message=constants.HOJ_REQ_MSG)
                        require_warn.append([ws[0].title, j, 17, constants.HOJ_REQ_MSG[16][0], constants.HOJ_REQ_MSG[16][1], constants.HOJ_REQ_MSG[16][2], constants.HOJ_REQ_MSG[16][3], constants.HOJ_REQ_MSG[16][4]])
                    else:
                        require_info.append([ws[0].title, j, 17, 16])
            return True
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ形式チェック処理
    ###########################################################################
    def check_format():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal format_warn
            nonlocal format_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ形式チェック処理（0000）
            ### (1)セル[8:2]からセル[8:17]について形式が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)HOJOワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 形式チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ### ※max_rowの8は入力部分の開始EXCEL行番号である。
            ### ※max_rowの8はNO.、水系・沿岸名等のキャプション部分の1つ下のEXCEL行番号である。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo.check_format()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 8:
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=1).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=1).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=100)
                            ### format_warn.append([ws[0].title, j, 1, constants.HOJ_FOR_MSG[100][0], constants.HOJ_FOR_MSG[100][1], constants.HOJ_FOR_MSG[100][2], constants.HOJ_FOR_MSG[100][3], constants.HOJ_FOR_MSG[100][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=0, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 1, constants.HOJ_FOR_MSG[0][0], constants.HOJ_FOR_MSG[0][1], constants.HOJ_FOR_MSG[0][2], constants.HOJ_FOR_MSG[0][3], constants.HOJ_FOR_MSG[0][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 1, 100])
                            format_info.append([ws[0].title, j, 1, 0])
    
                    ### セル[8:2]: 水系・沿岸名[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=2).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=2).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=101)
                            ### format_warn.append([ws[0].title, j, 2, constants.HOJ_FOR_MSG[101][0], constants.HOJ_FOR_MSG[101][1], constants.HOJ_FOR_MSG[101][2], constants.HOJ_FOR_MSG[101][3], constants.HOJ_FOR_MSG[101][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 2, constants.HOJ_FOR_MSG[1][0], constants.HOJ_FOR_MSG[1][1], constants.HOJ_FOR_MSG[1][2], constants.HOJ_FOR_MSG[1][3], constants.HOJ_FOR_MSG[1][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 2, 101])
                            format_info.append([ws[0].title, j, 2, 1])
                        
                    ### セル[8:3]: 水系種別[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=3).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=3).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=102)
                            ### format_warn.append([ws[0].title, j, 3, constants.HOJ_FOR_MSG[102][0], constants.HOJ_FOR_MSG[102][1], constants.HOJ_FOR_MSG[102][2], constants.HOJ_FOR_MSG[102][3], constants.HOJ_FOR_MSG[102][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 3, constants.HOJ_FOR_MSG[2][0], constants.HOJ_FOR_MSG[2][1], constants.HOJ_FOR_MSG[2][2], constants.HOJ_FOR_MSG[2][3], constants.HOJ_FOR_MSG[2][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 3, 102])
                            format_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[8:4]: 河川・海岸名[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=4).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=4).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=103)
                            ### format_warn.append([ws[0].title, j, 4, constants.HOJ_FOR_MSG[103][0], constants.HOJ_FOR_MSG[103][1], constants.HOJ_FOR_MSG[103][2], constants.HOJ_FOR_MSG[103][3], constants.HOJ_FOR_MSG[103][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 4, constants.HOJ_FOR_MSG[3][0], constants.HOJ_FOR_MSG[3][1], constants.HOJ_FOR_MSG[3][2], constants.HOJ_FOR_MSG[3][3], constants.HOJ_FOR_MSG[3][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 4, 103])
                            format_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[8:5]: 河川種別[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=5).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=5).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=104)
                            ### format_warn.append([ws[0].title, j, 5, constants.HOJ_FOR_MSG[104][0], constants.HOJ_FOR_MSG[104][1], constants.HOJ_FOR_MSG[104][2], constants.HOJ_FOR_MSG[104][3], constants.HOJ_FOR_MSG[104][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 5, constants.HOJ_FOR_MSG[4][0], constants.HOJ_FOR_MSG[4][1], constants.HOJ_FOR_MSG[4][2], constants.HOJ_FOR_MSG[4][3], constants.HOJ_FOR_MSG[4][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 5, 104])
                            format_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[8:6]: 都道府県コードについて形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=6).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=6).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=6).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=105)
                            ### format_warn.append([ws[0].title, j, 6, constants.HOJ_FOR_MSG[105][0], constants.HOJ_FOR_MSG[105][1], constants.HOJ_FOR_MSG[105][2], constants.HOJ_FOR_MSG[105][3], constants.HOJ_FOR_MSG[105][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 6, constants.HOJ_FOR_MSG[5][0], constants.HOJ_FOR_MSG[5][1], constants.HOJ_FOR_MSG[5][2], constants.HOJ_FOR_MSG[5][3], constants.HOJ_FOR_MSG[5][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 6, 105])
                            format_info.append([ws[0].title, j, 6, 5])
                        
                    ### セル[8:7]: 工事番号について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=7).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=7).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=7).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=106)
                            ### format_warn.append([ws[0].title, j, 7, constants.HOJ_FOR_MSG[106][0], constants.HOJ_FOR_MSG[106][1], constants.HOJ_FOR_MSG[106][2], constants.HOJ_FOR_MSG[106][3], constants.HOJ_FOR_MSG[106][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 7, constants.HOJ_FOR_MSG[6][0], constants.HOJ_FOR_MSG[6][1], constants.HOJ_FOR_MSG[6][2], constants.HOJ_FOR_MSG[6][3], constants.HOJ_FOR_MSG[6][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 7, 106])
                            format_info.append([ws[0].title, j, 7, 6])
                        
                    ### セル[8:8]: 枝番について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=8).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=8).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=8).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=107)
                            ### format_warn.append([ws[0].title, j, 8, constants.HOJ_FOR_MSG[107][0], constants.HOJ_FOR_MSG[107][1], constants.HOJ_FOR_MSG[107][2], constants.HOJ_FOR_MSG[107][3], constants.HOJ_FOR_MSG[107][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 8, constants.HOJ_FOR_MSG[7][0], constants.HOJ_FOR_MSG[7][1], constants.HOJ_FOR_MSG[7][2], constants.HOJ_FOR_MSG[7][3], constants.HOJ_FOR_MSG[7][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 8, 107])
                            format_info.append([ws[0].title, j, 8, 7])
                        
                    ### セル[8:9]: 工事区分について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=9).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=9).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=9).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=108)
                            ### format_warn.append([ws[0].title, j, 9, constants.HOJ_FOR_MSG[108][0], constants.HOJ_FOR_MSG[108][1], constants.HOJ_FOR_MSG[108][2], constants.HOJ_FOR_MSG[108][3], constants.HOJ_FOR_MSG[108][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 9, constants.HOJ_FOR_MSG[8][0], constants.HOJ_FOR_MSG[8][1], constants.HOJ_FOR_MSG[8][2], constants.HOJ_FOR_MSG[8][3], constants.HOJ_FOR_MSG[8][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 9, 108])
                            format_info.append([ws[0].title, j, 9, 8])
                        
                    ### セル[8:10]: 市区町村コードについて形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=10).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=10).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=10).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=109)
                            ### format_warn.append([ws[0].title, j, 10, constants.HOJ_FOR_MSG[109][0], constants.HOJ_FOR_MSG[109][1], constants.HOJ_FOR_MSG[109][2], constants.HOJ_FOR_MSG[109][3], constants.HOJ_FOR_MSG[109][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=9, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 10, constants.HOJ_FOR_MSG[9][0], constants.HOJ_FOR_MSG[9][1], constants.HOJ_FOR_MSG[9][2], constants.HOJ_FOR_MSG[9][3], constants.HOJ_FOR_MSG[9][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 10, 109])
                            format_info.append([ws[0].title, j, 10, 9])
                        
                    ### セル[8:11]: 工種区分について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=11).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=11).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=11).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=110)
                            ### format_warn.append([ws[0].title, j, 11, constants.HOJ_FOR_MSG[110][0], constants.HOJ_FOR_MSG[110][1], constants.HOJ_FOR_MSG[110][2], constants.HOJ_FOR_MSG[110][3], constants.HOJ_FOR_MSG[110][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 11, constants.HOJ_FOR_MSG[10][0], constants.HOJ_FOR_MSG[10][1], constants.HOJ_FOR_MSG[10][2], constants.HOJ_FOR_MSG[10][3], constants.HOJ_FOR_MSG[10][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 11, 110])
                            format_info.append([ws[0].title, j, 11, 10])
                        
                    ### セル[8:12]: 
                    ### セル[8:13]: 異常気象コードについて形式が正しいことをチェックする。
                    if ws[i].cell(row=j, column=13).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=13).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=13).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=112)
                            ### format_warn.append([ws[0].title, j, 13, constants.HOJ_FOR_MSG[112][0], constants.HOJ_FOR_MSG[112][1], constants.HOJ_FOR_MSG[112][2], constants.HOJ_FOR_MSG[112][3], constants.HOJ_FOR_MSG[112][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 13, constants.HOJ_FOR_MSG[12][0], constants.HOJ_FOR_MSG[12][1], constants.HOJ_FOR_MSG[12][2], constants.HOJ_FOR_MSG[12][3], constants.HOJ_FOR_MSG[12][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 13, 112])
                            format_info.append([ws[0].title, j, 13, 12])
                        
                    ### セル[8:14]: 水害発生月について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=14).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=14).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=14).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=113)
                            ### format_warn.append([ws[0].title, j, 14, constants.HOJ_FOR_MSG[113][0], constants.HOJ_FOR_MSG[113][1], constants.HOJ_FOR_MSG[113][2], constants.HOJ_FOR_MSG[113][3], constants.HOJ_FOR_MSG[113][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 14, constants.HOJ_FOR_MSG[13][0], constants.HOJ_FOR_MSG[13][1], constants.HOJ_FOR_MSG[13][2], constants.HOJ_FOR_MSG[13][3], constants.HOJ_FOR_MSG[13][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 14, 113])
                            format_info.append([ws[0].title, j, 14, 13])
                        
                    ### セル[8:15]: 水害発生日について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=15).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=15).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=15).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=114)
                            ### format_warn.append([ws[0].title, j, 15, constants.HOJ_FOR_MSG[114][0], constants.HOJ_FOR_MSG[114][1], constants.HOJ_FOR_MSG[114][2], constants.HOJ_FOR_MSG[114][3], constants.HOJ_FOR_MSG[114][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 15, constants.HOJ_FOR_MSG[14][0], constants.HOJ_FOR_MSG[14][1], constants.HOJ_FOR_MSG[14][2], constants.HOJ_FOR_MSG[14][3], constants.HOJ_FOR_MSG[14][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 15, 114])
                            format_info.append([ws[0].title, j, 15, 14])
                        
                    ### セル[8:16]: 決定額(千円)について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=16).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=16).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=16).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=115)
                            ### format_warn.append([ws[0].title, j, 16, constants.HOJ_FOR_MSG[115][0], constants.HOJ_FOR_MSG[115][1], constants.HOJ_FOR_MSG[115][2], constants.HOJ_FOR_MSG[115][3], constants.HOJ_FOR_MSG[115][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 16, constants.HOJ_FOR_MSG[15][0], constants.HOJ_FOR_MSG[15][1], constants.HOJ_FOR_MSG[15][2], constants.HOJ_FOR_MSG[15][3], constants.HOJ_FOR_MSG[15][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 16, 115])
                            format_info.append([ws[0].title, j, 16, 15])
                        
                    ### セル[8:17]: 備考について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=17).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=17).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=17).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=116)
                            ### format_warn.append([ws[0].title, j, 17, constants.HOJ_FOR_MSG[116][0], constants.HOJ_FOR_MSG[116][1], constants.HOJ_FOR_MSG[116][2], constants.HOJ_FOR_MSG[116][3], constants.HOJ_FOR_MSG[116][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=16, message=constants.HOJ_FOR_MSG)
                            format_warn.append([ws[0].title, j, 17, constants.HOJ_FOR_MSG[16][0], constants.HOJ_FOR_MSG[16][1], constants.HOJ_FOR_MSG[16][2], constants.HOJ_FOR_MSG[16][3], constants.HOJ_FOR_MSG[16][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 17, 116])
                            format_info.append([ws[0].title, j, 17, 16])
            return True
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ範囲チェック処理
    ###########################################################################
    def check_range():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal range_warn
            nonlocal range_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ範囲チェック処理（0000）
            ### (1)セル[8:2]からセル[8:17]について範囲が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)HOJOワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 範囲チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ### 範囲チェックでは、形式が正しい場合のみチェックを行う。
            ### 形式チェックは別途形式チェックで行うためである。
            ### 例えば、面積などの数値について、float()で例外とならないように、int、floatの場合のみチェックする。
            ### 範囲チェックでは、数値の下限と上限のチェックを行う。
            ### 範囲チェックでは、DBとの突合チェックに該当するチェックは行わない。
            ### DBとの突合チェックは別途突合チェックで行うためである。
            ### 範囲チェックの例は値が正であることである。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo.check_range()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 8:
                for j in range(8, max_row[0]+1):
                    ### セル[8:1]: NO.について範囲が正しいことをチェックする。
                    ### セル[8:2]: 水系・沿岸名[全角]について範囲が正しいことをチェックする。
                    ### セル[8:3]: 水系種別[全角]について範囲が正しいことをチェックする。
                    ### セル[8:4]: 河川・海岸名[全角]について範囲が正しいことをチェックする。
                    ### セル[8:5]: 河川種別[全角]について範囲が正しいことをチェックする。
                    ### セル[8:6]: 都道府県コードについて範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=6).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=6).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=6).value, float) == True:
                            if float(ws[0].cell(row=j, column=6).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=205)
                                ### range_warn.append([ws[0].title, j, 6, constants.HOJ_RAN_MSG[205][0], constants.HOJ_RAN_MSG[205][1], constants.HOJ_RAN_MSG[205][2], constants.HOJ_RAN_MSG[205][3], constants.HOJ_RAN_MSG[205][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 6, constants.HOJ_RAN_MSG[5][0], constants.HOJ_RAN_MSG[5][1], constants.HOJ_RAN_MSG[5][2], constants.HOJ_RAN_MSG[5][3], constants.HOJ_RAN_MSG[5][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 6, 205])
                                range_info.append([ws[0].title, j, 6, 5])
    
                    ### セル[8:7]: 工事番号について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=7).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=7).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=7).value, float) == True:
                            if float(ws[0].cell(row=j, column=7).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=206)
                                ### range_warn.append([ws[0].title, j, 7, constants.HOJ_RAN_MSG[206][0], constants.HOJ_RAN_MSG[206][1], constants.HOJ_RAN_MSG[206][2], constants.HOJ_RAN_MSG[206][3], constants.HOJ_RAN_MSG[206][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 7, constants.HOJ_RAN_MSG[6][0], constants.HOJ_RAN_MSG[6][1], constants.HOJ_RAN_MSG[6][2], constants.HOJ_RAN_MSG[6][3], constants.HOJ_RAN_MSG[6][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 7, 206])
                                range_info.append([ws[0].title, j, 7, 6])
                    
                    ### セル[8:8]: 枝番について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=8).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=8).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=8).value, float) == True:
                            if float(ws[0].cell(row=j, column=8).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=207)
                                ### range_warn.append([ws[0].title, j, 8, constants.HOJ_RAN_MSG[207][0], constants.HOJ_RAN_MSG[207][1], constants.HOJ_RAN_MSG[207][2], constants.HOJ_RAN_MSG[207][3], constants.HOJ_RAN_MSG[207][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 8, constants.HOJ_RAN_MSG[7][0], constants.HOJ_RAN_MSG[7][1], constants.HOJ_RAN_MSG[7][2], constants.HOJ_RAN_MSG[7][3], constants.HOJ_RAN_MSG[7][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 8, 207])
                                range_info.append([ws[0].title, j, 8, 7])
    
                    ### セル[8:9]: 工事区分について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=9).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=9).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=9).value, float) == True:
                            if float(ws[0].cell(row=j, column=9).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=208)
                                ### range_warn.append([ws[0].title, j, 9, constants.HOJ_RAN_MSG[208][0], constants.HOJ_RAN_MSG[208][1], constants.HOJ_RAN_MSG[208][2], constants.HOJ_RAN_MSG[208][3], constants.HOJ_RAN_MSG[208][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 9, constants.HOJ_RAN_MSG[8][0], constants.HOJ_RAN_MSG[8][1], constants.HOJ_RAN_MSG[8][2], constants.HOJ_RAN_MSG[8][3], constants.HOJ_RAN_MSG[8][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 9, 208])
                                range_info.append([ws[0].title, j, 9, 8])
    
                    ### セル[8:10]: 市区町村コードについて範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=10).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=10).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=10).value, float) == True:
                            if float(ws[0].cell(row=j, column=10).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=209)
                                ### range_warn.append([ws[0].title, j, 10, constants.HOJ_RAN_MSG[209][0], constants.HOJ_RAN_MSG[209][1], constants.HOJ_RAN_MSG[209][2], constants.HOJ_RAN_MSG[209][3], constants.HOJ_RAN_MSG[209][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=9, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 10, constants.HOJ_RAN_MSG[9][0], constants.HOJ_RAN_MSG[9][1], constants.HOJ_RAN_MSG[9][2], constants.HOJ_RAN_MSG[9][3], constants.HOJ_RAN_MSG[9][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 10, 209])
                                range_info.append([ws[0].title, j, 10, 9])
    
                    ### セル[8:11]: 工種区分について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=11).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=11).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=11).value, float) == True:
                            if float(ws[0].cell(row=j, column=11).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=210)
                                ### range_warn.append([ws[0].title, j, 11, constants.HOJ_RAN_MSG[210][0], constants.HOJ_RAN_MSG[210][1], constants.HOJ_RAN_MSG[210][2], constants.HOJ_RAN_MSG[210][3], constants.HOJ_RAN_MSG[210][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 11, constants.HOJ_RAN_MSG[10][0], constants.HOJ_RAN_MSG[10][1], constants.HOJ_RAN_MSG[10][2], constants.HOJ_RAN_MSG[10][3], constants.HOJ_RAN_MSG[10][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 11, 210])
                                range_info.append([ws[0].title, j, 11, 10])
    
                    ### セル[8:12]: 
                    ### セル[8:13]: 異常気象コードについて範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=13).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=13).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=13).value, float) == True:
                            if float(ws[0].cell(row=j, column=13).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=212)
                                ### range_warn.append([ws[0].title, j, 13, constants.HOJ_RAN_MSG[212][0], constants.HOJ_RAN_MSG[212][1], constants.HOJ_RAN_MSG[212][2], constants.HOJ_RAN_MSG[212][3], constants.HOJ_RAN_MSG[212][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 13, constants.HOJ_RAN_MSG[12][0], constants.HOJ_RAN_MSG[12][1], constants.HOJ_RAN_MSG[12][2], constants.HOJ_RAN_MSG[12][3], constants.HOJ_RAN_MSG[12][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 13, 212])
                                range_info.append([ws[0].title, j, 13, 12])
                    
                    ### セル[8:14]: 水害発生月について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=14).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=14).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=14).value, float) == True:
                            if float(ws[0].cell(row=j, column=14).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=213)
                                ### range_warn.append([ws[0].title, j, 14, constants.HOJ_RAN_MSG[213][0], constants.HOJ_RAN_MSG[213][1], constants.HOJ_RAN_MSG[213][2], constants.HOJ_RAN_MSG[213][3], constants.HOJ_RAN_MSG[213][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 14, constants.HOJ_RAN_MSG[13][0], constants.HOJ_RAN_MSG[13][1], constants.HOJ_RAN_MSG[13][2], constants.HOJ_RAN_MSG[13][3], constants.HOJ_RAN_MSG[13][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 14, 213])
                                range_info.append([ws[0].title, j, 14, 13])
    
                    ### セル[8:15]: 水害発生日について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=15).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=15).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=15).value, float) == True:
                            if float(ws[0].cell(row=j, column=15).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=214)
                                ### range_warn.append([ws[0].title, j, 15, constants.HOJ_RAN_MSG[214][0], constants.HOJ_RAN_MSG[214][1], constants.HOJ_RAN_MSG[214][2], constants.HOJ_RAN_MSG[214][3], constants.HOJ_RAN_MSG[214][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 15, constants.HOJ_RAN_MSG[14][0], constants.HOJ_RAN_MSG[14][1], constants.HOJ_RAN_MSG[14][2], constants.HOJ_RAN_MSG[14][3], constants.HOJ_RAN_MSG[14][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 15, 214])
                                range_info.append([ws[0].title, j, 15, 14])
    
                    ### セル[8:16]: 決定額(千円)について範囲が正しいことをチェックする。
                    if ws[i].cell(row=j, column=16).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=16).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=16).value, float) == True:
                            if float(ws[0].cell(row=j, column=16).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=215)
                                ### range_warn.append([ws[0].title, j, 16, constants.HOJ_RAN_MSG[215][0], constants.HOJ_RAN_MSG[215][1], constants.HOJ_RAN_MSG[215][2], constants.HOJ_RAN_MSG[215][3], constants.HOJ_RAN_MSG[215][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 16, constants.HOJ_RAN_MSG[15][0], constants.HOJ_RAN_MSG[15][1], constants.HOJ_RAN_MSG[15][2], constants.HOJ_RAN_MSG[15][3], constants.HOJ_RAN_MSG[15][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 16, 215])
                                range_info.append([ws[0].title, j, 16, 15])
    
                    ### セル[8:17]: 備考について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=17).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=17).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=17).value, float) == True:
                            if float(ws[0].cell(row=j, column=17).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=216)
                                ### range_warn.append([ws[0].title, j, 17, constants.HOJ_RAN_MSG[216][0], constants.HOJ_RAN_MSG[216][1], constants.HOJ_RAN_MSG[216][2], constants.HOJ_RAN_MSG[216][3], constants.HOJ_RAN_MSG[216][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=16, message=constants.HOJ_RAN_MSG)
                                range_warn.append([ws[0].title, j, 17, constants.HOJ_RAN_MSG[16][0], constants.HOJ_RAN_MSG[16][1], constants.HOJ_RAN_MSG[16][2], constants.HOJ_RAN_MSG[16][3], constants.HOJ_RAN_MSG[16][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 17, 216])
                                range_info.append([ws[0].title, j, 17, 16])
            return True
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ相関チェック処理
    ###########################################################################
    def check_correlate():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal correlate_warn
            nonlocal correlate_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ相関チェック処理（0000）
            ### (1)セル[8:2]からセル[8:17]について他項目との相関関係が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)HOJOワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo.check_correlate()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 8:
                for j in range(8, max_row[i]+1):
                    pass
                    ### セル[8:1]: NO.が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:2]: 水系・沿岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:3]: 水系種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:4]: 河川・海岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:5]: 河川種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:6]: 都道府県コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:7]: 工事番号が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:8]: 枝番が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:9]: 工事区分が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:10]: 市区町村コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:11]: 工種区分が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:12]:
                    ### セル[8:13]: 異常気象コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:14]: 水害発生月が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:15]: 水害発生日が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:16]: 決定額(千円)が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[8:17]: 備考が何かの値のときに、相関する他項目は正しく選択されているか。
            return True
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ突合チェック処理
    ###########################################################################
    def check_compare():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal compare_warn
            nonlocal compare_info
            ### nonlocal max_row
            ### nonlocal ken_code_list
            ### nonlocal ken_name_list
            ### nonlocal ken_name_code_list
            ### nonlocal city_code_list
            ### nonlocal city_name_list
            ### nonlocal city_name_code_list
            ### nonlocal suikei_code_list
            ### nonlocal suikei_name_list
            ### nonlocal suikei_name_code_list
            ### nonlocal suikei_type_code_list
            ### nonlocal suikei_type_name_list
            ### nonlocal suikei_type_name_code_list
            ### nonlocal kasen_code_list
            ### nonlocal kasen_name_list
            ### nonlocal kasen_name_code_list
            ### nonlocal kasen_type_code_list
            ### nonlocal kasen_type_name_list
            ### nonlocal kasen_type_name_code_list
            ### nonlocal kasen_kaigan_code_list
            ### nonlocal kasen_kaigan_name_list
            ### nonlocal kasen_kaigan_name_code_list
            ### nonlocal weather_id_list
            ### nonlocal weather_name_list
            ### nonlocal weather_name_id_list
            ###################################################################
            ### 関数内関数：EXCELセルデータ突合チェック処理（0000）
            ### (1)セル[8:2]からセル[8:17]についてデータベースに登録されている値と突合せチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)HOJOワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo.check_compare()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 8:
                for j in range(8, max_row[i]+1):
                    ### セル[8:1]: NO.についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:2]: 水系・沿岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=2).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=2).value not in list(building_code_list) and \
                            ws[0].cell(row=j, column=2).value not in list(building_name_list) and \
                            ws[0].cell(row=j, column=2).value not in list(building_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=401)
                            ### compare_warn.append([ws[0].title, j, 2, constants.HOJ_COM_MSG[401][0], constants.HOJ_COM_MSG[401][1], constants.HOJ_COM_MSG[401][2], constants.HOJ_COM_MSG[401][3], constants.HOJ_COM_MSG[401][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.HOJ_COM_MSG)
                            compare_warn.append([ws[0].title, j, 2, constants.HOJ_COM_MSG[1][0], constants.HOJ_COM_MSG[1][1], constants.HOJ_COM_MSG[1][2], constants.HOJ_COM_MSG[1][3], constants.HOJ_COM_MSG[1][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 2, 401])
                            compare_info.append([ws[0].title, j, 2, 1])
                    
                    ### セル[8:3]: 水系種別[全角]についてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=4).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=3).value not in list(building_code_list) and \
                            ws[0].cell(row=j, column=3).value not in list(building_name_list) and \
                            ws[0].cell(row=j, column=3).value not in list(building_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=402)
                            ### compare_warn.append([ws[0].title, j, 3, constants.HOJ_COM_MSG[402][0], constants.HOJ_COM_MSG[402][1], constants.HOJ_COM_MSG[402][2], constants.HOJ_COM_MSG[402][3], constants.HOJ_COM_MSG[402][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.HOJ_COM_MSG)
                            compare_warn.append([ws[0].title, j, 3, constants.HOJ_COM_MSG[2][0], constants.HOJ_COM_MSG[2][1], constants.HOJ_COM_MSG[2][2], constants.HOJ_COM_MSG[2][3], constants.HOJ_COM_MSG[2][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 3, 402])
                            compare_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[8:4]: 河川・海岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=4).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=4).value not in list(underground_code_list) and \
                            ws[0].cell(row=j, column=4).value not in list(underground_name_list) and \
                            ws[0].cell(row=j, column=4).value not in list(underground_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=403)
                            ### compare_warn.append([ws[0].title, j, 4, constants.HOJ_COM_MSG[403][0], constants.HOJ_COM_MSG[403][1], constants.HOJ_COM_MSG[403][2], constants.HOJ_COM_MSG[403][3], constants.HOJ_COM_MSG[403][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.HOJ_COM_MSG)
                            compare_warn.append([ws[0].title, j, 4, constants.HOJ_COM_MSG[3][0], constants.HOJ_COM_MSG[3][1], constants.HOJ_COM_MSG[3][2], constants.HOJ_COM_MSG[3][3], constants.HOJ_COM_MSG[3][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 4, 403])
                            compare_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[8:5]: 河川種別[全角]についてデータベースに登録されている値と突合せチェックする。
                    if ws[0].cell(row=j, column=5).value is None:
                        pass
                    else:
                        if ws[0].cell(row=j, column=5).value not in list(flood_sediment_code_list) and \
                            ws[0].cell(row=j, column=5).value not in list(flood_sediment_name_list) and \
                            ws[0].cell(row=j, column=5).value not in list(flood_sediment_name_code_list):
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=404)
                            ### compare_warn.append([ws[0].title, j, 5, constants.HOJ_COM_MSG[404][0], constants.HOJ_COM_MSG[404][1], constants.HOJ_COM_MSG[404][2], constants.HOJ_COM_MSG[404][3], constants.HOJ_COM_MSG[404][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.HOJ_COM_MSG)
                            compare_warn.append([ws[0].title, j, 5, constants.HOJ_COM_MSG[4][0], constants.HOJ_COM_MSG[4][1], constants.HOJ_COM_MSG[4][2], constants.HOJ_COM_MSG[4][3], constants.HOJ_COM_MSG[4][4]])
                        else:
                            ### compare_info.append([ws[0].title, j, 5, 404])
                            compare_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[8:6]: 都道府県コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:7]: 工事番号についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:8]: 枝番についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:9]: 工事区分についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:10]: 市区町村コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:11]: 工種区分についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:12]: 
                    ### セル[8:13]: 異常気象コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:14]: 水害発生月についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:15]: 水害発生日についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:16]: 決定額(千円)についてデータベースに登録されている値と突合せチェックする。
                    ### セル[8:17]: 備考についてデータベースに登録されている値と突合せチェックする。
            return True
        except:
            return False

    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.browser_post_hojo()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 1/30.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 2/30.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 3/30.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.browser_post_hojo()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.browser_post_hojo()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
        
        #######################################################################
        ### 局所変数セット処理(0030)
        ### チェック用の局所変数を初期化する。
        #######################################################################
        print_log('[DEBUG] P0120ken.browser_post_hojo()関数 STEP 4/30.', 'DEBUG')
        ### 必須チェック用の局所変数を初期化する。
        require_info = []
        require_warn = []

        ### 形式チェック用の局所変数を初期化する。
        format_info = []
        format_warn = []

        ### 範囲チェック用の局所変数を初期化する。
        range_info = []
        range_warn = []

        ### 相関チェック用の局所変数を初期化する。
        correlate_info = []
        correlate_warn = []

        ### 突合せチェックの結果を格納する
        compare_info = []
        compare_warn = []
    
        #######################################################################
        ### 局所変数セット処理(0040)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 5/30.', 'DEBUG')
        form = UploadHojoForm(request.POST, request.FILES)
            
        #######################################################################
        ### フォーム検証処理(0050)
        ### (1)フォームが正しい場合、処理を継続する。
        ### (2)フォームが正しくない場合、ERROR画面を表示して関数を抜ける。
        ### ※ネストを浅くするため。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 6/30.', 'DEBUG')
        if form.is_valid() == False:
            print_log('[WARN] P0120Ken.browser_post_hojo()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
    
        #######################################################################
        ### EXCEL入出力処理(1000)
        ### (1)局所変数に値をセットする。
        ### (2)アップロードされた公共土木施設補助事業調査票ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 7/30.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_Ym = datetime.now(JST).strftime('%Y%m')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        
        upload_file_object = request.FILES['file']
        upload_file_name, upload_file_ext = os.path.splitext(request.FILES['file'].name)
        upload_file_name = upload_file_name + '_' + datetime_now_YmdHMS + '.xlsx'
        ### upload_file_path = 'static/repository/' + datetime_now_Ym + '/' + upload_file_name
        upload_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + upload_file_name

        output_file_name, output_file_ext = os.path.splitext(request.FILES['file'].name)
        output_file_name = output_file_name + '_' + datetime_now_YmdHMS + '_output' + '.xlsx'
        ### output_file_path = 'static/repository/' + datetime_now_Ym + '/' + output_file_name
        output_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + output_file_name
        
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 upload_file_object={}'.format(upload_file_object), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 upload_file_path={}'.format(upload_file_path), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 upload_file_name={}'.format(upload_file_name), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 output_file_path={}'.format(output_file_path), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 output_file_name={}'.format(output_file_name), 'DEBUG')
        
        with open(upload_file_path, 'wb+') as destination:
            for chunk in upload_file_object.chunks():
                destination.write(chunk)
                
        #######################################################################
        ### EXCEL入出力処理(1010)
        ### (1)アップロードされた補助事業調査票ファイルのワークブックを読み込む。
        ### (2)HOJOワークシートをコピーして、チェック結果を格納するCHECK_RESULTワークシートを追加する。
        ### (3)追加したワークシートを2シート目に移動する。
        ### (4)ワークシートの最大行数を局所変数のmax_rowにセットする。
        ### (5)背景赤色の塗りつぶしを局所変数のfillにセットする。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 8/30.', 'DEBUG')
        wb = openpyxl.load_workbook(upload_file_path)
        ws = []
        ws_result = []
        ws_title = []
        for ws_temp in wb.worksheets:
            if 'HOJO' in ws_temp.title:
                ws.append(ws_temp)
                ws_result.append(wb.copy_worksheet(ws_temp))
                ws_result[-1].title = 'RESULT' + ws_temp.title
                ws_title.append(ws_temp.title)
                
        for ws_temp in wb.worksheets:
            if 'RESULT' in ws_temp.title:
                wb.move_sheet(ws_temp.title, offset=-wb.index(ws_temp))
                wb.move_sheet(ws_temp.title, offset=1)
        
        for ws_temp in wb.worksheets:
            ws_temp.sheet_view.tabSelected = None
            
        wb.active = 1

        #######################################################################
        ### EXCEL入出力処理(1020)
        ### (1)EXCELシート毎に最大行を探索する。
        ### (2)局所変数のmax_rowリストに追加する。
        ### ※max_row_tempの初期値の7はNO.、水系・沿岸名等のキャプション部分のEXCEL行番号である。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 9/30.', 'DEBUG')
        max_row = []
        for ws_temp in ws:
            ### EXCELシート毎に最大行を探索する。
            max_row_temp = 7
            for i in range(ws_temp.max_row+1, 7, -1):
                if ws_temp.cell(row=i, column=2).value is None:
                    pass
                else:
                    max_row_temp = i
                    break
            ### 局所変数のmax_rowリストに追加する。
            max_row.append(max_row_temp)

        #######################################################################
        ### EXCEL入出力処理(1030)
        ### EXCELセルの背景赤色を局所変数のfillに設定する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 10/30.', 'DEBUG')
        fill = openpyxl.styles.PatternFill(patternType='solid', fgColor='FF0000', bgColor='FF0000')

        #######################################################################
        ### DBアクセス処理(2000)
        ### (1)DBから突合せチェック用のデータを取得する。
        ### (2)突合せチェック用のリストを生成する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 11/30.', 'DEBUG')
        ### DBから突合せチェック用のデータを取得する。
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        city_list = CITY.objects.raw("""SELECT * FROM CITY ORDER BY CAST(CITY_CODE AS INTEGER)""")
        ### cause_list
        ### area_list
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_list = KASEN.objects.raw("""SELECT * FROM KASEN ORDER BY CAST(KASEN_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        ### gradient_list
        kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(KASEN_KAIGAN_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")
        ### building_list
        ### underground_list
        ### flood_sediment_list
        industry_list = INDUSTRY.objects.raw("""SELECT * FROM INDUSTRY ORDER BY CAST(INDUSTRY_CODE AS INTEGER)""")
        ### business_list
        ### usage_list
        
        ### 突合せチェック用のリストを生成する。
        ken_code_list = [ken.ken_code for ken in ken_list]
        ken_name_list = [ken.ken_name for ken in ken_list]
        ken_name_code_list = [str(ken.ken_name) + ":" + str(ken.ken_code) for ken in ken_list]
        city_code_list = [city.city_code for city in city_list]
        city_name_list = [city.city_name for city in city_list]
        city_name_code_list = [str(city.city_name) + ":" + str(city.city_code) for city in city_list]
        ### cause_code_list
        ### cause_name_list
        ### cause_name_code_list
        ### area_id_list
        ### area_name_list
        ### area_name_id_list
        suikei_code_list = [suikei.suikei_code for suikei in suikei_list]
        suikei_name_list = [suikei.suikei_name for suikei in suikei_list]
        suikei_name_code_list = [str(suikei.suikei_name) + ":" + str(suikei.suikei_code) for suikei in suikei_list]
        suikei_type_code_list = [suikei_type.suikei_type_code for suikei_type in suikei_type_list]
        suikei_type_name_list = [suikei_type.suikei_type_name for suikei_type in suikei_type_list]
        suikei_type_name_code_list = [str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code) for suikei_type in suikei_type_list]
        kasen_code_list = [kasen.kasen_code for kasen in kasen_list]
        kasen_name_list = [kasen.kasen_name for kasen in kasen_list]
        kasen_name_code_list = [str(kasen.kasen_name) + ":" + str(kasen.kasen_code) for kasen in kasen_list]
        kasen_type_code_list = [kasen_type.kasen_type_code for kasen_type in kasen_type_list]
        kasen_type_name_list = [kasen_type.kasen_type_name for kasen_type in kasen_type_list]
        kasen_type_name_code_list = [str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code) for kasen_type in kasen_type_list]
        ### gradient_code_list
        ### gradient_name_list
        ### gradient_name_code_list
        kasen_kaigan_code_list = [kasen_kaigan.kasen_kaigan_code for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_list = [kasen_kaigan.kasen_kaigan_name for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_code_list = [str(kasen_kaigan.kasen_kaigan_name) + ":" + str(kasen_kaigan.kasen_kaigan_code) for kasen_kaigan in kasen_kaigan_list]
        weather_id_list = [weather.weather_id for weather in weather_list]
        weather_name_list = [weather.weather_name for weather in weather_list]
        weather_name_id_list = [str(weather.weather_name) + ":" + str(weather.weather_id) for weather in weather_list]
        ### building_code_list
        ### building_name_list
        ### building_name_code_list
        ### underground_code_list
        ### underground_name_list
        ### underground_name_code_list
        ### flood_sediment_code_list
        ### flood_sediment_name_list
        ### flood_sediment_name_code_list
        ### industry_code_list
        ### industry_name_list
        ### industry_name_code_list
        ### business_code_list
        ### business_name_list
        ### business_name_code_list
        ### usage_code_list
        ### usage_name_list
        ### usage_name_code_list
    
        #######################################################################
        ### 必須、形式、範囲、相関、突合せチェック処理(2010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 12/30.', 'DEBUG')
        bool_return = check_require()
        if bool_return == False:
            print_log('[ERROR] check_require()関数が異常終了しました。', 'ERROR')
            raise Exception
            
        bool_return = check_format()
        if bool_return == False:
            print_log('[ERROR] check_format()関数が異常終了しました。', 'ERROR')
            raise Exception

        bool_return = check_range()
        if bool_return == False:
            print_log('[ERROR] check_range()関数が異常終了しました。', 'ERROR')
            raise Exception

        bool_return = check_correlate()
        if bool_return == False:
            print_log('[ERROR] check_correlate()関数が異常終了しました。', 'ERROR')
            raise Exception

        bool_return = check_compare()
        if bool_return == False:
            print_log('[ERROR] check_compare()関数が異常終了しました。', 'ERROR')
            raise Exception

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(3000)
        ### チェック結果ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 13/30.', 'DEBUG')
        wb.save(output_file_path)

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(3010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 14/30.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 max_row={}'.format(max_row), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(require_warn)={}'.format(len(require_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(format_warn)={}'.format(len(format_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(range_warn)={}'.format(len(range_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(correlate_warn)={}'.format(len(correlate_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(compare_warn)={}'.format(len(compare_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(require_info)={}'.format(len(require_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(format_info)={}'.format(len(format_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(range_info)={}'.format(len(range_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(correlate_info)={}'.format(len(correlate_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 len(compare_info)={}'.format(len(compare_info)), 'DEBUG')
        
        #######################################################################
        ### ファイル入出力処理、ログ出力処理(3020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 15/30.', 'DEBUG')
        info_str = ''
        warn_str = ''
        if len(require_info) > 0:
            for i in range(len(require_info)):
                info_str = info_str + \
                    str(require_info[i][0]) + ',' + \
                    str(require_info[i][1]) + ',' + \
                    str(require_info[i][2]) + ',' + \
                    str(constants.HOJ_REQ_MSG[require_info[i][3]][0]) + ',' + \
                    str(constants.HOJ_REQ_MSG[require_info[i][3]][1]) + ',' + \
                    str(constants.HOJ_REQ_MSG[require_info[i][3]][2]) + '\n'        
        
        if len(format_info) > 0:
            for i in range(len(format_info)):
                info_str = info_str + \
                    str(format_info[i][0]) + ',' + \
                    str(format_info[i][1]) + ',' + \
                    str(format_info[i][2]) + ',' + \
                    str(constants.HOJ_FOR_MSG[format_info[i][3]][0]) + ',' + \
                    str(constants.HOJ_FOR_MSG[format_info[i][3]][1]) + ',' + \
                    str(constants.HOJ_FOR_MSG[format_info[i][3]][2]) + '\n'        

        if len(range_info) > 0:
            for i in range(len(range_info)):
                info_str = info_str + \
                    str(range_info[i][0]) + ',' + \
                    str(range_info[i][1]) + ',' + \
                    str(range_info[i][2]) + ',' + \
                    str(constants.HOJ_RAN_MSG[range_info[i][3]][0]) + ',' + \
                    str(constants.HOJ_RAN_MSG[range_info[i][3]][1]) + ',' + \
                    str(constants.HOJ_RAN_MSG[range_info[i][3]][2]) + '\n'        

        if len(correlate_info) > 0:
            for i in range(len(correlate_info)):
                info_str = info_str + \
                    str(correlate_info[i][0]) + ',' + \
                    str(correlate_info[i][1]) + ',' + \
                    str(correlate_info[i][2]) + ',' + \
                    str(constants.HOJ_COR_MSG[correlate_info[i][3]][0]) + ',' + \
                    str(constants.HOJ_COR_MSG[correlate_info[i][3]][1]) + ',' + \
                    str(constants.HOJ_COR_MSG[correlate_info[i][3]][2]) + '\n'        

        if len(compare_info) > 0:
            for i in range(len(compare_info)):
                info_str = info_str + \
                    str(compare_info[i][0]) + ',' + \
                    str(compare_info[i][1]) + ',' + \
                    str(compare_info[i][2]) + ',' + \
                    str(constants.HOJ_COM_MSG[compare_info[i][3]][0]) + ',' + \
                    str(constants.HOJ_COM_MSG[compare_info[i][3]][1]) + ',' + \
                    str(constants.HOJ_COM_MSG[compare_info[i][3]][2]) + '\n'        

        if len(require_warn) > 0:
            for i in range(len(require_warn)):
                warn_str = warn_str + \
                    str(require_warn[i][0]) + ',' + \
                    str(require_warn[i][1]) + ',' + \
                    str(require_warn[i][2]) + ',' + \
                    str(constants.HOJ_REQ_MSG[require_warn[i][3]][0]) + ',' + \
                    str(constants.HOJ_REQ_MSG[require_warn[i][3]][1]) + ',' + \
                    str(constants.HOJ_REQ_MSG[require_warn[i][3]][2]) + '\n'        
        
        if len(format_warn) > 0:
            for i in range(len(format_warn)):
                warn_str = warn_str + \
                    str(format_warn[i][0]) + ',' + \
                    str(format_warn[i][1]) + ',' + \
                    str(format_warn[i][2]) + ',' + \
                    str(constants.HOJ_FOR_MSG[format_warn[i][3]][0]) + ',' + \
                    str(constants.HOJ_FOR_MSG[format_warn[i][3]][1]) + ',' + \
                    str(constants.HOJ_FOR_MSG[format_warn[i][3]][2]) + '\n'        

        if len(range_warn) > 0:
            for i in range(len(range_warn)):
                warn_str = warn_str + \
                    str(range_warn[i][0]) + ',' + \
                    str(range_warn[i][1]) + ',' + \
                    str(range_warn[i][2]) + ',' + \
                    str(constants.HOJ_RAN_MSG[range_warn[i][3]][0]) + ',' + \
                    str(constants.HOJ_RAN_MSG[range_warn[i][3]][1]) + ',' + \
                    str(constants.HOJ_RAN_MSG[range_warn[i][3]][2]) + '\n'

        if len(correlate_warn) > 0:
            for i in range(len(correlate_warn)):
                warn_str = warn_str + \
                    str(correlate_warn[i][0]) + ',' + \
                    str(correlate_warn[i][1]) + ',' + \
                    str(correlate_warn[i][2]) + ',' + \
                    str(constants.HOJ_COR_MSG[correlate_warn[i][3]][0]) + ',' + \
                    str(constants.HOJ_COR_MSG[correlate_warn[i][3]][1]) + ',' + \
                    str(constants.HOJ_COR_MSG[correlate_warn[i][3]][2]) + '\n'        

        if len(compare_warn) > 0:
            for i in range(len(compare_warn)):
                warn_str = warn_str + \
                    str(compare_warn[i][0]) + ',' + \
                    str(compare_warn[i][1]) + ',' + \
                    str(compare_warn[i][2]) + ',' + \
                    str(constants.HOJ_COM_MSG[compare_warn[i][3]][0]) + ',' + \
                    str(constants.HOJ_COM_MSG[compare_warn[i][3]][1]) + ',' + \
                    str(constants.HOJ_COM_MSG[compare_warn[i][3]][2]) + '\n'        

        #######################################################################
        ### DBアクセス処理(4000)
        ### ※入力チェックで警告が発見された場合に処理する。
        ### ※ネストを浅くするために、処理対象外の場合、終了させる。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 16/30.', 'DEBUG')
        if len(require_warn) > 0 or len(format_warn) > 0 or \
            len(range_warn) > 0 or len(correlate_warn) > 0 or \
            len(compare_warn) > 0:

            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")
                
                ###############################################################
                ### DBアクセス処理(4010)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の都道府県のHOJO_HEADERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 17/30.', 'DEBUG')
                params = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=8, column=6).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE HOJO_HEADER SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE hojo_header_id IN (
                    SELECT 
                        hojo_header_id 
                    FROM HOJO_HEADER 
                    WHERE 
                        ken_code=%(KEN_CODE)s AND 
                        deleted_at IS NULL)""", params)
        
                ###############################################################
                ### DBアクセス処理(4020)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の都道府県のHOJOのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 18/30.', 'DEBUG')
                params = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=8, column=6).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE HOJO SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE hojo_id IN (
                    SELECT 
                        hojo_id 
                    FROM HOJO_VIEW 
                    WHERE 
                        ken_code=%(KEN_CODE)s AND 
                        deleted_at IS NULL)""", params)
    
                ###############################################################
                ### DBアクセス処理(4030)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の都道府県のHOJO_SUMMARYのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 19/30.', 'DEBUG')
                params = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=8, column=6).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE HOJO_SUMMARY SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE hojo_id IN (
                    SELECT 
                        hojo_id 
                    FROM HOJO_SUMMARY_VIEW 
                    WHERE 
                        ken_code=%(KEN_CODE)s AND 
                        deleted_at IS NULL)""", params)
    
                ###############################################################
                ### DBアクセス処理(4040)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の都道府県のHOJO_TRIGGERのデータは、削除日時をセットして、削除済の扱いとする。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 20/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'ken_code': split_name_code(ws[0].cell(row=8, column=6).value)[-1], 
                    'action_code': _E01
                })
                bool_return = delete_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] delete_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
                ###############################################################
                ### DBアクセス処理(4050)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※トリガーテーブルにHOJ_ACT_01トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 21/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': None, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[0].cell(row=8, column=6).value)[-1]), 
                    'city_code': None, 
                    'action_code': _HOJ_ACT_01, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': get_info_log(), 
                    'warn_log': get_warn_log(), 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                    
                ###############################################################
                ### DBアクセス処理(4060)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※トリガーテーブルにHOJ_ACT_02トリガーを実行済、失敗として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 22/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': None, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[0].cell(row=8, column=6).value)[-1]), 
                    'city_code': None, 
                    'action_code': _HOJ_ACT_02, 
                    'status_code': _FAILURE, 
                    'info_count': 0, 
                    'warn_count': len(ws), 
                    'info_log': info_str, 
                    'warn_log': warn_str, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
                connection_cursor.execute("""COMMIT""")
                
            except:
                print_log('[ERROR] P0120Ken.browser_post_hojo()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] P0120Ken.browser_post_hojo()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
                print_log('[ERROR] P0120Ken.browser_post_hojo()関数が異常終了しました。', 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
            finally:
                connection_cursor.close()
                
            ###################################################################
            ### レスポンスセット処理(4070)
            ### ※入力チェックで警告が発見された場合、
            ### ※テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 23/30.', 'DEBUG')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'browser_post_hojo_warn': 'browser_post_hojo_warn',
                'require_warn': require_warn,
                'format_warn': format_warn,
                'range_warn': range_warn,
                'correlate_warn': correlate_warn,
                'compare_warn': compare_warn,
                'output_file_path': output_file_path, 
            }
            print_log('[WARN] P0120Ken.browser_post_hojo()関数が警告終了しました。', 'INFO')
            return False, HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(5000)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        ### ※入力データ_ヘッダ部分テーブルにデータを登録する。
        ### ※入力データ_一覧票部分テーブルにデータを登録する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 24/30.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")
            
            ###################################################################
            ### DBアクセス処理(5010)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の都道府県のHOJO_HEADERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 25/30.', 'DEBUG')
            params = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=8, column=6).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE HOJO_HEADER SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE hojo_header_id IN (
                SELECT 
                    hojo_header_id 
                FROM HOJO_HEADER 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL)""", params)
    
            ###################################################################
            ### DBアクセス処理(5020)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の都道府県のHOJOのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 26/30.', 'DEBUG')
            params = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=8, column=6).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE HOJO SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE hojo_id IN (
                SELECT 
                    hojo_id 
                FROM HOJO_VIEW 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL)""", params)

            ###################################################################
            ### DBアクセス処理(5030)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の都道府県のHOJO_SUMMARYのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 27/30.', 'DEBUG')
            params = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=8, column=6).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE HOJO_SUMMARY SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE hojo_id IN (
                SELECT 
                    hojo_id 
                FROM HOJO_SUMMARY_VIEW 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL)""", params)

            ###################################################################
            ### DBアクセス処理(5040)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の都道府県のHOJO_TRIGGERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 28/30.', 'DEBUG')
            metadata = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': split_name_code(ws[0].cell(row=8, column=6).value)[-1], 
                'city_code': None, 
                'action_code': _HOJ_ACT_01
            })
            bool_return = delete_message(metadata=metadata)
            if bool_return == False:
                print_log('[ERROR] delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            ###################################################################
            ### DBアクセス処理(5050)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※hojo_header_id__max で正しい。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 29/30.', 'DEBUG')
            for i, _ in enumerate(ws):
                hojo_header_id = HOJO_HEADER.objects.all().aggregate(Max('hojo_header_id'))['hojo_header_id__max']
                if hojo_header_id is None:
                    hojo_header_id = 1
                else:
                    hojo_header_id += 1
                    
                ###############################################################
                ### DBアクセス処理(5060)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### 補助事業調査票_ヘッダ部分テーブルにデータを登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 29_1/30.', 'DEBUG')
                params = dict({
                    'HOJO_HEADER_ID': hojo_header_id, 
                    'HOJO_HEADER_NAME': ws_title[i], 
                    'KEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=8, column=6).value)[-1]), 
                    'UPLOAD_FILE_PATH': upload_file_path, 
                    'UPLOAD_FILE_NAME': upload_file_name, 
                    'SUMMARY_FILE_PATH': None, 
                    'SUMMARY_FILE_NAME': None, 
                    'DELETED_AT': None
                })
                connection_cursor.execute("""
                    INSERT INTO HOJO_HEADER (
                        hojo_header_id, hojo_header_name, ken_code, 
                        upload_file_path, upload_file_name, summary_file_path, summary_file_name, 
                        committed_at, deleted_at 
                    ) VALUES (
                        %(HOJO_HEADER_ID)s, 
                        %(HOJO_HEADER_NAME)s, 
                        %(KEN_CODE)s, 
                        %(UPLOAD_FILE_PATH)s, 
                        %(UPLOAD_FILE_NAME)s, 
                        %(SUMMARY_FILE_PATH)s, 
                        %(SUMMARY_FILE_NAME)s, 
                        CURRENT_TIMESTAMP,  -- committed_at 
                        %(DELETED_AT)s)""", params)
                    
                ###############################################################
                ### DBアクセス処理(5070)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※補助事業調査票_一覧表部分テーブルにデータを登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 29_2/30.', 'DEBUG')
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 max_row[i]={}'.format(max_row[i]), 'DEBUG')
                if max_row[i] >= 8:
                    for j in range(8, max_row[i]+1):
                        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 j={}'.format(j), 'DEBUG')
                        params = dict({
                            'HOJO_NAME': convert_empty_to_none(ws[i].cell(row=j, column=2).value), 
                            'HOJO_HEADER_ID': hojo_header_id, 
                            'CITY_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=10).value)[-1]), 
                            'BEGIN_DATE': convert_empty_to_none(ws[i].cell(row=j, column=14).value), 
                            'SUIKEI_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=2).value)[-1]), 
                            'SUIKEI_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=3).value)[-1]), 
                            'KASEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=4).value)[-1]), 
                            'KASEN_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=5).value)[-1]), 
                            'KASEN_KAIGAN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=10).value)[-1]), 
                            'WEATHER_ID': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=13).value)[-1]), 
                            'KOJI_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=7).value)[-1]), 
                            'BRANCH_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=8).value)[-1]), 
                            'KOJI_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=9).value)[-1]), 
                            'KOSH_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=11).value)[-1]), 
                            'DETERMINED_COST': convert_empty_to_none(ws[i].cell(row=j, column=16).value), 
                            'COMMENT': convert_empty_to_none(ws[i].cell(row=j, column=17).value), 
                            'DELETED_AT': None
                        })
                        connection_cursor.execute(""" 
                            INSERT INTO HOJO (
                                hojo_id, hojo_name, hojo_header_id, 
                                city_code, begin_date, 
                                suikei_code, suikei_type_code, kasen_code, kasen_type_code, kasen_kaigan_code, weather_id, 
                                koji_code, branch_code, koji_type_code, kosh_type_code, determined_cost, comment, 
                                committed_at, deleted_at 
                            ) VALUES (
                                (SELECT CASE WHEN (MAX(hojo_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(hojo_id+1) AS INTEGER) END AS hojo_id FROM HOJO), -- hojo_id 
                                %(HOJO_NAME)s, 
                                %(HOJO_HEADER_ID)s, 
                                %(CITY_CODE)s, 
                                TO_DATE(%(BEGIN_DATE)s, 'YYYY/MM/DD'), 
                                %(SUIKEI_CODE)s, 
                                %(SUIKEI_TYPE_CODE)s, 
                                %(KASEN_CODE)s, 
                                %(KASEN_TYPE_CODE)s, 
                                %(KASEN_KAIGAN_CODE)s, 
                                %(WEATHER_ID)s, 
                                %(KOJI_CODE)s, 
                                %(BRANCH_CODE)s, 
                                %(KOJI_TYPE_CODE)s, 
                                %(KOSH_TYPE_CODE)s, 
                                %(DETERMINED_COST)s, 
                                %(COMMENT)s, 
                                CURRENT_TIMESTAMP, -- committed_at 
                                %(DELETED_AT)s)""", params)

                ###############################################################
                ### DBアクセス処理(5080)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにHOJ_ACT_01トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 29_3/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': hojo_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[i].cell(row=8, column=6).value)[-1]), 
                    'city_code': None, 
                    'action_code': _HOJ_ACT_01, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': get_info_log(), 
                    'warn_log': get_warn_log(), 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception

                ###############################################################
                ### DBアクセス処理(5090)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにHOJ_ACT_02トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 29_4/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': hojo_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[i].cell(row=8, column=6).value)[-1]), 
                    'city_code': None, 
                    'action_code': _HOJ_ACT_02, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': info_str, 
                    'warn_log': warn_str, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
            
                ###############################################################
                ### DBアクセス処理(5100)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにHOJ_ACT_03トリガーを未実行＝次回実行対象として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 29_5/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': hojo_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[i].cell(row=8, column=6).value)[-1]), 
                    'city_code': None, 
                    'action_code': _HOJ_ACT_03, 
                    'status_code': _RUNNING, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
            connection_cursor.execute("""COMMIT""")   
            
        except:
            print_log('[ERROR] P0120Ken.browser_post_hojo()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0120Ken.browser_post_hojo()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0120Ken.browser_post_hojo()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
            
        finally:
            connection_cursor.close()
        
        #######################################################################
        ### レスポンスセット処理(5110)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        ### ※テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_hojo()関数 STEP 30/30.', 'DEBUG')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'browser_post_hojo_info': 'browser_post_hojo_info',
            'require_info': require_info, 
            'format_info': format_info,
            'range_info': range_info,
            'correlate_info': correlate_info,
            'compare_info': compare_info,
        }
        print_log('[INFO] P0120Ken.browser_post_hojo()関数が正常終了しました。', 'INFO')
        return True, HttpResponse(template.render(context, request))
        
    except:
        print_log('[ERROR] P0120Ken.browser_post_hojo()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_post_hojo()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_post_hojo()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))

###############################################################################
### 都道府県用ブラウザ都アップロードファイル
###############################################################################
def browser_post_koeki(request):

    ###########################################################################
    ### 関数内関数：EXCELセルデータ必須チェック処理
    ###########################################################################
    def check_require():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal require_warn
            nonlocal require_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ必須チェック処理（0000）
            ### (1)セル[9:2]からセル[9:33]について、必須項目に値がセットされていることをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### ※max_rowの9は入力部分の開始EXCEL行番号である。
            ### ※max_rowの9はNO.、水系・沿岸名等のキャプション部分の1つ下のEXCEL行番号である。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki.check_require()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 9:
                for j in range(9, max_row[0]+1):
                    ### セル[9:1]: NO.に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=1).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=0, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 1, constants.KOE_REQ_MSG[0][0], constants.KOE_REQ_MSG[0][1], constants.KOE_REQ_MSG[0][2], constants.KOE_REQ_MSG[0][3], constants.KOE_REQ_MSG[0][4]])
                    else:
                        require_info.append([ws[0].title, j, 1, 0])
    
                    ### セル[9:2]: 水害発生開始月に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=2).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 2, constants.KOE_REQ_MSG[1][0], constants.KOE_REQ_MSG[1][1], constants.KOE_REQ_MSG[1][2], constants.KOE_REQ_MSG[1][3], constants.KOE_REQ_MSG[1][4]])
                    else:
                        require_info.append([ws[0].title, j, 2, 1])
                        
                    ### セル[9:3]: 水害発生開始日に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=3).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 3, constants.KOE_REQ_MSG[2][0], constants.KOE_REQ_MSG[2][1], constants.KOE_REQ_MSG[2][2], constants.KOE_REQ_MSG[2][3], constants.KOE_REQ_MSG[2][4]])
                    else:
                        require_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[9:4]: 水害発生終了月に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=4).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 4, constants.KOE_REQ_MSG[3][0], constants.KOE_REQ_MSG[3][1], constants.KOE_REQ_MSG[3][2], constants.KOE_REQ_MSG[3][3], constants.KOE_REQ_MSG[3][4]])
                    else:
                        require_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[9:5]: 水害発生終了日に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=5).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 5, constants.KOE_REQ_MSG[4][0], constants.KOE_REQ_MSG[4][1], constants.KOE_REQ_MSG[4][2], constants.KOE_REQ_MSG[4][3], constants.KOE_REQ_MSG[4][4]])
                    else:
                        require_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[9:6]: 被害箇所_都道府県名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=6).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 6, constants.KOE_REQ_MSG[5][0], constants.KOE_REQ_MSG[5][1], constants.KOE_REQ_MSG[5][2], constants.KOE_REQ_MSG[5][3], constants.KOE_REQ_MSG[5][4]])
                    else:
                        require_info.append([ws[0].title, j, 6, 5])
    
                    ### セル[9:7]: 被害箇所_都道府県コードに値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=7).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 7, constants.KOE_REQ_MSG[6][0], constants.KOE_REQ_MSG[6][1], constants.KOE_REQ_MSG[6][2], constants.KOE_REQ_MSG[6][3], constants.KOE_REQ_MSG[6][4]])
                    else:
                        require_info.append([ws[0].title, j, 7, 6])
    
                    ### セル[9:8]: 被害箇所_市区町村名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=8).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 8, constants.KOE_REQ_MSG[7][0], constants.KOE_REQ_MSG[7][1], constants.KOE_REQ_MSG[7][2], constants.KOE_REQ_MSG[7][3], constants.KOE_REQ_MSG[7][4]])
                    else:
                        require_info.append([ws[0].title, j, 8, 7])
    
                    ### セル[9:9]: 被害箇所_市区町村コードに値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=9).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 9, constants.KOE_REQ_MSG[8][0], constants.KOE_REQ_MSG[8][1], constants.KOE_REQ_MSG[8][2], constants.KOE_REQ_MSG[8][3], constants.KOE_REQ_MSG[8][4]])
                    else:
                        require_info.append([ws[0].title, j, 9, 8])
    
                    ### セル[9:10]: 被害箇所_町丁名・大字名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=10).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=9, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 10, constants.KOE_REQ_MSG[9][0], constants.KOE_REQ_MSG[9][1], constants.KOE_REQ_MSG[9][2], constants.KOE_REQ_MSG[9][3], constants.KOE_REQ_MSG[9][4]])
                    else:
                        require_info.append([ws[0].title, j, 10, 9])
    
                    ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=11).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 11, constants.KOE_REQ_MSG[10][0], constants.KOE_REQ_MSG[10][1], constants.KOE_REQ_MSG[10][2], constants.KOE_REQ_MSG[10][3], constants.KOE_REQ_MSG[10][4]])
                    else:
                        require_info.append([ws[0].title, j, 11, 10])
    
                    ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=12).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=11, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 12, constants.KOE_REQ_MSG[11][0], constants.KOE_REQ_MSG[11][1], constants.KOE_REQ_MSG[11][2], constants.KOE_REQ_MSG[11][3], constants.KOE_REQ_MSG[11][4]])
                    else:
                        require_info.append([ws[0].title, j, 12, 11])
    
                    ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=13).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 13, constants.KOE_REQ_MSG[12][0], constants.KOE_REQ_MSG[12][1], constants.KOE_REQ_MSG[12][2], constants.KOE_REQ_MSG[12][3], constants.KOE_REQ_MSG[12][4]])
                    else:
                        require_info.append([ws[0].title, j, 13, 12])
    
                    ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=14).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 14, constants.KOE_REQ_MSG[13][0], constants.KOE_REQ_MSG[13][1], constants.KOE_REQ_MSG[13][2], constants.KOE_REQ_MSG[13][3], constants.KOE_REQ_MSG[13][4]])
                    else:
                        require_info.append([ws[0].title, j, 14, 13])
    
                    ### セル[9:15]: 工種区分に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=15).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 15, constants.KOE_REQ_MSG[14][0], constants.KOE_REQ_MSG[14][1], constants.KOE_REQ_MSG[14][2], constants.KOE_REQ_MSG[14][3], constants.KOE_REQ_MSG[14][4]])
                    else:
                        require_info.append([ws[0].title, j, 15, 14])
    
                    ### セル[9:16]: 水害原因コード1に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=16).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 16, constants.KOE_REQ_MSG[15][0], constants.KOE_REQ_MSG[15][1], constants.KOE_REQ_MSG[15][2], constants.KOE_REQ_MSG[15][3], constants.KOE_REQ_MSG[15][4]])
                    else:
                        require_info.append([ws[0].title, j, 16, 15])
    
                    ### セル[9:17]: 水害原因コード2に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=17).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=16, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 17, constants.KOE_REQ_MSG[16][0], constants.KOE_REQ_MSG[16][1], constants.KOE_REQ_MSG[16][2], constants.KOE_REQ_MSG[16][3], constants.KOE_REQ_MSG[16][4]])
                    else:
                        require_info.append([ws[0].title, j, 17, 16])
    
                    ### セル[9:18]: 水害原因コード3に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=18).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 18, constants.KOE_REQ_MSG[17][0], constants.KOE_REQ_MSG[17][1], constants.KOE_REQ_MSG[17][2], constants.KOE_REQ_MSG[17][3], constants.KOE_REQ_MSG[17][4]])
                    else:
                        require_info.append([ws[0].title, j, 18, 17])
    
                    ### セル[9:19]: 異常気象コードに値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=19).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=18, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 19, constants.KOE_REQ_MSG[18][0], constants.KOE_REQ_MSG[18][1], constants.KOE_REQ_MSG[18][2], constants.KOE_REQ_MSG[18][3], constants.KOE_REQ_MSG[18][4]])
                    else:
                        require_info.append([ws[0].title, j, 19, 18])
    
                    ### セル[9:20]: 事業コードに値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=20).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=19, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 20, constants.KOE_REQ_MSG[19][0], constants.KOE_REQ_MSG[19][1], constants.KOE_REQ_MSG[19][2], constants.KOE_REQ_MSG[19][3], constants.KOE_REQ_MSG[19][4]])
                    else:
                        require_info.append([ws[0].title, j, 20, 19])
    
                    ### セル[9:21]: 調査対象機関名称に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=21).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=20, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 21, constants.KOE_REQ_MSG[20][0], constants.KOE_REQ_MSG[20][1], constants.KOE_REQ_MSG[20][2], constants.KOE_REQ_MSG[20][3], constants.KOE_REQ_MSG[20][4]])
                    else:
                        require_info.append([ws[0].title, j, 21, 20])
    
                    ### セル[9:22]: 被害金額_物的被害額(千円)に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=22).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=22, fill=fill, message_id=21, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 22, constants.KOE_REQ_MSG[21][0], constants.KOE_REQ_MSG[21][1], constants.KOE_REQ_MSG[21][2], constants.KOE_REQ_MSG[21][3], constants.KOE_REQ_MSG[21][4]])
                    else:
                        require_info.append([ws[0].title, j, 22, 21])
    
                    ### セル[9:23]: 被害金額_営業停止に伴う売上減少額に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=23).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=23, fill=fill, message_id=22, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 23, constants.KOE_REQ_MSG[22][0], constants.KOE_REQ_MSG[22][1], constants.KOE_REQ_MSG[22][2], constants.KOE_REQ_MSG[22][3], constants.KOE_REQ_MSG[22][4]])
                    else:
                        require_info.append([ws[0].title, j, 23, 22])
    
                    ### セル[9:24]: 被害金額_代替活動費(外注費)に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=24).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=24, fill=fill, message_id=23, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 24, constants.KOE_REQ_MSG[23][0], constants.KOE_REQ_MSG[23][1], constants.KOE_REQ_MSG[23][2], constants.KOE_REQ_MSG[23][3], constants.KOE_REQ_MSG[23][4]])
                    else:
                        require_info.append([ws[0].title, j, 24, 23])
    
                    ### セル[9:25]: 被害金額_その他に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=25).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=25, fill=fill, message_id=24, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 25, constants.KOE_REQ_MSG[24][0], constants.KOE_REQ_MSG[24][1], constants.KOE_REQ_MSG[24][2], constants.KOE_REQ_MSG[24][3], constants.KOE_REQ_MSG[24][4]])
                    else:
                        require_info.append([ws[0].title, j, 25, 24])
    
                    ### セル[9:26]: 被害金額_営業停止損失額合計(千円)に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=26).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=26, fill=fill, message_id=25, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 26, constants.KOE_REQ_MSG[25][0], constants.KOE_REQ_MSG[25][1], constants.KOE_REQ_MSG[25][2], constants.KOE_REQ_MSG[25][3], constants.KOE_REQ_MSG[25][4]])
                    else:
                        require_info.append([ws[0].title, j, 26, 25])
    
                    ### セル[9:27]: 営業停止期間等_営業停止期間日に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=27).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=27, fill=fill, message_id=26, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 27, constants.KOE_REQ_MSG[26][0], constants.KOE_REQ_MSG[26][1], constants.KOE_REQ_MSG[26][2], constants.KOE_REQ_MSG[26][3], constants.KOE_REQ_MSG[26][4]])
                    else:
                        require_info.append([ws[0].title, j, 27, 26])
    
                    ### セル[9:28]: 営業停止期間等_営業停止期間時間に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=28).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=28, fill=fill, message_id=27, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 28, constants.KOE_REQ_MSG[27][0], constants.KOE_REQ_MSG[27][1], constants.KOE_REQ_MSG[27][2], constants.KOE_REQ_MSG[27][3], constants.KOE_REQ_MSG[27][4]])
                    else:
                        require_info.append([ws[0].title, j, 28, 27])
    
                    ### セル[9:29]: 営業停止期間等_停止数量に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=29).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=29, fill=fill, message_id=28, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 29, constants.KOE_REQ_MSG[28][0], constants.KOE_REQ_MSG[28][1], constants.KOE_REQ_MSG[28][2], constants.KOE_REQ_MSG[28][3], constants.KOE_REQ_MSG[28][4]])
                    else:
                        require_info.append([ws[0].title, j, 29, 28])
    
                    ### セル[9:30]: 照会先_調査担当課名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=30).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=30, fill=fill, message_id=29, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 30, constants.KOE_REQ_MSG[29][0], constants.KOE_REQ_MSG[29][1], constants.KOE_REQ_MSG[29][2], constants.KOE_REQ_MSG[29][3], constants.KOE_REQ_MSG[29][4]])
                    else:
                        require_info.append([ws[0].title, j, 30, 29])
    
                    ### セル[9:31]: 照会先_調査担当者名[全角]に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=31).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=31, fill=fill, message_id=30, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 31, constants.KOE_REQ_MSG[30][0], constants.KOE_REQ_MSG[30][1], constants.KOE_REQ_MSG[30][2], constants.KOE_REQ_MSG[30][3], constants.KOE_REQ_MSG[30][4]])
                    else:
                        require_info.append([ws[0].title, j, 31, 30])
    
                    ### セル[9:32]: 照会先_電話番号に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=32).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=32, fill=fill, message_id=31, message=constants.KOE_REQ_MSGvv)
                        require_warn.append([ws[0].title, j, 32, constants.KOE_REQ_MSG[31][0], constants.KOE_REQ_MSG[31][1], constants.KOE_REQ_MSG[31][2], constants.KOE_REQ_MSG[31][3], constants.KOE_REQ_MSG[31][4]])
                    else:
                        require_info.append([ws[0].title, j, 32, 31])
    
                    ### セル[9:33]: 備考に値がセットされていることをチェックする。
                    if ws[0].cell(row=j, column=33).value is None:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=33, fill=fill, message_id=32, message=constants.KOE_REQ_MSG)
                        require_warn.append([ws[0].title, j, 33, constants.KOE_REQ_MSG[32][0], constants.KOE_REQ_MSG[32][1], constants.KOE_REQ_MSG[32][2], constants.KOE_REQ_MSG[32][3], constants.KOE_REQ_MSG[32][4]])
                    else:
                        require_info.append([ws[0].title, j, 33, 32])
            
            return True
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ形式チェック処理
    ###########################################################################
    def check_format():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal format_warn
            nonlocal format_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ形式チェック処理（0000）
            ### (1)セル[9:2]からセル[9:33]について形式が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 形式チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki.check_format()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 9:
                for j in range(9, max_row[0]+1):
                    ### セル[9:1]: NO.について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=1).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=1).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=100)
                            ### format_warn.append([ws[0].title, j, 1, constants.KOE_FOR_MSG[100][0], constants.KOE_FOR_MSG[100][1], constants.KOE_FOR_MSG[100][2], constants.KOE_FOR_MSG[100][3], constants.KOE_FOR_MSG[100][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, message_id=0, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 1, constants.KOE_FOR_MSG[0][0], constants.KOE_FOR_MSG[0][1], constants.KOE_FOR_MSG[0][2], constants.KOE_FOR_MSG[0][3], constants.KOE_FOR_MSG[0][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 1, 100])
                            format_info.append([ws[0].title, j, 1, 0])
    
                    ### セル[9:2]: 水害発生開始月について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=2).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=2).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=101)
                            ### format_warn.append([ws[0].title, j, 2, constants.KOE_FOR_MSG[101][0], constants.KOE_FOR_MSG[101][1], constants.KOE_FOR_MSG[101][2], constants.KOE_FOR_MSG[101][3], constants.KOE_FOR_MSG[101][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, message_id=1, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 2, constants.KOE_FOR_MSG[1][0], constants.KOE_FOR_MSG[1][1], constants.KOE_FOR_MSG[1][2], constants.KOE_FOR_MSG[1][3], constants.KOE_FOR_MSG[1][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 2, 101])
                            format_info.append([ws[0].title, j, 2, 1])
                        
                    ### セル[9:3]: 水害発生開始日について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=3).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=3).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=102)
                            ### format_warn.append([ws[0].title, j, 3, constants.KOE_FOR_MSG[102][0], constants.KOE_FOR_MSG[102][1], constants.KOE_FOR_MSG[102][2], constants.KOE_FOR_MSG[102][3], constants.KOE_FOR_MSG[102][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, message_id=2, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 3, constants.KOE_FOR_MSG[2][0], constants.KOE_FOR_MSG[2][1], constants.KOE_FOR_MSG[2][2], constants.KOE_FOR_MSG[2][3], constants.KOE_FOR_MSG[2][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 3, 102])
                            format_info.append([ws[0].title, j, 3, 2])
                        
                    ### セル[9:4]: 水害発生終了月について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=4).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=4).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=103)
                            ### format_warn.append([ws[0].title, j, 4, constants.KOE_FOR_MSG[103][0], constants.KOE_FOR_MSG[103][1], constants.KOE_FOR_MSG[103][2], constants.KOE_FOR_MSG[103][3], constants.KOE_FOR_MSG[103][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, message_id=3, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 4, constants.KOE_FOR_MSG[3][0], constants.KOE_FOR_MSG[3][1], constants.KOE_FOR_MSG[3][2], constants.KOE_FOR_MSG[3][3], constants.KOE_FOR_MSG[3][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 4, 103])
                            format_info.append([ws[0].title, j, 4, 3])
                        
                    ### セル[9:5]: 水害発生終了日について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=5).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=5).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=104)
                            ### format_warn.append([ws[0].title, j, 5, constants.KOE_FOR_MSG[104][0], constants.KOE_FOR_MSG[104][1], constants.KOE_FOR_MSG[104][2], constants.KOE_FOR_MSG[104][3], constants.KOE_FOR_MSG[104][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, message_id=4, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 5, constants.KOE_FOR_MSG[4][0], constants.KOE_FOR_MSG[4][1], constants.KOE_FOR_MSG[4][2], constants.KOE_FOR_MSG[4][3], constants.KOE_FOR_MSG[4][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 5, 104])
                            format_info.append([ws[0].title, j, 5, 4])
                        
                    ### セル[9:6]: 被害箇所_都道府県名[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=6).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=6).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=6).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=105)
                            ### format_warn.append([ws[0].title, j, 6, constants.KOE_FOR_MSG[105][0], constants.KOE_FOR_MSG[105][1], constants.KOE_FOR_MSG[105][2], constants.KOE_FOR_MSG[105][3], constants.KOE_FOR_MSG[105][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 6, constants.KOE_FOR_MSG[5][0], constants.KOE_FOR_MSG[5][1], constants.KOE_FOR_MSG[5][2], constants.KOE_FOR_MSG[5][3], constants.KOE_FOR_MSG[5][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 6, 105])
                            format_info.append([ws[0].title, j, 6, 5])
                        
                    ### セル[9:7]: 被害箇所_都道府県コードについて形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=7).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=7).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=7).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=106)
                            ### format_warn.append([ws[0].title, j, 7, constants.KOE_FOR_MSG[106][0], constants.KOE_FOR_MSG[106][1], constants.KOE_FOR_MSG[106][2], constants.KOE_FOR_MSG[106][3], constants.KOE_FOR_MSG[106][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 7, constants.KOE_FOR_MSG[6][0], constants.KOE_FOR_MSG[6][1], constants.KOE_FOR_MSG[6][2], constants.KOE_FOR_MSG[6][3], constants.KOE_FOR_MSG[6][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 7, 106])
                            format_info.append([ws[0].title, j, 7, 6])
                        
                    ### セル[9:8]: 被害箇所_市区町村名[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=8).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=8).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=8).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=107)
                            ### format_warn.append([ws[0].title, j, 8, constants.KOE_FOR_MSG[107][0], constants.KOE_FOR_MSG[107][1], constants.KOE_FOR_MSG[107][2], constants.KOE_FOR_MSG[107][3], constants.KOE_FOR_MSG[107][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 8, constants.KOE_FOR_MSG[7][0], constants.KOE_FOR_MSG[7][1], constants.KOE_FOR_MSG[7][2], constants.KOE_FOR_MSG[7][3], constants.KOE_FOR_MSG[7][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 8, 107])
                            format_info.append([ws[0].title, j, 8, 7])
                        
                    ### セル[9:9]: 被害箇所_市区町村コードについて形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=9).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=9).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=9).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=108)
                            ### format_warn.append([ws[0].title, j, 9, constants.KOE_FOR_MSG[108][0], constants.KOE_FOR_MSG[108][1], constants.KOE_FOR_MSG[108][2], constants.KOE_FOR_MSG[108][3], constants.KOE_FOR_MSG[108][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 9, constants.KOE_FOR_MSG[8][0], constants.KOE_FOR_MSG[8][1], constants.KOE_FOR_MSG[8][2], constants.KOE_FOR_MSG[8][3], constants.KOE_FOR_MSG[8][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 9, 108])
                            format_info.append([ws[0].title, j, 9, 8])
                        
                    ### セル[9:10]: 被害箇所_町丁名・大字名[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=10).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=10).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=10).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=109)
                            ### format_warn.append([ws[0].title, j, 10, constants.KOE_FOR_MSG[109][0], constants.KOE_FOR_MSG[109][1], constants.KOE_FOR_MSG[109][2], constants.KOE_FOR_MSG[109][3], constants.KOE_FOR_MSG[109][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=9, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 10, constants.KOE_FOR_MSG[9][0], constants.KOE_FOR_MSG[9][1], constants.KOE_FOR_MSG[9][2], constants.KOE_FOR_MSG[9][3], constants.KOE_FOR_MSG[9][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 10, 109])
                            format_info.append([ws[0].title, j, 10, 9])
                        
                    ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=11).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=11).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=11).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=110)
                            ### format_warn.append([ws[0].title, j, 11, constants.KOE_FOR_MSG[110][0], constants.KOE_FOR_MSG[110][1], constants.KOE_FOR_MSG[110][2], constants.KOE_FOR_MSG[110][3], constants.KOE_FOR_MSG[110][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 11, constants.KOE_FOR_MSG[10][0], constants.KOE_FOR_MSG[10][1], constants.KOE_FOR_MSG[10][2], constants.KOE_FOR_MSG[10][3], constants.KOE_FOR_MSG[10][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 11, 110])
                            format_info.append([ws[0].title, j, 11, 10])
                        
                    ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=12).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=12).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=12).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=111)
                            ### format_warn.append([ws[0].title, j, 12, constants.KOE_FOR_MSG[111][0], constants.KOE_FOR_MSG[111][1], constants.KOE_FOR_MSG[111][2], constants.KOE_FOR_MSG[111][3], constants.KOE_FOR_MSG[111][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=11, message=constants.KOE_FOR_MSGvvvv)
                            format_warn.append([ws[0].title, j, 12, constants.KOE_FOR_MSG[11][0], constants.KOE_FOR_MSG[11][1], constants.KOE_FOR_MSG[11][2], constants.KOE_FOR_MSG[11][3], constants.KOE_FOR_MSG[11][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 12, 111])
                            format_info.append([ws[0].title, j, 12, 11])
                        
                    ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=13).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=13).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=13).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=112)
                            ### format_warn.append([ws[0].title, j, 13, constants.KOE_FOR_MSG[112][0], constants.KOE_FOR_MSG[112][1], constants.KOE_FOR_MSG[112][2], constants.KOE_FOR_MSG[112][3], constants.KOE_FOR_MSG[112][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 13, constants.KOE_FOR_MSG[12][0], constants.KOE_FOR_MSG[12][1], constants.KOE_FOR_MSG[12][2], constants.KOE_FOR_MSG[12][3], constants.KOE_FOR_MSG[12][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 13, 112])
                            format_info.append([ws[0].title, j, 13, 12])
                        
                    ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=14).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=14).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=14).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=113)
                            ### format_warn.append([ws[0].title, j, 14, constants.KOE_FOR_MSG[113][0], constants.KOE_FOR_MSG[113][1], constants.KOE_FOR_MSG[113][2], constants.KOE_FOR_MSG[113][3], constants.KOE_FOR_MSG[113][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 14, constants.KOE_FOR_MSG[13][0], constants.KOE_FOR_MSG[13][1], constants.KOE_FOR_MSG[13][2], constants.KOE_FOR_MSG[13][3], constants.KOE_FOR_MSG[13][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 14, 113])
                            format_info.append([ws[0].title, j, 14, 13])
                        
                    ### セル[9:15]: 工種区分について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=15).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=15).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=15).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=114)
                            ### format_warn.append([ws[0].title, j, 15, constants.KOE_FOR_MSG[114][0], constants.KOE_FOR_MSG[114][1], constants.KOE_FOR_MSG[114][2], constants.KOE_FOR_MSG[114][3], constants.KOE_FOR_MSG[114][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 15, constants.KOE_FOR_MSG[14][0], constants.KOE_FOR_MSG[14][1], constants.KOE_FOR_MSG[14][2], constants.KOE_FOR_MSG[14][3], constants.KOE_FOR_MSG[14][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 15, 114])
                            format_info.append([ws[0].title, j, 15, 14])
                        
                    ### セル[9:16]: 水害原因コード1について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=16).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=16).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=16).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=115)
                            ### format_warn.append([ws[0].title, j, 16, constants.KOE_FOR_MSG[115][0], constants.KOE_FOR_MSG[115][1], constants.KOE_FOR_MSG[115][2], constants.KOE_FOR_MSG[115][3], constants.KOE_FOR_MSG[115][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 16, constants.KOE_FOR_MSG[15][0], constants.KOE_FOR_MSG[15][1], constants.KOE_FOR_MSG[15][2], constants.KOE_FOR_MSG[15][3], constants.KOE_FOR_MSG[15][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 16, 115])
                            format_info.append([ws[0].title, j, 16, 15])
                        
                    ### セル[9:17]: 水害原因コード2について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=17).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=17).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=17).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=116)
                            ### format_warn.append([ws[0].title, j, 17, constants.KOE_FOR_MSG[116][0], constants.KOE_FOR_MSG[116][1], constants.KOE_FOR_MSG[116][2], constants.KOE_FOR_MSG[116][3], constants.KOE_FOR_MSG[116][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=16, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 17, constants.KOE_FOR_MSG[16][0], constants.KOE_FOR_MSG[16][1], constants.KOE_FOR_MSG[16][2], constants.KOE_FOR_MSG[16][3], constants.KOE_FOR_MSG[16][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 17, 116])
                            format_info.append([ws[0].title, j, 17, 16])
                        
                    ### セル[9:18]: 水害原因コード3について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=18).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=18).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=18).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=117)
                            ### format_warn.append([ws[0].title, j, 18, constants.KOE_FOR_MSG[117][0], constants.KOE_FOR_MSG[117][1], constants.KOE_FOR_MSG[117][2], constants.KOE_FOR_MSG[117][3], constants.KOE_FOR_MSG[117][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 18, constants.KOE_FOR_MSG[17][0], constants.KOE_FOR_MSG[17][1], constants.KOE_FOR_MSG[17][2], constants.KOE_FOR_MSG[17][3], constants.KOE_FOR_MSG[17][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 18, 117])
                            format_info.append([ws[0].title, j, 18, 17])
                        
                    ### セル[9:19]: 異常気象コードについて形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=19).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=19).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=19).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=118)
                            ### format_warn.append([ws[0].title, j, 19, constants.KOE_FOR_MSG[118][0], constants.KOE_FOR_MSG[118][1], constants.KOE_FOR_MSG[118][2], constants.KOE_FOR_MSG[118][3], constants.KOE_FOR_MSG[118][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=18, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 19, constants.KOE_FOR_MSG[18][0], constants.KOE_FOR_MSG[18][1], constants.KOE_FOR_MSG[18][2], constants.KOE_FOR_MSG[18][3], constants.KOE_FOR_MSG[18][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 19, 118])
                            format_info.append([ws[0].title, j, 19, 18])
                        
                    ### セル[9:20]: 事業コードについて形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=20).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=20).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=20).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=119)
                            ### format_warn.append([ws[0].title, j, 20, constants.KOE_FOR_MSG[119][0], constants.KOE_FOR_MSG[119][1], constants.KOE_FOR_MSG[119][2], constants.KOE_FOR_MSG[119][3], constants.KOE_FOR_MSG[119][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=19, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 20, constants.KOE_FOR_MSG[19][0], constants.KOE_FOR_MSG[19][1], constants.KOE_FOR_MSG[19][2], constants.KOE_FOR_MSG[19][3], constants.KOE_FOR_MSG[19][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 20, 119])
                            format_info.append([ws[0].title, j, 20, 19])
                        
                    ### セル[9:21]: 調査対象機関名称[全角]について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=21).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=21).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=21).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=120)
                            ### format_warn.append([ws[0].title, j, 21, constants.KOE_FOR_MSG[120][0], constants.KOE_FOR_MSG[120][1], constants.KOE_FOR_MSG[120][2], constants.KOE_FOR_MSG[120][3], constants.KOE_FOR_MSG[120][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=20, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 21, constants.KOE_FOR_MSG[20][0], constants.KOE_FOR_MSG[20][1], constants.KOE_FOR_MSG[20][2], constants.KOE_FOR_MSG[20][3], constants.KOE_FOR_MSG[20][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 21, 120])
                            format_info.append([ws[0].title, j, 21, 20])
                        
                    ### セル[9:22]: 被害金額_物的被害額(千円)について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=22).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=22).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=22).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=22, fill=fill, message_id=121)
                            ### format_warn.append([ws[0].title, j, 22, constants.KOE_FOR_MSG[121][0], constants.KOE_FOR_MSG[121][1], constants.KOE_FOR_MSG[121][2], constants.KOE_FOR_MSG[121][3], constants.KOE_FOR_MSG[121][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=22, fill=fill, message_id=21, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 22, constants.KOE_FOR_MSG[21][0], constants.KOE_FOR_MSG[21][1], constants.KOE_FOR_MSG[21][2], constants.KOE_FOR_MSG[21][3], constants.KOE_FOR_MSG[21][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 22, 121])
                            format_info.append([ws[0].title, j, 22, 21])
                        
                    ### セル[9:23]: 被害金額_営業停止に伴う売上減少額について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=23).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=23).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=23).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=23, fill=fill, message_id=122)
                            ### format_warn.append([ws[0].title, j, 23, constants.KOE_FOR_MSG[122][0], constants.KOE_FOR_MSG[122][1], constants.KOE_FOR_MSG[122][2], constants.KOE_FOR_MSG[122][3], constants.KOE_FOR_MSG[122][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=23, fill=fill, message_id=22, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 23, constants.KOE_FOR_MSG[22][0], constants.KOE_FOR_MSG[22][1], constants.KOE_FOR_MSG[22][2], constants.KOE_FOR_MSG[22][3], constants.KOE_FOR_MSG[22][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 23, 122])
                            format_info.append([ws[0].title, j, 23, 22])
                        
                    ### セル[9:24]: 被害金額_代替活動費(外注費)について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=24).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=24).value, int) == False and \
                            isinstance(ws[0].cell(row=j, column=24).value, float) == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=24, fill=fill, message_id=123)
                            ### format_warn.append([ws[0].title, j, 24, constants.KOE_FOR_MSG[123][0], constants.KOE_FOR_MSG[123][1], constants.KOE_FOR_MSG[123][2], constants.KOE_FOR_MSG[123][3], constants.KOE_FOR_MSG[123][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=24, fill=fill, message_id=23, message=constants.KOE_FOR_MSGvvvv)
                            format_warn.append([ws[0].title, j, 24, constants.KOE_FOR_MSG[23][0], constants.KOE_FOR_MSG[23][1], constants.KOE_FOR_MSG[23][2], constants.KOE_FOR_MSG[23][3], constants.KOE_FOR_MSG[23][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 24, 123])
                            format_info.append([ws[0].title, j, 24, 23])
                        
                    ### セル[9:25]: 被害金額_その他について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=25).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=25).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=25, fill=fill, message_id=124)
                            ### format_warn.append([ws[0].title, j, 25, constants.KOE_FOR_MSG[124][0], constants.KOE_FOR_MSG[124][1], constants.KOE_FOR_MSG[124][2], constants.KOE_FOR_MSG[124][3], constants.KOE_FOR_MSG[124][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=25, fill=fill, message_id=24, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 25, constants.KOE_FOR_MSG[24][0], constants.KOE_FOR_MSG[24][1], constants.KOE_FOR_MSG[24][2], constants.KOE_FOR_MSG[24][3], constants.KOE_FOR_MSG[24][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 25, 124])
                            format_info.append([ws[0].title, j, 25, 24])
                        
                    ### セル[9:26]: 被害金額_営業停止損失額合計(千円)について形式が正しいことをチェックする。
                    if ws[0].cell(row=j, column=26).value is None:
                        pass
                    else:
                        if split_name_code(ws[0].cell(row=j, column=26).value)[-1].isdecimal() == False:
                            ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=26, fill=fill, message_id=125)
                            ### format_warn.append([ws[0].title, j, 26, constants.KOE_FOR_MSG[125][0], constants.KOE_FOR_MSG[125][1], constants.KOE_FOR_MSG[125][2], constants.KOE_FOR_MSG[125][3], constants.KOE_FOR_MSG[125][4]])
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=26, fill=fill, message_id=25, message=constants.KOE_FOR_MSG)
                            format_warn.append([ws[0].title, j, 26, constants.KOE_FOR_MSG[25][0], constants.KOE_FOR_MSG[25][1], constants.KOE_FOR_MSG[25][2], constants.KOE_FOR_MSG[25][3], constants.KOE_FOR_MSG[25][4]])
                        else:
                            ### format_info.append([ws[0].title, j, 26, 125])
                            format_info.append([ws[0].title, j, 26, 25])
                        
                    ### セル[9:27]: 営業停止期間等_営業停止期間日について形式が正しいことをチェックする。
                    ### セル[9:28]: 営業停止期間等_営業停止期間時間について形式が正しいことをチェックする。
                    ### セル[9:29]: 営業停止期間等_停止数量について形式が正しいことをチェックする。
                    ### セル[9:30]: 照会先_調査担当課名[全角]について形式が正しいことをチェックする。
                    ### セル[9:31]: 照会先_調査担当者名[全角]について形式が正しいことをチェックする。
                    ### セル[9:32]: 照会先_電話番号について形式が正しいことをチェックする。
                    ### セル[9:33]: 備考について形式が正しいことをチェックする。
            return True
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ範囲チェック処理
    ###########################################################################
    def check_range():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal range_warn
            nonlocal range_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ範囲チェック処理（0000）
            ### (1)セル[9:2]からセル[9:33]について範囲が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 範囲チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ### 範囲チェックでは、形式が正しい場合のみチェックを行う。
            ### 形式チェックは別途形式チェックで行うためである。
            ### 例えば、面積などの数値について、float()で例外とならないように、int、floatの場合のみチェックする。
            ### 範囲チェックでは、数値の下限と上限のチェックを行う。
            ### 範囲チェックでは、DBとの突合チェックに該当するチェックは行わない。
            ### DBとの突合チェックは別途突合チェックで行うためである。
            ### 範囲チェックの例は値が正であることである。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki.check_range()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 9:
                for j in range(9, max_row[0]+1):
                    ### セル[9:1]: NO.について範囲が正しいことをチェックする。
                    ### セル[9:2]: 水害発生開始月について範囲が正しいことをチェックする。
                    ### セル[9:3]: 水害発生開始日について範囲が正しいことをチェックする。
                    ### セル[9:4]: 水害発生終了月について範囲が正しいことをチェックする。
                    ### セル[9:5]: 水害発生終了日について範囲が正しいことをチェックする。
                    ### セル[9:6]: 被害箇所_都道府県名[全角]について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=6).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=6).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=6).value, float) == True:
                            if float(ws[0].cell(row=j, column=6).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=205)
                                ### range_warn.append([ws[0].title, j, 6, constants.KOE_RAN_MSG[205][0], constants.KOE_RAN_MSG[205][1], constants.KOE_RAN_MSG[205][2], constants.KOE_RAN_MSG[205][3], constants.KOE_RAN_MSG[205][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, message_id=5, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 6, constants.KOE_RAN_MSG[5][0], constants.KOE_RAN_MSG[5][1], constants.KOE_RAN_MSG[5][2], constants.KOE_RAN_MSG[5][3], constants.KOE_RAN_MSG[5][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 6, 205])
                                range_info.append([ws[0].title, j, 6, 5])
    
                    ### セル[9:7]: 被害箇所_都道府県コードについて範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=7).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=7).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=7).value, float) == True:
                            if float(ws[0].cell(row=j, column=7).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=206)
                                ### range_warn.append([ws[0].title, j, 7, constants.KOE_RAN_MSG[206][0], constants.KOE_RAN_MSG[206][1], constants.KOE_RAN_MSG[206][2], constants.KOE_RAN_MSG[206][3], constants.KOE_RAN_MSG[206][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, message_id=6, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 7, constants.KOE_RAN_MSG[6][0], constants.KOE_RAN_MSG[6][1], constants.KOE_RAN_MSG[6][2], constants.KOE_RAN_MSG[6][3], constants.KOE_RAN_MSG[6][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 7, 206])
                                range_info.append([ws[0].title, j, 7, 6])
                    
                    ### セル[9:8]: 被害箇所_市区町村名[全角]について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=8).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=8).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=8).value, float) == True:
                            if float(ws[0].cell(row=j, column=8).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=207)
                                ### range_warn.append([ws[0].title, j, 8, constants.KOE_RAN_MSG[207][0], constants.KOE_RAN_MSG[207][1], constants.KOE_RAN_MSG[207][2], constants.KOE_RAN_MSG[207][3], constants.KOE_RAN_MSG[207][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, message_id=7, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 8, constants.KOE_RAN_MSG[7][0], constants.KOE_RAN_MSG[7][1], constants.KOE_RAN_MSG[7][2], constants.KOE_RAN_MSG[7][3], constants.KOE_RAN_MSG[7][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 8, 207])
                                range_info.append([ws[0].title, j, 8, 7])
    
                    ### セル[9:9]: 被害箇所_市区町村コードについて範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=9).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=9).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=9).value, float) == True:
                            if float(ws[0].cell(row=j, column=9).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=208)
                                ### range_warn.append([ws[0].title, j, 9, constants.KOE_RAN_MSG[208][0], constants.KOE_RAN_MSG[208][1], constants.KOE_RAN_MSG[208][2], constants.KOE_RAN_MSG[208][3], constants.KOE_RAN_MSG[208][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, message_id=8, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 9, constants.KOE_RAN_MSG[8][0], constants.KOE_RAN_MSG[8][1], constants.KOE_RAN_MSG[8][2], constants.KOE_RAN_MSG[8][3], constants.KOE_RAN_MSG[8][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 9, 208])
                                range_info.append([ws[0].title, j, 9, 8])
    
                    ### セル[9:10]: 被害箇所_町丁名・大字名[全角]について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=10).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=10).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=10).value, float) == True:
                            if float(ws[0].cell(row=j, column=10).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=209)
                                ### range_warn.append([ws[0].title, j, 10, constants.KOE_RAN_MSG[209][0], constants.KOE_RAN_MSG[209][1], constants.KOE_RAN_MSG[209][2], constants.KOE_RAN_MSG[209][3], constants.KOE_RAN_MSG[209][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, message_id=9, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 10, constants.KOE_RAN_MSG[9][0], constants.KOE_RAN_MSG[9][1], constants.KOE_RAN_MSG[9][2], constants.KOE_RAN_MSG[9][3], constants.KOE_RAN_MSG[9][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 10, 209])
                                range_info.append([ws[0].title, j, 10, 9])
    
                    ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=11).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=11).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=11).value, float) == True:
                            if float(ws[0].cell(row=j, column=11).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=210)
                                ### range_warn.append([ws[0].title, j, 11, constants.KOE_RAN_MSG[210][0], constants.KOE_RAN_MSG[210][1], constants.KOE_RAN_MSG[210][2], constants.KOE_RAN_MSG[210][3], constants.KOE_RAN_MSG[210][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, message_id=10, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 11, constants.KOE_RAN_MSG[10][0], constants.KOE_RAN_MSG[10][1], constants.KOE_RAN_MSG[10][2], constants.KOE_RAN_MSG[10][3], constants.KOE_RAN_MSG[10][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 11, 210])
                                range_info.append([ws[0].title, j, 11, 10])
    
                    ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=12).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=12).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=12).value, float) == True:
                            if float(ws[0].cell(row=j, column=12).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=211)
                                ### range_warn.append([ws[0].title, j, 12, constants.KOE_RAN_MSG[211][0], constants.KOE_RAN_MSG[211][1], constants.KOE_RAN_MSG[211][2], constants.KOE_RAN_MSG[211][3], constants.KOE_RAN_MSG[211][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, message_id=11, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 12, constants.KOE_RAN_MSG[11][0], constants.KOE_RAN_MSG[11][1], constants.KOE_RAN_MSG[11][2], constants.KOE_RAN_MSG[11][3], constants.KOE_RAN_MSG[11][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 12, 211])
                                range_info.append([ws[0].title, j, 12, 11])
    
                    ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=13).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=13).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=13).value, float) == True:
                            if float(ws[0].cell(row=j, column=13).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=212)
                                ### range_warn.append([ws[0].title, j, 13, constants.KOE_RAN_MSG[212][0], constants.KOE_RAN_MSG[212][1], constants.KOE_RAN_MSG[212][2], constants.KOE_RAN_MSG[212][3], constants.KOE_RAN_MSG[212][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, message_id=12, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 13, constants.KOE_RAN_MSG[12][0], constants.KOE_RAN_MSG[12][1], constants.KOE_RAN_MSG[12][2], constants.KOE_RAN_MSG[12][3], constants.KOE_RAN_MSG[12][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 13, 212])
                                range_info.append([ws[0].title, j, 13, 12])
                    
                    ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=14).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=14).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=14).value, float) == True:
                            if float(ws[0].cell(row=j, column=14).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=213)
                                ### range_warn.append([ws[0].title, j, 14, constants.KOE_RAN_MSG[213][0], constants.KOE_RAN_MSG[213][1], constants.KOE_RAN_MSG[213][2], constants.KOE_RAN_MSG[213][3], constants.KOE_RAN_MSG[213][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, message_id=13, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 14, constants.KOE_RAN_MSG[13][0], constants.KOE_RAN_MSG[13][1], constants.KOE_RAN_MSG[13][2], constants.KOE_RAN_MSG[13][3], constants.KOE_RAN_MSG[13][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 14, 213])
                                range_info.append([ws[0].title, j, 14, 13])
    
                    ### セル[9:15]: 工種区分について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=15).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=15).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=15).value, float) == True:
                            if float(ws[0].cell(row=j, column=15).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=214)
                                ### range_warn.append([ws[0].title, j, 15, constants.KOE_RAN_MSG[214][0], constants.KOE_RAN_MSG[214][1], constants.KOE_RAN_MSG[214][2], constants.KOE_RAN_MSG[214][3], constants.KOE_RAN_MSG[214][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, message_id=14, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 15, constants.KOE_RAN_MSG[14][0], constants.KOE_RAN_MSG[14][1], constants.KOE_RAN_MSG[14][2], constants.KOE_RAN_MSG[14][3], constants.KOE_RAN_MSG[14][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 15, 214])
                                range_info.append([ws[0].title, j, 15, 14])
    
                    ### セル[9:16]: 水害原因コード1について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=16).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=16).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=16).value, float) == True:
                            if float(ws[0].cell(row=j, column=16).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=215)
                                ### range_warn.append([ws[0].title, j, 16, constants.KOE_RAN_MSG[215][0], constants.KOE_RAN_MSG[215][1], constants.KOE_RAN_MSG[215][2], constants.KOE_RAN_MSG[215][3], constants.KOE_RAN_MSG[215][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, message_id=15, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 16, constants.KOE_RAN_MSG[15][0], constants.KOE_RAN_MSG[15][1], constants.KOE_RAN_MSG[15][2], constants.KOE_RAN_MSG[15][3], constants.KOE_RAN_MSG[15][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 16, 215])
                                range_info.append([ws[0].title, j, 16, 15])
    
                    ### セル[9:17]: 水害原因コード2について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=17).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=17).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=17).value, float) == True:
                            if float(ws[0].cell(row=j, column=17).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=216)
                                ### range_warn.append([ws[0].title, j, 17, constants.KOE_RAN_MSG[216][0], constants.KOE_RAN_MSG[216][1], constants.KOE_RAN_MSG[216][2], constants.KOE_RAN_MSG[216][3], constants.KOE_RAN_MSG[216][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, message_id=16, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 17, constants.KOE_RAN_MSG[16][0], constants.KOE_RAN_MSG[16][1], constants.KOE_RAN_MSG[16][2], constants.KOE_RAN_MSG[16][3], constants.KOE_RAN_MSG[16][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 17, 216])
                                range_info.append([ws[0].title, j, 17, 16])
    
                    ### セル[9:18]: 水害原因コード3について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=18).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=18).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=18).value, float) == True:
                            if float(ws[0].cell(row=j, column=18).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=217)
                                ### range_warn.append([ws[0].title, j, 18, constants.KOE_RAN_MSG[217][0], constants.KOE_RAN_MSG[217][1], constants.KOE_RAN_MSG[217][2], constants.KOE_RAN_MSG[217][3], constants.KOE_RAN_MSG[217][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, message_id=17, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 18, constants.KOE_RAN_MSG[17][0], constants.KOE_RAN_MSG[17][1], constants.KOE_RAN_MSG[17][2], constants.KOE_RAN_MSG[17][3], constants.KOE_RAN_MSG[17][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 18, 217])
                                range_info.append([ws[0].title, j, 18, 17])
    
                    ### セル[9:19]: 異常気象コードについて範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=19).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=19).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=19).value, float) == True:
                            if float(ws[0].cell(row=j, column=19).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=218)
                                ### range_warn.append([ws[0].title, j, 19, constants.KOE_RAN_MSG[218][0], constants.KOE_RAN_MSG[218][1], constants.KOE_RAN_MSG[218][2], constants.KOE_RAN_MSG[218][3], constants.KOE_RAN_MSG[218][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, message_id=18, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 19, constants.KOE_RAN_MSG[18][0], constants.KOE_RAN_MSG[18][1], constants.KOE_RAN_MSG[18][2], constants.KOE_RAN_MSG[18][3], constants.KOE_RAN_MSG[18][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 19, 218])
                                range_info.append([ws[0].title, j, 19, 18])
    
                    ### セル[9:20]: 事業コードについて範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=20).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=20).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=20).value, float) == True:
                            if float(ws[0].cell(row=j, column=20).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=219)
                                ### range_warn.append([ws[0].title, j, 20, constants.KOE_RAN_MSG[219][0], constants.KOE_RAN_MSG[219][1], constants.KOE_RAN_MSG[219][2], constants.KOE_RAN_MSG[219][3], constants.KOE_RAN_MSG[219][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, message_id=19, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 20, constants.KOE_RAN_MSG[19][0], constants.KOE_RAN_MSG[19][1], constants.KOE_RAN_MSG[19][2], constants.KOE_RAN_MSG[19][3], constants.KOE_RAN_MSG[19][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 20, 219])
                                range_info.append([ws[0].title, j, 20, 19])
    
                    ### セル[9:21]: 調査対象機関名称[全角]について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=21).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=21).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=21).value, float) == True:
                            if float(ws[0].cell(row=j, column=21).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=220)
                                ### range_warn.append([ws[0].title, j, 21, constants.KOE_RAN_MSG[220][0], constants.KOE_RAN_MSG[220][1], constants.KOE_RAN_MSG[220][2], constants.KOE_RAN_MSG[220][3], constants.KOE_RAN_MSG[220][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, message_id=20, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 21, constants.KOE_RAN_MSG[20][0], constants.KOE_RAN_MSG[20][1], constants.KOE_RAN_MSG[20][2], constants.KOE_RAN_MSG[20][3], constants.KOE_RAN_MSG[20][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 21, 220])
                                range_info.append([ws[0].title, j, 21, 20])
    
                    ### セル[9:22]: 被害金額_物的被害額(千円)について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=22).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=22).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=22).value, float) == True:
                            if float(ws[0].cell(row=j, column=22).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=22, fill=fill, message_id=221)
                                ### range_warn.append([ws[0].title, j, 22, constants.KOE_RAN_MSG[221][0], constants.KOE_RAN_MSG[221][1], constants.KOE_RAN_MSG[221][2], constants.KOE_RAN_MSG[221][3], constants.KOE_RAN_MSG[221][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=22, fill=fill, message_id=21, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 22, constants.KOE_RAN_MSG[21][0], constants.KOE_RAN_MSG[21][1], constants.KOE_RAN_MSG[21][2], constants.KOE_RAN_MSG[21][3], constants.KOE_RAN_MSG[21][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 22, 221])
                                range_info.append([ws[0].title, j, 22, 21])
    
                    ### セル[9:23]: 被害金額_営業停止に伴う売上減少額について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=23).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=23).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=23).value, float) == True:
                            if float(ws[0].cell(row=j, column=23).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=23, fill=fill, message_id=222)
                                ### range_warn.append([ws[0].title, j, 23, constants.KOE_RAN_MSG[222][0], constants.KOE_RAN_MSG[222][1], constants.KOE_RAN_MSG[222][2], constants.KOE_RAN_MSG[222][3], constants.KOE_RAN_MSG[222][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=23, fill=fill, message_id=22, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 23, constants.KOE_RAN_MSG[22][0], constants.KOE_RAN_MSG[22][1], constants.KOE_RAN_MSG[22][2], constants.KOE_RAN_MSG[22][3], constants.KOE_RAN_MSG[22][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 23, 222])
                                range_info.append([ws[0].title, j, 23, 22])
    
                    ### セル[9:24]: 被害金額_代替活動費(外注費)について範囲が正しいことをチェックする。
                    if ws[0].cell(row=j, column=24).value is None:
                        pass
                    else:
                        if isinstance(ws[0].cell(row=j, column=24).value, int) == True or \
                            isinstance(ws[0].cell(row=j, column=24).value, float) == True:
                            if float(ws[0].cell(row=j, column=24).value) < 0:
                                ### add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=24, fill=fill, message_id=223)
                                ### range_warn.append([ws[0].title, j, 24, constants.KOE_RAN_MSG[223][0], constants.KOE_RAN_MSG[223][1], constants.KOE_RAN_MSG[223][2], constants.KOE_RAN_MSG[223][3], constants.KOE_RAN_MSG[223][4]])
                                add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=24, fill=fill, message_id=23, message=constants.KOE_RAN_MSG)
                                range_warn.append([ws[0].title, j, 24, constants.KOE_RAN_MSG[23][0], constants.KOE_RAN_MSG[23][1], constants.KOE_RAN_MSG[23][2], constants.KOE_RAN_MSG[23][3], constants.KOE_RAN_MSG[23][4]])
                            else:
                                ### range_info.append([ws[0].title, j, 24, 223])
                                range_info.append([ws[0].title, j, 24, 23])
    
                    ### セル[9:25]: 被害金額_その他について範囲が正しいことをチェックする。
                    ### セル[9:26]: 被害金額_営業停止損失額合計(千円)について範囲が正しいことをチェックする。
                    ### セル[9:27]: 営業停止期間等_営業停止期間日について範囲が正しいことをチェックする。
                    ### セル[9:28]: 営業停止期間等_営業停止期間時間について範囲が正しいことをチェックする。
                    ### セル[9:29]: 営業停止期間等_停止数量について範囲が正しいことをチェックする。
                    ### セル[9:30]: 照会先_調査担当課名[全角]について範囲が正しいことをチェックする。
                    ### セル[9:31]: 照会先_調査担当者名[全角]について範囲が正しいことをチェックする。
                    ### セル[9:32]: 照会先_電話番号について範囲が正しいことをチェックする。
                    ### セル[9:33]: 備考について範囲が正しいことをチェックする。
            
            return True
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ相関チェック処理
    ###########################################################################
    def check_correlate():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal correlate_warn
            nonlocal correlate_info
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ相関チェック処理（0000）
            ### (1)セル[9:2]からセル[9:33]について他項目との相関関係が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki.check_correlate()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 9:
                for j in range(9, max_row[0]+1):
                    pass
                    ### セル[9:1]: NO.が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:2]: 水害発生月が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:3]: 水害発生日が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:4]: 水害発生月が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:5]: 水害発生日が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:6]: 被害箇所_都道府県名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:7]: 被害箇所_都道府県コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:8]: 被害箇所_市区町村名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:9]: 被害箇所_市区町村コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:10]: 被害箇所_町丁名・大字名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:15]: 工種区分が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:16]: 水害原因コード1が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:17]: 水害原因コード2が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:18]: 水害原因コード3が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:19]: 異常気象コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:20]: 事業コードが何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:21]: 調査対象機関名称[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:22]: 被害金額_物的被害額(千円)が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:23]: 被害金額_営業停止に伴う売上減少額が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:24]: 被害金額_代替活動費(外注費)が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:25]: 被害金額_その他が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:26]: 被害金額_営業停止損失額合計(千円)が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:27]: 営業停止期間等_営業停止期間日が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:28]: 営業停止期間等_営業停止期間時間が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:29]: 営業停止期間等_停止数量が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:30]: 照会先_調査担当課名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:31]: 照会先_調査担当者名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:32]: 照会先_電話番号が何かの値のときに、相関する他項目は正しく選択されているか。
                    ### セル[9:33]: 備考が何かの値のときに、相関する他項目は正しく選択されているか。
            
            return True
        except:
            return False

    ###########################################################################
    ### 関数内関数：EXCELセルデータ突合チェック処理
    ###########################################################################
    def check_compare():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal compare_warn
            nonlocal compare_info
            ### nonlocal max_row
            ### nonlocal ken_code_list
            ### nonlocal ken_name_list
            ### nonlocal ken_name_code_list
            ### nonlocal city_code_list
            ### nonlocal city_name_list
            ### nonlocal city_name_code_list
            ### nonlocal suikei_code_list
            ### nonlocal suikei_name_list
            ### nonlocal suikei_name_code_list
            ### nonlocal suikei_type_code_list
            ### nonlocal suikei_type_name_list
            ### nonlocal suikei_type_name_code_list
            ### nonlocal kasen_code_list
            ### nonlocal kasen_name_list
            ### nonlocal kasen_name_code_list
            ### nonlocal kasen_type_code_list
            ### nonlocal kasen_type_name_list
            ### nonlocal kasen_type_name_code_list
            ### nonlocal kasen_kaigan_code_list
            ### nonlocal kasen_kaigan_name_list
            ### nonlocal kasen_kaigan_name_code_list
            ### nonlocal weather_id_list
            ### nonlocal weather_name_list
            ### nonlocal weather_name_id_list
            ###################################################################
            ### 関数内関数：EXCELセルデータ突合チェック処理（0000）
            ### (1)セル[9:2]からセル[9:33]についてデータベースに登録されている値と突合せチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki.check_compare()関数 STEP 1/1.', 'DEBUG')
            if max_row[0] >= 9:
                for j in range(9, max_row[0]+1):
                    pass
                    ### セル[9:1]: NO.についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:2]: 水害発生月についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:3]: 水害発生日についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:4]: 水害発生月についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:5]: 水害発生日についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:6]: 被害箇所_都道府県名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:7]: 被害箇所_都道府県コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:8]: 被害箇所_市区町村名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:9]: 被害箇所_市区町村コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:10]: 被害箇所_町丁名・大字名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:15]: 工種区分についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:16]: 水害原因コード1についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:17]: 水害原因コード2についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:18]: 水害原因コード3についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:19]: 異常気象コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:20]: 事業コードについてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:21]: 調査対象機関名称[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:22]: 被害金額_物的被害額(千円)についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:23]: 被害金額_営業停止に伴う売上減少額についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:24]: 被害金額_代替活動費(外注費)についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:25]: 被害金額_その他についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:26]: 被害金額_営業停止損失額合計(千円)についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:27]: 営業停止期間等_営業停止期間日についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:28]: 営業停止期間等_営業停止期間時間についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:29]: 営業停止期間等_停止数量についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:30]: 照会先_調査担当課名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:31]: 照会先_調査担当者名[全角]についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:32]: 照会先_電話番号についてデータベースに登録されている値と突合せチェックする。
                    ### セル[9:33]: 備考についてデータベースに登録されている値と突合せチェックする。
            
            return True
        except:
            return False

    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.browser_post_koeki()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 1/30.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 2/30.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 3/30.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.browser_post_koeki()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.browser_post_koeki()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
        
        #######################################################################
        ### 局所変数セット処理(0030)
        ### チェック用の局所変数を初期化する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 4/30.', 'DEBUG')
        ### 必須チェック用の局所変数を初期化する。
        require_info = []
        require_warn = []

        ### 形式チェック用の局所変数を初期化する。
        format_info = []
        format_warn = []

        ### 範囲チェック用の局所変数を初期化する。
        range_info = []
        range_warn = []

        ### 相関チェック用の局所変数を初期化する。
        correlate_info = []
        correlate_warn = []

        ### 突合せチェックの結果を格納するために局所変数をセットする。
        compare_info = []
        compare_warn = []

        #######################################################################
        ### 局所変数セット処理(0040)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 5/30.', 'DEBUG')
        form = UploadKoekiForm(request.POST, request.FILES)
    
        #######################################################################
        ### フォーム検証処理(0050)
        ### (1)フォームが正しい場合、処理を継続する。
        ### (2)フォームが正しくない場合、ERROR画面を表示して関数を抜ける。
        ### ※ネストを浅くするため。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 6/30.', 'DEBUG')
        if form.is_valid() == False:
            print_log('[WARN] P0120Ken.browser_post_koeki()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
    
        #######################################################################
        ### EXCEL入出力処理(1000)
        ### (1)局所変数に値をセットする。
        ### (2)アップロードされた公益事業等調査票ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 7/30.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_Ym = datetime.now(JST).strftime('%Y%m')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        
        upload_file_object = request.FILES['file']
        upload_file_name, upload_file_ext = os.path.splitext(request.FILES['file'].name)
        upload_file_name = upload_file_name + '_' + datetime_now_YmdHMS + '.xlsx'
        ### upload_file_path = 'static/repository/' + datetime_now_Ym + '/' + upload_file_name
        upload_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + upload_file_name

        output_file_name, output_file_ext = os.path.splitext(request.FILES['file'].name)
        output_file_name = output_file_name + '_' + datetime_now_YmdHMS + '_output' + '.xlsx'
        ### output_file_path = 'static/repository/' + datetime_now_Ym + '/' + output_file_name
        output_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + output_file_name
        
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 upload_file_object={}'.format(upload_file_object), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 upload_file_path={}'.format(upload_file_path), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 upload_file_name={}'.format(upload_file_name), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 output_file_path={}'.format(output_file_path), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 output_file_name={}'.format(output_file_name), 'DEBUG')
        
        with open(upload_file_path, 'wb+') as destination:
            for chunk in upload_file_object.chunks():
                destination.write(chunk)
                
        #######################################################################
        ### EXCEL入出力処理(1010)
        ### (1)アップロードされた公益事業等調査票ファイルのワークブックを読み込む。
        ### (2)KOEKIワークシートをコピーして、チェック結果を格納するCHECK_RESULTワークシートを追加する。
        ### (3)追加したワークシートを2シート目に移動する。
        ### (4)ワークシートの最大行数を局所変数のmax_rowにセットする。
        ### (5)背景赤色の塗りつぶしを局所変数のfillにセットする。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 8/30.', 'DEBUG')
        wb = openpyxl.load_workbook(upload_file_path)
        ws = []
        ws_result = []
        ws_title = []
        for ws_temp in wb.worksheets:
            if 'KOEKI' in ws_temp.title:
                ws.append(ws_temp)
                ws_result.append(wb.copy_worksheet(ws_temp))
                ws_result[-1].title = 'RESULT' + ws_temp.title
                ws_title.append(ws_temp.title)
                
        for ws_temp in wb.worksheets:
            if 'RESULT' in ws_temp.title:
                wb.move_sheet(ws_temp.title, offset=-wb.index(ws_temp))
                wb.move_sheet(ws_temp.title, offset=1)
        
        for ws_temp in wb.worksheets:
            ws_temp.sheet_view.tabSelected = None
            
        wb.active = 1

        #######################################################################
        ### EXCEL入出力処理(1020)
        ### (1)EXCELシート毎に最大行を探索する。
        ### (2)局所変数のmax_rowリストに追加する。
        ### ※max_row_tempの初期値の8はNO.、水系・沿岸名等のキャプション部分のEXCEL行番号である。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 9/30.', 'DEBUG')
        max_row = []
        for ws_temp in ws:
            ### EXCELシート毎に最大行を探索する。
            max_row_temp = 8
            for i in range(ws_temp.max_row+1, 8, -1):
                if ws_temp.cell(row=i, column=2).value is None:
                    pass
                else:
                    max_row_temp = i
                    break
            ### 局所変数のmax_rowリストに追加する。
            max_row.append(max_row_temp)

        #######################################################################
        ### EXCEL入出力処理(1030)
        ### EXCELセルの背景赤色を局所変数のfillに設定する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 10/30.', 'DEBUG')
        fill = openpyxl.styles.PatternFill(patternType='solid', fgColor='FF0000', bgColor='FF0000')

        #######################################################################
        ### DBアクセス処理(2000)
        ### (1)DBから突合せチェック用のデータを取得する。
        ### (2)突合せチェック用のリストを生成する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 11/30.', 'DEBUG')
        ### DBから突合せチェック用のデータを取得する。
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        city_list = CITY.objects.raw("""SELECT * FROM CITY ORDER BY CAST(CITY_CODE AS INTEGER)""")
        ### cause_list
        ### area_list
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_list = KASEN.objects.raw("""SELECT * FROM KASEN ORDER BY CAST(KASEN_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        ### gradient_list
        kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(KASEN_KAIGAN_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")
        ### building_list
        ### underground_list
        ### flood_sediment_list
        ### industry_list
        ### business_list
        ### usage_list
        
        ### 突合せチェック用のリストを生成する。
        ken_code_list = [ken.ken_code for ken in ken_list]
        ken_name_list = [ken.ken_name for ken in ken_list]
        ken_name_code_list = [str(ken.ken_name) + ":" + str(ken.ken_code) for ken in ken_list]
        city_code_list = [city.city_code for city in city_list]
        city_name_list = [city.city_name for city in city_list]
        city_name_code_list = [str(city.city_name) + ":" + str(city.city_code) for city in city_list]
        ### cause_code_list
        ### cause_name_list
        ### cause_name_code_list
        ### area_id_list
        ### area_name_list
        ### area_name_id_list
        suikei_code_list = [suikei.suikei_code for suikei in suikei_list]
        suikei_name_list = [suikei.suikei_name for suikei in suikei_list]
        suikei_name_code_list = [str(suikei.suikei_name) + ":" + str(suikei.suikei_code) for suikei in suikei_list]
        suikei_type_code_list = [suikei_type.suikei_type_code for suikei_type in suikei_type_list]
        suikei_type_name_list = [suikei_type.suikei_type_name for suikei_type in suikei_type_list]
        suikei_type_name_code_list = [str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code) for suikei_type in suikei_type_list]
        kasen_code_list = [kasen.kasen_code for kasen in kasen_list]
        kasen_name_list = [kasen.kasen_name for kasen in kasen_list]
        kasen_name_code_list = [str(kasen.kasen_name) + ":" + str(kasen.kasen_code) for kasen in kasen_list]
        kasen_type_code_list = [kasen_type.kasen_type_code for kasen_type in kasen_type_list]
        kasen_type_name_list = [kasen_type.kasen_type_name for kasen_type in kasen_type_list]
        kasen_type_name_code_list = [str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code) for kasen_type in kasen_type_list]
        ### gradient_code_list
        ### gradient_name_list
        ### gradient_name_code_list
        kasen_kaigan_code_list = [kasen_kaigan.kasen_kaigan_code for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_list = [kasen_kaigan.kasen_kaigan_name for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_code_list = [str(kasen_kaigan.kasen_kaigan_name) + ":" + str(kasen_kaigan.kasen_kaigan_code) for kasen_kaigan in kasen_kaigan_list]
        weather_id_list = [weather.weather_id for weather in weather_list]
        weather_name_list = [weather.weather_name for weather in weather_list]
        weather_name_id_list = [str(weather.weather_name) + ":" + str(weather.weather_id) for weather in weather_list]
        ### building_code_list
        ### building_name_list
        ### building_name_code_list
        ### underground_code_list
        ### underground_name_list
        ### underground_name_code_list
        ### flood_sediment_code_list
        ### flood_sediment_name_list
        ### flood_sediment_name_code_list
        ### industry_code_list
        ### industry_name_list
        ### industry_name_code_list
        ### business_code_list
        ### business_name_list
        ### business_name_code_list
        ### usage_code_list
        ### usage_name_list
        ### usage_name_code_list

        #######################################################################
        ### 必須、形式、範囲、相関、突合せチェック処理(2010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 12/30.', 'DEBUG')
        bool_return = check_require()
        if bool_return == False:
            print_log('[ERROR] check_require()関数が異常終了しました。', 'ERROR')
            raise Exception
            
        bool_return = check_format()
        if bool_return == False:
            print_log('[ERROR] check_format()関数が異常終了しました。', 'ERROR')
            raise Exception

        bool_return = check_range()
        if bool_return == False:
            print_log('[ERROR] check_range()関数が異常終了しました。', 'ERROR')
            raise Exception

        bool_return = check_correlate()
        if bool_return == False:
            print_log('[ERROR] check_correlate()関数が異常終了しました。', 'ERROR')
            raise Exception

        bool_return = check_compare()
        if bool_return == False:
            print_log('[ERROR] check_compare()関数が異常終了しました。', 'ERROR')
            raise Exception

        #######################################################################
        ### ファイル入出力処理(3000)
        ### チェック結果ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 13/30.', 'DEBUG')
        wb.save(output_file_path)

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(3010)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 14/30.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 max_row={}'.format(max_row), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(require_warn)={}'.format(len(require_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(format_warn)={}'.format(len(format_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(range_warn)={}'.format(len(range_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(correlate_warn)={}'.format(len(correlate_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(compare_warn)={}'.format(len(compare_warn)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(require_info)={}'.format(len(require_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(format_info)={}'.format(len(format_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(range_info)={}'.format(len(range_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(correlate_info)={}'.format(len(correlate_info)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 len(compare_info)={}'.format(len(compare_info)), 'DEBUG')
        
        #######################################################################
        ### ファイル入出力処理、ログ出力処理(3020)
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 15/30.', 'DEBUG')
        info_str = ''
        warn_str = ''
        if len(require_info) > 0:
            for i in range(len(require_info)):
                info_str = info_str + \
                    str(require_info[i][0]) + ',' + \
                    str(require_info[i][1]) + ',' + \
                    str(require_info[i][2]) + ',' + \
                    str(constants.KOE_REQ_MSG[require_info[i][3]][0]) + ',' + \
                    str(constants.KOE_REQ_MSG[require_info[i][3]][1]) + ',' + \
                    str(constants.KOE_REQ_MSG[require_info[i][3]][2]) + '\n'        
        
        if len(format_info) > 0:
            for i in range(len(format_info)):
                info_str = info_str + \
                    str(format_info[i][0]) + ',' + \
                    str(format_info[i][1]) + ',' + \
                    str(format_info[i][2]) + ',' + \
                    str(constants.KOE_FOR_MSG[format_info[i][3]][0]) + ',' + \
                    str(constants.KOE_FOR_MSG[format_info[i][3]][1]) + ',' + \
                    str(constants.KOE_FOR_MSG[format_info[i][3]][2]) + '\n'        

        if len(range_info) > 0:
            for i in range(len(range_info)):
                info_str = info_str + \
                    str(range_info[i][0]) + ',' + \
                    str(range_info[i][1]) + ',' + \
                    str(range_info[i][2]) + ',' + \
                    str(constants.KOE_RAN_MSG[range_info[i][3]][0]) + ',' + \
                    str(constants.KOE_RAN_MSG[range_info[i][3]][1]) + ',' + \
                    str(constants.KOE_RAN_MSG[range_info[i][3]][2]) + '\n'        

        if len(correlate_info) > 0:
            for i in range(len(correlate_info)):
                info_str = info_str + \
                    str(correlate_info[i][0]) + ',' + \
                    str(correlate_info[i][1]) + ',' + \
                    str(correlate_info[i][2]) + ',' + \
                    str(constants.KOE_COR_MSG[correlate_info[i][3]][0]) + ',' + \
                    str(constants.KOE_COR_MSG[correlate_info[i][3]][1]) + ',' + \
                    str(constants.KOE_COR_MSG[correlate_info[i][3]][2]) + '\n'        

        if len(compare_info) > 0:
            for i in range(len(compare_info)):
                info_str = info_str + \
                    str(compare_info[i][0]) + ',' + \
                    str(compare_info[i][1]) + ',' + \
                    str(compare_info[i][2]) + ',' + \
                    str(constants.KOE_COM_MSG[compare_info[i][3]][0]) + ',' + \
                    str(constants.KOE_COM_MSG[compare_info[i][3]][1]) + ',' + \
                    str(constants.KOE_COM_MSG[compare_info[i][3]][2]) + '\n'        

        if len(require_warn) > 0:
            for i in range(len(require_warn)):
                warn_str = warn_str + \
                    str(require_warn[i][0]) + ',' + \
                    str(require_warn[i][1]) + ',' + \
                    str(require_warn[i][2]) + ',' + \
                    str(constants.KOE_REQ_MSG[require_warn[i][3]][0]) + ',' + \
                    str(constants.KOE_REQ_MSG[require_warn[i][3]][1]) + ',' + \
                    str(constants.KOE_REQ_MSG[require_warn[i][3]][2]) + '\n'        
        
        if len(format_warn) > 0:
            for i in range(len(format_warn)):
                warn_str = warn_str + \
                    str(format_warn[i][0]) + ',' + \
                    str(format_warn[i][1]) + ',' + \
                    str(format_warn[i][2]) + ',' + \
                    str(constants.KOE_FOR_MSG[format_warn[i][3]][0]) + ',' + \
                    str(constants.KOE_FOR_MSG[format_warn[i][3]][1]) + ',' + \
                    str(constants.KOE_FOR_MSG[format_warn[i][3]][2]) + '\n'        

        if len(range_warn) > 0:
            for i in range(len(range_warn)):
                warn_str = warn_str + \
                    str(range_warn[i][0]) + ',' + \
                    str(range_warn[i][1]) + ',' + \
                    str(range_warn[i][2]) + ',' + \
                    str(constants.KOE_RAN_MSG[range_warn[i][3]][0]) + ',' + \
                    str(constants.KOE_RAN_MSG[range_warn[i][3]][1]) + ',' + \
                    str(constants.KOE_RAN_MSG[range_warn[i][3]][2]) + '\n'        

        if len(correlate_warn) > 0:
            for i in range(len(correlate_warn)):
                warn_str = warn_str + \
                    str(correlate_warn[i][0]) + ',' + \
                    str(correlate_warn[i][1]) + ',' + \
                    str(correlate_warn[i][2]) + ',' + \
                    str(constants.KOE_COR_MSG[correlate_warn[i][3]][0]) + ',' + \
                    str(constants.KOE_COR_MSG[correlate_warn[i][3]][1]) + ',' + \
                    str(constants.KOE_COR_MSG[correlate_warn[i][3]][2]) + '\n'        

        if len(compare_warn) > 0:
            for i in range(len(compare_warn)):
                warn_str = warn_str + \
                    str(compare_warn[i][0]) + ',' + \
                    str(compare_warn[i][1]) + ',' + \
                    str(compare_warn[i][2]) + ',' + \
                    str(constants.KOE_COM_MSG[compare_warn[i][3]][0]) + ',' + \
                    str(constants.KOE_COM_MSG[compare_warn[i][3]][1]) + ',' + \
                    str(constants.KOE_COM_MSG[compare_warn[i][3]][2]) + '\n'        

        #######################################################################
        ### DBアクセス処理(4000)
        ### ※入力チェックで警告が発見された場合に処理する。
        ### ※ネストを浅くするために、処理対象外の場合、終了させる。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 16/30.', 'DEBUG')
        if len(require_warn) > 0 or len(format_warn) > 0 or \
            len(range_warn) > 0 or len(correlate_warn) > 0 or \
            len(compare_warn) > 0:

            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")
                
                ###############################################################
                ### DBアクセス処理(4010)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の都道府県のKOEKI_HEADERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 17/30.', 'DEBUG')
                params = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE KOEKI_HEADER SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE koeki_header_id IN (
                    SELECT 
                        koeki_header_id 
                    FROM KOEKI_HEADER 
                    WHERE 
                        ken_code=%(KEN_CODE)s AND 
                        deleted_at IS NULL)""", params)
        
                ###############################################################
                ### DBアクセス処理(4020)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の都道府県のKOEKIのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 18/30.', 'DEBUG')
                params = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE KOEKI SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE koeki_id IN (
                    SELECT 
                        koeki_id 
                    FROM KOEKI_VIEW 
                    WHERE 
                        ken_code=%(KEN_CODE)s AND 
                        deleted_at IS NULL)""", params)
    
                ###############################################################
                ### DBアクセス処理(4030)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の都道府県のKOEKI_SUMMARYのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 19/30.', 'DEBUG')
                params = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE KOEKI_SUMMARY SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE koeki_id IN (
                    SELECT 
                        koeki_id 
                    FROM KOEKI_SUMMARY_VIEW 
                    WHERE 
                        ken_code=%(KEN_CODE)s AND 
                        deleted_at IS NULL)""", params)
    
                ###############################################################
                ### DBアクセス処理(4040)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の都道府県のKOEKI_TRIGGERのデータは、削除日時をセットして、削除済の扱いとする。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 20/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'ken_code': split_name_code(ws_chitan[0].cell(row=9, column=7).value)[-1], 
                    'action_code': _G01
                })
                bool_return = delete_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] delete_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
                ###############################################################
                ### DBアクセス処理(4050)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※トリガーテーブルにKOE_ACT_01トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 21/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': None, 
                    'ken_code': convert_empty_to_none(split_name_code(ws_chitan[0].cell(row=9, column=7).value)[-1]), 
                    'city_code': None, 
                    'action_code': _KOE_ACT_01, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': get_info_log(), 
                    'warn_log': get_warn_log(), 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                    
                ###############################################################
                ### DBアクセス処理(4060)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※トリガーテーブルにKOE_ACT_02トリガーを実行済、失敗として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 22/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': None, 
                    'ken_code': convert_empty_to_none(split_name_code(ws_chitan[0].cell(row=9, column=7).value)[-1]), 
                    'city_code': None, 
                    'action_code': _KOE_ACT_02, 
                    'status_code': _FAILURE, 
                    'info_count': 0, 
                    'warn_count': len(ws), 
                    'info_log': info_str, 
                    'warn_log': warn_str, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
                connection_cursor.execute("""COMMIT""");
                
            except:
                print_log('[ERROR] P0120Ken.browser_post_koeki()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] P0120Ken.browser_post_koeki()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
                print_log('[ERROR] P0120Ken.browser_post_koeki()関数が異常終了しました。', 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
            finally:
                connection_cursor.close()
                
            ###################################################################
            ### レスポンスセット処理(4070)
            ### ※入力チェックでエラーが発見された場合に処理する。
            ### ※テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 23/30.', 'DEBUG')
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'browser_post_koeki_warn': 'browser_post_koeki_warn',
                'require_warn': require_warn,
                'format_warn': format_warn,
                'range_warn': range_warn,
                'correlate_warn': correlate_warn,
                'compare_warn': compare_warn,
                'output_file_path': output_file_path, 
            }
            print_log('[WARN] P0120Ken.browser_post_koeki()関数が警告終了しました。', 'INFO')
            return False, HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(5000)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        ### ※入力データ_ヘッダ部分テーブルにデータを登録する。
        ### ※入力データ_一覧票部分テーブルにデータを登録する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 24/30.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")
            
            ###################################################################
            ### DBアクセス処理(5010)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の都道府県のKOEKI_HEADERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 25/30.', 'DEBUG')
            params = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE KOEKI_HEADER SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE koeki_header_id IN (
                SELECT 
                    koeki_header_id 
                FROM KOEKI_HEADER 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL)""", params)
    
            ###################################################################
            ### DBアクセス処理(5020)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の都道府県のKOEKIのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 26/30.', 'DEBUG')
            params = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE KOEKI SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE koeki_id IN (
                SELECT 
                    koeki_id 
                FROM KOEKI_VIEW 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL)""", params)

            ###################################################################
            ### DBアクセス処理(5030)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の都道府県のKOEKI_SUMMARYのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 27/30.', 'DEBUG')
            params = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE KOEKI_SUMMARY SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE koeki_id IN (
                SELECT 
                    koeki_id 
                FROM KOEKI_SUMMARY_VIEW 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL)""", params)

            ###################################################################
            ### DBアクセス処理(5040)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の都道府県のKOEKI_TRIGGERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 28/30.', 'DEBUG')
            metadata = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': split_name_code(ws[0].cell(row=9, column=7).value)[-1], 
                'city_code': None, 
                'action_code': _KOE_ACT_01
            })
            bool_return = delete_message(metadata=metadata)
            if bool_return == False:
                print_log('[ERROR] delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            ###################################################################
            ### DBアクセス処理(5050)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※koeki_header_id__max で正しい。
            ###################################################################
            print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 29/30.', 'DEBUG')
            for i, _ in enumerate(ws):
                koeki_header_id = KOEKI_HEADER.objects.all().aggregate(Max('koeki_header_id'))['koeki_header_id__max']
                if koeki_header_id is None:
                    koeki_header_id = 1
                else:
                    koeki_header_id += 1
                
                ###############################################################
                ### DBアクセス処理(5060)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※公益事業等調査票_ヘッダ部分テーブルにデータを登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 29_1/30.', 'DEBUG')
                params = dict({
                    'KOEKI_HEADER_ID': koeki_header_id, 
                    'KOEKI_HEADER_NAME': ws_title[i], 
                    'KEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=9, column=7).value)[-1]), 
                    'UPLOAD_FILE_PATH': upload_file_path, 
                    'UPLOAD_FILE_NAME': upload_file_name, 
                    'SUMMARY_FILE_PATH': None, 
                    'SUMMARY_FILE_NAME': None, 
                    'DELETED_AT': None
                })
                connection_cursor.execute("""
                    INSERT INTO KOEKI_HEADER (
                        koeki_header_id, koeki_header_name, ken_code, 
                        upload_file_path, upload_file_name, summary_file_path, summary_file_name, 
                        committed_at, deleted_at 
                    ) VALUES (
                        %(KOEKI_HEADER_ID)s, 
                        %(KOEKI_HEADER_NAME)s, 
                        %(KEN_CODE)s, 
                        %(UPLOAD_FILE_PATH)s, 
                        %(UPLOAD_FILE_NAME)s, 
                        %(SUMMARY_FILE_PATH)s, 
                        %(SUMMARY_FILE_NAME)s, 
                        CURRENT_TIMESTAMP,  -- committed_at 
                        %(DELETED_AT)s)""", params)
                    
                ###############################################################
                ### DBアクセス処理(5070)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※公益事業等調査票_一覧表部分テーブルにデータを登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 29_2/30.', 'DEBUG')
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 max_row[i]={}'.format(max_row[i]), 'DEBUG')
                if max_row[i] >= 9:
                    for j in range(9, max_row[i]+1):
                        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 j={}'.format(j), 'DEBUG')
                        params = dict({
                            'KOEKI_NAME': convert_empty_to_none(ws[i].cell(row=j, column=2).value), 
                            'KOEKI_HEADER_ID': koeki_header_id, 
                            'CITY_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=9).value)[-1]), 
                            'BEGIN_DATE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=2).value)[-1]), 
                            'END_DATE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=4).value)[-1]), 
                            'SUIKEI_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=11).value)[-1]), 
                            'SUIKEI_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=12).value)[-1]), 
                            'KASEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=13).value)[-1]), 
                            'KASEN_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=14).value)[-1]), 
                            'KASEN_KAIGAN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=15).value)[-1]), 
                            'WEATHER_ID': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=19).value)[-1]), 
                            'CAUSE_1_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=16).value)[-1]), 
                            'CAUSE_2_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=17).value)[-1]), 
                            'CAUSE_3_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=18).value)[-1]), 
                            'BUSINESS_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=20).value)[-1]), 
                            'ORGANIZATION_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=21).value)[-1]), 
                            'PHYSICAL_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=22).value), 
                            'SALES_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=23).value), 
                            'ALT_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=24).value), 
                            'OTHER_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=25).value), 
                            'TOTAL_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=26).value), 
                            'SUSPENDED_DAYS': convert_empty_to_none(ws[i].cell(row=j, column=27).value), 
                            'SUSPENDED_HOURS': convert_empty_to_none(ws[i].cell(row=j, column=28).value), 
                            'SUSPENDED_AMOUNTS': convert_empty_to_none(ws[i].cell(row=j, column=29).value), 
                            'DEPARTMENT_NAME': convert_empty_to_none(ws[i].cell(row=j, column=30).value), 
                            'EMPLOYEE_NAME': convert_empty_to_none(ws[i].cell(row=j, column=31).value), 
                            'TELEPHONE': convert_empty_to_none(ws[i].cell(row=j, column=32).value), 
                            'COMMENT': convert_empty_to_none(ws[i].cell(row=j, column=33).value), 
                            'DELETED_AT': None
                        })
                        connection_cursor.execute(""" 
                            INSERT INTO KOEKI (
                                koeki_id, koeki_name, koeki_header_id, 
                                city_code, begin_date, end_date, 
                                suikei_code, suikei_type_code, kasen_code, kasen_type_code, kasen_kaigan_code, weather_id, 
                                cause_1_code, cause_2_code, cause_3_code, business_code, organization_name, 
                                physical_damage, sales_damage, alt_damage, other_damage, total_damage, 
                                suspended_days, suspended_hours, suspended_amounts, 
                                department_name, employee_name, telephone, comment, 
                                committed_at, deleted_at 
                            ) VALUES (
                                (SELECT CASE WHEN (MAX(koeki_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(koeki_id+1) AS INTEGER) END AS koeki_id FROM KOEKI), -- koeki_id 
                                %(KOEKI_NAME)s, 
                                %(KOEKI_HEADER_ID)s, 
                                %(CITY_CODE)s, 
                                TO_DATE(%(BEGIN_DATE)s, 'YYYY/MM/DD'), 
                                TO_DATE(%(END_DATE)s, 'YYYY/MM/DD'), 
                                %(SUIKEI_CODE)s, 
                                %(SUIKEI_TYPE_CODE)s, 
                                %(KASEN_CODE)s, 
                                %(KASEN_TYPE_CODE)s, 
                                %(KASEN_KAIGAN_CODE)s, 
                                %(WEATHER_ID)s, 
                                %(CAUSE_1_CODE)s, 
                                %(CAUSE_2_CODE)s, 
                                %(CAUSE_3_CODE)s, 
                                %(BUSINESS_CODE)s, 
                                %(ORGANIZATION_NAME)s, 
                                %(PHYSICAL_DAMAGE)s, 
                                %(SALES_DAMAGE)s, 
                                %(ALT_DAMAGE)s, 
                                %(OTHER_DAMAGE)s, 
                                %(TOTAL_DAMAGE)s, 
                                %(SUSPENDED_DAYS)s, 
                                %(SUSPENDED_HOURS)s, 
                                %(SUSPENDED_AMOUNTS)s, 
                                %(DEPARTMENT_NAME)s, 
                                %(EMPLOYEE_NAME)s, 
                                %(TELEPHONE)s, 
                                %(COMMENT)s, 
                                CURRENT_TIMESTAMP, -- committed_at
                                %(DELETED_AT)s) """, params)

                ###############################################################
                ### DBアクセス処理(5080)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにKOE_ACT_01トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 29_3/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': koeki_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[0].cell(row=9, column=7).value)[-1]), 
                    'city_code': None, 
                    'action_code': _KOE_ACT_01, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': get_info_log(), 
                    'warn_log': get_warn_log(), 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception

                ###############################################################
                ### DBアクセス処理(5090)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにKOE_ACT_02トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 29_4/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': koeki_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[0].cell(row=9, column=7).value)[-1]), 
                    'city_code': None, 
                    'action_code': _KOE_ACT_02, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': info_str, 
                    'warn_log': warn_str, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
            
                ###############################################################
                ### DBアクセス処理(5100)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにKOE_ACT_03トリガーを未実行＝次回実行対象として登録する。
                ###############################################################
                print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 29_5/30.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': koeki_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[i].cell(row=9, column=7).value)[-1]), 
                    'city_code': None, 
                    'action_code': _KOE_ACT_03, 
                    'status_code': _RUNNING, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_message(metadata=metadata)
                if bool_return == False:
                    print_log('[ERROR] publish_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
            connection_cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0120Ken.browser_post_koeki()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0120Ken.browser_post_koeki()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0120Ken.browser_post_koeki()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            template = loader.get_template('P0120Ken/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))

        finally:
            connection_cursor.close()
        
        #######################################################################
        ### レスポンスセット処理(5110)
        ### ※入力チェックでエラーが発見されなかった場合に処理する。
        ### ※テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.browser_post_koeki()関数 STEP 30/30.', 'DEBUG')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'browser_post_koeki_info': 'browser_post_koeki_info',
            'require_info': require_info, 
            'format_info': format_info,
            'range_info': range_info,
            'correlate_info': correlate_info,
            'compare_info': compare_info,
        }
        print_log('[INFO] P0120Ken.browser_post_koeki()関数が正常終了しました。', 'INFO')
        return True, HttpResponse(template.render(context, request))
        
    except:
        print_log('[ERROR] P0120Ken.browser_post_koeki()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_post_koeki()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.browser_post_koeki()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0120Ken/browser/browser.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))

###############################################################################
### 都道府県用一般資産調査員調査票EXCELダウンロード
### 都道府県用一般資産調査員調査票CSVダウンロード
### 都道府県用一般資産集計結果EXCELダウンロード
### 都道府県用一般資産集計結果CSVダウンロード
### 都道府県用水害区域図PDFダウンロード
### 都道府県用水害区域図KMLダウンロード
### 都道府県用地方単独事業調査票EXCELダウンロード
### 都道府県用地方単独事業調査票CSVダウンロード
### 都道府県用地方単独事業集計結果EXCELダウンロード
### 都道府県用地方単独事業集計結果CSVダウンロード
### 都道府県用補助事業調査票EXCELダウンロード
### 都道府県用補助事業調査票CSVダウンロード
### 都道府県用補助事業集計結果EXCELダウンロード
### 都道府県用補助事業集計結果CSVダウンロード
### 都道府県用公益事業調査票EXCELダウンロード
### 都道府県用公益事業調査票CSVダウンロード
### 都道府県用公益事業集計結果EXCELダウンロード
### 都道府県用公益事業集計結果CSVダウンロード
###############################################################################
def download_header_id(request, header_id, file_type):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0120Ken.download_header_id()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0120Ken.download_header_id()関数 STEP 1/5.', 'DEBUG')
        print_log('[DEBUG] P0120Ken.download_header_id()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.download_header_id()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0120Ken.download_header_id()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.download_header_id()関数 STEP 2/5.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_KEN
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.download_header_id()関数 STEP 3/5.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0120Ken.download_header_id()関数が警告終了しました。', 'WARN')
            response = HttpResponseNotFound("")
            return False, response
        
        if user_proxy_list[0].ken_code == False:
            print_log('[WARN] P0120Ken.download_header_id()関数が警告終了しました。', 'WARN')
            response = HttpResponseNotFound("")
            return False, response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0120Ken.download_header_id()関数 STEP 4/5.', 'DEBUG')
        func_params = dict({
            'IPPAN_HEADER_ID': header_id, 
            'CHITAN_HEADER_ID': header_id, 
            'HOJO_HEADER_ID': header_id, 
            'KOEKI_HEADER_ID': header_id, 
            'AREA_ID': header_id, 
            'FILE_TYPE': file_type
        })
        if file_type == _IPP_CHO_EXC:
            bool_return, file_path = get_ippan_chosa_csv_excel(request, func_params)
        elif file_type == _IPP_CHO_CSV:
            bool_return, file_path = get_ippan_chosa_csv_excel(request, func_params)
        elif file_type == _IPP_SUM_EXC:
            bool_return, file_path = get_ippan_summary_csv_excel(request, func_params)
        elif file_type == _IPP_SUM_CSV:
            bool_return, file_path = get_ippan_summary_csv_excel(request, func_params)
        elif file_type == _CHI_CHO_EXC:
            bool_return, file_path = get_chitan_chosa_csv_excel(request, func_params)
        elif file_type == _CHI_CHO_CSV:
            bool_return, file_path = get_chitan_chosa_csv_excel(request, func_params)
        elif file_type == _CHI_SUM_EXC:
            bool_return, file_path = get_chitan_summary_csv_excel(request, func_params)
        elif file_type == _CHI_SUM_CSV:
            bool_return, file_path = get_chitan_summary_csv_excel(request, func_params)
        elif file_type == _HOJ_CHO_EXC:
            bool_return, file_path = get_hojo_chosa_csv_excel(request, func_params)
        elif file_type == _HOJ_CHO_CSV:
            bool_return, file_path = get_hojo_chosa_csv_excel(request, func_params)
        elif file_type == _HOJ_SUM_EXC:
            bool_return, file_path = get_hojo_summary_csv_excel(request, func_params)
        elif file_type == _HOJ_SUM_CSV:
            bool_return, file_path = get_hojo_summary_csv_excel(request, func_params)
        elif file_type == _KOE_CHO_EXC:
            bool_return, file_path = get_koeki_chosa_csv_excel(request, func_params)
        elif file_type == _KOE_CHO_CSV:
            bool_return, file_path = get_koeki_chosa_csv_excel(request, func_params)
        elif file_type == _KOE_SUM_EXC:
            bool_return, file_path = get_koeki_summary_csv_excel(request, func_params)
        elif file_type == _KOE_SUM_CSV:
            bool_return, file_path = get_koeki_summary_csv_excel(request, func_params)
        elif file_type == _ARE_PDF:
            bool_return, file_path = get_area_kml_pdf(request, func_params)
        elif file_type == _ARE_KML:
            bool_return, file_path = get_area_kml_pdf(request, func_params)
            
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0120Ken.download_header_id()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0120Ken.download_header_id()関数が正常終了しました。', 'INFO')
        if file_type == _IPP_CHO_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _IPP_CHO_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _IPP_SUM_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _IPP_SUM_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _ARE_PDF:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/pdf')
            response['Content-Disposition'] = 'attachment; filename="test.pdf"'
        elif file_type == _ARE_KML:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/kml') ### OK
            response['Content-Disposition'] = 'attachment; filename="test.kml"'
        elif file_type == _CHI_CHO_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _CHI_CHO_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _CHI_SUM_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _CHI_SUM_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _HOJ_CHO_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _HOJ_CHO_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _HOJ_SUM_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _HOJ_SUM_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _KOE_CHO_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _KOE_CHO_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _KOE_SUM_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _KOE_SUM_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'

        return True, response
    
    except:
        print_log('[ERROR] P0120Ken.download_header_id()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_header_id()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0120Ken.download_header_id()関数が異常終了しました。', 'ERROR')
        response = HttpResponseNotFound("")
        return False, response
