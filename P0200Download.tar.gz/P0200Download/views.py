###############################################################################
### ファイル名：P0200Download/views.py
### EXCELダウンロード
### 初期選択無しのダウンロード画面を表示する。
### 初期選択有りのダウンロード画面を表示する。
### メッセージキュー、非同期対応、負荷平準化、遅延処理対応のダウンロード状況画面を表示する。
###############################################################################

import glob
import hashlib
import os
import sys
import time

from datetime import date, datetime, timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User ### ADD 2023/03/01
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import redirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic import FormView
from django.views.generic.base import TemplateView

import openpyxl
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査員調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査員調査票_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査員調査票_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from MessageQueue.views import get_message 
from MessageQueue.views import publish_message 
from MessageQueue.views import publish_consume_message 
from MessageQueue.views import consume_message 
from MessageQueue.views import delete_message 

_KEN01 = '01'
_KEN02 = '02'
_KEN03 = '03'
_KEN04 = '04'
_KEN05 = '05'
_KEN06 = '06'
_KEN07 = '07'
_KEN08 = '08'
_KEN09 = '09'
_KEN10 = '10'
_KEN11 = '11'
_KEN12 = '12'
_KEN13 = '13'
_KEN14 = '14'
_KEN15 = '15'
_KEN16 = '16'
_KEN17 = '17'
_KEN18 = '18'
_KEN19 = '19'
_KEN20 = '20'
_KEN21 = '21'
_KEN22 = '22'
_KEN23 = '23'
_KEN24 = '24'
_KEN25 = '25'
_KEN26 = '26'
_KEN27 = '27'
_KEN28 = '28'
_KEN29 = '29'
_KEN30 = '30'
_KEN31 = '31'
_KEN32 = '32'
_KEN33 = '33'
_KEN34 = '34'
_KEN35 = '35'
_KEN36 = '36'
_KEN37 = '37'
_KEN38 = '38'
_KEN39 = '39'
_KEN40 = '40'
_KEN41 = '41'
_KEN42 = '42'
_KEN43 = '43'
_KEN44 = '44'
_KEN45 = '45'
_KEN46 = '46'
_KEN47 = '47'

### USER_PROXYテーブル.ROLE_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_ROLE_CITY = 'ROLE_CITY'
_ROLE_KEN = 'ROLE_KEN'
_ROLE_MANAGE = 'ROLE_MANAGE'

### ACTIONテーブル.ACTION_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_IPP_ACT_90 = 'IPP_ACT_90'
_IPP_ACT_91 = 'IPP_ACT_91'

_ARE_ACT_90 = 'ARE_ACT_90'
_ARE_ACT_91 = 'ARE_ACT_91'

_CHI_ACT_90 = 'CHI_ACT_90'
_CHI_ACT_91 = 'CHI_ACT_91'

_HOJ_ACT_90 = 'HOJ_ACT_90'
_HOJ_ACT_91 = 'HOJ_ACT_91'

_KOE_ACT_90 = 'KOE_ACT_90'
_KOE_ACT_91 = 'KOE_ACT_91'

### 局所定数 ※DOWNLOAD関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP_CHO = 'IPP_CHO'
_ARE = 'ARE'
_CHI_CHO = 'CHI_CHO'
_HOJ_CHO = 'HOJ_CHO'
_KOE_CHO = 'KOE_CHO'
_IPP_SUM = 'IPP_SUM'
_CHI_SUM = 'CHI_SUM'
_HOJ_SUM = 'HOJ_SUM'
_KOE_SUM = 'KOE_SUM'

###############################################################################
### 関数名：index_view(request)
### urlpattern：path('', views.index_view, name='index_view')
### 初期選択無しのダウンロード画面を表示する。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_view(request):
    bool_return, response = index_chosa_summary(request, '')
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：index_ippan_chosa_view(request)
### urlpattern：path('ippan/chosa/', views.index_ippan_chosa_view, name='index_ippan_chosa_view')
### 初期選択有りのダウンロード画面を表示する。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_ippan_chosa_view(request):
    bool_return, response = index_chosa_summary(request, _IPP_CHO)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：index_area_view(request)
### urlpattern：path('area/', views.index_area_view, name='index_area_view')
### 初期選択有りのダウンロード画面を表示する。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_area_view(request):
    bool_return, response = index_chosa_summary(request, _ARE)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：index_chitan_chosa_view(request)
### urlpattern：path('chitan/chosa/', views.index_chitan_chosa_view, name='index_chitan_chosa_view')
### 初期選択有りのダウンロード画面を表示する。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_chitan_chosa_view(request):
    bool_return, response = index_chosa_summary(request, _CHI_CHO)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：index_hojo_chosa_view(request)
### urlpattern：path('hojo/chosa/', views.index_hojo_chosa_view, name='index_hojo_chosa_view')
### 初期選択有りのダウンロード画面を表示する。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_hojo_chosa_view(request):
    bool_return, response = index_chosa_summary(request, _HOJ_CHO)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：index_koeki_chosa_view(request)
### urlpattern：path('koeki/chosa/', views.index_koeki_chosa_view, name='index_koeki_chosa_view')
### 初期選択有りのダウンロード画面を表示する。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_koeki_chosa_view(request):
    bool_return, response = index_chosa_summary(request, _KOE_CHO)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：index_ippan_summary_view(request)
### urlpattern：path('ippan/summary/', views.index_ippan_summary_view, name='index_ippan_summary_view')
### 初期選択有りのダウンロード画面を表示する。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_ippan_summary_view(request):
    bool_return, response = index_chosa_summary(request, _IPP_SUM)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：index_chitan_summary_view(request)
### urlpattern：path('chitan/summary/', views.index_chitan_summary_view, name='index_chitan_summary_view')
### 初期選択有りのダウンロード画面を表示する。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_chitan_summary_view(request):
    bool_return, response = index_chosa_summary(request, _CHI_SUM)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：index_hojo_summary_view(request)
### urlpattern：path('hojo/summary/', views.index_hojo_summary_view, name='index_hojo_summary_view')
### 初期選択有りのダウンロード画面を表示する。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_hojo_summary_view(request):
    bool_return, response = index_chosa_summary(request, _HOJ_SUM)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：index_koeki_summary_view(request)
### urlpattern：path('koeki/summary/', views.index_koeki_summary_view, name='index_koeki_summary_view')
### 初期選択有りのダウンロード画面を表示する。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_koeki_summary_view(request):
    bool_return, response = index_chosa_summary(request, _KOE_SUM)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：download_ippan_chosa_view(request)
### urlpattern：path('download/ippan/chosa/', views.download_ippan_chosa_view, name='download_ippan_chosa_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_chosa_view(request):
    bool_return, response = download_chosa_summary(request, _IPP_CHO)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：download_area_view(request)
### urlpattern：path('download/area/', views.download_area_view, name='download_area_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_area_view(request):
    bool_return, response = download_chosa_summary(request, _ARE)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：download_chitan_chosa_view(request)
### urlpattern：path('download/chitan/chosa/', views.download_chitan_chosa_view, name='download_chitan_chosa_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_chitan_chosa_view(request):
    bool_return, response = download_chosa_summary(request, _CHI_CHO)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：download_hojo_chosa_view(request)
### urlpattern：path('download/hojo/chosa/', views.download_hojo_chosa_view, name='download_hojo_chosa_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_hojo_chosa_view(request):
    bool_return, response = download_chosa_summary(request, _HOJ_CHO)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：download_koeki_chosa_view(request)
### urlpattern：path('download/koeki/chosa/', views.download_koeki_chosa_view, name='download_koeki_chosa_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_koeki_chosa_view(request):
    bool_return, response = download_chosa_summary(request, _KOE_CHO)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：download_ippan_summary_view(request)
### urlpattern：path('download/ippan/summary/', views.download_ippan_summary_view, name='download_ippan_summary_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_summary_view(request):
    bool_return, response = download_chosa_summary(request, _IPP_SUM)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：download_chitan_summary_view(request)
### urlpattern：path('download/chitan/summary/', views.download_chitan_summary_view, name='download_chitan_summary_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_chitan_summary_view(request):
    bool_return, response = download_chosa_summary(request, _CHI_SUM)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：download_hojo_summary_view(request)
### urlpattern：path('download/hojo/summary/', views.download_hojo_summary_view, name='download_hojo_summary_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_hojo_summary_view(request):
    bool_return, response = download_chosa_summary(request, _HOJ_SUM)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：download_koeki_summary_view(request)
### urlpattern：path('download/koeki/summary/', views.download_koeki_summary_view, name='download_koeki_summary_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_koeki_summary_view(request):
    bool_return, response = download_chosa_summary(request, _KOE_SUM)
    if bool_return == False:
        pass
    return response

###############################################################################
### 関数名：progress_view(request, hash_code)
### urlpattern：path('progress/<slug:hash_code>', views.progress_view, name='progress_view')
### メッセージキュー、非同期対応、負荷平準化、遅延処理対応のダウンロード状況画面を表示する。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def progress_view(request, hash_code, count):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0200Download.progress_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0200Download.progress_view()関数 STEP 1/5.', 'DEBUG')
        print_log('[DEBUG] P0200Download.progress_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0200Download.progress_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0200Download.progress_view()関数 hash_code={}'.format(hash_code), 'DEBUG')
        print_log('[DEBUG] P0200Download.progress_view()関数 count={}'.format(count), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0200Download.progress_view()関数 STEP 2/5.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user)
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].role_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0200Download.progress_view()関数 STEP 3/5.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0200Download.progress_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0200Download/progress.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))
        
        #######################################################################
        ### 計算処理、局所変数セット処理(0030)
        ### ハッシュ値を計算してダウンロードファイルパスに値をセットする。
        #######################################################################
        print_log('[DEBUG] P0200Download.progress_view()関数 STEP 4/5.', 'DEBUG')
        ### download_file_path = sorted(glob.glob('static/'+str(hash_code)+'/*.xlsx'), key=os.path.getmtime)
        download_file_path = sorted(glob.glob('static/tmp/'+str(hash_code)+'/*.xlsx'), key=os.path.getmtime)
        
        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0200Download.progress_view()関数 STEP 5/5.', 'DEBUG')
        template = loader.get_template('P0200Download/progress.html')
        context = {
            'role_code': user_proxy_list[0].role_code, 
            'count': count, 
            'download_file_path': download_file_path, 
            'hash_code': hash_code, 
        }
        print_log('[INFO] P0200Download.progress_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
        
    except:
        print_log('[ERROR] P0200Download.progress_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0200Download.progress_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0200Download.progress_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0200Download/progress.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 初期選択無しのダウンロード画面を表示する。
### 調査票ダウンロード
### 集計結果ダウンロード
###############################################################################
def index_chosa_summary(request, file_type):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        ### ※url.pyと代理のVIEW関数でファイル種別を絞り込んでいるため、file_typeをチェックしない。
        #######################################################################
        reset_log()
        print_log('[INFO] P0200Download.index_chosa_summary()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0200Download.index_chosa_summary()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0200Download.index_chosa_summary()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0200Download.index_chosa_summary()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0200Download.index_chosa_summary()関数 file_type={}'.format(file_type), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0200Download.index_chosa_summary()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user)
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].role_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0200Download.index_chosa_summary()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0200Download.index_chosa_summary()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0200Download/index.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、都道府県データを取得する。
        #######################################################################
        print_log('[DEBUG] P0200Download.index_chosa_summary()関数 STEP 4/6.', 'DEBUG')
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")

        #######################################################################
        ### DBアクセス処理(0040)
        ### DBにアクセスして、市区町村データを取得する。
        #######################################################################
        print_log('[DEBUG] P0200Download.index_chosa_summary()関数 STEP 5/6.', 'DEBUG')
        params = dict({
            'KEN01': _KEN01, 'KEN02': _KEN02, 'KEN03': _KEN03, 'KEN04': _KEN04, 'KEN05': _KEN05, 
            'KEN06': _KEN06, 'KEN07': _KEN07, 'KEN08': _KEN08, 'KEN09': _KEN09, 'KEN10': _KEN10, 
            'KEN11': _KEN11, 'KEN12': _KEN12, 'KEN13': _KEN13, 'KEN14': _KEN14, 'KEN15': _KEN15, 
            'KEN16': _KEN16, 'KEN17': _KEN17, 'KEN18': _KEN18, 'KEN19': _KEN19, 'KEN20': _KEN20, 
            'KEN21': _KEN21, 'KEN22': _KEN22, 'KEN23': _KEN23, 'KEN24': _KEN24, 'KEN25': _KEN25, 
            'KEN26': _KEN26, 'KEN27': _KEN27, 'KEN28': _KEN28, 'KEN29': _KEN29, 'KEN30': _KEN30, 
            'KEN31': _KEN31, 'KEN32': _KEN32, 'KEN33': _KEN33, 'KEN34': _KEN34, 'KEN35': _KEN35, 
            'KEN36': _KEN36, 'KEN37': _KEN37, 'KEN38': _KEN38, 'KEN39': _KEN39, 'KEN40': _KEN40, 
            'KEN41': _KEN41, 'KEN42': _KEN42, 'KEN43': _KEN43, 'KEN44': _KEN44, 'KEN45': _KEN45, 
            'KEN46': _KEN46, 'KEN47': _KEN47
        })
        city_list01 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN01)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list02 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN02)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list03 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN03)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list04 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN04)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list05 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN05)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list06 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN06)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list07 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN07)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list08 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN08)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list09 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN09)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list10 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN10)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list11 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN11)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list12 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN12)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list13 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN13)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list14 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN14)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list15 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN15)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list16 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN16)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list17 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN17)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list18 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN18)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list19 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN19)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list20 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN20)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list21 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN21)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list22 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN22)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list23 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN23)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list24 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN24)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list25 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN25)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list26 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN26)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list27 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN27)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list28 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN28)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list29 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN29)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list30 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN30)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list31 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN31)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list32 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN32)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list33 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN33)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list34 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN34)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list35 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN35)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list36 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN36)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list37 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN37)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list38 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN38)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list39 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN39)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list40 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN40)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list41 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN41)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list42 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN42)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list43 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN43)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list44 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN44)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list45 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN45)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list46 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN46)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)
        city_list47 = CITY.objects.raw("""SELECT * FROM CITY WHERE KEN_CODE=%(KEN47)s ORDER BY CAST(CITY_CODE AS INTEGER)""", params)

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0200Download.index_chosa_summary()関数 STEP 6/6.', 'DEBUG')
        template = loader.get_template('P0200Download/index.html')
        context = {
            'role_code': user_proxy_list[0].role_code, 
            'ken_code': user_proxy_list[0].ken_code, 
            'city_list01': city_list01,
            'city_list02': city_list02,
            'city_list03': city_list03,
            'city_list04': city_list04,
            'city_list05': city_list05,
            'city_list06': city_list06,
            'city_list07': city_list07,
            'city_list08': city_list08,
            'city_list09': city_list09,
            'city_list10': city_list10,
            'city_list11': city_list11,
            'city_list12': city_list12,
            'city_list13': city_list13,
            'city_list14': city_list14,
            'city_list15': city_list15,
            'city_list16': city_list16,
            'city_list17': city_list17,
            'city_list18': city_list18,
            'city_list19': city_list19,
            'city_list20': city_list20,
            'city_list21': city_list21,
            'city_list22': city_list22,
            'city_list23': city_list23,
            'city_list24': city_list24,
            'city_list25': city_list25,
            'city_list26': city_list26,
            'city_list27': city_list27,
            'city_list28': city_list28,
            'city_list29': city_list29,
            'city_list30': city_list30,
            'city_list31': city_list31,
            'city_list32': city_list32,
            'city_list33': city_list33,
            'city_list34': city_list34,
            'city_list35': city_list35,
            'city_list36': city_list36,
            'city_list37': city_list37,
            'city_list38': city_list38,
            'city_list39': city_list39,
            'city_list40': city_list40,
            'city_list41': city_list41,
            'city_list42': city_list42,
            'city_list43': city_list43,
            'city_list44': city_list44,
            'city_list45': city_list45,
            'city_list46': city_list46,
            'city_list47': city_list47,
            'ken_list': ken_list,
            'file_type': file_type, 
        }
        print_log('[INFO] P0200Download.index_chosa_summary()関数が正常終了しました。', 'INFO')
        return True, HttpResponse(template.render(context, request))

    except:
        print_log('[ERROR] P0200Download.index_chosa_summary()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0200Download.index_chosa_summary()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0200Download.index_chosa_summary()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0200Download/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))

###############################################################################
### ダウンロード処理
### 調査票ダウンロード
### 集計結果ダウンロード
###############################################################################
def download_chosa_summary(request, file_type):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        ### ※url.pyと代理のVIEW関数でファイル種別を絞り込んでいるため、file_typeをチェックしない。
        #######################################################################
        reset_log()
        print_log('[INFO] P0200Download.download_chosa_summary()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 STEP 1/8.', 'DEBUG')
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 file_type={}'.format(file_type), 'DEBUG')
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 request.POST.get(city_code_hidden)={}'.format(request.POST.get('city_code_hidden')), 'DEBUG')

        if request.method == 'GET':
            print_log('[WARN] P0200Download.download_chosa_summary()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0200Download/index.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))

        if request.POST.get('city_code_hidden') is None:
            print_log('[WARN] P0200Download.download_chosa_summary()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0200Download/index.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
            
        city_code_list = [x.strip() for x in request.POST.get('city_code_hidden').split(',')][:-1]

        if city_code_list is None:
            print_log('[WARN] P0200Download.download_chosa_summary()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0200Download/index.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))

        if len(city_code_list) == 0:
            print_log('[WARN] P0200Download.download_chosa_summary()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0200Download/index.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 STEP 2/8.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user) 
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].role_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 STEP 3/8.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0200Download.download_chosa_summary()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0200Download/index.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、都道府県データを取得する。
        #######################################################################
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 STEP 4/8.', 'DEBUG')
        ken_code_list = []
        ken_name_list = []
        city_name_list = []
        for city_code in city_code_list:
            params = dict({'CITY_CODE': city_code})
            city_list = CITY.objects.raw("""
                SELECT 
                    CT1.city_code, 
                    CT1.city_name, 
                    CT1.ken_code, 
                    KE1.ken_name 
                FROM CITY CT1 
                LEFT JOIN KEN KE1 ON CT1.ken_code=KE1.ken_code 
                WHERE 
                    CT1.city_code=%(CITY_CODE)s LIMIT 1""", params)
            
            ken_code_list.append([city.ken_code for city in city_list][0])
            ken_name_list.append([city.ken_name for city in city_list][0])
            city_name_list.append([city.city_name for city in city_list][0])
            
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 ken_code_list={}'.format(ken_code_list), 'DEBUG')
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 ken_name_list={}'.format(ken_name_list), 'DEBUG')
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 city_code_list={}'.format(city_code_list), 'DEBUG')
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 city_name_list={}'.format(city_name_list), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0040)
        ### ハッシュコードを生成する。
        ### ※リクエスト固有のディレクトリ名を生成するため等に使用する。
        #######################################################################
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 STEP 5/8.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        hash_code = hashlib.md5((str(datetime_now_YmdHMS)).encode()).hexdigest()[0:10]
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 hash_code={}'.format(hash_code), 'DEBUG')

        #######################################################################
        ### 局所変数セット処理(0050)
        ### ダウンロードファイルパス、ダウンロードファイル名に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 STEP 6/8.', 'DEBUG')
        download_file_path = []
        download_file_name = []
        if file_type == _IPP_CHO:
            for i, city_code in enumerate(city_code_list):
                download_file_path.append('static/tmp/' + str(hash_code) + '/ippan_chosa_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
                download_file_name.append('ippan_chosa_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
        elif file_type == _ARE:
            for i, city_code in enumerate(city_code_list):
                download_file_path.append('static/tmp/' + str(hash_code) + '/ippan_chosa_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
                download_file_name.append('area_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.pdf')
        elif file_type == _CHI_CHO:
            for i, city_code in enumerate(city_code_list):
                download_file_path.append('static/tmp/' + str(hash_code) + '/ippan_chosa_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
                download_file_name.append('chitan_chosa_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
        elif file_type == _HOJ_CHO:
            for i, city_code in enumerate(city_code_list):
                download_file_path.append('static/tmp/' + str(hash_code) + '/ippan_chosa_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
                download_file_name.append('hojo_chosa_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
        elif file_type == _KOE_CHO:
            for i, city_code in enumerate(city_code_list):
                download_file_path.append('static/tmp/' + str(hash_code) + '/ippan_chosa_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
                download_file_name.append('koeki_chosa_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
        elif file_type == _IPP_SUM:
            for i, city_code in enumerate(city_code_list):
                download_file_path.append('static/tmp/' + str(hash_code) + '/ippan_chosa_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
                download_file_name.append('ippan_summary_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
        elif file_type == _CHI_SUM:
            for i, city_code in enumerate(city_code_list):
                download_file_path.append('static/tmp/' + str(hash_code) + '/ippan_chosa_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
                download_file_name.append('chitan_summary_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
        elif file_type == _HOJ_SUM:
            for i, city_code in enumerate(city_code_list):
                download_file_path.append('static/tmp/' + str(hash_code) + '/ippan_chosa_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
                download_file_name.append('hojo_summary_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
        elif file_type == _KOE_SUM:
            for i, city_code in enumerate(city_code_list):
                download_file_path.append('static/tmp/' + str(hash_code) + '/ippan_chosa_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
                download_file_name.append('koeki_summary_' + str(city_code_list[i]) + '_' + str(ken_name_list[i]) + '_' + str(city_name_list[i]) + '.xlsx')
            
        new_dir_path = 'static/tmp/' + str(hash_code)
        os.makedirs(new_dir_path, exist_ok=True)

        #######################################################################
        ### DBアクセス処理(0060)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 STEP 7/8.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")
            
            if file_type == _IPP_CHO:
                for i, city_code in enumerate(city_code_list):
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'header_id': None, 
                        'ken_code': ken_code_list[i], 
                        'city_code': city_code_list[i], 
                        'action_code': _IPP_ACT_90, 
                        'status_code': None, 
                        'download_file_path': download_file_path[i], 
                        'download_file_name': download_file_name[i],
                        'upload_file_path': None, 
                        'upload_file_name': None
                    })
                    bool_return = publish_message(metadata=metadata)
                    if bool_return == False:
                        raise Exception
            elif file_type == _ARE:
                for i, city_code in enumerate(city_code_list):
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'header_id': None, 
                        'ken_code': ken_code_list[i], 
                        'city_code': city_code_list[i], 
                        'action_code': _ARE_ACT_90, 
                        'status_code': None, 
                        'download_file_path': download_file_path[i], 
                        'download_file_name': download_file_name[i],
                        'upload_file_path': None, 
                        'upload_file_name': None
                    })
                    bool_return = publish_message(metadata=metadata)
                    if bool_return == False:
                        raise Exception
            elif file_type == _CHIN_CHO:
                for i, city_code in enumerate(city_code_list):
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'header_id': None, 
                        'ken_code': ken_code_list[i], 
                        'city_code': city_code_list[i], 
                        'action_code': _CHI_ACT_90, 
                        'status_code': None, 
                        'download_file_path': download_file_path[i], 
                        'download_file_name': download_file_name[i],
                        'upload_file_path': None, 
                        'upload_file_name': None
                    })
                    bool_return = publish_message(metadata=metadata)
                    if bool_return == False:
                        raise Exception
            elif file_type == _HOJ_CHO:
                for i, city_code in enumerate(city_code_list):
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'header_id': None, 
                        'ken_code': ken_code_list[i], 
                        'city_code': city_code_list[i], 
                        'action_code': _HOJ_ACT_90, 
                        'status_code': None, 
                        'download_file_path': download_file_path[i], 
                        'download_file_name': download_file_name[i],
                        'upload_file_path': None, 
                        'upload_file_name': None
                    })
                    bool_return = publish_message(metadata=metadata)
                    if bool_return == False:
                        raise Exception
            elif file_type == _KOE_CHO:
                for i, city_code in enumerate(city_code_list):
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'header_id': None, 
                        'ken_code': ken_code_list[i], 
                        'city_code': city_code_list[i], 
                        'action_code': _KOE_ACT_90, 
                        'status_code': None, 
                        'download_file_path': download_file_path[i], 
                        'download_file_name': download_file_name[i],
                        'upload_file_path': None, 
                        'upload_file_name': None
                    })
                    bool_return = publish_message(metadata=metadata)
                    if bool_return == False:
                        raise Exception
            elif file_type == _IPP_SUM:
                for i, city_code in enumerate(city_code_list):
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'header_id': None, 
                        'ken_code': ken_code_list[i], 
                        'city_code': city_code_list[i], 
                        'action_code': _IPP_ACT_91, 
                        'status_code': None, 
                        'download_file_path': download_file_path[i], 
                        'download_file_name': download_file_name[i],
                        'upload_file_path': None, 
                        'upload_file_name': None
                    })
                    bool_return = publish_message(metadata=metadata)
                    if bool_return == False:
                        raise Exception
            elif file_type == _CHI_SUM:
                for i, city_code in enumerate(city_code_list):
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'header_id': None, 
                        'ken_code': ken_code_list[i], 
                        'city_code': city_code_list[i], 
                        'action_code': _CHI_ACT_91, 
                        'status_code': None, 
                        'download_file_path': download_file_path[i], 
                        'download_file_name': download_file_name[i],
                        'upload_file_path': None, 
                        'upload_file_name': None
                    })
                    bool_return = publish_message(metadata=metadata)
                    if bool_return == False:
                        raise Exception
            elif file_type == _HOJ_SUM:
                for i, city_code in enumerate(city_code_list):
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'header_id': None, 
                        'ken_code': ken_code_list[i], 
                        'city_code': city_code_list[i], 
                        'action_code': _HOJ_ACT_91, 
                        'status_code': None, 
                        'download_file_path': download_file_path[i], 
                        'download_file_name': download_file_name[i],
                        'upload_file_path': None, 
                        'upload_file_name': None
                    })
                    bool_return = publish_message(metadata=metadata)
                    if bool_return == False:
                        raise Exception
            elif file_type == _KOE_SUM:
                for i, city_code in enumerate(city_code_list):
                    metadata = dict({
                        'connection_cursor': connection_cursor, 
                        'header_id': None, 
                        'ken_code': ken_code_list[i], 
                        'city_code': city_code_list[i], 
                        'action_code': _KOE_ACT_91, 
                        'status_code': None, 
                        'download_file_path': download_file_path[i], 
                        'download_file_name': download_file_name[i],
                        'upload_file_path': None, 
                        'upload_file_name': None
                    })
                    bool_return = publish_message(metadata=metadata)
                    if bool_return == False:
                        raise Exception
                
            connection_cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0200Download.download_chosa_summary()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0200Download.download_chosa_summary()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
        finally:
            connection_cursor.close()

        #######################################################################
        ### レスポンスセット処理(0070)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        ### See https://groups.google.com/g/django-users/c/SLw6SrIC8wI
        #######################################################################
        print_log('[DEBUG] P0200Download.download_chosa_summary()関数 STEP 8/8.', 'DEBUG')
        ### return True, redirect('/P0220Ken/download/' + str(hash_code) + '/' + str(len(city_code_list)) + '/')
        return True, redirect('/P0200Download/progress/' + str(hash_code) + '/' + str(len(city_code_list)) + '/')

    except:
        print_log('[ERROR] P0200Download.download_chosa_summary()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0200Download.download_chosa_summary()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0200Download.download_chosa_summary()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0200Download/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))
