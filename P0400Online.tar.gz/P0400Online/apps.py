from django.apps import AppConfig

class P0400OnlineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'P0400Online'
