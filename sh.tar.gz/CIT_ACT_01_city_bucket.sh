#!/bin/bash

### while true
### do
###     echo "python3 manage.py CIT_ACT_01_city_bucket"
###     python3 manage.py CIT_ACT_01_city_bucket
###     echo "sleep 5s"
###     sleep 5s
### done

echo "python3 manage.py CIT_ACT_01_city_bucket"
python3 manage.py CIT_ACT_01_city_bucket
echo "sleep 5s"
sleep 5s
