#!/bin/bash

while true
do
    echo "python3 manage.py IPP_ACT_07_verify_sdb_by_reverse"
    python3 manage.py IPP_ACT_07_verify_sdb_by_reverse
    echo "sleep 5s"
    sleep 5s
done
