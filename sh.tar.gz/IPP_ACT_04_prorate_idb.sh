#!/bin/bash

while true
do
    echo "python3 manage.py IPP_ACT_04_prorate_idb"
    python3 manage.py IPP_ACT_04_prorate_idb
    echo "sleep 5s"
    sleep 5s
done
