#!/bin/bash

### while true
### do
###     echo "python3 manage.py KEN_ACT_01_ken_bucket"
###     python3 manage.py KEN_ACT_01_ken_bucket
###     echo "sleep 5s"
###     sleep 5s
### done

echo "python3 manage.py KEN_ACT_01_ken_bucket"
python3 manage.py KEN_ACT_01_ken_bucket
echo "sleep 5s"
sleep 5s

