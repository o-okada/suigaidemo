#!/bin/bash

while true
do
    echo "python3 manage.py IPP_ACT_90_download_koeki_chosa"
    python3 manage.py IPP_ACT_90_download_koeki_chosa
    echo "sleep 5s"
    sleep 5s
done
