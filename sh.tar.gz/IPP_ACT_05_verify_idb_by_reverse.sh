#!/bin/bash

while true
do
    echo "python3 manage.py IPP_ACT_05_verify_idb_by_reverse"
    python3 manage.py IPP_ACT_05_verify_idb_by_reverse
    echo "sleep 5s"
    sleep 5s
done
