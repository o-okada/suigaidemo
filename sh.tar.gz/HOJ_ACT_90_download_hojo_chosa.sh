#!/bin/bash

while true
do
    echo "python3 manage.py HOJ_ACT_90_download_hojo_chosa"
    python3 manage.py HOJ_ACT_90_download_hojo_chosa
    echo "sleep 5s"
    sleep 5s
done
