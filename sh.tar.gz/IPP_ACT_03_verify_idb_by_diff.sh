#!/bin/bash

while true
do
    echo "python3 manage.py IPP_ACT_03_verify_idb_by_diff"
    python3 manage.py IPP_ACT_03_verify_idb_by_diff
    echo "sleep 5s"
    sleep 5s
done
