#!/bin/bash

### ./IPP_ACT_03_verify_idb_by_diff_method.sh &
### sleep 5s

### ./IPP_ACT_04_prorate_idb.sh &
### sleep 5s

### ./IPP_ACT_05_verify_idb_by_reverse_method.sh &
### sleep 5s

### ./IPP_ACT_06_summarize_sdb.sh &
### sleep 5s

### ./IPP_ACT_07_verify_sdb_by_reverse_method.sh &
### sleep 5s

./IPP_ACT_90_download_ippan_chosa.sh &
sleep 5s

### ./CHI_ACT_90_download_chitan_chosa.sh &
### sleep 5s

### ./HOJ_ACT_90_download_hojo_chosa.sh &
### sleep 5s

### ./KOE_ACT_90_download_koeki_chosa.sh &
### sleep 5s
