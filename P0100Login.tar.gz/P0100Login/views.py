###############################################################################
### ファイル名：P0100Login/views.py
### ログイン
###############################################################################

import sys
from django.contrib.auth import authenticate
from django.contrib.auth import login
from django.contrib.auth import logout
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

### USER_PROXY.ROLE_CODE
_ROLE_CITY = 'ROLE_CITY'
_ROLE_KEN = 'ROLE_KEN'
_ROLE_MANAGE = 'ROLE_MANAGE'

###############################################################################
### 関数名：index_view(request)
### urlpattern：path('', views.index_view, name='index_view')
###############################################################################
def index_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0100Login.index_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0100Login.index_view()関数 STEP 1/4.', 'DEBUG')
        print_log('[DEBUG] P0100Login.index_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0100Login.index_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### 認証処理(0010)
        ### ログイン中、ログアウト中にかかわらずに、ログアウトする。
        #######################################################################
        print_log('[DEBUG] P0100Login.index_view()関数 STEP 2/4.', 'DEBUG')
        logout(request)
        
        #######################################################################
        ### 条件分岐処理(0020)
        ### GETのときログイン画面を表示する。
        ### ※ネストを浅くするため、GETの場合、テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0100Login.index_view()関数 STEP 3/4.', 'DEBUG')
        if request.method == 'GET':
            template = loader.get_template('P0100Login/index.html')
            context = {
            }
            print_log('[INFO] P0100Login.index_view()関数が正常終了しました。', 'INFO')
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### 条件分岐処理(0030)
        ### POSTのときユーザを認証する。
        #######################################################################
        print_log('[DEBUG] P0100Login.index_view()関数 STEP 4/4.', 'DEBUG')
        if request.method == 'POST':

            user = authenticate(
                username = request.POST['username'], 
                password = request.POST['password'])

            ### print_log('[DEBUG] P0100Login.index_view()関数 request.POST.username={}'.format(request.POST['username']), 'DEBUG')
            ### print_log('[DEBUG] P0100Login.index_view()関数 request.POST.password={}'.format(request.POST['password']), 'DEBUG')
            print_log('[DEBUG] P0100Login.index_view()関数 str(user)={}'.format(str(user)), 'DEBUG')
            
            params = dict({
                'USERNAME': str(user),
            })
            ### bool_return, user_proxy_list = user_proxy_objects_raw(params)
            ### if bool_return == False:
            ###     raise Exception
            user_proxy_list = USER_PROXY.objects.raw("""
                SELECT 
                    P1.ID, 
                    A1.USERNAME, 
                    P1.ROLE_CODE, 
                    P1.KEN_CODE, 
                    P1.CITY_CODE 
                FROM USER_PROXY P1 
                LEFT JOIN (
                    SELECT 
                        * 
                    FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
                WHERE 
                    A1.USERNAME=%(USERNAME)s""", params)

            print_log('{}'.format(user_proxy_list), 'DEBUG')
            print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
            print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
            print_log('{}'.format(user_proxy_list[0].role_code), 'DEBUG')
                
            ### 認証に成功した場合、、、
            print_log('[DEBUG] P0100Login.index_view()関数 STEP 4_1/4.', 'DEBUG')
            if user is not None:
                if user.is_active:
                    ### ユーザが活性（有効）の場合、ログインして、ファイル管理画面にリダイレクトする。
                    login(request, user)
                    print_log('[INFO] P0100Login.index_view()関数が正常終了しました。', 'INFO')
                    if user_proxy_list[0].role_code == _ROLE_CITY:
                        return HttpResponseRedirect('/P0110City/')
                    elif user_proxy_list[0].role_code == _ROLE_KEN:
                        return HttpResponseRedirect('/P0120Ken/')
                    elif user_proxy_list[0].role_code == _ROLE_MANAGE:
                        return HttpResponseRedirect('/P0130Manage/')
                    else:
                        return HttpResponseRedirect('/P0110City/')
                
                else:
                    ### ユーザが非活性（無効）の場合、テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
                    template = loader.get_template('P0100Login/index.html')
                    context = {
                        'message': 'ログインに失敗しました。'
                    }
                    print_log('[WARN] P0100Login.index_view()関数が警告終了しました。', 'WARN')
                    return HttpResponse(template.render(context, request))

            ### 認証に失敗した場合、テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
            print_log('[DEBUG] P0100Login.index_view()関数 STEP 4_2/4.', 'DEBUG')
            if user is None:
                template = loader.get_template('P0100Login/index.html')
                context = {
                    'message': 'ログインに失敗しました。'
                }
                print_log('[WARN] P0100Login.index_view()関数が警告終了しました。', 'WARN')
                return HttpResponse(template.render(context, request))
            
    except:
        print_log('[ERROR] P0100Login.index_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0100Login.index_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0100Login.index_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0100Login/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
        