###############################################################################
### ファイル名：P0130Manage/views.py
### ファイル管理
###############################################################################

import json
import os
import sys

from datetime import date, datetime
from datetime import timedelta, timezone

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.http import HttpResponseNotFound
from django.http.response import JsonResponse
from django.shortcuts import redirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic.base import TemplateView

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ

#from P0000Common.services import get_alert_log
#from P0000Common.services import print_log
#from P0000Common.services import reset_log

###############################################################################
### 関数名：check_user_proxy(request)【済】
### ※ユーザプロキシをチェックする。
###############################################################################
#def check_user_proxy(request):
#    try:
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
#        print_log('[DEBUG] P0500Gis.check_user_proxy()関数 STEP 1/2.', 'DEBUG')
#        params = dict({
#            'USERNAME': str(request.user), ### ※str(request.user)で正解。ここではstrへのキャストが必要。
#        })
#        user_proxy_list = USER_PROXY.objects.raw("""
#            SELECT 
#                P1.ID, 
#                A1.USERNAME, 
#                P1.ROLE_CODE, 
#                P1.KEN_CODE, 
#                P1.CITY_CODE 
#            FROM USER_PROXY P1 
#            LEFT JOIN (
#                SELECT 
#                    * 
#                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
#            WHERE 
#                A1.USERNAME=%(USERNAME)s""", params)
            
#        print_log('{}'.format(user_proxy_list), 'DEBUG')
#        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
#        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
#        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
#        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値を戻す。
        #######################################################################
#        print_log('[DEBUG] P0500Gis.check_user_proxy()関数 STEP 2/2.', 'DEBUG')
#        return True, user_proxy_list
        
#    except:
#        print_log('[ERROR] P0500Gis.check_user_proxy()関数が異常終了しました。', 'ERROR')
#        return False, []

###############################################################################
### GIS
### 関数名：index_view(request)
### urlpattern：path('', views.index_view, name='index_view')
###############################################################################
### @login_required(None, login_url='/P0100Login/')
def index_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
#        reset_log()
#        print_log('[INFO] P0500Gis.index_view()関数が開始しました。', 'INFO')
#        print_log('[DEBUG] P0500Gis.index_view()関数 STEP 1/5.', 'DEBUG')
#        print_log('[DEBUG] P0500Gis.index_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
#        print_log('[DEBUG] P0500Gis.index_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        
        #######################################################################
        ### ユーザプロキシチェック処理(0010)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
#        print_log('[DEBUG] P0500Gis.index_view()関数 STEP 2/5.', 'DEBUG')
        ### bool_return, user_proxy_list = check_user_proxy(request)
        ### if bool_return == False:
        ###     print_log('[WARN] P0500Gis.index_view()関数が警告終了しました。', 'WARN')
        ###     template = loader.get_template('P0500Gis/index.html')
        ###     context = {
        ###         'alert_log': get_alert_log(), 
        ###     }
        ###     return HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0020)
        ### DBにアクセスして、データを取得する。
        #######################################################################
#        print_log('[DEBUG] P0500Gis.index_view()関数 STEP 3/5.', 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0030)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
#        print_log('[DEBUG] P0500Gis.index_view()関数 STEP 4/5.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
#        print_log('[DEBUG] P0500Gis.index_view()関数 STEP 5/5.', 'DEBUG')
#        print_log('[INFO] P0500Gis.index_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0500Gis/index.html')
        context = {
        }
        return HttpResponse(template.render(context, request))
    
    except:
#        print_log('[ERROR] P0500Gis.index_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
#        print_log('[ERROR] P0500Gis.index_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
#        print_log('[ERROR] P0500Gis.index_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0500Gis/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

### import matplotlib.pyplot as plt
### import io

### def plt2png():
###     buf = io.BytesIO()
###     plt.savefig(buf, format='png', dpi=200)
###     s = buf.getvalue()
###     buf.close()
###     return s

###############################################################################
### GIS
### 関数名：map_view(request)
### urlpattern：path('map/<slug:z>/<slug:x>/<slug:y>', views.map_view, name='map_view')
###############################################################################
### @login_required(None, login_url='/P0100Login/')
### def map_view(request, z, x, y):
###     try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
###         reset_log()
###         print_log('[INFO] P0500Gis.map_view()関数が開始しました。', 'INFO')
###         print_log('[DEBUG] P0500Gis.map_view()関数 STEP 1/5.', 'DEBUG')
###         print_log('[DEBUG] P0500Gis.map_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
###         print_log('[DEBUG] P0500Gis.map_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        #######################################################################
        ### ユーザプロキシチェック処理(0010)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
###         print_log('[DEBUG] P0500Gis.map_view()関数 STEP 2/5.', 'DEBUG')
        ### bool_return, user_proxy_list = check_user_proxy(request)
        ### if bool_return == False:
        ###     print_log('[WARN] P0500Gis.map_view()関数が警告終了しました。', 'WARN')
        ###     template = loader.get_template('P0500Gis/index.html')
        ###     context = {
        ###         'alert_log': get_alert_log(), 
        ###     }
        ###     return HttpResponse(template.render(context, request))
        #######################################################################
        ### DBアクセス処理(0020)
        ### DBにアクセスして、データを取得する。
        #######################################################################
###         print_log('[DEBUG] P0500Gis.map_view()関数 STEP 3/5.', 'DEBUG')
        #######################################################################
        ### 戻り値チェック処理(0030)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
###         print_log('[DEBUG] P0500Gis.map_view()関数 STEP 4/5.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
###         print_log('[DEBUG] P0500Gis.map_view()関数 STEP 5/5.', 'DEBUG')
###         print_log('[INFO] P0500Gis.map_view()関数が正常終了しました。', 'INFO')
        ### template = loader.get_template('P0500Gis/index.html')
        ### context = {
        ### }
        ### return HttpResponse(template.render(context, request))
        ### with open('static/15/29105/12986.png') as f:
        ###     binary = f.read()
###         x = [1, 5, 9]
###         y = [4, 6, 8]
###         ax = plt.subplot()
###         ax.scatter(x, y)
###         png = plt2png()
###         plt.cla()
###         return HttpResponse(png, content_type='image/png')
###     except:
###         print_log('[ERROR] P0500Gis.map_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
###         print_log('[ERROR] P0500Gis.map_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
###         print_log('[ERROR] P0500Gis.map_view()関数が異常終了しました。', 'ERROR')
###         template = loader.get_template('P0500Gis/index.html')
###         context = {
###             'alert_log': get_alert_log(), 
###         }
###         return HttpResponse(template.render(context, request))
