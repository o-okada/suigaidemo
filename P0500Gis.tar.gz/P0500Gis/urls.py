from django.urls import path
from . import views

app_name = 'P0500Gis'
urlpatterns = [
    path('', views.index_view, name='index_view'),
    ### path('map/<slug:z>/<slug:x>/<slug:y>', views.map_view, name='map_view'), 
]
