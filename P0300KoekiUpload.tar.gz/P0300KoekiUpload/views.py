###############################################################################
### ファイル名：P0300KoekiUpload/views.py
### 公益事業等調査票アップロード
###############################################################################

import os
import sys
from datetime import date, datetime, timedelta, timezone
from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db import transaction
from django.db.models import Max
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic

import hashlib

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from .forms import KoekiUploadForm

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 0000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 0010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 0020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 0030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from P0000Common.common import split_name_code
from P0000Common.common import isdate
from P0000Common.common import convert_empty_to_none
from P0000Common.common import add_comment

from . import constants

from MessageQueue.views import get_message 
from MessageQueue.views import publish_message 
from MessageQueue.views import publish_consume_message 
from MessageQueue.views import consume_message 
from MessageQueue.views import delete_message 

_G01 = 'G01'
_G02 = 'G02'
_G03 = 'G03'
_G04 = 'G04'
_G05 = 'G05'
_G06 = 'G06'
_G07 = 'G07'
_G08 = 'G08'
_G09 = 'G09'
_G10 = 'G10'
_G99 = 'G99'

_WAITING = 'WAITING'
_RUNNING = 'RUNNING'
_SUCCESS = 'SUCCESS'
_FAILURE = 'FAILURE'
_CANCEL = 'CANCEL'

###############################################################################
### 関数名：index_view(request)
### urlpattern：path('', views.index_view, name='index_view')
### (1)GETの場合、公益事業等調査票アップロード画面を表示する。
### (2)POSTの場合、アップロードされた公益事業等調査票ファイルをチェックして、正常ケースの場合、DBに登録する。
### ※複数EXCELシート未対応版
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(10000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0300KoekiUpload.index_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 1/35.', 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 request={}'.format(request.method), 'DEBUG')
        
        #######################################################################
        ### 局所変数セット処理(10010)
        ### チェック用の局所変数を初期化する。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 2/35.', 'DEBUG')
        ### 必須チェック用の局所変数を初期化する。
        require_info = []
        require_warn = []

        ### 形式チェック用の局所変数を初期化する。
        format_info = []
        format_warn = []

        ### 範囲チェック用の局所変数を初期化する。
        range_info = []
        range_warn = []

        ### 相関チェック用の局所変数を初期化する。
        correlate_info = []
        correlate_warn = []

        ### 突合せチェックの結果を格納するために局所変数をセットする。
        compare_info = []
        compare_warn = []
    
        #######################################################################
        ### 条件分岐処理(10020)
        ### (1)GETの場合、公益事業等調査票アップロード画面を表示して関数を抜ける。
        ### (2)POSTの場合、アップロードされた公益事業等調査票ファイルをチェックする。
        ### ※ネストを浅くするため。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 3/35.', 'DEBUG')
        if request.method == 'GET':
            form = KoekiUploadForm()
            context = {
                'form': form, 
            }
            print_log('[INFO] P0300KoekiUpload.index_view()関数が正常終了しました。', 'INFO')
            return render(request, 'P0300KoekiUpload/index.html', context)
        
        elif request.method == 'POST':
            form = KoekiUploadForm(request.POST, request.FILES)
            
        #######################################################################
        ### フォーム検証処理(10030)
        ### (1)フォームが正しい場合、処理を継続する。
        ### (2)フォームが正しくない場合、ERROR画面を表示して関数を抜ける。
        ### ※ネストを浅くするため。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 4/35.', 'DEBUG')
        if form.is_valid() == False:
            print_log('[WARN] P0300KoekiUpload.index_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0300KoekiUpload/index.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))
    
        #######################################################################
        ### EXCEL入出力処理(11000)
        ### (1)局所変数に値をセットする。
        ### (2)アップロードされた公益事業等調査票ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 5/35.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_Ym = datetime.now(JST).strftime('%Y%m')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        
        upload_file_object = request.FILES['file']
        upload_file_name, upload_file_ext = os.path.splitext(request.FILES['file'].name)
        upload_file_name = upload_file_name + '_' + datetime_now_YmdHMS + '.xlsx'
        upload_file_path = 'static/repository/' + datetime_now_Ym + '/' + upload_file_name
        
        with open(upload_file_path, 'wb+') as destination:
            for chunk in upload_file_object.chunks():
                destination.write(chunk)

        output_file_name, output_file_ext = os.path.splitext(request.FILES['file'].name)
        output_file_name = output_file_name + '_' + datetime_now_YmdHMS + '_output' + '.xlsx'
        output_file_path = 'static/repository/' + datetime_now_Ym + '/' + output_file_name
        
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 upload_file_object={}'.format(upload_file_object), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 upload_file_path={}'.format(upload_file_path), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 upload_file_name={}'.format(upload_file_name), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 output_file_path={}'.format(output_file_path), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 output_file_name={}'.format(output_file_name), 'DEBUG')
                
        #######################################################################
        ### EXCEL入出力処理(11010)
        ### (1)アップロードされた公益事業等調査票ファイルのワークブックを読み込む。
        ### (2)KOEKIワークシートをコピーして、チェック結果を格納するCHECK_RESULTワークシートを追加する。
        ### (3)追加したワークシートを2シート目に移動する。
        ### (4)ワークシートの最大行数を局所変数のmax_rowにセットする。
        ### (5)背景赤色の塗りつぶしを局所変数のfillにセットする。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 6/35.', 'DEBUG')
        wb = openpyxl.load_workbook(upload_file_path)
        ws = []
        ws_result = []
        ws_title = []

        for ws_temp in wb.worksheets:
            if 'KOEKI' in ws_temp.title:
                ws.append(ws_temp)
                ws_result.append(wb.copy_worksheet(ws_temp))
                ws_result[-1].title = 'RESULT' + ws_temp.title
                ws_title.append(ws_temp.title)
                
        for ws_temp in wb.worksheets:
            if 'RESULT' in ws_temp.title:
                wb.move_sheet(ws_temp.title, offset=-wb.index(ws_temp))
                wb.move_sheet(ws_temp.title, offset=1)
        
        for ws_temp in wb.worksheets:
            ws_temp.sheet_view.tabSelected = None
            
        wb.active = 1

        #######################################################################
        ### EXCEL入出力処理(11020)
        ### (1)EXCELシート毎に最大行を探索する。
        ### (2)局所変数のmax_rowリストに追加する。
        ### ※max_row_tempの初期値の8はNO.、水系・沿岸名等のキャプション部分のEXCEL行番号である。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 7/35.', 'DEBUG')
        max_row = []
        
        for ws_temp in ws:
            ### EXCELシート毎に最大行を探索する。
            max_row_temp = 8
            for i in range(ws_temp.max_row+1, 8, -1):
                if ws_temp.cell(row=i, column=2).value is None:
                    pass
                else:
                    max_row_temp = i
                    break
                    
            ### 局所変数のmax_rowリストに追加する。
            max_row.append(max_row_temp)

        #######################################################################
        ### EXCEL入出力処理(11030)
        ### EXCELセルの背景赤色を局所変数のfillに設定する。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 8/35.', 'DEBUG')
        fill = openpyxl.styles.PatternFill(patternType='solid', fgColor='FF0000', bgColor='FF0000')

        #######################################################################
        ### DBアクセス処理(12000)
        ### (1)DBから突合せチェック用のデータを取得する。
        ### (2)突合せチェック用のリストを生成する。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 9/35.', 'DEBUG')
        ### DBから突合せチェック用のデータを取得する。
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        city_list = CITY.objects.raw("""SELECT * FROM CITY ORDER BY CAST(CITY_CODE AS INTEGER)""")
        ### cause_list
        ### area_list
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_list = KASEN.objects.raw("""SELECT * FROM KASEN ORDER BY CAST(KASEN_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        ### gradient_list
        kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(KASEN_KAIGAN_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")
        ### building_list
        ### underground_list
        ### flood_sediment_list
        ### industry_list
        ### business_list
        ### usage_list
        
        ### 突合せチェック用のリストを生成する。
        ken_code_list = [ken.ken_code for ken in ken_list]
        ken_name_list = [ken.ken_name for ken in ken_list]
        ken_name_code_list = [str(ken.ken_name) + ":" + str(ken.ken_code) for ken in ken_list]
        city_code_list = [city.city_code for city in city_list]
        city_name_list = [city.city_name for city in city_list]
        city_name_code_list = [str(city.city_name) + ":" + str(city.city_code) for city in city_list]
        ### cause_code_list
        ### cause_name_list
        ### cause_name_code_list
        ### area_id_list
        ### area_name_list
        ### area_name_id_list
        suikei_code_list = [suikei.suikei_code for suikei in suikei_list]
        suikei_name_list = [suikei.suikei_name for suikei in suikei_list]
        suikei_name_code_list = [str(suikei.suikei_name) + ":" + str(suikei.suikei_code) for suikei in suikei_list]
        suikei_type_code_list = [suikei_type.suikei_type_code for suikei_type in suikei_type_list]
        suikei_type_name_list = [suikei_type.suikei_type_name for suikei_type in suikei_type_list]
        suikei_type_name_code_list = [str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code) for suikei_type in suikei_type_list]
        kasen_code_list = [kasen.kasen_code for kasen in kasen_list]
        kasen_name_list = [kasen.kasen_name for kasen in kasen_list]
        kasen_name_code_list = [str(kasen.kasen_name) + ":" + str(kasen.kasen_code) for kasen in kasen_list]
        kasen_type_code_list = [kasen_type.kasen_type_code for kasen_type in kasen_type_list]
        kasen_type_name_list = [kasen_type.kasen_type_name for kasen_type in kasen_type_list]
        kasen_type_name_code_list = [str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code) for kasen_type in kasen_type_list]
        ### gradient_code_list
        ### gradient_name_list
        ### gradient_name_code_list
        kasen_kaigan_code_list = [kasen_kaigan.kasen_kaigan_code for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_list = [kasen_kaigan.kasen_kaigan_name for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_code_list = [str(kasen_kaigan.kasen_kaigan_name) + ":" + str(kasen_kaigan.kasen_kaigan_code) for kasen_kaigan in kasen_kaigan_list]
        weather_id_list = [weather.weather_id for weather in weather_list]
        weather_name_list = [weather.weather_name for weather in weather_list]
        weather_name_id_list = [str(weather.weather_name) + ":" + str(weather.weather_id) for weather in weather_list]
        ### building_code_list
        ### building_name_list
        ### building_name_code_list
        ### underground_code_list
        ### underground_name_list
        ### underground_name_code_list
        ### flood_sediment_code_list
        ### flood_sediment_name_list
        ### flood_sediment_name_code_list
        ### industry_code_list
        ### industry_name_list
        ### industry_name_code_list
        ### business_code_list
        ### business_name_list
        ### business_name_code_list
        ### usage_code_list
        ### usage_name_list
        ### usage_name_code_list

        #######################################################################
        ### EXCELセルデータ必須チェック処理（20000）
        #######################################################################
    
        #######################################################################
        ### EXCELセルデータ必須チェック処理（20010）
        ### (1)セル[9:2]からセル[9:33]について、必須項目に値がセットされていることをチェックする。
        ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
        ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
        ### ※max_rowの9は入力部分の開始EXCEL行番号である。
        ### ※max_rowの9はNO.、水系・沿岸名等のキャプション部分の1つ下のEXCEL行番号である。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 13/35.', 'DEBUG')
        if max_row[0] >= 9:
            for j in range(9, max_row[0]+1):
                ### セル[9:1]: NO.に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=1).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, comment_index=0)
                    require_warn.append([ws[0].title, j, 1, 0])
                else:
                    require_info.append([ws[0].title, j, 1, 0])

                ### セル[9:2]: 水害発生開始月に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=2).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, comment_index=1)
                    require_warn.append([ws[0].title, j, 2, 1])
                else:
                    require_info.append([ws[0].title, j, 2, 1])
                    
                ### セル[9:3]: 水害発生開始日に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=3).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, comment_index=2)
                    require_warn.append([ws[0].title, j, 3, 2])
                else:
                    require_info.append([ws[0].title, j, 3, 2])
                    
                ### セル[9:4]: 水害発生終了月に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=4).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, comment_index=3)
                    require_warn.append([ws[0].title, j, 4, 3])
                else:
                    require_info.append([ws[0].title, j, 4, 3])
                    
                ### セル[9:5]: 水害発生終了日に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=5).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, comment_index=4)
                    require_warn.append([ws[0].title, j, 5, 4])
                else:
                    require_info.append([ws[0].title, j, 5, 4])
                    
                ### セル[9:6]: 被害箇所_都道府県名[全角]に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=6).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, comment_index=5)
                    require_warn.append([ws[0].title, j, 6, 5])
                else:
                    require_info.append([ws[0].title, j, 6, 5])

                ### セル[9:7]: 被害箇所_都道府県コードに値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=7).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, comment_index=6)
                    require_warn.append([ws[0].title, j, 7, 6])
                else:
                    require_info.append([ws[0].title, j, 7, 6])

                ### セル[9:8]: 被害箇所_市区町村名[全角]に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=8).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, comment_index=7)
                    require_warn.append([ws[0].title, j, 8, 7])
                else:
                    require_info.append([ws[0].title, j, 8, 7])

                ### セル[9:9]: 被害箇所_市区町村コードに値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=9).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, comment_index=8)
                    require_warn.append([ws[0].title, j, 9, 8])
                else:
                    require_info.append([ws[0].title, j, 9, 8])

                ### セル[9:10]: 被害箇所_町丁名・大字名[全角]に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=10).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, comment_index=9)
                    require_warn.append([ws[0].title, j, 10, 9])
                else:
                    require_info.append([ws[0].title, j, 10, 9])

                ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=11).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, comment_index=10)
                    require_warn.append([ws[0].title, j, 11, 10])
                else:
                    require_info.append([ws[0].title, j, 11, 10])

                ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=12).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, comment_index=11)
                    require_warn.append([ws[0].title, j, 12, 11])
                else:
                    require_info.append([ws[0].title, j, 12, 11])

                ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=13).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, comment_index=12)
                    require_warn.append([ws[0].title, j, 13, 12])
                else:
                    require_info.append([ws[0].title, j, 13, 12])

                ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=14).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, comment_index=13)
                    require_warn.append([ws[0].title, j, 14, 13])
                else:
                    require_info.append([ws[0].title, j, 14, 13])

                ### セル[9:15]: 工種区分に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=15).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, comment_index=14)
                    require_warn.append([ws[0].title, j, 15, 14])
                else:
                    require_info.append([ws[0].title, j, 15, 14])

                ### セル[9:16]: 水害原因コード1に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=16).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, comment_index=15)
                    require_warn.append([ws[0].title, j, 16, 15])
                else:
                    require_info.append([ws[0].title, j, 16, 15])

                ### セル[9:17]: 水害原因コード2に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=17).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, comment_index=16)
                    require_warn.append([ws[0].title, j, 17, 16])
                else:
                    require_info.append([ws[0].title, j, 17, 16])

                ### セル[9:18]: 水害原因コード3に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=18).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, comment_index=17)
                    require_warn.append([ws[0].title, j, 18, 17])
                else:
                    require_info.append([ws[0].title, j, 18, 17])

                ### セル[9:19]: 異常気象コードに値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=19).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, comment_index=18)
                    require_warn.append([ws[0].title, j, 19, 18])
                else:
                    require_info.append([ws[0].title, j, 19, 18])

                ### セル[9:20]: 事業コードに値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=20).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, comment_index=19)
                    require_warn.append([ws[0].title, j, 20, 19])
                else:
                    require_info.append([ws[0].title, j, 20, 19])

                ### セル[9:21]: 調査対象機関名称に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=21).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, comment_index=20)
                    require_warn.append([ws[0].title, j, 21, 20])
                else:
                    require_info.append([ws[0].title, j, 21, 20])

                ### セル[9:22]: 被害金額_物的被害額(千円)に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=22).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=22, fill=fill, comment_index=21)
                    require_warn.append([ws[0].title, j, 22, 21])
                else:
                    require_info.append([ws[0].title, j, 22, 21])

                ### セル[9:23]: 被害金額_営業停止に伴う売上減少額に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=23).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=23, fill=fill, comment_index=22)
                    require_warn.append([ws[0].title, j, 23, 22])
                else:
                    require_info.append([ws[0].title, j, 23, 22])

                ### セル[9:24]: 被害金額_代替活動費(外注費)に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=24).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=24, fill=fill, comment_index=23)
                    require_warn.append([ws[0].title, j, 24, 23])
                else:
                    require_info.append([ws[0].title, j, 24, 23])

                ### セル[9:25]: 被害金額_その他に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=25).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=25, fill=fill, comment_index=24)
                    require_warn.append([ws[0].title, j, 25, 24])
                else:
                    require_info.append([ws[0].title, j, 25, 24])

                ### セル[9:26]: 被害金額_営業停止損失額合計(千円)に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=26).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=26, fill=fill, comment_index=25)
                    require_warn.append([ws[0].title, j, 26, 25])
                else:
                    require_info.append([ws[0].title, j, 26, 25])

                ### セル[9:27]: 営業停止期間等_営業停止期間日に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=27).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=27, fill=fill, comment_index=26)
                    require_warn.append([ws[0].title, j, 27, 26])
                else:
                    require_info.append([ws[0].title, j, 27, 26])

                ### セル[9:28]: 営業停止期間等_営業停止期間時間に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=28).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=28, fill=fill, comment_index=27)
                    require_warn.append([ws[0].title, j, 28, 27])
                else:
                    require_info.append([ws[0].title, j, 28, 27])

                ### セル[9:29]: 営業停止期間等_停止数量に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=29).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=29, fill=fill, comment_index=28)
                    require_warn.append([ws[0].title, j, 29, 28])
                else:
                    require_info.append([ws[0].title, j, 29, 28])

                ### セル[9:30]: 照会先_調査担当課名[全角]に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=30).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=30, fill=fill, comment_index=29)
                    require_warn.append([ws[0].title, j, 30, 29])
                else:
                    require_info.append([ws[0].title, j, 30, 29])

                ### セル[9:31]: 照会先_調査担当者名[全角]に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=31).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=31, fill=fill, comment_index=30)
                    require_warn.append([ws[0].title, j, 31, 30])
                else:
                    require_info.append([ws[0].title, j, 31, 30])

                ### セル[9:32]: 照会先_電話番号に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=32).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=32, fill=fill, comment_index=31)
                    require_warn.append([ws[0].title, j, 32, 31])
                else:
                    require_info.append([ws[0].title, j, 32, 31])

                ### セル[9:33]: 備考に値がセットされていることをチェックする。
                if ws[0].cell(row=j, column=33).value is None:
                    add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=33, fill=fill, comment_index=32)
                    require_warn.append([ws[0].title, j, 33, 32])
                else:
                    require_info.append([ws[0].title, j, 33, 32])

        #######################################################################
        ### EXCELセルデータ形式チェック処理（21000）
        #######################################################################
        
        #######################################################################
        ### EXCELセルデータ形式チェック処理（21010）
        ### (1)セル[9:2]からセル[9:33]について形式が正しいことをチェックする。
        ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
        ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
        ### 形式チェックでは、値がセットされている場合のみチェックを行う。
        ### 必須チェックは別途必須チェックで行うためである。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 17/35.', 'DEBUG')
        if max_row[0] >= 9:
            for j in range(9, max_row[0]+1):
                ### セル[9:1]: NO.について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=1).value is None:
                    pass
                else:
                    if split_name_code(ws[0].cell(row=j, column=1).value)[-1].isdecimal() == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=1, fill=fill, comment_index=100)
                        format_warn.append([ws[0].title, j, 1, 100])
                    else:
                        format_info.append([ws[0].title, j, 1, 100])

                ### セル[9:2]: 水害発生開始月について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=2).value is None:
                    pass
                else:
                    if split_name_code(ws[0].cell(row=j, column=2).value)[-1].isdecimal() == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=2, fill=fill, comment_index=101)
                        format_warn.append([ws[0].title, j, 2, 101])
                    else:
                        format_info.append([ws[0].title, j, 2, 101])
                    
                ### セル[9:3]: 水害発生開始日について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=3).value is None:
                    pass
                else:
                    if split_name_code(ws[0].cell(row=j, column=3).value)[-1].isdecimal() == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=3, fill=fill, comment_index=102)
                        format_warn.append([ws[0].title, j, 3, 102])
                    else:
                        format_info.append([ws[0].title, j, 3, 102])
                    
                ### セル[9:4]: 水害発生終了月について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=4).value is None:
                    pass
                else:
                    if split_name_code(ws[0].cell(row=j, column=4).value)[-1].isdecimal() == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=4, fill=fill, comment_index=103)
                        format_warn.append([ws[0].title, j, 4, 103])
                    else:
                        format_info.append([ws[0].title, j, 4, 103])
                    
                ### セル[9:5]: 水害発生終了日について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=5).value is None:
                    pass
                else:
                    if split_name_code(ws[0].cell(row=j, column=5).value)[-1].isdecimal() == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=5, fill=fill, comment_index=104)
                        format_warn.append([ws[0].title, j, 5, 104])
                    else:
                        format_info.append([ws[0].title, j, 5, 104])
                    
                ### セル[9:6]: 被害箇所_都道府県名[全角]について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=6).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=6).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=6).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, comment_index=105)
                        format_warn.append([ws[0].title, j, 6, 105])
                    else:
                        format_info.append([ws[0].title, j, 6, 105])
                    
                ### セル[9:7]: 被害箇所_都道府県コードについて形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=7).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=7).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=7).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, comment_index=106)
                        format_warn.append([ws[0].title, j, 7, 106])
                    else:
                        format_info.append([ws[0].title, j, 7, 106])
                    
                ### セル[9:8]: 被害箇所_市区町村名[全角]について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=8).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=8).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=8).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, comment_index=107)
                        format_warn.append([ws[0].title, j, 8, 107])
                    else:
                        format_info.append([ws[0].title, j, 8, 107])
                    
                ### セル[9:9]: 被害箇所_市区町村コードについて形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=9).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=9).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=9).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, comment_index=108)
                        format_warn.append([ws[0].title, j, 9, 108])
                    else:
                        format_info.append([ws[0].title, j, 9, 108])
                    
                ### セル[9:10]: 被害箇所_町丁名・大字名[全角]について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=10).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=10).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=10).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, comment_index=109)
                        format_warn.append([ws[0].title, j, 10, 109])
                    else:
                        format_info.append([ws[0].title, j, 10, 109])
                    
                ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=11).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=11).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=11).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, comment_index=110)
                        format_warn.append([ws[0].title, j, 11, 110])
                    else:
                        format_info.append([ws[0].title, j, 11, 110])
                    
                ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=12).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=12).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=12).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, comment_index=111)
                        format_warn.append([ws[0].title, j, 12, 111])
                    else:
                        format_info.append([ws[0].title, j, 12, 111])
                    
                ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=13).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=13).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=13).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, comment_index=112)
                        format_warn.append([ws[0].title, j, 13, 112])
                    else:
                        format_info.append([ws[0].title, j, 13, 112])
                    
                ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=14).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=14).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=14).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, comment_index=113)
                        format_warn.append([ws[0].title, j, 14, 113])
                    else:
                        format_info.append([ws[0].title, j, 14, 113])
                    
                ### セル[9:15]: 工種区分について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=15).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=15).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=15).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, comment_index=114)
                        format_warn.append([ws[0].title, j, 15, 114])
                    else:
                        format_info.append([ws[0].title, j, 15, 114])
                    
                ### セル[9:16]: 水害原因コード1について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=16).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=16).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=16).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, comment_index=115)
                        format_warn.append([ws[0].title, j, 16, 115])
                    else:
                        format_info.append([ws[0].title, j, 16, 115])
                    
                ### セル[9:17]: 水害原因コード2について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=17).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=17).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=17).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, comment_index=116)
                        format_warn.append([ws[0].title, j, 17, 116])
                    else:
                        format_info.append([ws[0].title, j, 17, 116])
                    
                ### セル[9:18]: 水害原因コード3について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=18).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=18).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=18).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, comment_index=117)
                        format_warn.append([ws[0].title, j, 18, 117])
                    else:
                        format_info.append([ws[0].title, j, 18, 117])
                    
                ### セル[9:19]: 異常気象コードについて形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=19).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=19).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=19).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, comment_index=118)
                        format_warn.append([ws[0].title, j, 19, 118])
                    else:
                        format_info.append([ws[0].title, j, 19, 118])
                    
                ### セル[9:20]: 事業コードについて形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=20).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=20).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=20).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, comment_index=119)
                        format_warn.append([ws[0].title, j, 20, 119])
                    else:
                        format_info.append([ws[0].title, j, 20, 119])
                    
                ### セル[9:21]: 調査対象機関名称[全角]について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=21).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=21).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=21).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, comment_index=120)
                        format_warn.append([ws[0].title, j, 21, 120])
                    else:
                        format_info.append([ws[0].title, j, 21, 120])
                    
                ### セル[9:22]: 被害金額_物的被害額(千円)について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=22).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=22).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=22).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=22, fill=fill, comment_index=121)
                        format_warn.append([ws[0].title, j, 22, 121])
                    else:
                        format_info.append([ws[0].title, j, 22, 121])
                    
                ### セル[9:23]: 被害金額_営業停止に伴う売上減少額について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=23).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=23).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=23).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=23, fill=fill, comment_index=122)
                        format_warn.append([ws[0].title, j, 23, 122])
                    else:
                        format_info.append([ws[0].title, j, 23, 122])
                    
                ### セル[9:24]: 被害金額_代替活動費(外注費)について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=24).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=24).value, int) == False and \
                        isinstance(ws[0].cell(row=j, column=24).value, float) == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=24, fill=fill, comment_index=123)
                        format_warn.append([ws[0].title, j, 24, 123])
                    else:
                        format_info.append([ws[0].title, j, 24, 123])
                    
                ### セル[9:25]: 被害金額_その他について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=25).value is None:
                    pass
                else:
                    if split_name_code(ws[0].cell(row=j, column=25).value)[-1].isdecimal() == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=25, fill=fill, comment_index=124)
                        format_warn.append([ws[0].title, j, 25, 124])
                    else:
                        format_info.append([ws[0].title, j, 25, 124])
                    
                ### セル[9:26]: 被害金額_営業停止損失額合計(千円)について形式が正しいことをチェックする。
                if ws[0].cell(row=j, column=26).value is None:
                    pass
                else:
                    if split_name_code(ws[0].cell(row=j, column=26).value)[-1].isdecimal() == False:
                        add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=26, fill=fill, comment_index=125)
                        format_warn.append([ws[0].title, j, 26, 125])
                    else:
                        format_info.append([ws[0].title, j, 26, 125])
                    
                ### セル[9:27]: 営業停止期間等_営業停止期間日について形式が正しいことをチェックする。
                ### セル[9:28]: 営業停止期間等_営業停止期間時間について形式が正しいことをチェックする。
                ### セル[9:29]: 営業停止期間等_停止数量について形式が正しいことをチェックする。
                ### セル[9:30]: 照会先_調査担当課名[全角]について形式が正しいことをチェックする。
                ### セル[9:31]: 照会先_調査担当者名[全角]について形式が正しいことをチェックする。
                ### セル[9:32]: 照会先_電話番号について形式が正しいことをチェックする。
                ### セル[9:33]: 備考について形式が正しいことをチェックする。

        #######################################################################
        ### EXCELセルデータ範囲チェック処理（22000）
        #######################################################################
    
        #######################################################################
        ### EXCELセルデータ範囲チェック処理（22010）
        ### (1)セル[9:2]からセル[9:33]について範囲が正しいことをチェックする。
        ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
        ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
        ### 範囲チェックでは、値がセットされている場合のみチェックを行う。
        ### 必須チェックは別途必須チェックで行うためである。
        ### 範囲チェックでは、形式が正しい場合のみチェックを行う。
        ### 形式チェックは別途形式チェックで行うためである。
        ### 例えば、面積などの数値について、float()で例外とならないように、int、floatの場合のみチェックする。
        ### 範囲チェックでは、数値の下限と上限のチェックを行う。
        ### 範囲チェックでは、DBとの突合チェックに該当するチェックは行わない。
        ### DBとの突合チェックは別途突合チェックで行うためである。
        ### 範囲チェックの例は値が正であることである。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 21/35.', 'DEBUG')
        if max_row[0] >= 9:
            for j in range(9, max_row[0]+1):
                ### セル[9:1]: NO.について範囲が正しいことをチェックする。
                ### セル[9:2]: 水害発生開始月について範囲が正しいことをチェックする。
                ### セル[9:3]: 水害発生開始日について範囲が正しいことをチェックする。
                ### セル[9:4]: 水害発生終了月について範囲が正しいことをチェックする。
                ### セル[9:5]: 水害発生終了日について範囲が正しいことをチェックする。
                ### セル[9:6]: 被害箇所_都道府県名[全角]について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=6).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=6).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=6).value, float) == True:
                        if float(ws[0].cell(row=j, column=6).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=6, fill=fill, comment_index=205)
                            range_warn.append([ws[0].title, j, 6, 205])
                        else:
                            range_info.append([ws[0].title, j, 6, 205])

                ### セル[9:7]: 被害箇所_都道府県コードについて範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=7).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=7).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=7).value, float) == True:
                        if float(ws[0].cell(row=j, column=7).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=7, fill=fill, comment_index=206)
                            range_warn.append([ws[0].title, j, 7, 206])
                        else:
                            range_info.append([ws[0].title, j, 7, 206])
                
                ### セル[9:8]: 被害箇所_市区町村名[全角]について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=8).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=8).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=8).value, float) == True:
                        if float(ws[0].cell(row=j, column=8).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=8, fill=fill, comment_index=207)
                            range_warn.append([ws[0].title, j, 8, 207])
                        else:
                            range_info.append([ws[0].title, j, 8, 207])

                ### セル[9:9]: 被害箇所_市区町村コードについて範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=9).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=9).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=9).value, float) == True:
                        if float(ws[0].cell(row=j, column=9).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=9, fill=fill, comment_index=208)
                            range_warn.append([ws[0].title, j, 9, 208])
                        else:
                            range_info.append([ws[0].title, j, 9, 208])

                ### セル[9:10]: 被害箇所_町丁名・大字名[全角]について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=10).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=10).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=10).value, float) == True:
                        if float(ws[0].cell(row=j, column=10).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=10, fill=fill, comment_index=209)
                            range_warn.append([ws[0].title, j, 10, 209])
                        else:
                            range_info.append([ws[0].title, j, 10, 209])

                ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=11).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=11).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=11).value, float) == True:
                        if float(ws[0].cell(row=j, column=11).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=11, fill=fill, comment_index=210)
                            range_warn.append([ws[0].title, j, 11, 210])
                        else:
                            range_info.append([ws[0].title, j, 11, 210])

                ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=12).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=12).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=12).value, float) == True:
                        if float(ws[0].cell(row=j, column=12).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=12, fill=fill, comment_index=211)
                            range_warn.append([ws[0].title, j, 12, 211])
                        else:
                            range_info.append([ws[0].title, j, 12, 211])

                ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=13).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=13).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=13).value, float) == True:
                        if float(ws[0].cell(row=j, column=13).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=13, fill=fill, comment_index=212)
                            range_warn.append([ws[0].title, j, 13, 212])
                        else:
                            range_info.append([ws[0].title, j, 13, 212])
                
                ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=14).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=14).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=14).value, float) == True:
                        if float(ws[0].cell(row=j, column=14).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=14, fill=fill, comment_index=213)
                            range_warn.append([ws[0].title, j, 14, 213])
                        else:
                            range_info.append([ws[0].title, j, 14, 213])

                ### セル[9:15]: 工種区分について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=15).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=15).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=15).value, float) == True:
                        if float(ws[0].cell(row=j, column=15).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=15, fill=fill, comment_index=214)
                            range_warn.append([ws[0].title, j, 15, 214])
                        else:
                            range_info.append([ws[0].title, j, 15, 214])

                ### セル[9:16]: 水害原因コード1について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=16).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=16).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=16).value, float) == True:
                        if float(ws[0].cell(row=j, column=16).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=16, fill=fill, comment_index=215)
                            range_warn.append([ws[0].title, j, 16, 215])
                        else:
                            range_info.append([ws[0].title, j, 16, 215])

                ### セル[9:17]: 水害原因コード2について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=17).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=17).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=17).value, float) == True:
                        if float(ws[0].cell(row=j, column=17).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=17, fill=fill, comment_index=216)
                            range_warn.append([ws[0].title, j, 17, 216])
                        else:
                            range_info.append([ws[0].title, j, 17, 216])

                ### セル[9:18]: 水害原因コード3について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=18).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=18).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=18).value, float) == True:
                        if float(ws[0].cell(row=j, column=18).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=18, fill=fill, comment_index=217)
                            range_warn.append([ws[0].title, j, 18, 217])
                        else:
                            range_info.append([ws[0].title, j, 18, 217])

                ### セル[9:19]: 異常気象コードについて範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=19).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=19).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=19).value, float) == True:
                        if float(ws[0].cell(row=j, column=19).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=19, fill=fill, comment_index=218)
                            range_warn.append([ws[0].title, j, 19, 218])
                        else:
                            range_info.append([ws[0].title, j, 19, 218])

                ### セル[9:20]: 事業コードについて範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=20).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=20).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=20).value, float) == True:
                        if float(ws[0].cell(row=j, column=20).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=20, fill=fill, comment_index=219)
                            range_warn.append([ws[0].title, j, 20, 219])
                        else:
                            range_info.append([ws[0].title, j, 20, 219])

                ### セル[9:21]: 調査対象機関名称[全角]について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=21).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=21).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=21).value, float) == True:
                        if float(ws[0].cell(row=j, column=21).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=21, fill=fill, comment_index=220)
                            range_warn.append([ws[0].title, j, 21, 220])
                        else:
                            range_info.append([ws[0].title, j, 21, 220])

                ### セル[9:22]: 被害金額_物的被害額(千円)について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=22).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=22).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=22).value, float) == True:
                        if float(ws[0].cell(row=j, column=22).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=22, fill=fill, comment_index=221)
                            range_warn.append([ws[0].title, j, 22, 221])
                        else:
                            range_info.append([ws[0].title, j, 22, 221])

                ### セル[9:23]: 被害金額_営業停止に伴う売上減少額について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=23).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=23).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=23).value, float) == True:
                        if float(ws[0].cell(row=j, column=23).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=23, fill=fill, comment_index=222)
                            range_warn.append([ws[0].title, j, 23, 222])
                        else:
                            range_info.append([ws[0].title, j, 23, 222])

                ### セル[9:24]: 被害金額_代替活動費(外注費)について範囲が正しいことをチェックする。
                if ws[0].cell(row=j, column=24).value is None:
                    pass
                else:
                    if isinstance(ws[0].cell(row=j, column=24).value, int) == True or \
                        isinstance(ws[0].cell(row=j, column=24).value, float) == True:
                        if float(ws[0].cell(row=j, column=24).value) < 0:
                            add_comment(ws=ws[0], ws_result=ws_result[0], row=j, column=24, fill=fill, comment_index=223)
                            range_warn.append([ws[0].title, j, 24, 223])
                        else:
                            range_info.append([ws[0].title, j, 24, 223])

                ### セル[9:25]: 被害金額_その他について範囲が正しいことをチェックする。
                ### セル[9:26]: 被害金額_営業停止損失額合計(千円)について範囲が正しいことをチェックする。
                ### セル[9:27]: 営業停止期間等_営業停止期間日について範囲が正しいことをチェックする。
                ### セル[9:28]: 営業停止期間等_営業停止期間時間について範囲が正しいことをチェックする。
                ### セル[9:29]: 営業停止期間等_停止数量について範囲が正しいことをチェックする。
                ### セル[9:30]: 照会先_調査担当課名[全角]について範囲が正しいことをチェックする。
                ### セル[9:31]: 照会先_調査担当者名[全角]について範囲が正しいことをチェックする。
                ### セル[9:32]: 照会先_電話番号について範囲が正しいことをチェックする。
                ### セル[9:33]: 備考について範囲が正しいことをチェックする。

        #######################################################################
        ### EXCELセルデータ相関チェック処理（23000）
        #######################################################################
    
        #######################################################################
        ### EXCELセルデータ相関チェック処理（23010）
        ### (1)セル[9:2]からセル[9:33]について他項目との相関関係が正しいことをチェックする。
        ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
        ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 25/35.', 'DEBUG')
        if max_row[0] >= 9:
            for j in range(9, max_row[0]+1):
                pass
                ### セル[9:1]: NO.が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:2]: 水害発生月が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:3]: 水害発生日が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:4]: 水害発生月が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:5]: 水害発生日が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:6]: 被害箇所_都道府県名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:7]: 被害箇所_都道府県コードが何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:8]: 被害箇所_市区町村名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:9]: 被害箇所_市区町村コードが何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:10]: 被害箇所_町丁名・大字名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:15]: 工種区分が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:16]: 水害原因コード1が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:17]: 水害原因コード2が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:18]: 水害原因コード3が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:19]: 異常気象コードが何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:20]: 事業コードが何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:21]: 調査対象機関名称[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:22]: 被害金額_物的被害額(千円)が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:23]: 被害金額_営業停止に伴う売上減少額が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:24]: 被害金額_代替活動費(外注費)が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:25]: 被害金額_その他が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:26]: 被害金額_営業停止損失額合計(千円)が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:27]: 営業停止期間等_営業停止期間日が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:28]: 営業停止期間等_営業停止期間時間が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:29]: 営業停止期間等_停止数量が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:30]: 照会先_調査担当課名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:31]: 照会先_調査担当者名[全角]が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:32]: 照会先_電話番号が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[9:33]: 備考が何かの値のときに、相関する他項目は正しく選択されているか。

        #######################################################################
        ### EXCELセルデータ突合チェック処理（24000）
        #######################################################################
    
        #######################################################################
        ### EXCELセルデータ突合チェック処理（24010）
        ### (1)セル[9:2]からセル[9:33]についてデータベースに登録されている値と突合せチェックする。
        ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
        ### (3)KOEKIワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 29/35.', 'DEBUG')
        if max_row[0] >= 9:
            for j in range(9, max_row[0]+1):
                pass
                ### セル[9:1]: NO.についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:2]: 水害発生月についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:3]: 水害発生日についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:4]: 水害発生月についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:5]: 水害発生日についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:6]: 被害箇所_都道府県名[全角]についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:7]: 被害箇所_都道府県コードについてデータベースに登録されている値と突合せチェックする。
                ### セル[9:8]: 被害箇所_市区町村名[全角]についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:9]: 被害箇所_市区町村コードについてデータベースに登録されている値と突合せチェックする。
                ### セル[9:10]: 被害箇所_町丁名・大字名[全角]についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:11]: 河川・海岸名・地区名_水系・沿岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:12]: 河川・海岸名・地区名_水系種別[全角]についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:13]: 河川・海岸名・地区名_河川・海岸名[全角]についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:14]: 河川・海岸名・地区名_河川種別[全角]についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:15]: 工種区分についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:16]: 水害原因コード1についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:17]: 水害原因コード2についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:18]: 水害原因コード3についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:19]: 異常気象コードについてデータベースに登録されている値と突合せチェックする。
                ### セル[9:20]: 事業コードについてデータベースに登録されている値と突合せチェックする。
                ### セル[9:21]: 調査対象機関名称[全角]についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:22]: 被害金額_物的被害額(千円)についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:23]: 被害金額_営業停止に伴う売上減少額についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:24]: 被害金額_代替活動費(外注費)についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:25]: 被害金額_その他についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:26]: 被害金額_営業停止損失額合計(千円)についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:27]: 営業停止期間等_営業停止期間日についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:28]: 営業停止期間等_営業停止期間時間についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:29]: 営業停止期間等_停止数量についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:30]: 照会先_調査担当課名[全角]についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:31]: 照会先_調査担当者名[全角]についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:32]: 照会先_電話番号についてデータベースに登録されている値と突合せチェックする。
                ### セル[9:33]: 備考についてデータベースに登録されている値と突合せチェックする。

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(30000)
        #######################################################################

        #######################################################################
        ### ファイル入出力処理(30000)
        ### チェック結果ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 30/35.', 'DEBUG')
        wb.save(output_file_path)

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(30010)
        ### チェック結果ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 31/35.', 'DEBUG')
        if len(require_warn) > 0 or len(format_warn) > 0 or \
            len(range_warn) > 0 or len(correlate_warn) > 0 or \
            len(compare_warn) > 0:
            print_log('[DEBUG] P0300KoekiUpload.index_view()関数 False', 'DEBUG')
        else:
            print_log('[DEBUG] P0300KoekiUpload.index_view()関数 True', 'DEBUG')
            
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 max_row={}'.format(max_row), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 len(require_warn)={}'.format(len(require_warn)), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 len(format_warn)={}'.format(len(format_warn)), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 len(range_warn)={}'.format(len(range_warn)), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 len(correlate_warn)={}'.format(len(correlate_warn)), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 len(compare_warn)={}'.format(len(compare_warn)), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 len(require_info)={}'.format(len(require_info)), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 len(format_info)={}'.format(len(format_info)), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 len(range_info)={}'.format(len(range_info)), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 len(correlate_info)={}'.format(len(correlate_info)), 'DEBUG')
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 len(compare_info)={}'.format(len(compare_info)), 'DEBUG')
        
        #######################################################################
        ### ファイル入出力処理、ログ出力処理(30020)
        ### チェック結果ファイルを保存する。
        #######################################################################
        info_str = ''
        if len(require_info) > 0:
            for i in range(len(require_info)):
                info_str = info_str + \
                    str(require_info[i][0]) + ',' + \
                    str(require_info[i][1]) + ',' + \
                    str(require_info[i][2]) + ',' + \
                    str(constants.MESSAGE[require_info[i][3]][0]) + ',' + \
                    str(constants.MESSAGE[require_info[i][3]][1]) + ',' + \
                    str(constants.MESSAGE[require_info[i][3]][2]) + '\n'        
        
        if len(format_info) > 0:
            for i in range(len(format_info)):
                info_str = info_str + \
                    str(format_info[i][0]) + ',' + \
                    str(format_info[i][1]) + ',' + \
                    str(format_info[i][2]) + ',' + \
                    str(constants.MESSAGE[format_info[i][3]][0]) + ',' + \
                    str(constants.MESSAGE[format_info[i][3]][1]) + ',' + \
                    str(constants.MESSAGE[format_info[i][3]][2]) + '\n'        

        if len(range_info) > 0:
            for i in range(len(range_info)):
                info_str = info_str + \
                    str(range_info[i][0]) + ',' + \
                    str(range_info[i][1]) + ',' + \
                    str(range_info[i][2]) + ',' + \
                    str(constants.MESSAGE[range_info[i][3]][0]) + ',' + \
                    str(constants.MESSAGE[range_info[i][3]][1]) + ',' + \
                    str(constants.MESSAGE[range_info[i][3]][2]) + '\n'        

        if len(correlate_info) > 0:
            for i in range(len(correlate_info)):
                info_str = info_str + \
                    str(correlate_info[i][0]) + ',' + \
                    str(correlate_info[i][1]) + ',' + \
                    str(correlate_info[i][2]) + ',' + \
                    str(constants.MESSAGE[correlate_info[i][3]][0]) + ',' + \
                    str(constants.MESSAGE[correlate_info[i][3]][1]) + ',' + \
                    str(constants.MESSAGE[correlate_info[i][3]][2]) + '\n'        

        if len(compare_info) > 0:
            for i in range(len(compare_info)):
                info_str = info_str + \
                    str(compare_info[i][0]) + ',' + \
                    str(compare_info[i][1]) + ',' + \
                    str(compare_info[i][2]) + ',' + \
                    str(constants.MESSAGE[compare_info[i][3]][0]) + ',' + \
                    str(constants.MESSAGE[compare_info[i][3]][1]) + ',' + \
                    str(constants.MESSAGE[compare_info[i][3]][2]) + '\n'        

        warn_str = ''
        if len(require_warn) > 0:
            for i in range(len(require_warn)):
                warn_str = warn_str + \
                    str(require_warn[i][0]) + ',' + \
                    str(require_warn[i][1]) + ',' + \
                    str(require_warn[i][2]) + ',' + \
                    str(constants.MESSAGE[require_warn[i][3]][0]) + ',' + \
                    str(constants.MESSAGE[require_warn[i][3]][1]) + ',' + \
                    str(constants.MESSAGE[require_warn[i][3]][2]) + '\n'        
        
        if len(format_warn) > 0:
            for i in range(len(format_warn)):
                warn_str = warn_str + \
                    str(format_warn[i][0]) + ',' + \
                    str(format_warn[i][1]) + ',' + \
                    str(format_warn[i][2]) + ',' + \
                    str(constants.MESSAGE[format_warn[i][3]][0]) + ',' + \
                    str(constants.MESSAGE[format_warn[i][3]][1]) + ',' + \
                    str(constants.MESSAGE[format_warn[i][3]][2]) + '\n'        

        if len(range_warn) > 0:
            for i in range(len(range_warn)):
                warn_str = warn_str + \
                    str(range_warn[i][0]) + ',' + \
                    str(range_warn[i][1]) + ',' + \
                    str(range_warn[i][2]) + ',' + \
                    str(constants.MESSAGE[range_warn[i][3]][0]) + ',' + \
                    str(constants.MESSAGE[range_warn[i][3]][1]) + ',' + \
                    str(constants.MESSAGE[range_warn[i][3]][2]) + '\n'        

        if len(correlate_warn) > 0:
            for i in range(len(correlate_warn)):
                warn_str = warn_str + \
                    str(correlate_warn[i][0]) + ',' + \
                    str(correlate_warn[i][1]) + ',' + \
                    str(correlate_warn[i][2]) + ',' + \
                    str(constants.MESSAGE[correlate_warn[i][3]][0]) + ',' + \
                    str(constants.MESSAGE[correlate_warn[i][3]][1]) + ',' + \
                    str(constants.MESSAGE[correlate_warn[i][3]][2]) + '\n'        

        if len(compare_warn) > 0:
            for i in range(len(compare_warn)):
                warn_str = warn_str + \
                    str(compare_warn[i][0]) + ',' + \
                    str(compare_warn[i][1]) + ',' + \
                    str(compare_warn[i][2]) + ',' + \
                    str(constants.MESSAGE[compare_warn[i][3]][0]) + ',' + \
                    str(constants.MESSAGE[compare_warn[i][3]][1]) + ',' + \
                    str(constants.MESSAGE[compare_warn[i][3]][2]) + '\n'        

        #######################################################################
        ### DBアクセス処理(40000)
        ### ※入力チェックでエラーが発見された場合に処理する。
        #######################################################################
            
        #######################################################################
        ### DBアクセス処理(40010)
        ### ※ネストを浅くするために、処理対象外の場合、終了させる。
        ### ※入力チェックでエラーが発見された場合に処理する。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 32/35.', 'DEBUG')
        if len(require_warn) > 0 or len(format_warn) > 0 or \
            len(range_warn) > 0 or len(correlate_warn) > 0 or \
            len(compare_warn) > 0:

            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")
                
                ###############################################################
                ### DBアクセス処理(40020)
                ### 既存の都道府県のKOEKI_HEADERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ### ※入力チェックでエラーが発見された場合に処理する。
                ###############################################################
                params = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE KOEKI_HEADER SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE koeki_header_id IN (
                    SELECT 
                        koeki_header_id 
                    FROM KOEKI_HEADER 
                    WHERE 
                        ken_code=%(KEN_CODE)s AND 
                        deleted_at IS NULL)
                    """, params)
        
                ###############################################################
                ### DBアクセス処理(40030)
                ### 既存の都道府県のKOEKIのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ### ※入力チェックでエラーが発見された場合に処理する。
                ###############################################################
                params = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE KOEKI SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE koeki_id IN (
                    SELECT 
                        koeki_id 
                    FROM KOEKI_VIEW 
                    WHERE 
                        ken_code=%(KEN_CODE)s AND 
                        deleted_at IS NULL)
                    """, params)
    
                ###############################################################
                ### DBアクセス処理(40040)
                ### 既存の都道府県のKOEKI_SUMMARYのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ### ※入力チェックでエラーが発見された場合に処理する。
                ###############################################################
                params = dict({
                    'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE KOEKI_SUMMARY SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE koeki_id IN (
                    SELECT 
                        koeki_id 
                    FROM KOEKI_SUMMARY_VIEW 
                    WHERE 
                        ken_code=%(KEN_CODE)s AND 
                        deleted_at IS NULL)
                    """, params)
    
                ###############################################################
                ### DBアクセス処理(40050)
                ### 既存の都道府県のKOEKI_TRIGGERのデータは、削除日時をセットして、削除済の扱いとする。
                ### ※入力チェックでエラーが発見された場合に処理する。
                ###############################################################
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'ken_code': split_name_code(ws_chitan[0].cell(row=9, column=7).value)[-1], 
                    'action_code': _G01
                })
                bool_return = delete_message(metadata=metadata)
                if bool_return == False:
                    print_log('[WARN] delete_message()関数が警告終了しました。', 'WARN')
                    raise Exception
                
                ###############################################################
                ### DBアクセス処理(40060)
                ### トリガーテーブルにG01トリガーを実行済、成功として登録する。
                ### ※入力チェックでエラーが発見された場合に処理する。
                ###############################################################
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': None, 
                    'ken_code': convert_empty_to_none(split_name_code(ws_chitan[0].cell(row=9, column=7).value)[-1]), 
                    'city_code': None, 
                    'action_code': _G01, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': get_info_log(), 
                    'warn_log': get_warn_log(), 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[WARN] publish_consume_message()関数が警告終了しました。', 'WARN')
                    raise Exception
                    
                ###############################################################
                ### DBアクセス処理(40070)
                ### トリガーテーブルにG02トリガーを実行済、失敗として登録する。
                ### ※入力チェックでエラーが発見された場合に処理する。
                ###############################################################
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': None, 
                    'ken_code': convert_empty_to_none(split_name_code(ws_chitan[0].cell(row=9, column=7).value)[-1]), 
                    'city_code': None, 
                    'action_code': _G02, 
                    'status_code': _FAILURE, 
                    'info_count': 0, 
                    'warn_count': len(ws), 
                    'info_log': info_str, 
                    'warn_log': warn_str, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[WARN] publish_consume_message()関数が警告終了しました。', 'WARN')
                    raise Exception
                
                connection_cursor.execute("""COMMIT""");
                
            except:
                print_log('[ERROR] P0300KoekiUpload.index_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] P0300KoekiUpload.index_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
                print_log('[ERROR] P0300KoekiUpload.index_view()関数が異常終了しました。', 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
                template = loader.get_template('P0300KoekiUpload/index.html')
                context = {
                    'alert_log': get_alert_log(), 
                }
                return HttpResponse(template.render(context, request))
                
            finally:
                connection_cursor.close()
                
            ###################################################################
            ### レスポンスセット処理(40080)
            ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
            ### ※入力チェックでエラーが発見された場合に処理する。
            ###################################################################
            template = loader.get_template('P0300KoekiUpload/fail.html')
            context = {
                'compare_warn': compare_warn,
                'correlate_warn': correlate_warn,
                'format_warn': format_warn,
                'output_file_path': output_file_path,
                'range_warn': range_warn,
                'require_warn': require_warn,
            }
            print_log('[WARN] P0300KoekiUpload.index_view()関数が警告終了しました。', 'INFO')
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(50000)
        ### ※入力チェックでエラーが発見されなかった場合に処理する。
        #######################################################################
        
        #######################################################################
        ### DBアクセス処理(50010)
        ### (1)入力データ_ヘッダ部分テーブルにデータを登録する。
        ### (2)入力データ_一覧票部分テーブルにデータを登録する。
        ### ※入力チェックでエラーが発見されなかった場合に処理する。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 33/35.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")
            
            ###################################################################
            ### DBアクセス処理(50020)
            ### 既存の都道府県のKOEKI_HEADERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ### ※入力チェックでエラーが発見されなかった場合に処理する。
            ###################################################################
            params = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE KOEKI_HEADER SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE koeki_header_id IN (
                SELECT 
                    koeki_header_id 
                FROM KOEKI_HEADER 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL)""", params)
    
            ###################################################################
            ### DBアクセス処理(50030)
            ### 既存の都道府県のKOEKIのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ### ※入力チェックでエラーが発見されなかった場合に処理する。
            ###################################################################
            params = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE KOEKI SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE koeki_id IN (
                SELECT 
                    koeki_id 
                FROM KOEKI_VIEW 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL)""", params)

            ###################################################################
            ### DBアクセス処理(50040)
            ### 既存の都道府県のKOEKI_SUMMARYのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ### ※入力チェックでエラーが発見されなかった場合に処理する。
            ###################################################################
            params = dict({
                'KEN_CODE': split_name_code(ws[0].cell(row=9, column=7).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE KOEKI_SUMMARY SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE koeki_id IN (
                SELECT 
                    koeki_id 
                FROM KOEKI_SUMMARY_VIEW 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL)""", params)

            ###################################################################
            ### DBアクセス処理(50050)
            ### 既存の都道府県のKOEKI_TRIGGERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ### ※入力チェックでエラーが発見されなかった場合に処理する。
            ###################################################################
            metadata = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': split_name_code(ws_chitan[0].cell(row=9, column=7).value)[-1], 
                'action_code': _G01
            })
            bool_return = delete_message(metadata=metadata)
            if bool_return == False:
                print_log('[WARN] delete_message()関数が警告終了しました。', 'WARN')
                raise Exception

            ###################################################################
            ### DBアクセス処理(50060)
            ### koeki_header_id__max で正しい。
            ### ※入力チェックでエラーが発見されなかった場合に処理する。
            ###################################################################
            print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 34_1/35.', 'DEBUG')
            for i, _ in enumerate(ws):
                koeki_header_id = KOEKI_HEADER.objects.all().aggregate(Max('koeki_header_id'))['koeki_header_id__max']
                if koeki_header_id is None:
                    koeki_header_id = 1
                else:
                    koeki_header_id += 1
                
                ###############################################################
                ### DBアクセス処理(50070)
                ### 公益事業等調査票_ヘッダ部分テーブルにデータを登録する。
                ### ※入力チェックでエラーが発見されなかった場合に処理する。
                ###############################################################
                print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 34_2/35.', 'DEBUG')
                params = dict({
                    'KOEKI_HEADER_ID': koeki_header_id, 
                    'KOEKI_HEADER_NAME': ws_title[i], 
                    'KEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=9, column=7).value)[-1]), 
                    'UPLOAD_FILE_PATH': upload_file_path, 
                    'UPLOAD_FILE_NAME': upload_file_name, 
                    'SUMMARY_FILE_PATH': None, 
                    'SUMMARY_FILE_NAME': None, 
                    'DELETED_AT': None
                })
                connection_cursor.execute("""
                    INSERT INTO KOEKI_HEADER (
                        koeki_header_id, koeki_header_name, ken_code, 
                        upload_file_path, upload_file_name, summary_file_path, summary_file_name, 
                        committed_at, deleted_at 
                    ) VALUES (
                        %(KOEKI_HEADER_ID)s, 
                        %(KOEKI_HEADER_NAME)s, 
                        %(KEN_CODE)s, 
                        %(UPLOAD_FILE_PATH)s, 
                        %(UPLOAD_FILE_NAME)s, 
                        %(SUMMARY_FILE_PATH)s, 
                        %(SUMMARY_FILE_NAME)s, 
                        CURRENT_TIMESTAMP,  -- committed_at 
                        %(DELETED_AT)s)""", params)
                    
                ###############################################################
                ### DBアクセス処理(50080)
                ### 公益事業等調査票_一覧表部分テーブルにデータを登録する。
                ### ※入力チェックでエラーが発見されなかった場合に処理する。
                ###############################################################
                print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 34_3/35.', 'DEBUG')
                print_log('[DEBUG] P0300KoekiUpload.index_view()関数 max_row[i]={}'.format(max_row[i]), 'DEBUG')
                if max_row[i] >= 9:
                    for j in range(9, max_row[i]+1):
                        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 j={}'.format(j), 'DEBUG')
                        params = dict({
                            'KOEKI_NAME': convert_empty_to_none(ws[i].cell(row=j, column=2).value), 
                            'KOEKI_HEADER_ID': koeki_header_id, 
                            'CITY_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=9).value)[-1]), 
                            'BEGIN_DATE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=2).value)[-1]), 
                            'END_DATE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=4).value)[-1]), 
                            'SUIKEI_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=11).value)[-1]), 
                            'SUIKEI_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=12).value)[-1]), 
                            'KASEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=13).value)[-1]), 
                            'KASEN_TYPE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=14).value)[-1]), 
                            'KASEN_KAIGAN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=15).value)[-1]), 
                            'WEATHER_ID': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=19).value)[-1]), 
                            'CAUSE_1_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=16).value)[-1]), 
                            'CAUSE_2_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=17).value)[-1]), 
                            'CAUSE_3_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=18).value)[-1]), 
                            'BUSINESS_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=20).value)[-1]), 
                            'ORGANIZATION_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=21).value)[-1]), 
                            'PHYSICAL_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=22).value), 
                            'SALES_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=23).value), 
                            'ALT_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=24).value), 
                            'OTHER_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=25).value), 
                            'TOTAL_DAMAGE': convert_empty_to_none(ws[i].cell(row=j, column=26).value), 
                            'SUSPENDED_DAYS': convert_empty_to_none(ws[i].cell(row=j, column=27).value), 
                            'SUSPENDED_HOURS': convert_empty_to_none(ws[i].cell(row=j, column=28).value), 
                            'SUSPENDED_AMOUNTS': convert_empty_to_none(ws[i].cell(row=j, column=29).value), 
                            'DEPARTMENT_NAME': convert_empty_to_none(ws[i].cell(row=j, column=30).value), 
                            'EMPLOYEE_NAME': convert_empty_to_none(ws[i].cell(row=j, column=31).value), 
                            'TELEPHONE': convert_empty_to_none(ws[i].cell(row=j, column=32).value), 
                            'COMMENT': convert_empty_to_none(ws[i].cell(row=j, column=33).value), 
                            'DELETED_AT': None
                        })
                        connection_cursor.execute(""" 
                            INSERT INTO KOEKI (
                                koeki_id, koeki_name, koeki_header_id, 
                                city_code, begin_date, end_date, 
                                suikei_code, suikei_type_code, kasen_code, kasen_type_code, kasen_kaigan_code, weather_id, 
                                cause_1_code, cause_2_code, cause_3_code, business_code, organization_name, 
                                physical_damage, sales_damage, alt_damage, other_damage, total_damage, 
                                suspended_days, suspended_hours, suspended_amounts, 
                                department_name, employee_name, telephone, comment, 
                                committed_at, deleted_at 
                            ) VALUES (
                                (SELECT CASE WHEN (MAX(koeki_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(koeki_id+1) AS INTEGER) END AS koeki_id FROM KOEKI), -- koeki_id 
                                %(KOEKI_NAME)s, 
                                %(KOEKI_HEADER_ID)s, 
                                %(CITY_CODE)s, 
                                TO_DATE(%(BEGIN_DATE)s, 'YYYY/MM/DD'), 
                                TO_DATE(%(END_DATE)s, 'YYYY/MM/DD'), 
                                %(SUIKEI_CODE)s, 
                                %(SUIKEI_TYPE_CODE)s, 
                                %(KASEN_CODE)s, 
                                %(KASEN_TYPE_CODE)s, 
                                %(KASEN_KAIGAN_CODE)s, 
                                %(WEATHER_ID)s, 
                                %(CAUSE_1_CODE)s, 
                                %(CAUSE_2_CODE)s, 
                                %(CAUSE_3_CODE)s, 
                                %(BUSINESS_CODE)s, 
                                %(ORGANIZATION_NAME)s, 
                                %(PHYSICAL_DAMAGE)s, 
                                %(SALES_DAMAGE)s, 
                                %(ALT_DAMAGE)s, 
                                %(OTHER_DAMAGE)s, 
                                %(TOTAL_DAMAGE)s, 
                                %(SUSPENDED_DAYS)s, 
                                %(SUSPENDED_HOURS)s, 
                                %(SUSPENDED_AMOUNTS)s, 
                                %(DEPARTMENT_NAME)s, 
                                %(EMPLOYEE_NAME)s, 
                                %(TELEPHONE)s, 
                                %(COMMENT)s, 
                                CURRENT_TIMESTAMP, -- committed_at
                                %(DELETED_AT)s) """, params)

                ###############################################################
                ### DBアクセス処理(50090)
                ### トリガーテーブルにG01トリガーを実行済、成功として登録する。
                ### ※入力チェックでエラーが発見されなかった場合に処理する。
                ###############################################################
                print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 34_5/35.', 'DEBUG')
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': koeki_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws_chitan[0].cell(row=9, column=7).value)[-1]), 
                    'city_code': None, 
                    'action_code': _G01, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': get_info_log(), 
                    'warn_log': get_warn_log(), 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[WARN] publish_consume_message()関数が警告終了しました。', 'WARN')
                    raise Exception

                ###############################################################
                ### DBアクセス処理(50100)
                ### トリガーテーブルにG02トリガーを実行済、成功として登録する。
                ### ※入力チェックでエラーが発見されなかった場合に処理する。
                ###############################################################
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': koeki_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws_chitan[0].cell(row=9, column=7).value)[-1]), 
                    'city_code': None, 
                    'action_code': _G02, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': info_str, 
                    'warn_log': warn_str, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_Name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=metadata)
                if bool_return == False:
                    print_log('[WARN] publish_consume_message()関数が警告終了しました。', 'WARN')
                    raise Exception
            
                ###############################################################
                ### DBアクセス処理(50110)
                ### トリガーテーブルにC03トリガーを未実行＝次回実行対象として登録する。
                ### ※入力チェックでエラーが発見されなかった場合に処理する。
                ###############################################################
                metadata = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': koeki_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[i].cell(row=9, column=7).value)[-1]), 
                    'city_code': None, 
                    'action_code': _G03, 
                    'status_code': _RUNNING, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_message(metadata=metadata)
                if bool_return == False:
                    print_log('[WARN] publish_message()関数が警告終了しました。', 'WARN')
                    raise Exception
                
            connection_cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0300KoekiUpload.index_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0300KoekiUpload.index_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            print_log('[ERROR] P0300KoekiUpload.index_view()関数が異常終了しました。', 'ERROR')
            template = loader.get_template('P0300KoekiUpload/index.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))
            
        finally:
            connection_cursor.close()
        
        #######################################################################
        ### レスポンスセット処理(50120)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        ### ※入力チェックでエラーが発見されなかった場合に処理する。
        #######################################################################
        print_log('[DEBUG] P0300KoekiUpload.index_view()関数 STEP 35/35.', 'DEBUG')
        template = loader.get_template('P0300KoekiUpload/success.html')
        context = {
        }
        print_log('[INFO] P0300KoekiUpload.index_view()関数が正常終了しました。', 'INFO')
        return HttpResponse(template.render(context, request))
        
    except:
        print_log('[ERROR] P0300KoekiUpload.index_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0300KoekiUpload.index_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0300KoekiUpload.index_viwe()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0300KoekiUpload/index.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))
