from django.urls import path
from . import views

app_name = 'P0300AreaWeather'
urlpatterns = [
    path('', views.index_view, name='index_view'), 
    path('type/<slug:type_code>/ken/<slug:ken_code>/header/<slug:ippan_header_id>/', views.type_ken_header_view, name='type_ken_header_view'), 
]
