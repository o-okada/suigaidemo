###############################################################################
### ファイル名：MessageQueue/views.py
### メッセージキュー
###############################################################################

import sys
from django.contrib.auth.decorators import login_required
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views.generic.base import TemplateView

import openpyxl
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook
from openpyxl.styles import PatternFill
from openpyxl.formatting.rule import FormulaRule

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査票_調査員用_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY_VIEW      ### 0000: ビューデータ_一般資産調査票_調査員用_一覧表部分
from P0000Common.models import CHITAN_SUMMARY_VIEW     ### 0010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY_VIEW       ### 0020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY_VIEW      ### 0030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査票_調査員用_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.common import get_alert_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

### ACTIONテーブル.ACTION_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_IPP_ACT_01 = 'IPP_ACT_01'
_IPP_ACT_02 = 'IPP_ACT_02'
_IPP_ACT_03 = 'IPP_ACT_03'
_IPP_ACT_04 = 'IPP_ACT_04'
_IPP_ACT_05 = 'IPP_ACT_05'
_IPP_ACT_06 = 'IPP_ACT_06'
_IPP_ACT_07 = 'IPP_ACT_07'
_IPP_ACT_90 = 'IPP_ACT_90'
_IPP_ACT_91 = 'IPP_ACT_91'

_CHI_ACT_01 = 'CHI_ACT_01'
_CHI_ACT_02 = 'CHI_ACT_02'
_CHI_ACT_03 = 'CHI_ACT_03'
_CHI_ACT_04 = 'CHI_ACT_04'
_CHI_ACT_05 = 'CHI_ACT_05'
_CHI_ACT_06 = 'CHI_ACT_06'
_CHI_ACT_07 = 'CHI_ACT_07'
_CHI_ACT_90 = 'CHI_ACT_90'
_CHI_ACT_91 = 'CHI_ACT_91'

_HOJ_ACT_01 = 'HOJ_ACT_01'
_HOJ_ACT_02 = 'HOJ_ACT_02'
_HOJ_ACT_03 = 'HOJ_ACT_03'
_HOJ_ACT_04 = 'HOJ_ACT_04'
_HOJ_ACT_05 = 'HOJ_ACT_05'
_HOJ_ACT_06 = 'HOJ_ACT_06'
_HOJ_ACT_07 = 'HOJ_ACT_07'
_HOJ_ACT_90 = 'HOJ_ACT_90'
_HOJ_ACT_91 = 'HOJ_ACT_91'

_KOE_ACT_01 = 'KOE_ACT_01'
_KOE_ACT_02 = 'KOE_ACT_02'
_KOE_ACT_03 = 'KOE_ACT_03'
_KOE_ACT_04 = 'KOE_ACT_04'
_KOE_ACT_05 = 'KOE_ACT_05'
_KOE_ACT_06 = 'KOE_ACT_06'
_KOE_ACT_07 = 'KOE_ACT_07'
_KOE_ACT_90 = 'KOE_ACT_90'
_KOE_ACT_91 = 'KOE_ACT_91'

_ARE_ACT_01 = 'ARE_ACT_01'
_ARE_ACT_02 = 'ARE_ACT_02'
_ARE_ACT_03 = 'ARE_ACT_03'
_ARE_ACT_04 = 'ARE_ACT_04'
_ARE_ACT_05 = 'ARE_ACT_05'
_ARE_ACT_06 = 'ARE_ACT_06'
_ARE_ACT_07 = 'ARE_ACT_07'
_ARE_ACT_90 = 'ARE_ACT_90'

### STATUSテーブル.STATUS_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_WAITING = 'WAITING'
_RUNNING = 'RUNNING'
_SUCCESS = 'SUCCESS'
_FAILURE = 'FAILURE'
_CANCEL = 'CANCEL'

###############################################################################
### 関数名：get_message(metadata=None)
### 引数：metadata['action_code']
### 引数：metadata['status_code']
###############################################################################
def get_message(metadata=None):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[INFO] MessageQueue.get_message()関数が開始しました。', 'INFO')
        print_log('[DEBUG] MessageQueue.get_message()関数 STEP 1/3.', 'DEBUG')
        action_code = metadata['action_code']
        status_code = metadata['status_code']
        if action_code not in [
            '', 
            _IPP_ACT_01, _IPP_ACT_02, _IPP_ACT_03, _IPP_ACT_04, _IPP_ACT_05, _IPP_ACT_06, _IPP_ACT_07, _IPP_ACT_90, _IPP_ACT_91, 
            _CHI_ACT_01, _CHI_ACT_02, _CHI_ACT_03, _CHI_ACT_04, _CHI_ACT_05, _CHI_ACT_06, _CHI_ACT_07, _CHI_ACT_90, _CHI_ACT_91, 
            _HOJ_ACT_01, _HOJ_ACT_02, _HOJ_ACT_03, _HOJ_ACT_04, _HOJ_ACT_05, _HOJ_ACT_06, _HOJ_ACT_07, _HOJ_ACT_90, _HOJ_ACT_91, 
            _KOE_ACT_01, _KOE_ACT_02, _KOE_ACT_03, _KOE_ACT_04, _KOE_ACT_05, _KOE_ACT_06, _KOE_ACT_07, _KOE_ACT_90, _KOE_ACT_91, 
            _ARE_ACT_01, _ARE_ACT_02, _ARE_ACT_03, _ARE_ACT_04, _ARE_ACT_05, _ARE_ACT_06, _ARE_ACT_07, _ARE_ACT_90, 
            ]:
            return False, []

        if status_code not in [
            '', 
            _WAITING, _RUNNING, _SUCCESS, _FAILURE, _CANCEL
            ]:
            return False, []
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] MessageQueue.get_message()関数 STEP 2/3.', 'DEBUG')
        ### 一般資産調査員調査票
        if action_code in [
            _IPP_ACT_01, _IPP_ACT_02, _IPP_ACT_03, _IPP_ACT_04, _IPP_ACT_05, _IPP_ACT_06, _IPP_ACT_07, _IPP_ACT_90, _IPP_ACT_91
            ]:
            params = dict({
                'ACTION_CODE': action_code
            })
            ippan_trigger_list = IPPAN_TRIGGER.objects.raw("""
                SELECT 
                    * 
                FROM IPPAN_TRIGGER 
                WHERE 
                    action_code=%(ACTION_CODE)s AND 
                    consumed_at IS NULL AND 
                    deleted_at IS NULL 
                ORDER BY 
                    CAST(ken_code AS INTEGER), 
                    CAST(city_code AS INTEGER) LIMIT 1""", params)

        ### 地方単独事業調査票
        elif action_code in [
            _CHI_ACT_01, _CHI_ACT_02, _CHI_ACT_03, _CHI_ACT_04, _CHI_ACT_05, _CHI_ACT_06, _CHI_ACT_07, _CHI_ACT_90, _CHI_ACT_91
            ]:
            params = dict({
                'ACTION_CODE': action_code
            })
            chitan_trigger_list = CHITAN_TRIGGER.objects.raw("""
                SELECT 
                    * 
                FROM CHITAN_TRIGGER 
                WHERE 
                    action_code=%(ACTION_CODE)s AND 
                    consumed_at IS NULL AND 
                    deleted_at IS NULL 
                ORDER BY 
                    CAST(ken_code AS INTEGER), 
                    CAST(city_code AS INTEGER) LIMIT 1""", params)

        ### 補助事業調査票
        elif action_code in [
            _HOJ_ACT_01, _HOJ_ACT_02, _HOJ_ACT_03, _HOJ_ACT_04, _HOJ_ACT_05, _HOJ_ACT_06, _HOJ_ACT_07, _HOJ_ACT_90, _HOJ_ACT_91
            ]:
            params = dict({
                'ACTION_CODE': action_code
            })
            hojo_trigger_list = HOJO_TRIGGER.objects.raw("""
                SELECT 
                    * 
                FROM HOJO_TRIGGER 
                WHERE 
                    action_code=%(ACTION_CODE)s AND 
                    consumed_at IS NULL AND 
                    deleted_at IS NULL 
                ORDER BY 
                    CAST(ken_code AS INTEGER), 
                    CAST(city_code AS INTEGER) LIMIT 1""", params)

        ### 公益事業等調査票
        elif action_code in [
            _KOE_ACT_01, _KOE_ACT_02, _KOE_ACT_03, _KOE_ACT_04, _KOE_ACT_05, _KOE_ACT_06, _KOE_ACT_07, _KOE_ACT_90, _KOE_ACT_91
            ]:
            params = dict({
                'ACTION_CODE': action_code
            })
            koeki_trigger_list = KOEKI_TRIGGER.objects.raw("""
                SELECT 
                    * 
                FROM KOEKI_TRIGGER 
                WHERE 
                    action_code=%(ACTION_CODE)s AND 
                    consumed_at IS NULL AND 
                    deleted_at IS NULL 
                ORDER BY 
                    CAST(ken_code AS INTEGER), 
                    CAST(city_code AS INTEGER) LIMIT 1""", params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値をセットする。
        #######################################################################
        print_log('[DEBUG] MessageQueue.get_message()関数 STEP 3/3.', 'DEBUG')
        ### 一般資産調査員調査票
        if action_code in [
            _IPP_ACT_01, _IPP_ACT_02, _IPP_ACT_03, _IPP_ACT_04, _IPP_ACT_05, _IPP_ACT_06, _IPP_ACT_07, _IPP_ACT_90, _IPP_ACT_91
            ]:
            return True, ippan_trigger_list
        
        ### 地方単独事業調査票
        elif action_code in [
            _CHI_ACT_01, _CHI_ACT_02, _CHI_ACT_03, _CHI_ACT_04, _CHI_ACT_05, _CHI_ACT_06, _CHI_ACT_07, _CHI_ACT_90, _CHI_ACT_91
            ]:
            return True, chitan_trigger_list
        
        ### 補助事業調査票
        elif action_code in [
            _HOJ_ACT_01, _HOJ_ACT_02, _HOJ_ACT_03, _HOJ_ACT_04, _HOJ_ACT_05, _HOJ_ACT_06, _HOJ_ACT_07, _HOJ_ACT_90, _HOJ_ACT_91
            ]:
            return True, hojo_trigger_list
        
        ### 公益事業等調査票
        elif action_code in [
            _KOE_ACT_01, _KOE_ACT_02, _KOE_ACT_03, _KOE_ACT_04, _KOE_ACT_05, _KOE_ACT_06, _KOE_ACT_07, _KOE_ACT_90, _KOE_ACT_91
            ]:
            return True, koeki_trigger_list
                
        return False, []
        
    except:
        return False, []

###############################################################################
### 関数名：publish_message(metadata=None)
### 引数：metadata['connection_cursor']
### 引数：metadata['header_id']
### 引数：metadata['ken_code']
### 引数：metadata['city_code']
### 引数：metadata['action_code']
### 引数：metadata['status_code']
### 引数：metadata['download_file_path']
### 引数：metadata['download_file_name']
### 引数：metadata['upload_file_path']
### 引数：metadata['upload_file_name']
###############################################################################
def publish_message(metadata=None):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[INFO] MessageQueue.publish_message()関数が開始しました。', 'INFO')
        print_log('[DEBUG] MessageQueue.publish_message()関数 STEP 1/3.', 'DEBUG')
        connection_cursor = metadata['connection_cursor']
        header_id = metadata['header_id']
        ken_code = metadata['ken_code']
        city_code = metadata['city_code']
        action_code = metadata['action_code']
        status_code = metadata['status_code']
        download_file_path = metadata['download_file_path']
        download_file_name = metadata['download_file_name']
        upload_file_path = metadata['upload_file_path']
        upload_file_name = metadata['upload_file_name']
        if action_code not in [
            '', 
            _IPP_ACT_01, _IPP_ACT_02, _IPP_ACT_03, _IPP_ACT_04, _IPP_ACT_05, _IPP_ACT_06, _IPP_ACT_07, _IPP_ACT_90, _IPP_ACT_91, 
            _CHI_ACT_01, _CHI_ACT_02, _CHI_ACT_03, _CHI_ACT_04, _CHI_ACT_05, _CHI_ACT_06, _CHI_ACT_07, _CHI_ACT_90, _CHI_ACT_91, 
            _HOJ_ACT_01, _HOJ_ACT_02, _HOJ_ACT_03, _HOJ_ACT_04, _HOJ_ACT_05, _HOJ_ACT_06, _HOJ_ACT_07, _HOJ_ACT_90, _HOJ_ACT_91, 
            _KOE_ACT_01, _KOE_ACT_02, _KOE_ACT_03, _KOE_ACT_04, _KOE_ACT_05, _KOE_ACT_06, _KOE_ACT_07, _KOE_ACT_90, _KOE_ACT_91, 
            _ARE_ACT_01, _ARE_ACT_02, _ARE_ACT_03, _ARE_ACT_04, _ARE_ACT_05, _ARE_ACT_06, _ARE_ACT_07, _ARE_ACT_90, 
            ]:
            return False

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] MessageQueue.publish_message()関数 STEP 2/3.', 'DEBUG')
        ### 一般資産調査員調査票
        if action_code in [
            _IPP_ACT_01, _IPP_ACT_02, _IPP_ACT_03, _IPP_ACT_04, _IPP_ACT_05, _IPP_ACT_06, _IPP_ACT_07, _IPP_ACT_90, _IPP_ACT_91
            ]:
            params = dict({
                'HEADER_ID': header_id, 
                'KEN_CODE': ken_code, 
                'CITY_CODE': city_code, 
                'ACTION_CODE': action_code, 
                'STATUS_CODE': status_code, 
                'INFO_COUNT': None, 
                'WARN_COUNT': None, 
                'INFO_LOG': None, 
                'WARN_LOG': None, 
                'DOWNLOAD_FILE_PATH': download_file_path, 
                'DOWNLOAD_FILE_NAME': download_file_name, 
                'UPLOAD_FILE_PATH': upload_file_path, 
                'UPLOAD_FILE_NAME': upload_file_name, 
                'PUBLISHED_AT': None, 
                'CONSUMED_AT': None, 
                'DELETED_AT': None
            })
            connection_cursor.execute("""
                INSERT INTO IPPAN_TRIGGER (
                    ippan_trigger_id, 
                    ippan_header_id, 
                    ken_code, 
                    city_code, 
                    action_code, 
                    status_code, 
                    info_count, 
                    warn_count, 
                    info_log, 
                    warn_log, 
                    download_file_path, 
                    download_file_name, 
                    upload_file_path, 
                    upload_file_name, 
                    published_at, 
                    consumed_at, 
                    deleted_at 
                ) VALUES (
                    (SELECT CASE WHEN (MAX(ippan_trigger_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(ippan_trigger_id+1) AS INTEGER) END AS ippan_trigger_id FROM IPPAN_TRIGGER), 
                    %(HEADER_ID)s, 
                    %(KEN_CODE)s, 
                    %(CITY_CODE)s, 
                    %(ACTION_CODE)s, 
                    %(STATUS_CODE)s, 
                    %(INFO_COUNT)s, 
                    %(WARN_COUNT)s, 
                    %(INFO_LOG)s, 
                    %(WARN_LOG)s, 
                    %(DOWNLOAD_FILE_PATH)s, 
                    %(DOWNLOAD_FILE_NAME)s, 
                    %(UPLOAD_FILE_PATH)s, 
                    %(UPLOAD_FILE_NAME)s, 
                    CURRENT_TIMESTAMP, -- published_at 
                    %(CONSUMED_AT)s, 
                    %(DELETED_AT)s)""", params)

        ### 地方単独事業調査票
        elif action_code in [
            _CHI_ACT_01, _CHI_ACT_02, _CHI_ACT_03, _CHI_ACT_04, _CHI_ACT_05, _CHI_ACT_06, _CHI_ACT_07, _CHI_ACT_90, _CHI_ACT_91
            ]:
            params = dict({
                'HEADER_ID': header_id, 
                'KEN_CODE': ken_code, 
                'CITY_CODE': city_code, 
                'ACTION_CODE': action_code, 
                'STATUS_CODE': status_code, 
                'INFO_COUNT': None, 
                'WARN_COUNT': None, 
                'INFO_LOG': None, 
                'WARN_LOG': None, 
                'DOWNLOAD_FILE_PATH': download_file_path, 
                'DOWNLOAD_FILE_NAME': download_file_name, 
                'UPLOAD_FILE_PATH': upload_file_path, 
                'UPLOAD_FILE_NAME': upload_file_name, 
                'PUBLISHED_AT': None, 
                'CONSUMED_AT': None, 
                'DELETED_AT': None
            })
            connection_cursor.execute("""
                INSERT INTO CHITAN_TRIGGER (
                    chitan_trigger_id, 
                    chitan_header_id, 
                    ken_code, 
                    city_code, 
                    action_code, 
                    status_code, 
                    info_count, 
                    warn_count, 
                    info_log, 
                    warn_log, 
                    download_file_path, 
                    download_file_name, 
                    upload_file_path, 
                    upload_file_name, 
                    published_at, 
                    consumed_at, 
                    deleted_at 
                ) VALUES (
                    (SELECT CASE WHEN (MAX(chitan_trigger_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(chitan_trigger_id+1) AS INTEGER) END AS chitan_trigger_id FROM CHITAN_TRIGGER), 
                    %(HEADER_ID)s, 
                    %(KEN_CODE)s, 
                    %(CITY_CODE)s, 
                    %(ACTION_CODE)s, 
                    %(STATUS_CODE)s, 
                    %(INFO_COUNT)s, 
                    %(WARN_COUNT)s, 
                    %(INFO_LOG)s, 
                    %(WARN_LOG)s, 
                    %(DOWNLOAD_FILE_PATH)s, 
                    %(DOWNLOAD_FILE_NAME)s, 
                    %(UPLOAD_FILE_PATH)s, 
                    %(UPLOAD_FILE_NAME)s, 
                    CURRENT_TIMESTAMP, -- published_at 
                    %(CONSUMED_AT)s, 
                    %(DELETED_AT)s)""", params)

        ### 補助事業調査票
        elif action_code in [
            _HOJ_ACT_01, _HOJ_ACT_02, _HOJ_ACT_03, _HOJ_ACT_04, _HOJ_ACT_05, _HOJ_ACT_06, _HOJ_ACT_07, _HOJ_ACT_90, _HOJ_ACT_91
            ]:
            params = dict({
                'HEADER_ID': header_id, 
                'KEN_CODE': ken_code, 
                'CITY_CODE': city_code, 
                'ACTION_CODE': action_code, 
                'STATUS_CODE': status_code, 
                'INFO_COUNT': None, 
                'WARN_COUNT': None, 
                'INFO_LOG': None, 
                'WARN_LOG': None, 
                'DOWNLOAD_FILE_PATH': download_file_path, 
                'DOWNLOAD_FILE_NAME': download_file_name, 
                'UPLOAD_FILE_PATH': upload_file_path, 
                'UPLOAD_FILE_NAME': upload_file_name, 
                'PUBLISHED_AT': None, 
                'CONSUMED_AT': None, 
                'DELETED_AT': None
            })
            connection_cursor.execute("""
                INSERT INTO HOJO_TRIGGER (
                    hojo_trigger_id, 
                    hojo_header_id, 
                    ken_code, 
                    city_code, 
                    action_code, 
                    status_code, 
                    info_count, 
                    warn_count, 
                    info_log, 
                    warn_log, 
                    download_file_path, 
                    download_file_name, 
                    upload_file_path, 
                    upload_file_name, 
                    published_at, 
                    consumed_at, 
                    deleted_at 
                ) VALUES (
                    (SELECT CASE WHEN (MAX(hojo_trigger_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(hojo_trigger_id+1) AS INTEGER) END AS hojo_trigger_id FROM HOJO_TRIGGER), -- [0] hojo_trigger_id 
                    %(HEADER_ID)s, 
                    %(KEN_CODE)s, 
                    %(CITY_CODE)s, 
                    %(ACTION_CODE)s, 
                    %(STATUS_CODE)s, 
                    %(INFO_COUNT)s, 
                    %(WARN_COUNT)s, 
                    %(INFO_LOG)s, 
                    %(WARN_LOG)s, 
                    %(DOWNLOAD_FILE_PATH)s, 
                    %(DOWNLOAD_FILE_NAME)s, 
                    %(UPLOAD_FILE_PATH)s, 
                    %(UPLOAD_FILE_NAME)s, 
                    CURRENT_TIMESTAMP, -- published_at 
                    %(CONSUMED_AT)s, 
                    %(DELETED_AT)s)""", params)

        ### 公益事業等調査票
        elif action_code in [
            _KOE_ACT_01, _KOE_ACT_02, _KOE_ACT_03, _KOE_ACT_04, _KOE_ACT_05, _KOE_ACT_06, _KOE_ACT_07, _KOE_ACT_90, _KOE_ACT_91
            ]:
            params = dict({
                'HEADER_ID': header_id, 
                'KEN_CODE': ken_code, 
                'CITY_CODE': city_code, 
                'ACTION_CODE': action_code, 
                'STATUS_CODE': status_code, 
                'INFO_COUNT': None, 
                'WARN_COUNT': None, 
                'INFO_LOG': None, 
                'WARN_LOG': None, 
                'DOWNLOAD_FILE_PATH': download_file_path, 
                'DOWNLOAD_FILE_NAME': download_file_name, 
                'UPLOAD_FILE_PATH': upload_file_path, 
                'UPLOAD_FILE_NAME': upload_file_name, 
                'PUBLISHED_AT': None, 
                'CONSUMED_AT': None, 
                'DELETED_AT': None
            })
            connection_cursor.execute("""
                INSERT INTO KOEKI_TRIGGER (
                    koeki_trigger_id, 
                    koeki_header_id, 
                    ken_code, 
                    city_code, 
                    action_code, 
                    status_code, 
                    info_count, 
                    warn_count, 
                    info_log, 
                    warn_log, 
                    download_file_path, 
                    download_file_name, 
                    upload_file_path, 
                    upload_file_name, 
                    published_at, 
                    consumed_at, 
                    deleted_at 
                ) VALUES (
                    (SELECT CASE WHEN (MAX(koeki_trigger_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(koeki_trigger_id+1) AS INTEGER) END AS koeki_trigger_id FROM KOEKI_TRIGGER), 
                    %(HEADER_ID)s, 
                    %(KEN_CODE)s, 
                    %(CITY_CODE)s, 
                    %(ACTION_CODE)s, 
                    %(STATUS_CODE)s, 
                    %(INFO_COUNT)s, 
                    %(WARN_COUNT)s, 
                    %(INFO_LOG)s, 
                    %(WARN_LOG)s, 
                    %(DOWNLOAD_FILE_PATH)s, 
                    %(DOWNLOAD_FILE_NAME)s, 
                    %(UPLOAD_FILE_PATH)s, 
                    %(UPLOAD_FILE_NAME)s, 
                    CURRENT_TIMESTAMP, -- published_at 
                    %(CONSUMED_AT)s, 
                    %(DELETED_AT)s)""", params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値をセットする。
        #######################################################################
        print_log('[DEBUG] MessageQueue.publish_message()関数 STEP 3/3.', 'DEBUG')
        return True
    
    except:
        return False

###############################################################################
### 関数名：publish_consume_message(metadata=None)
### 引数：metadata['connection_cursor']
### 引数：metadata['header_id']
### 引数：metadata['ken_code']
### 引数：metadata['city_code']
### 引数：metadata['action_code']
### 引数：metadata['status_code']
### 引数：metadata['info_count']
### 引数：metadata['warn_count']
### 引数：metadata['info_log']
### 引数：metadata['warn_log']
### 引数：metadata['download_file_path']
### 引数：metadata['download_file_name']
### 引数：metadata['upload_file_path']
### 引数：metadata['upload_file_name']
###############################################################################
def publish_consume_message(metadata=None):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[INFO] MessageQueue.publish_consume_message()関数が開始しました。', 'INFO')
        print_log('[DEBUG] MessageQueue.publish_consume_message()関数 STEP 1/3.', 'DEBUG')
        connection_cursor = metadata['connection_cursor']
        header_id = metadata['header_id']
        ken_code = metadata['ken_code']
        city_code = metadata['city_code']
        action_code = metadata['action_code']
        status_code = metadata['status_code']
        info_count = metadata['info_count']
        warn_count = metadata['warn_count']
        info_log = metadata['info_log']
        warn_log = metadata['warn_log']
        download_file_path = metadata['download_file_path']
        download_file_name = metadata['download_file_name']
        upload_file_path = metadata['upload_file_path']
        upload_file_name = metadata['upload_file_name']
        if action_code not in [
            '', 
            _IPP_ACT_01, _IPP_ACT_02, _IPP_ACT_03, _IPP_ACT_04, _IPP_ACT_05, _IPP_ACT_06, _IPP_ACT_07, _IPP_ACT_90, _IPP_ACT_91, 
            _CHI_ACT_01, _CHI_ACT_02, _CHI_ACT_03, _CHI_ACT_04, _CHI_ACT_05, _CHI_ACT_06, _CHI_ACT_07, _CHI_ACT_90, _CHI_ACT_91, 
            _HOJ_ACT_01, _HOJ_ACT_02, _HOJ_ACT_03, _HOJ_ACT_04, _HOJ_ACT_05, _HOJ_ACT_06, _HOJ_ACT_07, _HOJ_ACT_90, _HOJ_ACT_91, 
            _KOE_ACT_01, _KOE_ACT_02, _KOE_ACT_03, _KOE_ACT_04, _KOE_ACT_05, _KOE_ACT_06, _KOE_ACT_07, _KOE_ACT_90, _KOE_ACT_91, 
            _ARE_ACT_01, _ARE_ACT_02, _ARE_ACT_03, _ARE_ACT_04, _ARE_ACT_05, _ARE_ACT_06, _ARE_ACT_07, _ARE_ACT_90, 
            ]:
            return False

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] MessageQueue.publish_consume_message()関数 STEP 2/3.', 'DEBUG')
        ### 一般資産調査員調査票
        if action_code in [
            _IPP_ACT_01, _IPP_ACT_02, _IPP_ACT_03, _IPP_ACT_04, _IPP_ACT_05, _IPP_ACT_06, _IPP_ACT_07, _IPP_ACT_90, _IPP_ACT_91
            ]:
            params = dict({
                'HEADER_ID': header_id, 
                'KEN_CODE': ken_code, 
                'CITY_CODE': city_code, 
                'ACTION_CODE': action_code, 
                'STATUS_CODE': status_code, 
                'INFO_COUNT': info_count, 
                'WARN_COUNT': warn_count, 
                'INFO_LOG': '\n'.join(info_log), 
                'WARN_LOG': '\n'.join(warn_log), 
                'DOWNLOAD_FILE_PATH': download_file_path, 
                'DOWNLOAD_FILE_NAME': download_file_name, 
                'UPLOAD_FILE_PATH': upload_file_path, 
                'UPLOAD_FILE_NAME': upload_file_name, 
                'PUBLISHED_AT': None, 
                'CONSUMED_AT': None, 
                'DELETED_AT': None
            })
            connection_cursor.execute("""
                INSERT INTO IPPAN_TRIGGER (
                    ippan_trigger_id, 
                    ippan_header_id, 
                    ken_code, 
                    city_code, 
                    action_code, 
                    status_code, 
                    info_count, 
                    warn_count, 
                    info_log, 
                    warn_log, 
                    download_file_path, 
                    download_file_name, 
                    upload_file_path, 
                    upload_file_name, 
                    published_at, 
                    consumed_at, 
                    deleted_at 
                ) VALUES (
                    (SELECT CASE WHEN (MAX(ippan_trigger_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(ippan_trigger_id+1) AS INTEGER) END AS ippan_trigger_id FROM IPPAN_TRIGGER), 
                    %(HEADER_ID)s, 
                    %(KEN_CODE)s, 
                    %(CITY_CODE)s, 
                    %(ACTION_CODE)s, 
                    %(STATUS_CODE)s, 
                    %(INFO_COUNT)s, 
                    %(WARN_COUNT)s, 
                    %(INFO_LOG)s, 
                    %(WARN_LOG)s, 
                    %(DOWNLOAD_FILE_PATH)s, 
                    %(DOWNLOAD_FILE_NAME)s, 
                    %(UPLOAD_FILE_PATH)s, 
                    %(UPLOAD_FILE_NAME)s, 
                    CURRENT_TIMESTAMP, -- published_at 
                    CURRENT_TIMESTAMP, -- consumed_at 
                    %(DELETED_AT)s)""", params)

        ### 地方単独事業調査票
        elif action_code in [
            _CHI_ACT_01, _CHI_ACT_02, _CHI_ACT_03, _CHI_ACT_04, _CHI_ACT_05, _CHI_ACT_06, _CHI_ACT_07, _CHI_ACT_90, _CHI_ACT_91
            ]:
            params = dict({
                'HEADER_ID': header_id, 
                'KEN_CODE': ken_code, 
                'CITY_CODE': city_code, 
                'ACTION_CODE': action_code, 
                'STATUS_CODE': status_code, 
                'INFO_COUNT': info_count, 
                'WARN_COUNT': warn_count, 
                'INFO_LOG': '\n'.join(info_log), 
                'WARN_LOG': '\n'.join(warn_log), 
                'DOWNLOAD_FILE_PATH': download_file_path, 
                'DOWNLOAD_FILE_NAME': download_file_name, 
                'UPLOAD_FILE_PATH': upload_file_path, 
                'UPLOAD_FILE_NAME': upload_file_name, 
                'PUBLISHED_AT': None, 
                'CONSUMED_AT': None, 
                'DELETED_AT': None
            })
            connection_cursor.execute("""
                INSERT INTO CHITAN_TRIGGER (
                    chitan_trigger_id, 
                    chitan_header_id, 
                    ken_code, 
                    city_code, 
                    action_code, 
                    status_code, 
                    info_count, 
                    warn_count, 
                    info_log, 
                    warn_log, 
                    download_file_path, 
                    download_file_name, 
                    upload_file_path, 
                    upload_file_name, 
                    published_at, 
                    consumed_at, 
                    deleted_at 
                ) VALUES (
                    (SELECT CASE WHEN (MAX(chitan_trigger_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(chitan_trigger_id+1) AS INTEGER) END AS chitan_trigger_id FROM CHITAN_TRIGGER), 
                    %(HEADER_ID)s, 
                    %(KEN_CODE)s, 
                    %(CITY_CODE)s, 
                    %(ACTION_CODE)s, 
                    %(STATUS_CODE)s, 
                    %(INFO_COUNT)s, 
                    %(WARN_COUNT)s, 
                    %(INFO_LOG)s, 
                    %(WARN_LOG)s, 
                    %(DOWNLOAD_FILE_PATH)s, 
                    %(DOWNLOAD_FILE_NAME)s, 
                    %(UPLOAD_FILE_PATH)s, 
                    %(UPLOAD_FILE_NAME)s, 
                    CURRENT_TIMESTAMP, -- published_at 
                    CURRENT_TIMESTAMP, -- consumed_at 
                    %(DELETED_AT)s)""", params)

        ### 補助事業調査票
        elif action_code in [
            _HOJ_ACT_01, _HOJ_ACT_02, _HOJ_ACT_03, _HOJ_ACT_04, _HOJ_ACT_05, _HOJ_ACT_06, _HOJ_ACT_07, _HOJ_ACT_90, _HOJ_ACT_91
            ]:
            params = dict({
                'HEADER_ID': header_id, 
                'KEN_CODE': ken_code, 
                'CITY_CODE': city_code, 
                'ACTION_CODE': action_code, 
                'STATUS_CODE': status_code, 
                'INFO_COUNT': info_count, 
                'WARN_COUNT': warn_count, 
                'INFO_LOG': '\n'.join(info_log), 
                'WARN_LOG': '\n'.join(warn_log), 
                'DOWNLOAD_FILE_PATH': download_file_path, 
                'DOWNLOAD_FILE_NAME': download_file_name, 
                'UPLOAD_FILE_PATH': upload_file_path, 
                'UPLOAD_FILE_NAME': upload_file_name, 
                'PUBLISHED_AT': None, 
                'CONSUMED_AT': None, 
                'DELETED_AT': None
            })
            connection_cursor.execute("""
                INSERT INTO HOJO_TRIGGER (
                    hojo_trigger_id, 
                    hojo_header_id, 
                    ken_code, 
                    city_code, 
                    action_code, 
                    status_code, 
                    info_count, 
                    warn_count, 
                    info_log, 
                    warn_log, 
                    download_file_path, 
                    download_file_name, 
                    upload_file_path, 
                    upload_file_name, 
                    published_at, 
                    consumed_at, 
                    deleted_at 
                ) VALUES (
                    (SELECT CASE WHEN (MAX(hojo_trigger_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(hojo_trigger_id+1) AS INTEGER) END AS hojo_trigger_id FROM HOJO_TRIGGER), 
                    %(HEADER_ID)s, 
                    %(KEN_CODE)s, 
                    %(CITY_CODE)s, 
                    %(ACTION_CODE)s, 
                    %(STATUS_CODE)s, 
                    %(INFO_COUNT)s, 
                    %(WARN_COUNT)s, 
                    %(INFO_LOG)s, 
                    %(WARN_LOG)s, 
                    %(DOWNLOAD_FILE_PATH)s, 
                    %(DOWNLOAD_FILE_NAME)s, 
                    %(UPLOAD_FILE_PATH)s, 
                    %(UPLOAD_FILE_NAME)s, 
                    CURRENT_TIMESTAMP, -- published_at 
                    CURRENT_TIMESTAMP, -- consumed_at 
                    %(DELETED_AT)s)""", params)

        ### 公益事業等調査票
        elif action_code in [
            _KOE_ACT_01, _KOE_ACT_02, _KOE_ACT_03, _KOE_ACT_04, _KOE_ACT_05, _KOE_ACT_06, _KOE_ACT_07, _KOE_ACT_90, _KOE_ACT_91
            ]:
            params = dict({
                'HEADER_ID': header_id, 
                'KEN_CODE': ken_code, 
                'CITY_CODE': city_code, 
                'ACTION_CODE': action_code, 
                'STATUS_CODE': status_code, 
                'INFO_COUNT': info_count, 
                'WARN_COUNT': warn_count, 
                'INFO_LOG': '\n'.join(info_log), 
                'WARN_LOG': '\n'.join(warn_log), 
                'DOWNLOAD_FILE_PATH': download_file_path, 
                'DOWNLOAD_FILE_NAME': download_file_name, 
                'UPLOAD_FILE_PATH': upload_file_path, 
                'UPLOAD_FILE_NAME': upload_file_name, 
                'PUBLISHED_AT': None, 
                'CONSUMED_AT': None, 
                'DELETED_AT': None
            })
            connection_cursor.execute("""
                INSERT INTO KOEKI_TRIGGER (
                    koeki_trigger_id, 
                    koeki_header_id, 
                    ken_code, 
                    city_code, 
                    action_code, 
                    status_code, 
                    info_count, 
                    warn_count, 
                    info_log, 
                    warn_log, 
                    download_file_path, 
                    download_file_name, 
                    upload_file_path, 
                    upload_file_name, 
                    published_at, 
                    consumed_at, 
                    deleted_at 
                ) VALUES (
                    (SELECT CASE WHEN (MAX(koeki_trigger_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(koeki_trigger_id+1) AS INTEGER) END AS koeki_trigger_id FROM KOEKI_TRIGGER), 
                    %(HEADER_ID)s, 
                    %(KEN_CODE)s, 
                    %(CITY_CODE)s, 
                    %(ACTION_CODE)s, 
                    %(STATUS_CODE)s, 
                    %(INFO_COUNT)s, 
                    %(WARN_COUNT)s, 
                    %(INFO_LOG)s, 
                    %(WARN_LOG)s, 
                    %(DOWNLOAD_FILE_PATH)s, 
                    %(DOWNLOAD_FILE_NAME)s, 
                    %(UPLOAD_FILE_PATH)s, 
                    %(UPLOAD_FILE_NAME)s, 
                    CURRENT_TIMESTAMP, -- published_at 
                    CURRENT_TIMESTAMP, -- consumed_at 
                    %(DELETED_AT)s)""", params)

        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値をセットする。
        #######################################################################
        print_log('[DEBUG] MessageQueue.publish_message()関数 STEP 3/3.', 'DEBUG')
        return True
    
    except:
        return False

###############################################################################
### 関数名：consume_message(metadata=None)
### 引数：metadata['connection_cursor']
### 引数：metadata['trigger_id']
### 引数：metadata['action_code']
### 引数：metadata['status_code']
### 引数：metadata['info_count']
### 引数：metadata['warn_count']
### 引数：metadata['info_log']
### 引数：metadata['warn_log']
###############################################################################
def consume_message(metadata=None):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[INFO] MessageQueue.consume_message()関数が開始しました。', 'INFO')
        print_log('[DEBUG] MessageQueue.consume_message()関数 STEP 1/3.', 'DEBUG')
        connection_cursor = metadata['connection_cursor']
        print_log('[DEBUG] MessageQueue.consume_message()関数 STEP 1_1/3.', 'DEBUG')
        trigger_id = metadata['trigger_id']
        print_log('[DEBUG] MessageQueue.consume_message()関数 STEP 1_2/3.', 'DEBUG')
        action_code = metadata['action_code']
        print_log('[DEBUG] MessageQueue.consume_message()関数 STEP 1_3/3.', 'DEBUG')
        status_code = metadata['status_code']
        print_log('[DEBUG] MessageQueue.consume_message()関数 STEP 1_4/3.', 'DEBUG')
        info_count = metadata['info_count']
        print_log('[DEBUG] MessageQueue.consume_message()関数 STEP 1_5/3.', 'DEBUG')
        warn_count = metadata['warn_count']
        print_log('[DEBUG] MessageQueue.consume_message()関数 STEP 1_6/3.', 'DEBUG')
        info_log = metadata['info_log']
        print_log('[DEBUG] MessageQueue.consume_message()関数 STEP 1_7/3.', 'DEBUG')
        warn_log = metadata['warn_log']
        print_log('[DEBUG] MessageQueue.consume_message()関数 STEP 1_8/3.', 'DEBUG')
        if action_code not in [
            '', 
            _IPP_ACT_01, _IPP_ACT_02, _IPP_ACT_03, _IPP_ACT_04, _IPP_ACT_05, _IPP_ACT_06, _IPP_ACT_07, _IPP_ACT_90, _IPP_ACT_91, 
            _CHI_ACT_01, _CHI_ACT_02, _CHI_ACT_03, _CHI_ACT_04, _CHI_ACT_05, _CHI_ACT_06, _CHI_ACT_07, _CHI_ACT_90, _CHI_ACT_91, 
            _HOJ_ACT_01, _HOJ_ACT_02, _HOJ_ACT_03, _HOJ_ACT_04, _HOJ_ACT_05, _HOJ_ACT_06, _HOJ_ACT_07, _HOJ_ACT_90, _HOJ_ACT_91, 
            _KOE_ACT_01, _KOE_ACT_02, _KOE_ACT_03, _KOE_ACT_04, _KOE_ACT_05, _KOE_ACT_06, _KOE_ACT_07, _KOE_ACT_90, _KOE_ACT_91, 
            _ARE_ACT_01, _ARE_ACT_02, _ARE_ACT_03, _ARE_ACT_04, _ARE_ACT_05, _ARE_ACT_06, _ARE_ACT_07, _ARE_ACT_90, 
            ]:
            return False

        print_log('[DEBUG] MessageQueue.consume_message()関数 STEP 1_9/3.', 'DEBUG')
        if status_code not in [
            '', 
            _WAITING, _RUNNING, _SUCCESS, _FAILURE, _CANCEL
            ]:
            return False
        
        print_log('[DEBUG] MessageQueue.consume_message()関数 STEP 1_10/3.', 'DEBUG')
        ### if info_count in ['']: ### TODO TO-DO TO_DO
        ### if warn_count in ['']: ### TODO TO-DO TO_DO
        ### if info_log in ['']: ### TODO TO-DO TO_DO
        ### if warn_log in ['']: ### TODO TO-DO TO_DO
        ### if trigger_id in ['']: ### TODO TO-DO TO_DO

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] MessageQueue.consume_message()関数 STEP 2/3.', 'DEBUG')
        ### 一般資産調査員調査票
        if action_code in [
            _IPP_ACT_01, _IPP_ACT_02, _IPP_ACT_03, _IPP_ACT_04, _IPP_ACT_05, _IPP_ACT_06, _IPP_ACT_07, _IPP_ACT_90, _IPP_ACT_91
            ]:
            params = dict({
                'STATUS_CODE': status_code, 
                'INFO_COUNT': info_count, 
                'WARN_COUNT': warn_count, 
                'INFO_LOG': '\n'.join(info_log), 
                'WARN_LOG': '\n'.join(warn_log), 
                'TRIGGER_ID': trigger_id
            })
            connection_cursor.execute("""
                UPDATE IPPAN_TRIGGER SET 
                    status_code=%(STATUS_CODE)s, 
                    info_count=%(INFO_COUNT)s, 
                    warn_count=%(WARN_COUNT)s, 
                    consumed_at=CURRENT_TIMESTAMP, 
                    info_log=%(INFO_LOG)s, 
                    warn_log=%(WARN_LOG)s 
                WHERE 
                    ippan_trigger_id=%(TRIGGER_ID)s """, params)
        
        ### 地方単独事業調査票
        elif action_code in [
            _CHI_ACT_01, _CHI_ACT_02, _CHI_ACT_03, _CHI_ACT_04, _CHI_ACT_05, _CHI_ACT_06, _CHI_ACT_07, _CHI_ACT_90, _CHI_ACT_91
            ]:
            params = dict({
                'STATUS_CODE': status_code, 
                'INFO_COUNT': info_count, 
                'WARN_COUNT': warn_count, 
                'INFO_LOG': '\n'.join(info_log), 
                'WARN_LOG': '\n'.join(warn_log), 
                'TRIGGER_ID': trigger_id
            })
            connection_cursor.execute("""
                UPDATE CHITAN_TRIGGER SET 
                    status_code=%(STATUS_CODE)s, 
                    info_count=%(INFO_COUNT)s, 
                    warn_count=%(WARN_COUNT)s, 
                    consumed_at=CURRENT_TIMESTAMP, 
                    info_log=%(INFO_LOG)s, 
                    warn_log=%(WARN_LOG)s 
                WHERE 
                    chitan_trigger_id=%(TRIGGER_ID)s """, params)

        ### 補助事業調査票
        elif action_code in [
            _HOJ_ACT_01, _HOJ_ACT_02, _HOJ_ACT_03, _HOJ_ACT_04, _HOJ_ACT_05, _HOJ_ACT_06, _HOJ_ACT_07, _HOJ_ACT_90, _HOJ_ACT_91
            ]:
            params = dict({
                'STATUS_CODE': status_code, 
                'INFO_COUNT': info_count, 
                'WARN_COUNT': warn_count, 
                'INFO_LOG': '\n'.join(info_log), 
                'WARN_LOG': '\n'.join(warn_log), 
                'TRIGGER_ID': trigger_id
            })
            connection_cursor.execute("""
                UPDATE HOJO_TRIGGER SET 
                    status_code=%(STATUS_CODE)s, 
                    info_count=%(INFO_COUNT)s, 
                    warn_count=%(WARN_COUNT)s, 
                    consumed_at=CURRENT_TIMESTAMP, 
                    info_log=%(INFO_LOG)s, 
                    warn_log=%(WARN_LOG)s 
                WHERE 
                    hojo_trigger_id=%(TRIGGER_ID)s """, params)

        ### 公益事業等調査票
        elif action_code in [
            _KOE_ACT_01, _KOE_ACT_02, _KOE_ACT_03, _KOE_ACT_04, _KOE_ACT_05, _KOE_ACT_06, _KOE_ACT_07, _KOE_ACT_90, _KOE_ACT_91
            ]:
            params = dict({
                'STATUS_CODE': status_code, 
                'INFO_COUNT': info_count, 
                'WARN_COUNT': warn_count, 
                'INFO_LOG': '\n'.join(info_log), 
                'WARN_LOG': '\n'.join(warn_log), 
                'TRIGGER_ID': trigger_id
            })
            connection_cursor.execute("""
                UPDATE KOEKI_TRIGGER SET 
                    status_code=%(STATUS_CODE)s, 
                    info_count=%(INFO_COUNT)s, 
                    warn_count=%(WARN_COUNT)s, 
                    consumed_at=CURRENT_TIMESTAMP, 
                    info_log=%(INFO_LOG)s, 
                    warn_log=%(WARN_LOG)s 
                WHERE 
                    koeki_trigger_id=%(TRIGGER_ID)s """, params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値をセットする。
        #######################################################################
        print_log('[DEBUG] MessageQueue.consume_message()関数 STEP 3/3.', 'DEBUG')
        return True
    
    except:
        return False

###############################################################################
### 関数名：delete_message(metadata=None)
### 引数：metadata['connection_cursor']
### 引数：metadata['ken_code']
### 引数：metadata['city_code']
### 引数：metadata['action_code']
###############################################################################
def delete_message(metadata=None):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### 引数をチェックする。
        #######################################################################
        print_log('[INFO] MessageQueue.delete_message()関数が開始しました。', 'INFO')
        print_log('[DEBUG] MessageQueue.delete_message()関数 STEP 1/3.', 'DEBUG')
        connection_cursor = metadata['connection_cursor']
        ken_code = metadata['ken_code']
        city_code = metadata['city_code']
        action_code = metadata['action_code']
        print_log('{}'.format(action_code), 'DEBUG')
        print_log('[DEBUG] MessageQueue.delete_message()関数 STEP 1/3.', 'DEBUG')
        if action_code not in [
            '', 
            _IPP_ACT_01, _IPP_ACT_02, _IPP_ACT_03, _IPP_ACT_04, _IPP_ACT_05, _IPP_ACT_06, _IPP_ACT_07, _IPP_ACT_90, _IPP_ACT_91, 
            _CHI_ACT_01, _CHI_ACT_02, _CHI_ACT_03, _CHI_ACT_04, _CHI_ACT_05, _CHI_ACT_06, _CHI_ACT_07, _CHI_ACT_90, _CHI_ACT_91, 
            _HOJ_ACT_01, _HOJ_ACT_02, _HOJ_ACT_03, _HOJ_ACT_04, _HOJ_ACT_05, _HOJ_ACT_06, _HOJ_ACT_07, _HOJ_ACT_90, _HOJ_ACT_91, 
            _KOE_ACT_01, _KOE_ACT_02, _KOE_ACT_03, _KOE_ACT_04, _KOE_ACT_05, _KOE_ACT_06, _KOE_ACT_07, _KOE_ACT_90, _KOE_ACT_91, 
            _ARE_ACT_01, _ARE_ACT_02, _ARE_ACT_03, _ARE_ACT_04, _ARE_ACT_05, _ARE_ACT_06, _ARE_ACT_07, _ARE_ACT_90, 
            ]:
            return False
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] MessageQueue.delete_message()関数 STEP 2/3.', 'DEBUG')
        ### 一般資産調査員調査票
        if action_code in [
            _IPP_ACT_01, _IPP_ACT_02, _IPP_ACT_03, _IPP_ACT_04, _IPP_ACT_05, _IPP_ACT_06, _IPP_ACT_07, _IPP_ACT_90, _IPP_ACT_91
            ]:
            params = dict({
                'CITY_CODE': city_code, 
                'IPP_ACT_01': _IPP_ACT_01, 
                'IPP_ACT_02': _IPP_ACT_02, 
                'IPP_ACT_03': _IPP_ACT_03, 
                'IPP_ACT_04': _IPP_ACT_04, 
                'IPP_ACT_05': _IPP_ACT_05, 
                'IPP_ACT_06': _IPP_ACT_06, 
                'IPP_ACT_07': _IPP_ACT_07 
            })
            connection_cursor.execute("""
                UPDATE IPPAN_TRIGGER SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE ippan_trigger_id IN (
                SELECT ippan_trigger_id FROM IPPAN_TRIGGER 
                WHERE 
                    city_code=%(CITY_CODE)s AND 
                    deleted_at IS NULL AND 
                    action_code IN (%(IPP_ACT_01)s, %(IPP_ACT_02)s, %(IPP_ACT_03)s, %(IPP_ACT_04)s, %(IPP_ACT_05)s, %(IPP_ACT_06)s, %(IPP_ACT_07)s))""", params)
            
        ### 地方単独事業調査票
        elif action_code in [
            _CHI_ACT_01, _CHI_ACT_02, _CHI_ACT_03, _CHI_ACT_04, _CHI_ACT_05, _CHI_ACT_06, _CHI_ACT_07, _CHI_ACT_90, _CHI_ACT_91
            ]:
            params = dict({
                'KEN_CODE': ken_code, 
                'CHI_ACT_01': _CHI_ACT_01, 
                'CHI_ACT_02': _CHI_ACT_02, 
                'CHI_ACT_03': _CHI_ACT_03, 
                'CHI_ACT_04': _CHI_ACT_04, 
                'CHI_ACT_05': _CHI_ACT_05, 
                'CHI_ACT_06': _CHI_ACT_06, 
                'CHI_ACT_07': _CHI_ACT_07 
            })
            connection_cursor.execute("""
                UPDATE CHITAN_TRIGGER SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE chitan_trigger_id IN (
                SELECT chitan_trigger_id FROM CHITAN_TRIGGER 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL AND 
                    action_code IN (%(CHI_ACT_01)s, %(CHI_ACT_02)s, %(CHI_ACT_03)s, %(CHI_ACT_04)s, %(CHI_ACT_05)s, %(CHI_ACT_06)s, %(CHI_ACT_07)s))""", params)

        ### 補助事業調査票
        elif action_code in [
            _HOJ_ACT_01, _HOJ_ACT_02, _HOJ_ACT_03, _HOJ_ACT_04, _HOJ_ACT_05, _HOJ_ACT_06, _HOJ_ACT_07, _HOJ_ACT_90, _HOJ_ACT_91
            ]:
            params = dict({
                'KEN_CODE': ken_code, 
                'HOJ_ACT_01': _HOJ_ACT_01, 
                'HOJ_ACT_02': _HOJ_ACT_02, 
                'HOJ_ACT_03': _HOJ_ACT_03, 
                'HOJ_ACT_04': _HOJ_ACT_04, 
                'HOJ_ACT_05': _HOJ_ACT_05, 
                'HOJ_ACT_06': _HOJ_ACT_06, 
                'HOJ_ACT_07': _HOJ_ACT_07 
            })
            connection_cursor.execute("""
                UPDATE HOJO_TRIGGER SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE hojo_trigger_id IN (
                SELECT hojo_trigger_id FROM HOJO_TRIGGER 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL AND 
                    action_code IN (%(HOJ_ACT_01)s, %(HOJ_ACT_02)s, %(HOJ_ACT_03)s, %(HOJ_ACT_04)s, %(HOJ_ACT_05)s, %(HOJ_ACT_06)s, %(HOJ_ACT_07)s))""", params)

        ### 公益事業等調査票
        elif action_code in [
            _KOE_ACT_01, _KOE_ACT_02, _KOE_ACT_03, _KOE_ACT_04, _KOE_ACT_05, _KOE_ACT_06, _KOE_ACT_07, _KOE_ACT_90, _KOE_ACT_91
            ]:
            params = dict({
                'KEN_CODE': ken_code, 
                'KOE_ACT_01': _KOE_ACT_01, 
                'KOE_ACT_02': _KOE_ACT_02, 
                'KOE_ACT_03': _KOE_ACT_03, 
                'KOE_ACT_04': _KOE_ACT_04, 
                'KOE_ACT_05': _KOE_ACT_05, 
                'KOE_ACT_06': _KOE_ACT_06, 
                'KOE_ACT_07': _KOE_ACT_07 
            })
            connection_cursor.execute("""
                UPDATE KOEKI_TRIGGER SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE koeki_trigger_id IN (
                SELECT koeki_trigger_id FROM KOEKI_TRIGGER 
                WHERE 
                    ken_code=%(KEN_CODE)s AND 
                    deleted_at IS NULL AND 
                    action_code IN (%(KOE_ACT_01)s, %(KOE_ACT_02)s, %(KOE_ACT_03)s, %(KOE_ACT_04)s, %(KOE_ACT_05)s, %(KOE_ACT_06)s, %(KOE_ACT_07)s))""", params)
        
        #######################################################################
        ### 戻り値セット処理(0020)
        ### 戻り値をセットする。
        #######################################################################
        print_log('[DEBUG] MessageQueue.delete_message()関数 STEP 3/3.', 'DEBUG')
        return True
    
    except:
        return False
