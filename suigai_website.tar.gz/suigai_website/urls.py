from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    ### Common Applications
    path('', include('P0100Login.urls')),
    path('P0100Login/', include('P0100Login.urls')),

    ### File Applications
    path('P0110City/', include('P0110City.urls')),         ### Add 2023/01/27
    path('P0120Ken/', include('P0120Ken.urls')),           ### Add 2023/01/27
    path('P0130Manage/', include('P0130Manage.urls')),     ### Add 2023/01/27

    ### Excel Applications
    path('P0200Download/', include('P0200Download.urls')), ### Add 2023/03/03
    ### path('P0210City/', include('P0210City.urls')),         ### Add 2023/03/03
    ### path('P0220Ken/', include('P0220Ken.urls')),           ### Add 2023/02/28
    ### path('P0230Manage/', include('P0230Manage.urls')),     ### Add 2023/02/08

    ### Online Applications
    path('P0400Online/', include('P0400Online.urls')),

    ### Gis Applications
    path('P0500Gis/', include('P0500Gis.urls')),

    ### Approval Applications
    path('P0600Approval/', include('P0600Approval.urls')),

    ### EStat Applications
    path('P0700EStat/', include('P0700EStat.urls')),

    ### Reverse Applications
    path('P0800Reverse/', include('P0800Reverse.urls')),
    
    ### Action Applications
    path('P0900Action/', include('P0900Action.urls')),
    
    ### See Python Django開発入門, P227
    path('admin/', admin.site.urls),
]
