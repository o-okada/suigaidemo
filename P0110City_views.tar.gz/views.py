###############################################################################
### ファイル名：P0110City/views.py
### ファイル管理
### 更新履歴
### 2023/11/14 browser_post_ippan 関数において試行版用に水害区域番号のチェックをコメントアウトする。
###############################################################################

import json                                            ### ADD 2023/02/06
import os                                              ### ADD 2023/02/21
import sys

from datetime import date, datetime                    ### ADD 2023/02/21
from datetime import timedelta, timezone               ### ADD 2023/02/21

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import connection                       ### ADD 2023/02/21
from django.db import transaction                      ### ADD 2023/02/21
from django.db.models import Max                       ### ADD 2023/02/21
from django.http import Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.http import HttpResponseNotFound           ### ADD 2023/02/17
from django.http.response import JsonResponse          ### ADD 2023/02/06
from django.shortcuts import redirect                  ### ADD 2023/02/10
from django.shortcuts import render
from django.template import loader
from django.views import generic
from django.views import View                          ### ADD 2023/03/09
from django.views.generic.base import TemplateView

import openpyxl
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.writer.excel import save_virtual_workbook

from P0000Common.models import USER_PROXY              ### 0000: マスタデータ_ユーザプロキシ

from P0000Common.models import BUILDING                ### 1000: マスタデータ_建物区分
from P0000Common.models import KEN                     ### 1010: マスタデータ_都道府県
from P0000Common.models import CITY                    ### 1020: マスタデータ_市区町村
from P0000Common.models import KASEN_KAIGAN            ### 1030: マスタデータ_水害発生地点工種（河川海岸区分）
from P0000Common.models import SUIKEI                  ### 1040: マスタデータ_水系（水系・沿岸）
from P0000Common.models import SUIKEI_TYPE             ### 1050: マスタデータ_水系種別（水系・沿岸種別）
from P0000Common.models import KASEN                   ### 1060: マスタデータ_河川（河川・海岸）
from P0000Common.models import KASEN_TYPE              ### 1070: マスタデータ_河川種別（河川・海岸種別）
from P0000Common.models import CAUSE                   ### 1080: マスタデータ_水害原因
from P0000Common.models import UNDERGROUND             ### 1090: マスタデータ_地上地下区分
from P0000Common.models import USAGE                   ### 1100: マスタデータ_地下空間の利用形態
from P0000Common.models import FLOOD_SEDIMENT          ### 1110: マスタデータ_浸水土砂区分
from P0000Common.models import GRADIENT                ### 1120: マスタデータ_地盤勾配区分
from P0000Common.models import INDUSTRY                ### 1130: マスタデータ_一般資産調査員調査票_産業分類
from P0000Common.models import BUSINESS                ### 1140: マスタデータ_公益事業等調査票_事業分類

from P0000Common.models import HOUSE_ASSET             ### 2000: マスタデータ_家屋評価額
from P0000Common.models import HOUSE_RATE              ### 2010: マスタデータ_家屋被害率
from P0000Common.models import HOUSE_ALT               ### 2020: マスタデータ_家庭応急対策費_代替活動費
from P0000Common.models import HOUSE_CLEAN             ### 2030: マスタデータ_家庭応急対策費_清掃日数

from P0000Common.models import HOUSEHOLD_ASSET         ### 3000: マスタデータ_家庭用品自動車以外所有額
from P0000Common.models import HOUSEHOLD_RATE          ### 3010: マスタデータ_家庭用品自動車以外被害率

from P0000Common.models import CAR_ASSET               ### 4000: マスタデータ_家庭用品自動車所有額
from P0000Common.models import CAR_RATE                ### 4010: マスタデータ_家庭用品自動車被害率

from P0000Common.models import OFFICE_ASSET            ### 5000: マスタデータ_事業所資産額
from P0000Common.models import OFFICE_RATE             ### 5010: マスタデータ_事業所被害率
from P0000Common.models import OFFICE_SUSPEND          ### 5020: マスタデータ_事業所営業停止日数
from P0000Common.models import OFFICE_STAGNATE         ### 5030: マスタデータ_事業所営業停滞日数
from P0000Common.models import OFFICE_ALT              ### 5040: マスタデータ_事業所応急対策費_代替活動費

from P0000Common.models import FARMER_FISHER_ASSET     ### 6000: マスタデータ_農漁家資産額
from P0000Common.models import FARMER_FISHER_RATE      ### 6010: マスタデータ_農漁家被害率

from P0000Common.models import AREA                    ### 7000: アップロードデータ_水害区域
from P0000Common.models import WEATHER                 ### 7010: アップロードデータ_異常気象
from P0000Common.models import IPPAN_HEADER            ### 7020: アップロードデータ_一般資産調査員調査票_ヘッダ部分
from P0000Common.models import IPPAN                   ### 7030: アップロードデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_HEADER           ### 7050: アップロードデータ_公共土木施設調査票_地方単独事業_ヘッダ部分
from P0000Common.models import CHITAN                  ### 7060: アップロードデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_HEADER             ### 7070: アップロードデータ_公共土木施設調査票_補助事業_ヘッダ部分
from P0000Common.models import HOJO                    ### 7080: アップロードデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_HEADER            ### 7090: アップロードデータ_公益事業等調査票_ヘッダ部分
from P0000Common.models import KOEKI                   ### 7100: アップロードデータ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_SUMMARY           ### 8000: 集計データ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_SUMMARY          ### 8010: 集計データ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_SUMMARY            ### 8020: 集計データ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_SUMMARY           ### 8030: 集計データ_公益事業等調査票_一覧表部分

from P0000Common.models import IPPAN_VIEW              ### 9000: ビューデータ_一般資産調査員調査票_一覧表部分
from P0000Common.models import CHITAN_VIEW             ### 9010: ビューデータ_公共土木施設調査票_地方単独事業_一覧表部分
from P0000Common.models import HOJO_VIEW               ### 9020: ビューデータ_公共土木施設調査票_補助事業_一覧表部分
from P0000Common.models import KOEKI_VIEW              ### 9030: ビューデータ_公益事業等調査票_一覧表部分

from P0000Common.models import ACTION                  ### 10000: マスタデータ_アクション
from P0000Common.models import STATUS                  ### 10010: マスタデータ_状態
from P0000Common.models import IPPAN_TRIGGER           ### 10020: キューデータ_一般資産調査員調査票_トリガーメッセージ
from P0000Common.models import CHITAN_TRIGGER          ### 10030: キューデータ_公共土木施設調査票_地方単独事業_トリガーメッセージ
from P0000Common.models import HOJO_TRIGGER            ### 10040: キューデータ_公共土木施設調査票_補助事業_トリガーメッセージ
from P0000Common.models import KOEKI_TRIGGER           ### 10050: キューデータ_公益事業等調査票_トリガーメッセージ

from P0000Common.models import KEN_BUCKET              ### 99999: バケットデータ_都道府県
from P0000Common.models import CITY_BUCKET             ### 99999: バケットデータ_市区町村

from P0000Common.common import get_alert_log
from P0000Common.common import get_info_log
from P0000Common.common import get_warn_log
from P0000Common.common import print_log
from P0000Common.common import reset_log

from P0000Common.common import split_name_code
from P0000Common.common import isdate
from P0000Common.common import convert_empty_to_none
### from P0000Common.common import add_comment ### DELETE 2023/02/24

from P0000Common.services import get_ippan_chosa_csv_excel     ### ADD 2023/03/09
from P0000Common.services import get_ippan_summary_csv_excel   ### ADD 2023/03/09
from P0000Common.services import get_area_kml_pdf              ### ADD 2023/03/09
from P0000Common.services import get_chitan_chosa_csv_excel    ### ADD 2023/03/09
from P0000Common.services import get_chitan_summary_csv_excel  ### ADD 2023/03/09
from P0000Common.services import get_hojo_chosa_csv_excel      ### ADD 2023/03/09
from P0000Common.services import get_koeki_chosa_csv_excel     ### ADD 2023/03/09
from P0000Common.services import get_koeki_summary_csv_excel   ### ADD 2023/03/09

from P0000Common.services import create_ippan_chosa_excel      ### ADD 2023/03/09
from P0000Common.services import create_chitan_chosa_excel     ### ADD 2023/03/09
from P0000Common.services import create_hojo_chosa_excel       ### ADD 2023/03/09
from P0000Common.services import create_koeki_chosa_excel      ### ADD 2023/03/09

from . import constants

from .forms import UploadIppanForm
from .forms import UploadAreaForm

from MessageQueue.views import get_message 
from MessageQueue.views import publish_message 
from MessageQueue.views import publish_consume_message 
from MessageQueue.views import consume_message 
from MessageQueue.views import delete_message 

### USER_PROXYテーブル.ROLE_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_ROLE_CITY = 'ROLE_CITY'
_ROLE_KEN = 'ROLE_KEN'
_ROLE_MANAGE = 'ROLE_MANAGE'

### ACTIONテーブル.ACTION_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_IPP_ACT_01 = 'IPP_ACT_01'
_IPP_ACT_02 = 'IPP_ACT_02'
_IPP_ACT_03 = 'IPP_ACT_03'
_IPP_ACT_04 = 'IPP_ACT_04'
_IPP_ACT_05 = 'IPP_ACT_05'
_IPP_ACT_06 = 'IPP_ACT_06'
_IPP_ACT_07 = 'IPP_ACT_07'

_CHI_ACT_01 = 'CHI_ACT_01'
_CHI_ACT_02 = 'CHI_ACT_02'
_CHI_ACT_03 = 'CHI_ACT_03'
_CHI_ACT_04 = 'CHI_ACT_04'
_CHI_ACT_05 = 'CHI_ACT_05'
_CHI_ACT_06 = 'CHI_ACT_06'
_CHI_ACT_07 = 'CHI_ACT_07'

_HOJ_ACT_01 = 'HOJ_ACT_01'
_HOJ_ACT_02 = 'HOJ_ACT_02'
_HOJ_ACT_03 = 'HOJ_ACT_03'
_HOJ_ACT_04 = 'HOJ_ACT_04'
_HOJ_ACT_05 = 'HOJ_ACT_05'
_HOJ_ACT_06 = 'HOJ_ACT_06'
_HOJ_ACT_07 = 'HOJ_ACT_07'

_KOE_ACT_01 = 'KOE_ACT_01'
_KOE_ACT_02 = 'KOE_ACT_02'
_KOE_ACT_03 = 'KOE_ACT_03'
_KOE_ACT_04 = 'KOE_ACT_04'
_KOE_ACT_05 = 'KOE_ACT_05'
_KOE_ACT_06 = 'KOE_ACT_06'
_KOE_ACT_07 = 'KOE_ACT_07'

_ARE_ACT_01 = 'ARE_ACT_01'
_ARE_ACT_02 = 'ARE_ACT_02'
_ARE_ACT_03 = 'ARE_ACT_03'
_ARE_ACT_04 = 'ARE_ACT_04'
_ARE_ACT_05 = 'ARE_ACT_05'
_ARE_ACT_06 = 'ARE_ACT_06'
_ARE_ACT_07 = 'ARE_ACT_07'

### STATUSテーブル.STATUS_CODEカラムの値 ※つまり、値を変えると広域に処理に影響する。
_WAITING = 'WAITING'
_RUNNING = 'RUNNING'
_SUCCESS = 'SUCCESS'
_FAILURE = 'FAILURE'
_CANCEL = 'CANCEL'

### 局所定数 ※DELETE関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP = 'IPP'
_ARE = 'ARE'
_CHI = 'CHI'
_HOJ = 'HOJ'
_KOE = 'KOE'

### 局所定数 ※DOWNLOAD関数分岐用 ※つまり、値を変えても広域な処理に影響しない。
_IPP_CHO_EXC = 'IPP_CHO_EXC'
_IPP_CHO_CSV = 'IPP_CHO_CSV'
_IPP_SUM_EXC = 'IPP_SUM_EXC'
_IPP_SUM_CSV = 'IPP_SUM_CSV'
_ARE_PDF = 'ARE_PDF'
_ARE_KML = 'ARE_KML'

###############################################################################
### 関数名：add_comment(ws, ws_result, row, column, fill, message_id, message)
### ※調査票の種類に応じてエラーメッセージが異なるため、共通化せずに、個々のviews.pyに記述する。
###############################################################################
def add_comment(ws, ws_result, row, column, fill, message_id, message):
    ws.cell(row=row, column=column).fill = fill
    ws_result.cell(row=row, column=column).fill = fill
    
    msg_str = message[message_id][3] + message[message_id][4]

    if ws.cell(row=row, column=column).comment is None:
        ws.cell(row=row, column=column).comment = Comment(msg_str, '')
    else:
        ws.cell(row=row, column=column).comment = Comment(str(ws.cell(row=row, column=column).comment.text) + msg_str, '')
        
    if ws_result.cell(row=row, column=column).comment is None:
        ws_result.cell(row=row, column=column).comment = Comment(msg_str, '')
    else:
        ws_result.cell(row=row, column=column).comment = Comment(str(ws_result.cell(row=row, column=column).comment.text) + msg_str, '')
        
    return True

###############################################################################
### /P0110City/ => /P0110City/bucket/ リダイレクト用【済】
### 関数名：index_view(request)
### urlpattern：path('', views.index_view, name='index_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def index_view(request):
    return redirect('bucket/')

###############################################################################
### 市区町村用バケット【済】
### 関数名：bucket_view(request)
### urlpattern：path('bucket/', views.bucket_view, name='bucket_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def bucket_view(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0110City.bucket_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0110City.bucket_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0110City.bucket_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0110City.bucket_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.bucket_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_CITY
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.bucket_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0110City.bucket_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/bucket/bucket.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))
        
        if user_proxy_list[0].city_code == False:
            print_log('[WARN] P0110City.bucket_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/bucket/bucket.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.bucket_view()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'CITY_CODE': user_proxy_list[0].city_code 
        })
        city_bucket_list = CITY_BUCKET.objects.raw("""
            SELECT 
                CITY_CODE, 
                CITY_NAME, 
                KEN_CODE, 
                USAGE, 
                FILES 
            FROM CITY_BUCKET 
            WHERE 
                CITY_CODE=%(CITY_CODE)s""", params)
        
        print_log('{}'.format(city_bucket_list), 'DEBUG')
        print_log('{}'.format(len(city_bucket_list)), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0]), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.bucket_view()関数 STEP 5/6.', 'DEBUG')
        if city_bucket_list == False:
            print_log('[WARN] P0110City.bucket_view()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/bucket/bucket.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return HttpResponse(template.render(context, request))

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.bucket_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0110City.bucket_view()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0110City/bucket/bucket.html')
        context = {
            'city_bucket_list': city_bucket_list, 
        }
        return HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0110City.bucket_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.bucket_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.bucket_view()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0110City/bucket/bucket.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return HttpResponse(template.render(context, request))

###############################################################################
### 市区町村用ブラウザ【済】
### 関数名：browser_view(request)
### urlpattern：path('browser/', views.browser_view, name='browser_view')
### (1)GETの場合、ファイル管理画面を表示する。
### (2)POSTの場合、アップロードされた一般資産調査員調査票、水害区域図ファイルをチェックして、正常ケースの場合、DBに登録する。
### ※複数EXCELシート対応版
### ※DELEGATE処理のため、関数からの戻り値のbool_returnを処理しない。
### ※except、異常処理は関数からの戻り値のresponseに含めること。
###############################################################################
@login_required(None, login_url='/P0100Login/')
def browser_view(request):
    if request.method == 'GET':
        bool_return, response = browser_get(request)
        return response
    elif request.method == 'POST':
        if 'upload_ippan_button' in request.POST:
            bool_return, response = browser_post_ippan(request)
            return response
        elif 'upload_area_button' in request.POST:
            bool_return, response = browser_post_area(request)
            return response
        else:
            return redirect('/P0110City/browser/')
    else:
        return redirect('/P0110City/browser/')

###############################################################################
### 市区町村用一般資産調査員調査票右スライドメニュー表示【済】
### 関数名：slide_ippan_header_id_view(request, header_id)
### urlpattern：path('slide/ippan/<slug:header_id>/', views.slide_ippan_header_id_view, name='slide_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def slide_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0110City.slide_ippan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_CITY
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0110City.slide_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].city_code == False:
            print_log('[WARN] P0110City.slide_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'CITY_CODE': user_proxy_list[0].city_code, 
            'IPPAN_HEADER_ID': header_id, 
            'IPP_ACT_01': _IPP_ACT_01,
            'IPP_ACT_02': _IPP_ACT_02,
            'IPP_ACT_03': _IPP_ACT_03,
            'IPP_ACT_04': _IPP_ACT_04,
            'IPP_ACT_05': _IPP_ACT_05,
            'IPP_ACT_06': _IPP_ACT_06,
            'IPP_ACT_07': _IPP_ACT_07,
        })
        ippan_header_list = IPPAN_HEADER.objects.raw("""
            SELECT 
                IPPAN_HEADER_ID, 
                IPPAN_HEADER_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM IPPAN_HEADER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                CITY_CODE=%(CITY_CODE)s""", params)
        
        print_log('{}'.format(ippan_header_list), 'DEBUG')
        print_log('{}'.format(len(ippan_header_list)), 'DEBUG')
        print_log('{}'.format(ippan_header_list[0]), 'DEBUG')
        print_log('{}'.format(ippan_header_list[0].ippan_header_id), 'DEBUG')

        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 4_1/6.', 'DEBUG')
        ippan_trigger_act_01_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                CITY_CODE=%(CITY_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_01)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 4_2/6.', 'DEBUG')
        ippan_trigger_act_02_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                CITY_CODE=%(CITY_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_02)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 4_3/6.', 'DEBUG')
        ippan_trigger_act_03_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                CITY_CODE=%(CITY_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_03)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 4_4/6.', 'DEBUG')
        ippan_trigger_act_04_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                CITY_CODE=%(CITY_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_04)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 4_5/6.', 'DEBUG')
        ippan_trigger_act_05_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                CITY_CODE=%(CITY_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_05)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 4_6/6.', 'DEBUG')
        ippan_trigger_act_06_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                CITY_CODE=%(CITY_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_06)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)

        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 4_7/6.', 'DEBUG')
        ippan_trigger_act_07_list = IPPAN_TRIGGER.objects.raw("""
            SELECT 
                IPPAN_TRIGGER_ID, 
                IPPAN_HEADER_ID, 
                KEN_CODE, 
                CITY_CODE, 
                ACTION_CODE, 
                STATUS_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                TO_CHAR(timezone('JST', published_at::timestamptz), 'yyyy/mm/dd') AS published_at, 
                TO_CHAR(timezone('JST', consumed_at::timestamptz), 'yyyy/mm/dd') AS consumed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd') AS deleted_at 
            FROM IPPAN_TRIGGER 
            WHERE 
                IPPAN_HEADER_ID=%(IPPAN_HEADER_ID)s AND 
                CITY_CODE=%(CITY_CODE)s AND 
                ACTION_CODE=%(IPP_ACT_07)s 
            ORDER BY IPPAN_TRIGGER_ID LIMIT 1""", params)
        
        print_log('{}'.format(ippan_trigger_act_01_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_01_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_01_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_01_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_02_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_02_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_02_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_02_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_03_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_03_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_03_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_03_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_04_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_04_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_04_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_04_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_05_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_05_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_05_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_05_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_06_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_06_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_06_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_06_list[0].ippan_trigger_id), 'DEBUG')

        print_log('{}'.format(ippan_trigger_act_07_list), 'DEBUG')
        print_log('{}'.format(len(ippan_trigger_act_07_list)), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_07_list[0]), 'DEBUG')
        ### print_log('{}'.format(ippan_trigger_act_07_list[0].ippan_trigger_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 5/6.', 'DEBUG')
        if ippan_header_list == False:
            print_log('[WARN] P0110City.slide_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        ### if ippan_trigger_act_01_list == False:
        ###     print_log('[WARN] P0110City.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_02_list == False:
        ###     print_log('[WARN] P0110City.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_03_list == False:
        ###     print_log('[WARN] P0110City.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_04_list == False:
        ###     print_log('[WARN] P0110City.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_05_list == False:
        ###     print_log('[WARN] P0110City.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_06_list == False:
        ###     print_log('[WARN] P0110City.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        ### if ippan_trigger_act_07_list == False:
        ###     print_log('[WARN] P0110City.slide_ippan_header_id()関数が警告終了しました。', 'WARN')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        data = {
            'return_code': ["TRUE"], 
            'ippan_header_id': ippan_header_list[0].ippan_header_id, 
            'ippan_header_name': ippan_header_list[0].ippan_header_name, 
            'ken_code': ippan_header_list[0].ken_code, 
            'city_code': ippan_header_list[0].city_code, 
            'upload_file_path': ippan_header_list[0].upload_file_path, 
            'upload_file_name': ippan_header_list[0].upload_file_name, 
            'upload_file_size': ippan_header_list[0].upload_file_size, 
            'summary_file_path': ippan_header_list[0].summary_file_path, 
            'summary_file_name': ippan_header_list[0].summary_file_name, 
            'summary_file_size': ippan_header_list[0].summary_file_size, 
            'committed_at': ippan_header_list[0].committed_at, 
            'deleted_at': ippan_header_list[0].deleted_at, 
        }
        
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 6_1/6.', 'DEBUG')
        if ippan_trigger_act_01_list:
            data01 = {
                'act_01_status_code': ippan_trigger_act_01_list[0].status_code, 
                'act_01_published_at': ippan_trigger_act_01_list[0].published_at, 
                'act_01_consumed_at': ippan_trigger_act_01_list[0].consumed_at, 
                'act_01_deleted_at': ippan_trigger_act_01_list[0].deleted_at, 
            }
        else:
            data01 = {
                'act_01_status_code': None, 
                'act_01_published_at': None, 
                'act_01_consumed_at': None, 
                'act_01_deleted_at': None, 
            }
            
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 6_2/6.', 'DEBUG')
        if ippan_trigger_act_02_list:
            data02 = {
                'act_02_status_code': ippan_trigger_act_02_list[0].status_code, 
                'act_02_published_at': ippan_trigger_act_02_list[0].published_at, 
                'act_02_consumed_at': ippan_trigger_act_02_list[0].consumed_at, 
                'act_02_deleted_at': ippan_trigger_act_02_list[0].deleted_at, 
            }
        else:
            data02 = {
                'act_02_status_code': None, 
                'act_02_published_at': None, 
                'act_02_consumed_at': None, 
                'act_02_deleted_at': None, 
            }
            
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 6_3/6.', 'DEBUG')
        if ippan_trigger_act_03_list:
            data03 = {
                'act_03_status_code': ippan_trigger_act_03_list[0].status_code, 
                'act_03_published_at': ippan_trigger_act_03_list[0].published_at, 
                'act_03_consumed_at': ippan_trigger_act_03_list[0].consumed_at, 
                'act_03_deleted_at': ippan_trigger_act_03_list[0].deleted_at, 
            }
        else:
            data03 = {
                'act_03_status_code': None, 
                'act_03_published_at': None, 
                'act_03_consumed_at': None, 
                'act_03_deleted_at': None, 
            }
            
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 6_4/6.', 'DEBUG')
        if ippan_trigger_act_04_list:
            data04 = {
                'act_04_status_code': ippan_trigger_act_04_list[0].status_code, 
                'act_04_published_at': ippan_trigger_act_04_list[0].published_at, 
                'act_04_consumed_at': ippan_trigger_act_04_list[0].consumed_at, 
                'act_04_deleted_at': ippan_trigger_act_04_list[0].deleted_at, 
            }
        else:
            data04 = {
                'act_04_status_code': None, 
                'act_04_published_at': None, 
                'act_04_consumed_at': None, 
                'act_04_deleted_at': None, 
            }
            
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 6_5/6.', 'DEBUG')
        if ippan_trigger_act_05_list:
            data05 = {
                'act_05_status_code': ippan_trigger_act_05_list[0].status_code, 
                'act_05_published_at': ippan_trigger_act_05_list[0].published_at, 
                'act_05_consumed_at': ippan_trigger_act_05_list[0].consumed_at, 
                'act_05_deleted_at': ippan_trigger_act_05_list[0].deleted_at, 
            }
        else:
            data05 = {
                'act_05_status_code': None, 
                'act_05_published_at': None, 
                'act_05_consumed_at': None, 
                'act_05_deleted_at': None, 
            }
            
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 6_6/6.', 'DEBUG')
        if ippan_trigger_act_06_list:
            data06 = {
                'act_06_status_code': ippan_trigger_act_06_list[0].status_code, 
                'act_06_published_at': ippan_trigger_act_06_list[0].published_at, 
                'act_06_consumed_at': ippan_trigger_act_06_list[0].consumed_at, 
                'act_06_deleted_at': ippan_trigger_act_06_list[0].deleted_at, 
            }
        else:
            data06 = {
                'act_06_status_code': None, 
                'act_06_published_at': None, 
                'act_06_consumed_at': None, 
                'act_06_deleted_at': None, 
            }
            
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 6_7/6.', 'DEBUG')
        if ippan_trigger_act_07_list:
            data07 = {
                'act_07_status_code': ippan_trigger_act_07_list[0].status_code, 
                'act_07_published_at': ippan_trigger_act_07_list[0].published_at, 
                'act_07_consumed_at': ippan_trigger_act_07_list[0].consumed_at, 
                'act_07_deleted_at': ippan_trigger_act_07_list[0].deleted_at, 
            }
        else:
            data07 = {
                'act_07_status_code': None, 
                'act_07_published_at': None, 
                'act_07_consumed_at': None, 
                'act_07_deleted_at': None, 
            }
            
        print_log('[DEBUG] P0110City.slide_ippan_header_id_view()関数 STEP 6_8/6.', 'DEBUG')
        data.update(data01)
        data.update(data02)
        data.update(data03)
        data.update(data04)
        data.update(data05)
        data.update(data06)
        data.update(data07)
        
        print_log('[INFO] P0110City.slide_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0110City.slide_ippan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.slide_ippan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.slide_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 市区町村用水害区域図右スライドメニュー表示【済】
### 関数名：slide_area_header_id_view(request, header_id)
### urlpattern：path('slide_area/header/<slug:header_id>/', views.slide_area_header_id_view, name='slide_area_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def slide_area_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0110City.slide_area_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0110City.slide_area_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0110City.slide_area_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0110City.slide_area_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0110City.slide_area_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.slide_area_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_CITY
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.slide_area_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0110City.slide_area_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].city_code == False:
            print_log('[WARN] P0110City.slide_area_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.slide_area_header_id_view()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'AREA_ID': str(header_id), 
            'CITY_CODE': user_proxy_list[0].city_code, 
        })
        area_list = AREA.objects.raw("""
            SELECT 
                AREA_ID, 
                AREA_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM AREA 
            WHERE 
                AREA_ID=%(AREA_ID)s AND 
                CITY_CODE=%(CITY_CODE)s""", params)
        
        print_log('{}'.format(area_list), 'DEBUG')
        print_log('{}'.format(len(area_list)), 'DEBUG')
        print_log('{}'.format(area_list[0]), 'DEBUG')
        print_log('{}'.format(area_list[0].area_id), 'DEBUG')

        ### bool_return, area_trigger_list = area_trigger_objects_raw(params)
        ### area_trigger_list = AREA_TRIGGER.objects.raw("""
        ###     """, params)
        ### if bool_return == False:
        ###     raise Exception
        ### print_log('{}'.format(area_trigger_list), 'DEBUG')
        ### print_log('{}'.format(len(area_trigger_list)), 'DEBUG')
        ### print_log('{}'.format(area_trigger_list[0]), 'DEBUG')
        ### print_log('{}'.format(area_trigger_list[0].area_trigger_id), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.slide_area_header_id_view()関数 STEP 5/6.', 'DEBUG')
        if area_list == False:
            print_log('[WARN] P0110City.slide_area_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        ### if area_trigger_list == False:
        ###     print_log('[WARN] P0110City.json_area_header_id_view()関数が警告終了しました。', 'WARN')
        ###     data = {
        ###         'sample1': [1, 2, 3], 
        ###         'sample2': [3, 6, 9],
        ###     }
        ###     response = JsonResponse(data)
        ###     response['Access-Control-Allow-Origin'] = 'localhost:8000'
        ###     response['Access-Control-Allow-Credentials'] = 'true'
        ###     response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        ###     response['Access-Control-Allow-Methods'] = 'GET'
        ###     return response

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.slide_area_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0110City.slide_area_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
            'area_id': area_list[0].area_id, 
            'area_name': area_list[0].area_name,
            'ken_code': area_list[0].ken_code,
            'city_code': area_list[0].city_code,
            'upload_file_path': area_list[0].upload_file_path, 
            'upload_file_name': area_list[0].upload_file_name, 
            'upload_file_size': area_list[0].upload_file_size, 
            'committed_at': area_list[0].committed_at, 
            'deleted_at': area_list[0].deleted_at, 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0110City.slide_area_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.slide_area_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.slide_area_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 市区町村用一般資産調査員調査票EXCELダウンロード【済】
### 関数名：download_ippan_chosa_excel_header_id_view(request, header_id)
### urlpattern：path('download/ippan/chosa/excel/header/<slug:header_id>/', views.download_ippan_chosa_excel_header_id_view, name='download_ippan_chosa_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_chosa_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _IPP_CHO_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response
    
###############################################################################
### 市区町村用一般資産調査員調査票CSVダウンロード【済】
### 関数名：download_ippan_chosa_csv_header_id_view(request, header_id)
### urlpattern：path('download/ippan/chosa/csv/header/<slug:header_id>/', views.download_ippan_chosa_csv_header_id_view, name='download_ippan_chosa_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_chosa_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _IPP_CHO_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 市区町村用一般資産集計結果EXCELダウンロード【済】
### 関数名：download_ippan_summary_excel_header_id_view(request, header_id)
### urlpattern：path('download/ippan/summary/excel/header/<slug:header_id>/', views.download_ippan_summary_excel_header_id_view, name='download_ippan_summary_excel_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_summary_excel_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _IPP_SUM_EXC)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response
    
###############################################################################
### 市区町村用一般資産集計結果CSVダウンロード【済】
### 関数名：download_ippan_summary_csv_header_id_view(request, header_id)
### urlpattern：path('download/ippan/summary/csv/header/<slug:header_id>/', views.download_ippan_summary_csv_header_id_view, name='download_ippan_summary_csv_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_ippan_summary_csv_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _IPP_SUM_CSV)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response
    
###############################################################################
### 市区町村用水害区域図PDFダウンロード【済】
### 関数名：download_area_pdf_header_id_view(request, header_id)
### urlpattern：path('download/area/pdf/header/<slug:header_id>/', views.download_area_pdf_header_id_view, name='download_area_pdf_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_area_pdf_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _ARE_PDF)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response
    
###############################################################################
### 市区町村用水害区域図KMLダウンロード【済】
### 関数名：download_area_kml_header_id_view(request, header_id)
### urlpattern：path('download/area/kml/header/<slug:header_id>/', views.download_area_kml_header_id_view, name='download_area_kml_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def download_area_kml_header_id_view(request, header_id):
    bool_return, response = download_header_id(request, header_id, _ARE_KML)
    ### if bool_return == False:
    ###     return HttpResponseNotFound("")
    return response

###############################################################################
### 市区町村用一般資産調査員調査票 vs 区域図紐づけ
### 関数名：link_ippan_header_id_area_id_view(request, header_id, area_id)
### urlpattern：path('link/ippan/header/<slug:header_id>/area/<slug:area_id>/', views.link_ippan_header_id_area_id_view, name='link_ippan_header_id_area_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def link_ippan_header_id_area_id_view(request, header_id, area_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0110City.link_ippan_header_id_area_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0110City.link_ippan_header_id_area_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0110City.link_ippan_header_id_area_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0110City.link_ippan_header_id_area_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0110City.link_ippan_header_id_area_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0110City.link_ippan_header_id_area_id_view()関数 area_id={}'.format(area_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.link_ippan_header_id_area_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_CITY
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.link_ippan_header_id_area_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0110City.link_ippan_header_id_area_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].city_code == False:
            print_log('[WARN] P0110City.link_ippan_header_id_area_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.link_ippan_header_id_area_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.link_ippan_header_id_area_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0110City.link_ippan_header_id_area_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0110City.link_ippan_header_id_area_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.link_ippan_header_id_area_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.link_ippan_header_id_area_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 市区町村用一般資産調査員調査票 vs 異常気象コード紐づけ
### 関数名：link_ippan_header_id_weather_id_view(request, header_id, weather_id)
### urlpattern：path('link/ippan/header/<slug:header_id>/weather/<slug:weather_id>/', views.link_ippan_header_id_weather_id_view, name='link_ippan_header_id_weather_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def link_ippan_header_id_weather_id_view(request, header_id, weather_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0110City.link_ippan_header_id_weather_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0110City.link_ippan_header_id_weather_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0110City.link_ippan_header_id_weather_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0110City.link_ippan_header_id_weather_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0110City.link_ippan_header_id_weather_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        print_log('[DEBUG] P0110City.link_ippan_header_id_weather_id_view()関数 area_id={}'.format(weather_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.link_ippan_header_id_weather_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_CITY
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.link_ippan_header_id_weather_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0110City.link_ippan_header_id_weather_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].city_code == False:
            print_log('[WARN] P0110City.link_ippan_header_id_weather_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.link_ippan_header_id_weather_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.link_ippan_header_id_weather_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0110City.link_ippan_header_id_weather_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0110City.link_ippan_header_id_weather_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.link_ippan_header_id_weather_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.link_ippan_header_id_weather_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 市区町村用一般資産調査員調査票再チェック
### 関数名：check_ippan_header_id(request, header_id)
### urlpattern：path('check/ippan/header/<slug:header_id>/', views.check_ippan_header_id_view, name='check_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def check_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0110City.check_ippan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0110City.check_ippan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0110City.check_ippan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0110City.check_ippan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0110City.check_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.check_ippan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_CITY
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.check_ippan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0110City.check_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].city_code == False:
            print_log('[WARN] P0110City.check_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.check_ippan_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.check_ippan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0110City.check_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0110City.check_ippan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.check_ippan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.check_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 市区町村用一般資産調査員調査票再集計
### 関数名：summarize_ippan_header_id(request, header_id)
### urlpattern：path('summarize/ippan/header/<slug:header_id>/', views.summarize_ippan_header_id_view, name='summarize_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def summarize_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0110City.summarize_ippan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0110City.summarize_ippan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0110City.summarize_ippan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0110City.summarize_ippan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0110City.summarize_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.summarize_ippan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_CITY
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.summarize_ippan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0110City.summarize_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].city_code == False:
            print_log('[WARN] P0110City.summarize_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.summarize_ippan_header_id_view()関数 STEP 4/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.summarize_ippan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0110City.summarize_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

    except:
        print_log('[ERROR] P0110City.summarize_ippan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.summarize_ippan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.summarize_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 市区町村用一般資産調査員調査票ファイル削除
### 関数名：delete_ippan_header_id_view(request, header_id)
### urlpattern：path('delete/ippan/header/<slug:header_id>/', views.delete_ippan_header_id_view, name='delete_ippan_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def delete_ippan_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0110City.delete_ippan_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_CITY
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0110City.delete_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].city_code == False:
            print_log('[WARN] P0110City.delete_ippan_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 STEP 4/6.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")
            params = dict({
                'CITY_CODE': user_proxy_list[0].city_code, 
                'IPPAN_HEADER_ID': header_id, 
            })
            func_params = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': None, 
                'city_code': user_proxy_list[0].city_code, 
                'action_code': _IPP_ACT_01
            })

            connection_cursor.execute("""
                UPDATE IPPAN_HEADER SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE IPPAN_HEADER_ID IN (
                SELECT 
                    IPPAN_HEADER_ID 
                FROM IPPAN_HEADER 
                WHERE 
                    CITY_CODE=%(CITY_CODE)s AND 
                    DELETED_AT IS NULL)""", params)

            connection_cursor.execute("""
                UPDATE IPPAN SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE IPPAN_ID IN (
                SELECT 
                    IPPAN_ID 
                FROM IPPAN_VIEW 
                WHERE 
                    CITY_CODE=%(CITY_CODE)s AND 
                    DELETED_AT IS NULL)""", params)

            connection_cursor.execute("""
                UPDATE IPPAN_SUMMARY SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE IPPAN_ID IN (
                SELECT 
                    IPPAN_ID 
                FROM IPPAN_SUMMARY_VIEW 
                WHERE 
                    CITY_CODE=%(CITY_CODE)s AND 
                    DELETED_AT IS NULL)""", params)

            bool_return = delete_message(metadata=func_params)
            if bool_return == False:
                print_log('[ERROR] delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            connection_cursor.execute("""COMMIT""")
            
        except:
            connection_cursor.execute("""ROLLBACK""")
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 STEP 5/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.delete_ippan_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0110City.delete_ippan_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0110City.delete_ippan_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.delete_ippan_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.delete_ippan_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 市区町村用水害区域図ファイル削除
### 関数名：delete_area_header_id_view(request, header_id)
### urlpattern：path('delete/area/header/<slug:header_id>/', views.delete_area_header_id_view, name='delete_area_header_id_view')
###############################################################################
@login_required(None, login_url='/P0100Login/')
def delete_area_header_id_view(request, header_id):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0110City.delete_area_header_id_view()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0110City.delete_area_header_id_view()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0110City.delete_area_header_id_view()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0110City.delete_area_header_id_view()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0110City.delete_area_header_id_view()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.delete_area_header_id_view()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_CITY
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.delete_area_header_id_view()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0110City.delete_area_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response
        
        if user_proxy_list[0].city_code == False:
            print_log('[WARN] P0110City.delete_area_header_id_view()関数が警告終了しました。', 'WARN')
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.delete_area_header_id_view()関数 STEP 4/6.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            params = dict({
                'CITY_CODE': user_proxy_list[0].city_code, 
                'AREA_ID': header_id, 
            })

            connection_cursor.execute("""
                UPDATE AREA SET 
                    DELETED_AT=CURRENT_TIMESTAMP 
                WHERE 
                    AREA_ID=%(AREA_ID)s AND 
                    DELETED_AT IS NULL""", params)

            connection_cursor.execute("""COMMIT""")
                
        except:
            connection_cursor.execute("""ROLLBACK""")
            data = {
                'return_code': ["FALSE"], 
            }
            response = JsonResponse(data)
            response['Access-Control-Allow-Origin'] = 'localhost:8000'
            response['Access-Control-Allow-Credentials'] = 'true'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
            response['Access-Control-Allow-Methods'] = 'GET'
            return response

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.delete_area_header_id_view()関数 STEP 5/6.', 'DEBUG')

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.delete_area_header_id_view()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0110City.delete_area_header_id_view()関数が正常終了しました。', 'INFO')
        data = {
            'return_code': ["TRUE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response
    
    except:
        print_log('[ERROR] P0110City.delete_area_header_id_view()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.delete_area_header_id_view()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.delete_area_header_id_view()関数が異常終了しました。', 'ERROR')
        data = {
            'return_code': ["FALSE"], 
        }
        response = JsonResponse(data)
        response['Access-Control-Allow-Origin'] = 'localhost:8000'
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Accept, X-CSRFToken'
        response['Access-Control-Allow-Methods'] = 'GET'
        return response

###############################################################################
### 市区町村用ブラウザ
###############################################################################
def browser_get(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0110City.browser_get()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0110City.browser_get()関数 STEP 1/6.', 'DEBUG')
        print_log('[DEBUG] P0110City.browser_get()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_get()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        ### 下記の処理でアクセス制御を行う。
        ### ※コンテンツにアクセス可能なユーザは市区町村のみとする。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_get()関数 STEP 2/6.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_CITY
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_get()関数 STEP 3/6.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0110City.browser_get()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
        
        if user_proxy_list[0].city_code == False:
            print_log('[WARN] P0110City.browser_get()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_get()関数 STEP 4/6.', 'DEBUG')
        params = dict({
            'CITY_CODE': user_proxy_list[0].city_code 
        })
        ### HTMLタイトル部分表示用
        city_bucket_list = CITY_BUCKET.objects.raw("""
            SELECT 
                CITY_CODE, 
                CITY_NAME, 
                KEN_CODE, 
                USAGE, 
                FILES 
            FROM CITY_BUCKET 
            WHERE 
                CITY_CODE=%(CITY_CODE)s""", params)
        
        print_log('{}'.format(city_bucket_list), 'DEBUG')
        print_log('{}'.format(len(city_bucket_list)), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0]), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(city_bucket_list[0].city_code), 'DEBUG')

        ### HTML一覧部分表示用
        ippan_header_list = IPPAN_HEADER.objects.raw("""
            SELECT 
                IPPAN_HEADER_ID, 
                IPPAN_HEADER_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                SUMMARY_FILE_PATH, 
                SUMMARY_FILE_NAME, 
                SUMMARY_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM IPPAN_HEADER 
            WHERE 
                CITY_CODE=%(CITY_CODE)s AND 
                DELETED_AT IS NULL 
            ORDER BY COMMITTED_AT""", params)
        
        print_log('{}'.format(ippan_header_list), 'DEBUG')
        print_log('{}'.format(len(ippan_header_list)), 'DEBUG')

        ### HTML一覧部分表示用
        area_list = AREA.objects.raw("""
            SELECT 
                AREA_ID, 
                AREA_NAME, 
                KEN_CODE, 
                CITY_CODE, 
                UPLOAD_FILE_PATH, 
                UPLOAD_FILE_NAME, 
                UPLOAD_FILE_SIZE, 
                TO_CHAR(timezone('JST', committed_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS committed_at, 
                TO_CHAR(timezone('JST', deleted_at::timestamptz), 'yyyy/mm/dd HH24:MI') AS deleted_at 
            FROM AREA 
            WHERE 
                CITY_CODE=%(CITY_CODE)s AND 
                DELETED_AT IS NULL 
            ORDER BY COMMITTED_AT""", params)
        
        print_log('{}'.format(area_list), 'DEBUG')
        print_log('{}'.format(len(area_list)), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0040)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_get()関数 STEP 5/6.', 'DEBUG')
        if city_bucket_list == False:
            print_log('[WARN] P0110City.browser_get()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))

        ### 一般資産調査員調査票ファイルの0件は正常であるため、チェックしない。
        ### 水害区域図ファイルの0件は正常であるため、チェックしない。

        #######################################################################
        ### レスポンスセット処理(0050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_get()関数 STEP 6/6.', 'DEBUG')
        print_log('[INFO] P0110City.browser_get()関数が正常終了しました。', 'INFO')
        template = loader.get_template('P0110City/browser/browser.html')
        context = {
            ### 'role_code': _ROLE_CITY,
            'city_bucket_list': city_bucket_list, 
            'area_list': area_list, 
            'ippan_header_list': ippan_header_list, 
        }
        return True, HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0110City.browser_get()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.browser_get()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.browser_get()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0110City/browser/browser.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))

###############################################################################
### 市区町村用ブラウザ
###############################################################################
def browser_post_ippan(request):
    
    ###########################################################################
    ### 関数内関数：EXCELセルデータ必須チェック処理
    ###########################################################################
    def check_require():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal require_warn_list
            nonlocal require_info_list
            nonlocal require_warn_grid
            nonlocal require_info_grid
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ必須チェック処理（0000）
            ### (1)セル[7:2]からセル[7:9]について、必須項目に値がセットされていることをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_require()関数 STEP 1/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                ### セル[7:2]: 都道府県に値がセットされていることをチェックする。
                if ws[i].cell(row=7, column=2).value is None:
                    add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=2, fill=fill, message_id=0, message=constants.IPP_REQ_MSG)
                    require_warn_list.append([ws[i].title, 7, 2, constants.IPP_REQ_MSG[0][0], constants.IPP_REQ_MSG[0][1], constants.IPP_REQ_MSG[0][2], constants.IPP_REQ_MSG[0][3], constants.IPP_REQ_MSG[0][4]])
                else:
                    require_info_list.append([ws[i].title, 7, 2, 0])
                    
                ### セル[7:3]: 市区町村に値がセットされていることをチェックする。
                if ws[i].cell(row=7, column=3).value is None:
                    add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=3, fill=fill, message_id=1, message=constants.IPP_REQ_MSG)
                    require_warn_list.append([ws[i].title, 7, 3, constants.IPP_REQ_MSG[1][0], constants.IPP_REQ_MSG[1][1], constants.IPP_REQ_MSG[1][2], constants.IPP_REQ_MSG[1][3], constants.IPP_REQ_MSG[1][4]])
                else:
                    require_info_list.append([ws[i].title, 7, 3, 1])
                
                ### セル[7:4]: 水害発生月日に値がセットされていることをチェックする。
                if ws[i].cell(row=7, column=4).value is None:
                    add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=4, fill=fill, message_id=2, message=constants.IPP_REQ_MSG)
                    require_warn_list.append([ws[i].title, 7, 4, constants.IPP_REQ_MSG[2][0], constants.IPP_REQ_MSG[2][1], constants.IPP_REQ_MSG[2][2], constants.IPP_REQ_MSG[2][3], constants.IPP_REQ_MSG[2][4]])
                else:
                    require_info_list.append([ws[i].title, 7, 4, 2])
        
                ### セル[7:5]: 水害終了月日に値がセットされていることをチェックする。
                ### セル[7:6]: 水害原因1に値がセットされていることをチェックする。
                if ws[i].cell(row=7, column=6).value is None:
                    add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=4, message=constants.IPP_REQ_MSG)
                    require_warn_list.append([ws[i].title, 7, 6, constants.IPP_REQ_MSG[4][0], constants.IPP_REQ_MSG[4][1], constants.IPP_REQ_MSG[4][2], constants.IPP_REQ_MSG[4][3], constants.IPP_REQ_MSG[4][4]])
                else:
                    require_info_list.append([ws[i].title, 7, 6, 4])
        
                ### セル[7:7]: 水害原因2に値がセットされていることをチェックする。
                ### セル[7:8]: 水害原因3に値がセットされていることをチェックする。
                ### セル[7:9]: 水害区域番号に値がセットされていることをチェックする。
                ### if ws[i].cell(row=7, column=9).value is None:
                ###     add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=9, fill=fill, message_id=7, message=constants.IPP_REQ_MSG)
                ###     require_warn_list.append([ws[i].title, 7, 9, constants.IPP_REQ_MSG[7][0], constants.IPP_REQ_MSG[7][1], constants.IPP_REQ_MSG[7][2], constants.IPP_REQ_MSG[7][3], constants.IPP_REQ_MSG[7][4]])
                ### else:
                ###     require_info_list.append([ws[i].title, 7, 9, 7])
        
            ###################################################################
            ### 関数内関数：EXCELセルデータ必須チェック処理（0010）
            ### (1)セル[10:2]からセル[10:6]について、必須項目に値がセットされていることをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_require()関数 STEP 2/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                ### セル[10:2]: 水系・沿岸名に値がセットされていることをチェックする。
                if ws[i].cell(row=10, column=2).value is None:
                    add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=2, fill=fill, message_id=8, message=constants.IPP_REQ_MSG)
                    require_warn_list.append([ws[i].title, 10, 2, constants.IPP_REQ_MSG[8][0], constants.IPP_REQ_MSG[8][1], constants.IPP_REQ_MSG[8][2], constants.IPP_REQ_MSG[8][3], constants.IPP_REQ_MSG[8][4]])
                else:
                    require_info_list.append([ws[i].title, 10, 2, 8])
                    
                ### セル[10:3]: 水系種別に値がセットされていることをチェックする。
                if ws[i].cell(row=10, column=3).value is None:
                    add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=9, message=constants.IPP_REQ_MSG)
                    require_warn_list.append([ws[i].title, 10, 3, constants.IPP_REQ_MSG[9][0], constants.IPP_REQ_MSG[9][1], constants.IPP_REQ_MSG[9][2], constants.IPP_REQ_MSG[9][3], constants.IPP_REQ_MSG[9][4]])
                else:
                    require_info_list.append([ws[i].title, 10, 3, 9])
                    
                ### セル[10:4]: 河川・海岸名に値がセットされていることをチェックする。
                if ws[i].cell(row=10, column=4).value is None:
                    add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=4, fill=fill, message_id=10, message=constants.IPP_REQ_MSG)
                    require_warn_list.append([ws[i].title, 10, 4, constants.IPP_REQ_MSG[10][0], constants.IPP_REQ_MSG[10][1], constants.IPP_REQ_MSG[10][2], constants.IPP_REQ_MSG[10][3], constants.IPP_REQ_MSG[10][4]])
                else:
                    require_info_list.append([ws[i].title, 10, 4, 10])
                    
                ### セル[10:5]: 河川種別に値がセットされていることをチェックする。
                if ws[i].cell(row=10, column=5).value is None:
                    add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=11, message=constants.IPP_REQ_MSG)
                    require_warn_list.append([ws[i].title, 10, 5, constants.IPP_REQ_MSG[11][0], constants.IPP_REQ_MSG[11][1], constants.IPP_REQ_MSG[11][2], constants.IPP_REQ_MSG[11][3], constants.IPP_REQ_MSG[11][4]])
                else:
                    require_info_list.append([ws[i].title, 10, 5, 11])
                    
                ### セル[10:6]: 地盤勾配区分に値がセットされていることをチェックする。
                if ws[i].cell(row=10, column=6).value is None:
                    add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=6, fill=fill, message_id=12, message=constants.IPP_REQ_MSG)
                    require_warn_list.append([ws[i].title, 10, 6, constants.IPP_REQ_MSG[12][0], constants.IPP_REQ_MSG[12][1], constants.IPP_REQ_MSG[12][2], constants.IPP_REQ_MSG[12][3], constants.IPP_REQ_MSG[12][4]])
                else:
                    require_info_list.append([ws[i].title, 10, 6, 12])
        
            ###################################################################
            ### 関数内関数：EXCELセルデータ必須チェック処理（0020）
            ### (1)セル[14:2]からセル[14:10]について、必須項目に値がセットされていることをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_require()関数 STEP 3/4.', 'DEBUG')
            ### for i, _ in enumerate(ws):
                ### セル[14:2]: 水害区域面積の宅地に値がセットされていることをチェックする。
                ### セル[14:3]: 水害区域面積の農地に値がセットされていることをチェックする。
                ### セル[14:4]: 水害区域面積の地下に値がセットされていることをチェックする。
                ### セル[14:5]: 
                ### セル[14:6]: 工種に値がセットされていることをチェックする。
                ### セル[14:7]: 
                ### セル[14:8]: 農作物被害額に値がセットされていることをチェックする。
                ### セル[14:9]: 
                ### セル[14:10]: 異常気象コードに値がセットされていることをチェックする。
        
            ###################################################################
            ### 関数内関数：EXCELセルデータ必須チェック処理（0030）
            ### (1)セル[20:2]からセル[20:27]について、必須項目に値がセットされていることをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### ※max_rowの20は入力部分の開始EXCEL行番号である。
            ### ※max_rowの20は町丁名・大字名、名称等のキャプション部分の1つ下のEXCEL行番号である。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_require()関数 STEP 4/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                if max_row[i] >= 20:
                    for j in range(20, max_row[i]+1):
                        ### セル[20:2]: 町丁名・大字名に値がセットされていることをチェックする。
                        if ws[i].cell(row=j, column=2).value is None:
                            ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=2, fill=fill, message_id=50)
                            ### require_warn_grid.append([ws[i].title, j, 2, constants.IPP_REQ_MSG[50][0], constants.IPP_REQ_MSG[50][1], constants.IPP_REQ_MSG[50][2], constants.IPP_REQ_MSG[50][3], constants.IPP_REQ_MSG[50][4]])
                            add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=2, fill=fill, message_id=19, message=constants.IPP_REQ_MSG)
                            require_warn_grid.append([ws[i].title, j, 2, constants.IPP_REQ_MSG[19][0], constants.IPP_REQ_MSG[19][1], constants.IPP_REQ_MSG[19][2], constants.IPP_REQ_MSG[19][3], constants.IPP_REQ_MSG[19][4]])
                        else:
                            ### require_info_grid.append([ws[i].title, j, 2, 50])
                            require_info_grid.append([ws[i].title, j, 2, 19])
                            
                        ### セル[20:3]: 名称に値がセットされていることをチェックする。
                        if ws[i].cell(row=j, column=3).value is None:
                            ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=3, fill=fill, message_id=51)
                            ### require_warn_grid.append([ws[i].title, j, 3, constants.IPP_REQ_MSG[51][0], constants.IPP_REQ_MSG[51][1], constants.IPP_REQ_MSG[51][2], constants.IPP_REQ_MSG[51][3], constants.IPP_REQ_MSG[51][4]])
                            add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=3, fill=fill, message_id=20, message=constants.IPP_REQ_MSG)
                            require_warn_grid.append([ws[i].title, j, 3, constants.IPP_REQ_MSG[20][0], constants.IPP_REQ_MSG[20][1], constants.IPP_REQ_MSG[20][2], constants.IPP_REQ_MSG[20][3], constants.IPP_REQ_MSG[20][4]])
                        else:
                            ### require_info_grid.append([ws[i].title, j, 3, 51])
                            require_info_grid.append([ws[i].title, j, 3, 20])
                            
                        ### セル[20:4]: 地上・地下被害の区分に値がセットされていることをチェックする。
                        if ws[i].cell(row=j, column=4).value is None:
                            ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=52)
                            ### require_warn_grid.append([ws[i].title, j, 4, constants.IPP_REQ_MSG[52][0], constants.IPP_REQ_MSG[52][1], constants.IPP_REQ_MSG[52][2], constants.IPP_REQ_MSG[52][3], constants.IPP_REQ_MSG[52][4]])
                            add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=21, message=constants.IPP_REQ_MSG)
                            require_warn_grid.append([ws[i].title, j, 4, constants.IPP_REQ_MSG[21][0], constants.IPP_REQ_MSG[21][1], constants.IPP_REQ_MSG[21][2], constants.IPP_REQ_MSG[21][3], constants.IPP_REQ_MSG[21][4]])
                        else:
                            ### require_info_grid.append([ws[i].title, j, 4, 52])
                            require_info_grid.append([ws[i].title, j, 4, 21])
                            
                        ### セル[20:5]: 浸水土砂被害の区分に値がセットされていることをチェックする。
                        if ws[i].cell(row=j, column=5).value is None:
                            ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=5, fill=fill, message_id=53)
                            ### require_warn_grid.append([ws[i].title, j, 5, constants.IPP_REQ_MSG[53][0], constants.IPP_REQ_MSG[53][1], constants.IPP_REQ_MSG[53][2], constants.IPP_REQ_MSG[53][3], constants.IPP_REQ_MSG[53][4]])
                            add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=5, fill=fill, message_id=22, message=constants.IPP_REQ_MSG)
                            require_warn_grid.append([ws[i].title, j, 5, constants.IPP_REQ_MSG[22][0], constants.IPP_REQ_MSG[22][1], constants.IPP_REQ_MSG[22][2], constants.IPP_REQ_MSG[22][3], constants.IPP_REQ_MSG[22][4]])
                        else:
                            ### require_info_grid.append([ws[i].title, j, 5, 53])
                            require_info_grid.append([ws[i].title, j, 5, 22])
                            
                        ### セル[20:6]: 被害建物棟数, 床下浸水に値がセットされていることをチェックする。
                        ### セル[20:7]: 被害建物棟数, 1cm〜49cmに値がセットされていることをチェックする。
                        ### セル[20:8]: 被害建物棟数, 50cm〜99cmに値がセットされていることをチェックする。
                        ### セル[20:9]: 被害建物棟数, 1m以上に値がセットされていることをチェックする。
                        ### セル[20:10]: 被害建物棟数, 半壊に値がセットされていることをチェックする。
                        ### セル[20:11]: 被害建物棟数, 全壊・流失に値がセットされていることをチェックする。
                        ### セル[20:12]: 被害建物の延床面積に値がセットされていることをチェックする。
                        ### セル[20:13]: 被災世帯数に値がセットされていることをチェックする。
                        ### セル[20:14]: 被災事業所数に値がセットされていることをチェックする。
                        ### セル[20:15]: 農家・漁家戸数, 床下浸水に値がセットされていることをチェックする。
                        ### セル[20:16]: 農家・漁家戸数, 1cm〜49cmに値がセットされていることをチェックする。
                        ### セル[20:17]: 農家・漁家戸数, 50cm〜99cmに値がセットされていることをチェックする。
                        ### セル[20:18]: 農家・漁家戸数, 1m以上・半壊に値がセットされていることをチェックする。
                        ### セル[20:19]: 農家・漁家戸数, 全壊・流失に値がセットされていることをチェックする。
                        ### セル[20:20]: 事業所従業者数, 床下浸水に値がセットされていることをチェックする。
                        ### セル[20:21]: 事業所従業者数, 1cm〜49cmに値がセットされていることをチェックする。
                        ### セル[20:22]: 事業所従業者数, 50cm〜99cmに値がセットされていることをチェックする。
                        ### セル[20:23]: 事業所従業者数, 1m以上・半壊に値がセットされていることをチェックする。
                        ### セル[20:24]: 事業所従業者数, 全壊・流失に値がセットされていることをチェックする。
                        ### セル[20:25]: 事業所の産業区分に値がセットされていることをチェックする。
                        ### セル[20:26]: 地下空間の利用形態に値がセットされていることをチェックする。
                        ### セル[20:27]: 備考に値がセットされていることをチェックする。
            return True
        except:
            return False
    
    ###########################################################################
    ### 関数内関数：EXCELセルデータ形式チェック処理
    ###########################################################################
    def check_format():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal format_warn_list
            nonlocal format_info_list
            nonlocal format_warn_grid
            nonlocal format_info_grid
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ形式チェック処理（0000）
            ### (1)セル[7:2]からセル[7:9]について形式が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 形式チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_format()関数 STEP 1/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                ### セル[7:2]: 都道府県について形式が正しいことをチェックする。
                if ws[i].cell(row=7, column=2).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=7, column=2).value)[-1].isdecimal() == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=2, fill=fill, message_id=100)
                        ### format_warn_list.append([ws[i].title, 7, 2, constants.IPP_FOR_MSG[100][0], constants.IPP_FOR_MSG[100][1], constants.IPP_FOR_MSG[100][2], constants.IPP_FOR_MSG[100][3], constants.IPP_FOR_MSG[100][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=2, fill=fill, message_id=0, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 7, 2, constants.IPP_FOR_MSG[0][0], constants.IPP_FOR_MSG[0][1], constants.IPP_FOR_MSG[0][2], constants.IPP_FOR_MSG[0][3], constants.IPP_FOR_MSG[0][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 7, 2, 100])
                        format_info_list.append([ws[i].title, 7, 2, 0])
            
                ### セル[7:3]: 市区町村について形式が正しいことをチェックする。
                if ws[i].cell(row=7, column=3).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=7, column=3).value)[-1].isdecimal() == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=3, fill=fill, message_id=101)
                        ### format_warn_list.append([ws[i].title, 7, 3, constants.IPP_FOR_MSG[101][0], constants.IPP_FOR_MSG[101][1], constants.IPP_FOR_MSG[101][2], constants.IPP_FOR_MSG[101][3], constants.IPP_FOR_MSG[101][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=3, fill=fill, message_id=1, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 7, 3, constants.IPP_FOR_MSG[1][0], constants.IPP_FOR_MSG[1][1], constants.IPP_FOR_MSG[1][2], constants.IPP_FOR_MSG[1][3], constants.IPP_FOR_MSG[1][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 7, 3, 101])
                        format_info_list.append([ws[i].title, 7, 3, 1])
          
                ### セル[7:4]: 水害発生月日について形式が正しいことをチェックする。
                if ws[i].cell(row=7, column=4).value is None:
                    pass
                else:
                    if isdate(ws[i].cell(row=7, column=4).value) == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=4, fill=fill, message_id=102)
                        ### format_warn_list.append([ws[i].title, 7, 4, constants.IPP_FOR_MSG[102][0], constants.IPP_FOR_MSG[102][1], constants.IPP_FOR_MSG[102][2], constants.IPP_FOR_MSG[102][3], constants.IPP_FOR_MSG[102][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=4, fill=fill, message_id=2, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 7, 4, constants.IPP_FOR_MSG[2][0], constants.IPP_FOR_MSG[2][1], constants.IPP_FOR_MSG[2][2], constants.IPP_FOR_MSG[2][3], constants.IPP_FOR_MSG[2][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 7, 4, 102])
                        format_info_list.append([ws[i].title, 7, 4, 2])
            
                ### セル[7:5]: 水害終了月日について形式が正しいことをチェックする。
                if ws[i].cell(row=7, column=5).value is None:
                    pass
                else:
                    if isdate(ws[i].cell(row=7, column=5).value) == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=5, fill=fill, message_id=103)
                        ### format_warn_list.append([ws[i].title, 7, 5, constants.IPP_FOR_MSG[103][0], constants.IPP_FOR_MSG[103][1], constants.IPP_FOR_MSG[103][2], constants.IPP_FOR_MSG[103][3], constants.IPP_FOR_MSG[103][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=5, fill=fill, message_id=3, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 7, 5, constants.IPP_FOR_MSG[3][0], constants.IPP_FOR_MSG[3][1], constants.IPP_FOR_MSG[3][2], constants.IPP_FOR_MSG[3][3], constants.IPP_FOR_MSG[3][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 7, 5, 103])
                        format_info_list.append([ws[i].title, 7, 5, 3])
                    
                ### セル[7:6]: 水害原因1について形式が正しいことをチェックする。
                if ws[i].cell(row=7, column=6).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=7, column=6).value)[-1].isdecimal() == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=104)
                        ### format_warn_list.append([ws[i].title, 7, 6, constants.IPP_FOR_MSG[104][0], constants.IPP_FOR_MSG[104][1], constants.IPP_FOR_MSG[104][2], constants.IPP_FOR_MSG[104][3], constants.IPP_FOR_MSG[104][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=4, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 7, 6, constants.IPP_FOR_MSG[4][0], constants.IPP_FOR_MSG[4][1], constants.IPP_FOR_MSG[4][2], constants.IPP_FOR_MSG[4][3], constants.IPP_FOR_MSG[4][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 7, 6, 104])
                        format_info_list.append([ws[i].title, 7, 6, 4])
                    
                ### セル[7:7]: 水害原因2について形式が正しいことをチェックする。
                if ws[i].cell(row=7, column=7).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=7, column=7).value)[-1].isdecimal() == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=105)
                        ### format_warn_list.append([ws[i].title, 7, 7, constants.IPP_FOR_MSG[105][0], constants.IPP_FOR_MSG[105][1], constants.IPP_FOR_MSG[105][2], constants.IPP_FOR_MSG[105][3], constants.IPP_FOR_MSG[105][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=5, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 7, 7, constants.IPP_FOR_MSG[5][0], constants.IPP_FOR_MSG[5][1], constants.IPP_FOR_MSG[5][2], constants.IPP_FOR_MSG[5][3], constants.IPP_FOR_MSG[5][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 7, 7, 105])
                        format_info_list.append([ws[i].title, 7, 7, 5])
                    
                ### セル[7:8]: 水害原因3について形式が正しいことをチェックする。
                if ws[i].cell(row=7, column=8).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=7, column=8).value)[-1].isdecimal() == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=106)
                        ### format_warn_list.append([ws[i].title, 7, 8, constants.IPP_FOR_MSG[106][0], constants.IPP_FOR_MSG[106][1], constants.IPP_FOR_MSG[106][2], constants.IPP_FOR_MSG[106][3], constants.IPP_FOR_MSG[106][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=6, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 7, 8, constants.IPP_FOR_MSG[6][0], constants.IPP_FOR_MSG[6][1], constants.IPP_FOR_MSG[6][2], constants.IPP_FOR_MSG[6][3], constants.IPP_FOR_MSG[6][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 7, 8, 106])
                        format_info_list.append([ws[i].title, 7, 8, 6])
                    
                ### セル[7:9]: 水害区域番号について形式が正しいことをチェックする。 ### COMMENT OUT 2023/11/14
                ### if ws[i].cell(row=7, column=9).value is None:
                ###     pass
                ### else:
                ###     if split_name_code(ws[i].cell(row=7, column=9).value)[-1].isdecimal() == False:
                ###         ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=9, fill=fill, message_id=107)
                ###         ### format_warn_list.append([ws[i].title, 7, 9, constants.IPP_FOR_MSG[107][0], constants.IPP_FOR_MSG[107][1], constants.IPP_FOR_MSG[107][2], constants.IPP_FOR_MSG[107][3], constants.IPP_FOR_MSG[107][4]])
                ###         add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=9, fill=fill, message_id=7, message=constants.IPP_FOR_MSG)
                ###         format_warn_list.append([ws[i].title, 7, 9, constants.IPP_FOR_MSG[7][0], constants.IPP_FOR_MSG[7][1], constants.IPP_FOR_MSG[7][2], constants.IPP_FOR_MSG[7][3], constants.IPP_FOR_MSG[7][4]])
                ###     else:
                ###         ### format_info_list.append([ws[i].title, 7, 9, 107])
                ###         format_info_list.append([ws[i].title, 7, 9, 7])
        
            ###################################################################
            ### 関数内関数：EXCELセルデータ形式チェック処理（0010）
            ### (1)セル[10:2]からセル[10:6]について形式が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_format()関数 STEP 2/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                ### セル[10:2]: 水系・沿岸名について形式が正しいことをチェックする。
                if ws[i].cell(row=10, column=2).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=10, column=2).value)[-1].isdecimal() == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=2, fill=fill, message_id=108)
                        ### format_warn_list.append([ws[i].title, 10, 2, constants.IPP_FOR_MSG[108][0], constants.IPP_FOR_MSG[108][1], constants.IPP_FOR_MSG[108][2], constants.IPP_FOR_MSG[108][3], constants.IPP_FOR_MSG[108][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=2, fill=fill, message_id=8, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 10, 2, constants.IPP_FOR_MSG[8][0], constants.IPP_FOR_MSG[8][1], constants.IPP_FOR_MSG[8][2], constants.IPP_FOR_MSG[8][3], constants.IPP_FOR_MSG[8][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 10, 2, 108])
                        format_info_list.append([ws[i].title, 10, 2, 8])
                    
                ### セル[10:3]: 水系種別について形式が正しいことをチェックする。
                if ws[i].cell(row=10, column=3).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=10, column=3).value)[-1].isdecimal() == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=109)
                        ### format_warn_list.append([ws[i].title, 10, 3, constants.IPP_FOR_MSG[109][0], constants.IPP_FOR_MSG[109][1], constants.IPP_FOR_MSG[109][2], constants.IPP_FOR_MSG[109][3], constants.IPP_FOR_MSG[109][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=9, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 10, 3, constants.IPP_FOR_MSG[9][0], constants.IPP_FOR_MSG[9][1], constants.IPP_FOR_MSG[9][2], constants.IPP_FOR_MSG[9][3], constants.IPP_FOR_MSG[9][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 10, 3, 109])
                        format_info_list.append([ws[i].title, 10, 3, 9])
                    
                ### セル[10:4]: 河川・海岸名について形式が正しいことをチェックする。
                if ws[i].cell(row=10, column=4).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=10, column=4).value)[-1].isdecimal() == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=4, fill=fill, message_id=110)
                        ### format_warn_list.append([ws[i].title, 10, 4, constants.IPP_FOR_MSG[110][0], constants.IPP_FOR_MSG[110][1], constants.IPP_FOR_MSG[110][2], constants.IPP_FOR_MSG[110][3], constants.IPP_FOR_MSG[110][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=4, fill=fill, message_id=10, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 10, 4, constants.IPP_FOR_MSG[10][0], constants.IPP_FOR_MSG[10][1], constants.IPP_FOR_MSG[10][2], constants.IPP_FOR_MSG[10][3], constants.IPP_FOR_MSG[10][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 10, 4, 110])
                        format_info_list.append([ws[i].title, 10, 4, 10])
                    
                ### セル[10:5]: 河川種別について形式が正しいことをチェックする。
                if ws[i].cell(row=10, column=5).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=10, column=5).value)[-1].isdecimal() == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=111)
                        ### format_warn_list.append([ws[i].title, 10, 5, constants.IPP_FOR_MSG[111][0], constants.IPP_FOR_MSG[111][1], constants.IPP_FOR_MSG[111][2], constants.IPP_FOR_MSG[111][3], constants.IPP_FOR_MSG[111][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=11, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 10, 5, constants.IPP_FOR_MSG[11][0], constants.IPP_FOR_MSG[11][1], constants.IPP_FOR_MSG[11][2], constants.IPP_FOR_MSG[11][3], constants.IPP_FOR_MSG[11][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 10, 5, 111])
                        format_info_list.append([ws[i].title, 10, 5, 11])
                    
                ### セル[10:6]: 地盤勾配区分について形式が正しいことをチェックする。
                if ws[i].cell(row=10, column=6).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=10, column=6).value)[-1].isdecimal() == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=6, fill=fill, message_id=112)
                        ### format_warn_list.append([ws[i].title, 10, 6, constants.IPP_FOR_MSG[112][0], constants.IPP_FOR_MSG[112][1], constants.IPP_FOR_MSG[112][2], constants.IPP_FOR_MSG[112][3], constants.IPP_FOR_MSG[112][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=6, fill=fill, message_id=12, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 10, 6, constants.IPP_FOR_MSG[12][0], constants.IPP_FOR_MSG[12][1], constants.IPP_FOR_MSG[12][2], constants.IPP_FOR_MSG[12][3], constants.IPP_FOR_MSG[12][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 10, 6, 112])
                        format_info_list.append([ws[i].title, 10, 6, 12])
        
            ###################################################################
            ### 関数内関数：EXCELセルデータ形式チェック処理（0020）
            ### (1)セル[14:2]からセル[14:10]について形式が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_format()関数 STEP 3/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                ### セル[14:2]: 水害区域面積の宅地について形式が正しいことをチェックする。
                if ws[i].cell(row=14, column=2).value is None:
                    pass
                else:
                    if isinstance(ws[i].cell(row=14, column=2).value, int) == False and \
                        isinstance(ws[i].cell(row=14, column=2).value, float) == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=2, fill=fill, message_id=113)
                        ### format_warn_list.append([ws[i].title, 14, 2, constants.IPP_FOR_MSG[113][0], constants.IPP_FOR_MSG[113][1], constants.IPP_FOR_MSG[113][2], constants.IPP_FOR_MSG[113][3], constants.IPP_FOR_MSG[113][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=2, fill=fill, message_id=13, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 14, 2, constants.IPP_FOR_MSG[13][0], constants.IPP_FOR_MSG[13][1], constants.IPP_FOR_MSG[13][2], constants.IPP_FOR_MSG[13][3], constants.IPP_FOR_MSG[13][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 14, 2, 113])
                        format_info_list.append([ws[i].title, 14, 2, 13])
        
                ### セル[14:3]: 水害区域面積の農地について形式が正しいことをチェックする。
                if ws[i].cell(row=14, column=3).value is None:
                    pass
                else:
                    if isinstance(ws[i].cell(row=14, column=3).value, int) == False and \
                        isinstance(ws[i].cell(row=14, column=3).value, float) == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=3, fill=fill, message_id=114)
                        ### format_warn_list.append([ws[i].title, 14, 3, constants.IPP_FOR_MSG[114][0], constants.IPP_FOR_MSG[114][1], constants.IPP_FOR_MSG[114][2], constants.IPP_FOR_MSG[114][3], constants.IPP_FOR_MSG[114][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=3, fill=fill, message_id=14, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 14, 3, constants.IPP_FOR_MSG[14][0], constants.IPP_FOR_MSG[14][1], constants.IPP_FOR_MSG[14][2], constants.IPP_FOR_MSG[14][3], constants.IPP_FOR_MSG[14][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 14, 3, 114])
                        format_info_list.append([ws[i].title, 14, 3, 14])
                    
                ### セル[14:4]: 水害区域面積の地下について形式が正しいことをチェックする。
                if ws[i].cell(row=14, column=4).value is None:
                    pass
                else:
                    if isinstance(ws[i].cell(row=14, column=4).value, int) == False and \
                        isinstance(ws[i].cell(row=14, column=4).value, float) == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=4, fill=fill, message_id=115)
                        ### format_warn_list.append([ws[i].title, 14, 4, constants.IPP_FOR_MSG[115][0], constants.IPP_FOR_MSG[115][1], constants.IPP_FOR_MSG[115][2], constants.IPP_FOR_MSG[115][3], constants.IPP_FOR_MSG[115][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=4, fill=fill, message_id=15, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 14, 4, constants.IPP_FOR_MSG[15][0], constants.IPP_FOR_MSG[15][1], constants.IPP_FOR_MSG[15][2], constants.IPP_FOR_MSG[15][3], constants.IPP_FOR_MSG[15][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 14, 4, 115])
                        format_info_list.append([ws[i].title, 14, 4, 15])
                    
                ### セル[14:6]: 工種について形式が正しいことをチェックする。
                if ws[i].cell(row=14, column=6).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=14, column=6).value)[-1].isdecimal() == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=116)
                        ### format_warn_list.append([ws[i].title, 14, 6, constants.IPP_FOR_MSG[116][0], constants.IPP_FOR_MSG[116][1], constants.IPP_FOR_MSG[116][2], constants.IPP_FOR_MSG[116][3], constants.IPP_FOR_MSG[116][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=16, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 14, 6, constants.IPP_FOR_MSG[16][0], constants.IPP_FOR_MSG[16][1], constants.IPP_FOR_MSG[16][2], constants.IPP_FOR_MSG[16][3], constants.IPP_FOR_MSG[16][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 14, 6, 116])
                        format_info_list.append([ws[i].title, 14, 6, 16])
                    
                ### セル[14:8]: 農作物被害額について形式が正しいことをチェックする。
                if ws[i].cell(row=14, column=8).value is None:
                    pass
                else:
                    if isinstance(ws[i].cell(row=14, column=8).value, int) == False and \
                        isinstance(ws[i].cell(row=14, column=8).value, float) == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=8, fill=fill, message_id=117)
                        ### format_warn_list.append([ws[i].title, 14, 8, constants.IPP_FOR_MSG[117][0], constants.IPP_FOR_MSG[117][1], constants.IPP_FOR_MSG[117][2], constants.IPP_FOR_MSG[117][3], constants.IPP_FOR_MSG[117][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=8, fill=fill, message_id=17, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 14, 8, constants.IPP_FOR_MSG[17][0], constants.IPP_FOR_MSG[17][1], constants.IPP_FOR_MSG[17][2], constants.IPP_FOR_MSG[17][3], constants.IPP_FOR_MSG[17][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 14, 8, 117])
                        format_info_list.append([ws[i].title, 14, 8, 17])
                    
                ### セル[14:10]: 異常気象コードについて形式が正しいことをチェックする。
                if ws[i].cell(row=14, column=10).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=14, column=10).value)[-1].isdecimal() == False:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=10, fill=fill, message_id=118)
                        ### format_warn_list.append([ws[i].title, 14, 10, constants.IPP_FOR_MSG[118][0], constants.IPP_FOR_MSG[118][1], constants.IPP_FOR_MSG[118][2], constants.IPP_FOR_MSG[118][3], constants.IPP_FOR_MSG[118][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=10, fill=fill, message_id=18, message=constants.IPP_FOR_MSG)
                        format_warn_list.append([ws[i].title, 14, 10, constants.IPP_FOR_MSG[18][0], constants.IPP_FOR_MSG[18][1], constants.IPP_FOR_MSG[18][2], constants.IPP_FOR_MSG[18][3], constants.IPP_FOR_MSG[18][4]])
                    else:
                        ### format_info_list.append([ws[i].title, 14, 10, 118])
                        format_info_list.append([ws[i].title, 14, 10, 18])
                    
            ###################################################################
            ### 関数内関数：EXCELセルデータ形式チェック処理（0030）
            ### (1)セル[20:2]からセル[20:27]について形式が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_format()関数 STEP 4/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                if max_row[i] >= 20:
                    for j in range(20, max_row[i]+1):
                        ### セル[20:2]: 町丁名・大字名について形式が正しいことをチェックする。
                        ### セル[20:3]: 名称について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=3).value is None:
                            pass
                        else:
                            if split_name_code(ws[i].cell(row=j, column=3).value)[-1].isdecimal() == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=3, fill=fill, message_id=151)
                                ### format_warn_grid.append([ws[i].title, j, 3, constants.IPP_FOR_MSG[151][0], constants.IPP_FOR_MSG[151][1], constants.IPP_FOR_MSG[151][2], constants.IPP_FOR_MSG[151][3], constants.IPP_FOR_MSG[151][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=3, fill=fill, message_id=20, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 3, constants.IPP_FOR_MSG[20][0], constants.IPP_FOR_MSG[20][1], constants.IPP_FOR_MSG[20][2], constants.IPP_FOR_MSG[20][3], constants.IPP_FOR_MSG[20][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 3, 151])
                                format_info_grid.append([ws[i].title, j, 3, 20])
                            
                        ### セル[20:4]: 地上・地下被害の区分について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=4).value is None:
                            pass
                        else:
                            if split_name_code(ws[i].cell(row=j, column=4).value)[-1].isdecimal() == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=152)
                                ### format_warn_grid.append([ws[i].title, j, 4, constants.IPP_FOR_MSG[152][0], constants.IPP_FOR_MSG[152][1], constants.IPP_FOR_MSG[152][2], constants.IPP_FOR_MSG[152][3], constants.IPP_FOR_MSG[152][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=21, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 4, constants.IPP_FOR_MSG[21][0], constants.IPP_FOR_MSG[21][1], constants.IPP_FOR_MSG[21][2], constants.IPP_FOR_MSG[21][3], constants.IPP_FOR_MSG[21][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 4, 152])
                                format_info_grid.append([ws[i].title, j, 4, 21])
                            
                        ### セル[20:5]: 浸水土砂被害の区分について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=5).value is None:
                            pass
                        else:
                            if split_name_code(ws[i].cell(row=j, column=5).value)[-1].isdecimal() == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=5, fill=fill, message_id=153)
                                ### format_warn_grid.append([ws[i].title, j, 5, constants.IPP_FOR_MSG[153][0], constants.IPP_FOR_MSG[153][1], constants.IPP_FOR_MSG[153][2], constants.IPP_FOR_MSG[153][3], constants.IPP_FOR_MSG[153][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=5, fill=fill, message_id=22, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 5, constants.IPP_FOR_MSG[22][0], constants.IPP_FOR_MSG[22][1], constants.IPP_FOR_MSG[22][2], constants.IPP_FOR_MSG[22][3], constants.IPP_FOR_MSG[22][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 5, 153])
                                format_info_grid.append([ws[i].title, j, 5, 22])
                            
                        ### セル[20:6]: 被害建物棟数, 床下浸水について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=6).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=6).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=6).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=6, fill=fill, message_id=154)
                                ### format_warn_grid.append([ws[i].title, j, 6, constants.IPP_FOR_MSG[154][0], constants.IPP_FOR_MSG[154][1], constants.IPP_FOR_MSG[154][2], constants.IPP_FOR_MSG[154][3], constants.IPP_FOR_MSG[154][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=6, fill=fill, message_id=23, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 6, constants.IPP_FOR_MSG[23][0], constants.IPP_FOR_MSG[23][1], constants.IPP_FOR_MSG[23][2], constants.IPP_FOR_MSG[23][3], constants.IPP_FOR_MSG[23][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 6, 154])
                                format_info_grid.append([ws[i].title, j, 6, 23])
                            
                        ### セル[20:7]: 被害建物棟数, 1cm〜49cmについて形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=7).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=7).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=7).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=7, fill=fill, message_id=155)
                                ### format_warn_grid.append([ws[i].title, j, 7, constants.IPP_FOR_MSG[155][0], constants.IPP_FOR_MSG[155][1], constants.IPP_FOR_MSG[155][2], constants.IPP_FOR_MSG[155][3], constants.IPP_FOR_MSG[155][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=7, fill=fill, message_id=24, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 7, constants.IPP_FOR_MSG[24][0], constants.IPP_FOR_MSG[24][1], constants.IPP_FOR_MSG[24][2], constants.IPP_FOR_MSG[24][3], constants.IPP_FOR_MSG[24][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 7, 155])
                                format_info_grid.append([ws[i].title, j, 7, 24])
                            
                        ### セル[20:8]: 被害建物棟数, 50cm〜99cmについて形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=8).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=8).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=8).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=8, fill=fill, message_id=156)
                                ### format_warn_grid.append([ws[i].title, j, 8, constants.IPP_FOR_MSG[156][0], constants.IPP_FOR_MSG[156][1], constants.IPP_FOR_MSG[156][2], constants.IPP_FOR_MSG[156][3], constants.IPP_FOR_MSG[156][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=8, fill=fill, message_id=25, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 8, constants.IPP_FOR_MSG[25][0], constants.IPP_FOR_MSG[25][1], constants.IPP_FOR_MSG[25][2], constants.IPP_FOR_MSG[25][3], constants.IPP_FOR_MSG[25][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 8, 156])
                                format_info_grid.append([ws[i].title, j, 8, 25])
                            
                        ### セル[20:9]: 被害建物棟数, 1m以上について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=9).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=9).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=9).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=9, fill=fill, message_id=157)
                                ### format_warn_grid.append([ws[i].title, j, 9, constants.IPP_FOR_MSG[157][0], constants.IPP_FOR_MSG[157][1], constants.IPP_FOR_MSG[157][2], constants.IPP_FOR_MSG[157][3], constants.IPP_FOR_MSG[157][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=9, fill=fill, message_id=26, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 9, constants.IPP_FOR_MSG[26][0], constants.IPP_FOR_MSG[26][1], constants.IPP_FOR_MSG[26][2], constants.IPP_FOR_MSG[26][3], constants.IPP_FOR_MSG[26][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 9, 157])
                                format_info_grid.append([ws[i].title, j, 9, 26])
                            
                        ### セル[20:10]: 被害建物棟数, 半壊について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=10).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=10).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=10).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=10, fill=fill, message_id=158)
                                ### format_warn_grid.append([ws[i].title, j, 10, constants.IPP_FOR_MSG[158][0], constants.IPP_FOR_MSG[158][1], constants.IPP_FOR_MSG[158][2], constants.IPP_FOR_MSG[158][3], constants.IPP_FOR_MSG[158][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=10, fill=fill, message_id=27, message=constants.IPP_FOR_MSGvvv)
                                format_warn_grid.append([ws[i].title, j, 10, constants.IPP_FOR_MSG[27][0], constants.IPP_FOR_MSG[27][1], constants.IPP_FOR_MSG[27][2], constants.IPP_FOR_MSG[27][3], constants.IPP_FOR_MSG[27][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 10, 158])
                                format_info_grid.append([ws[i].title, j, 10, 27])
                            
                        ### セル[20:11]: 被害建物棟数, 全壊・流失について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=11).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=11).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=11).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=11, fill=fill, message_id=159)
                                ### format_warn_grid.append([ws[i].title, j, 11, constants.IPP_FOR_MSG[159][0], constants.IPP_FOR_MSG[159][1], constants.IPP_FOR_MSG[159][2], constants.IPP_FOR_MSG[159][3], constants.IPP_FOR_MSG[159][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=11, fill=fill, message_id=28, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 11, constants.IPP_FOR_MSG[28][0], constants.IPP_FOR_MSG[28][1], constants.IPP_FOR_MSG[28][2], constants.IPP_FOR_MSG[28][3], constants.IPP_FOR_MSG[28][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 11, 159])
                                format_info_grid.append([ws[i].title, j, 11, 28])
                            
                        ### セル[20:12]: 被害建物の延床面積について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=12).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=12).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=12).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=12, fill=fill, message_id=160)
                                ### format_warn_grid.append([ws[i].title, j, 12, constants.IPP_FOR_MSG[160][0], constants.IPP_FOR_MSG[160][1], constants.IPP_FOR_MSG[160][2], constants.IPP_FOR_MSG[160][3], constants.IPP_FOR_MSG[160][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=12, fill=fill, message_id=29, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 12, constants.IPP_FOR_MSG[29][0], constants.IPP_FOR_MSG[29][1], constants.IPP_FOR_MSG[29][2], constants.IPP_FOR_MSG[29][3], constants.IPP_FOR_MSG[29][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 12, 160])
                                format_info_grid.append([ws[i].title, j, 12, 29])
                            
                        ### セル[20:13]: 被災世帯数について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=13).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=13).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=13).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=13, fill=fill, message_id=161)
                                ### format_warn_grid.append([ws[i].title, j, 13, constants.IPP_FOR_MSG[161][0], constants.IPP_FOR_MSG[161][1], constants.IPP_FOR_MSG[161][2], constants.IPP_FOR_MSG[161][3], constants.IPP_FOR_MSG[161][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=13, fill=fill, message_id=30, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 13, constants.IPP_FOR_MSG[30][0], constants.IPP_FOR_MSG[30][1], constants.IPP_FOR_MSG[30][2], constants.IPP_FOR_MSG[30][3], constants.IPP_FOR_MSG[30][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 13, 161])
                                format_info_grid.append([ws[i].title, j, 13, 30])
                            
                        ### セル[20:14]: 被災事業所数について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=14).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=14).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=14).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=162)
                                ### format_warn_grid.append([ws[i].title, j, 14, constants.IPP_FOR_MSG[162][0], constants.IPP_FOR_MSG[162][1], constants.IPP_FOR_MSG[162][2], constants.IPP_FOR_MSG[162][3], constants.IPP_FOR_MSG[162][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=31, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 14, constants.IPP_FOR_MSG[31][0], constants.IPP_FOR_MSG[31][1], constants.IPP_FOR_MSG[31][2], constants.IPP_FOR_MSG[31][3], constants.IPP_FOR_MSG[31][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 14, 162])
                                format_info_grid.append([ws[i].title, j, 14, 31])
                            
                        ### セル[20:15]: 農家・漁家戸数, 床下浸水について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=15).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=15).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=15).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=15, fill=fill, message_id=163)
                                ### format_warn_grid.append([ws[i].title, j, 15, constants.IPP_FOR_MSG[163][0], constants.IPP_FOR_MSG[163][1], constants.IPP_FOR_MSG[163][2], constants.IPP_FOR_MSG[163][3], constants.IPP_FOR_MSG[163][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=15, fill=fill, message_id=32, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 15, constants.IPP_FOR_MSG[32][0], constants.IPP_FOR_MSG[32][1], constants.IPP_FOR_MSG[32][2], constants.IPP_FOR_MSG[32][3], constants.IPP_FOR_MSG[32][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 15, 163])
                                format_info_grid.append([ws[i].title, j, 15, 32])
                            
                        ### セル[20:16]: 農家・漁家戸数, 1cm〜49cmについて形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=16).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=16).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=16).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=16, fill=fill, message_id=164)
                                ### format_warn_grid.append([ws[i].title, j, 16, constants.IPP_FOR_MSG[164][0], constants.IPP_FOR_MSG[164][1], constants.IPP_FOR_MSG[164][2], constants.IPP_FOR_MSG[164][3], constants.IPP_FOR_MSG[164][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=16, fill=fill, message_id=33, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 16, constants.IPP_FOR_MSG[33][0], constants.IPP_FOR_MSG[33][1], constants.IPP_FOR_MSG[33][2], constants.IPP_FOR_MSG[33][3], constants.IPP_FOR_MSG[33][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 16, 164])
                                format_info_grid.append([ws[i].title, j, 16, 33])
                            
                        ### セル[20:17]: 農家・漁家戸数, 50cm〜99cmについて形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=17).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=17).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=17).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=17, fill=fill, message_id=165)
                                ### format_warn_grid.append([ws[i].title, j, 17, constants.IPP_FOR_MSG[165][0], constants.IPP_FOR_MSG[165][1], constants.IPP_FOR_MSG[165][2], constants.IPP_FOR_MSG[165][3], constants.IPP_FOR_MSG[165][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=17, fill=fill, message_id=34, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 17, constants.IPP_FOR_MSG[34][0], constants.IPP_FOR_MSG[34][1], constants.IPP_FOR_MSG[34][2], constants.IPP_FOR_MSG[34][3], constants.IPP_FOR_MSG[34][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 17, 165])
                                format_info_grid.append([ws[i].title, j, 17, 34])
                            
                        ### セル[20:18]: 農家・漁家戸数, 1m以上・半壊について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=18).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=18).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=18).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=18, fill=fill, message_id=166)
                                ### format_warn_grid.append([ws[i].title, j, 18, constants.IPP_FOR_MSG[166][0], constants.IPP_FOR_MSG[166][1], constants.IPP_FOR_MSG[166][2], constants.IPP_FOR_MSG[166][3], constants.IPP_FOR_MSG[166][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=18, fill=fill, message_id=35, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 18, constants.IPP_FOR_MSG[35][0], constants.IPP_FOR_MSG[35][1], constants.IPP_FOR_MSG[35][2], constants.IPP_FOR_MSG[35][3], constants.IPP_FOR_MSG[35][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 18, 166])
                                format_info_grid.append([ws[i].title, j, 18, 35])
                            
                        ### セル[20:19]: 農家・漁家戸数, 全壊・流失について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=19).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=19).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=19).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=19, fill=fill, message_id=167)
                                ### format_warn_grid.append([ws[i].title, j, 19, constants.IPP_FOR_MSG[167][0], constants.IPP_FOR_MSG[167][1], constants.IPP_FOR_MSG[167][2], constants.IPP_FOR_MSG[167][3], constants.IPP_FOR_MSG[167][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=19, fill=fill, message_id=36, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 19, constants.IPP_FOR_MSG[36][0], constants.IPP_FOR_MSG[36][1], constants.IPP_FOR_MSG[36][2], constants.IPP_FOR_MSG[36][3], constants.IPP_FOR_MSG[36][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 19, 167])
                                format_info_grid.append([ws[i].title, j, 19, 36])
                            
                        ### セル[20:20]: 事業所従業者数, 床下浸水について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=20).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=20).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=20).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=20, fill=fill, message_id=168)
                                ### format_warn_grid.append([ws[i].title, j, 20, constants.IPP_FOR_MSG[168][0], constants.IPP_FOR_MSG[168][1], constants.IPP_FOR_MSG[168][2], constants.IPP_FOR_MSG[168][3], constants.IPP_FOR_MSG[168][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=20, fill=fill, message_id=37, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 20, constants.IPP_FOR_MSG[37][0], constants.IPP_FOR_MSG[37][1], constants.IPP_FOR_MSG[37][2], constants.IPP_FOR_MSG[37][3], constants.IPP_FOR_MSG[37][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 20, 168])
                                format_info_grid.append([ws[i].title, j, 20, 37])
                            
                        ### セル[20:21]: 事業所従業者数, 1cm〜49cmについて形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=21).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=21).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=21).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=21, fill=fill, message_id=169)
                                ### format_warn_grid.append([ws[i].title, j, 21, constants.IPP_FOR_MSG[169][0], constants.IPP_FOR_MSG[169][1], constants.IPP_FOR_MSG[169][2], constants.IPP_FOR_MSG[169][3], constants.IPP_FOR_MSG[169][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=21, fill=fill, message_id=38, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 21, constants.IPP_FOR_MSG[38][0], constants.IPP_FOR_MSG[38][1], constants.IPP_FOR_MSG[38][2], constants.IPP_FOR_MSG[38][3], constants.IPP_FOR_MSG[38][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 21, 169])
                                format_info_grid.append([ws[i].title, j, 21, 38])
                            
                        ### セル[20:22]: 事業所従業者数, 50cm〜99cmについて形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=22).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=22).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=22).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=22, fill=fill, message_id=170)
                                ### format_warn_grid.append([ws[i].title, j, 22, constants.IPP_FOR_MSG[170][0], constants.IPP_FOR_MSG[170][1], constants.IPP_FOR_MSG[170][2], constants.IPP_FOR_MSG[170][3], constants.IPP_FOR_MSG[170][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=22, fill=fill, message_id=39, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 22, constants.IPP_FOR_MSG[39][0], constants.IPP_FOR_MSG[39][1], constants.IPP_FOR_MSG[39][2], constants.IPP_FOR_MSG[39][3], constants.IPP_FOR_MSG[39][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 22, 170])
                                format_info_grid.append([ws[i].title, j, 22, 39])
                            
                        ### セル[20:23]: 事業所従業者数, 1m以上・半壊について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=23).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=23).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=23).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=23, fill=fill, message_id=171)
                                ### format_warn_grid.append([ws[i].title, j, 23, constants.IPP_FOR_MSG[171][0], constants.IPP_FOR_MSG[171][1], constants.IPP_FOR_MSG[171][2], constants.IPP_FOR_MSG[171][3], constants.IPP_FOR_MSG[171][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=23, fill=fill, message_id=40, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 23, constants.IPP_FOR_MSG[40][0], constants.IPP_FOR_MSG[40][1], constants.IPP_FOR_MSG[40][2], constants.IPP_FOR_MSG[40][3], constants.IPP_FOR_MSG[40][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 23, 171])
                                format_info_grid.append([ws[i].title, j, 23, 40])
                            
                        ### セル[20:24]: 事業所従業者数, 全壊・流失について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=24).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=24).value, int) == False and \
                                isinstance(ws[i].cell(row=j, column=24).value, float) == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=24, fill=fill, message_id=172)
                                ### format_warn_grid.append([ws[i].title, j, 24, constants.IPP_FOR_MSG[172][0], constants.IPP_FOR_MSG[172][1], constants.IPP_FOR_MSG[172][2], constants.IPP_FOR_MSG[172][3], constants.IPP_FOR_MSG[172][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=24, fill=fill, message_id=41, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 24, constants.IPP_FOR_MSG[41][0], constants.IPP_FOR_MSG[41][1], constants.IPP_FOR_MSG[41][2], constants.IPP_FOR_MSG[41][3], constants.IPP_FOR_MSG[41][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 24, 172])
                                format_info_grid.append([ws[i].title, j, 24, 41])
                            
                        ### セル[20:25]: 事業所の産業区分について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=25).value is None:
                            pass
                        else:
                            if split_name_code(ws[i].cell(row=j, column=25).value)[-1].isdecimal() == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=25, fill=fill, message_id=173)
                                ### format_warn_grid.append([ws[i].title, j, 25, constants.IPP_FOR_MSG[173][0], constants.IPP_FOR_MSG[173][1], constants.IPP_FOR_MSG[173][2], constants.IPP_FOR_MSG[173][3], constants.IPP_FOR_MSG[173][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=25, fill=fill, message_id=42, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 25, constants.IPP_FOR_MSG[42][0], constants.IPP_FOR_MSG[42][1], constants.IPP_FOR_MSG[42][2], constants.IPP_FOR_MSG[42][3], constants.IPP_FOR_MSG[42][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 25, 173])
                                format_info_grid.append([ws[i].title, j, 25, 42])
                            
                        ### セル[20:26]: 地下空間の利用形態について形式が正しいことをチェックする。
                        if ws[i].cell(row=j, column=26).value is None:
                            pass
                        else:
                            if split_name_code(ws[i].cell(row=j, column=26).value)[-1].isdecimal() == False:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=26, fill=fill, message_id=174)
                                ### format_warn_grid.append([ws[i].title, j, 26, constants.IPP_FOR_MSG[174][0], constants.IPP_FOR_MSG[174][1], constants.IPP_FOR_MSG[174][2], constants.IPP_FOR_MSG[174][3], constants.IPP_FOR_MSG[174][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=26, fill=fill, message_id=43, message=constants.IPP_FOR_MSG)
                                format_warn_grid.append([ws[i].title, j, 26, constants.IPP_FOR_MSG[43][0], constants.IPP_FOR_MSG[43][1], constants.IPP_FOR_MSG[43][2], constants.IPP_FOR_MSG[43][3], constants.IPP_FOR_MSG[43][4]])
                            else:
                                ### format_info_grid.append([ws[i].title, j, 26, 174])
                                format_info_grid.append([ws[i].title, j, 26, 43])
                            
                        ### セル[20:27]: 備考について形式が正しいことをチェックする。
            return True
        except:
            return False
    
    ###########################################################################
    ### 関数内関数：EXCELセルデータ範囲チェック処理
    ###########################################################################
    def check_range():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal range_warn_list
            nonlocal range_info_list
            nonlocal range_warn_grid
            nonlocal range_info_grid
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ範囲チェック処理（0000）
            ### (1)セル[7:2]からセル[7:9]について範囲が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### 範囲チェックでは、値がセットされている場合のみチェックを行う。
            ### 必須チェックは別途必須チェックで行うためである。
            ### 範囲チェックでは、形式が正しい場合のみチェックを行う。
            ### 形式チェックは別途形式チェックで行うためである。
            ### 例えば、面積などの数値について、float()で例外とならないように、int、floatの場合のみチェックする。
            ### 範囲チェックでは、数値の下限と上限のチェックを行う。
            ### 範囲チェックでは、DBとの突合チェックに該当するチェックは行わない。
            ### DBとの突合チェックは別途突合チェックで行うためである。
            ### 範囲チェックの例は値が正であることである。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_range()関数 STEP 1/4.', 'DEBUG')
            ### for i, _ in enumerate(ws):
                ### セル[7:2]: 都道府県について範囲が正しいことをチェックする。
                ### セル[7:3]: 市区町村について範囲が正しいことをチェックする。
                ### セル[7:4]: 水害発生月日について範囲が正しいことをチェックする。
                ### セル[7:5]: 水害終了月日について範囲が正しいことをチェックする。
                ### セル[7:6]: 水害原因1について範囲が正しいことをチェックする。
                ### セル[7:7]: 水害原因2について範囲が正しいことをチェックする。
                ### セル[7:8]: 水害原因3について範囲が正しいことをチェックする。
                ### セル[7:9]: 水害区域番号について範囲が正しいことをチェックする。
    
            ###################################################################
            ### 関数内関数：EXCELセルデータ範囲チェック処理（0010）
            ### (1)セル[10:2]からセル[10:6]について範囲が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_range()関数 STEP 2/4.', 'DEBUG')
            ### for i, _ in enumerate(ws):
                ### セル[10:2]: 水系・沿岸名について範囲が正しいことをチェックする。
                ### セル[10:3]: 水系種別について範囲が正しいことをチェックする。
                ### セル[10:4]: 河川・海岸名について範囲が正しいことをチェックする。
                ### セル[10:5]: 河川種別について範囲が正しいことをチェックする。
                ### セル[10:6]: 地盤勾配区分について範囲が正しいことをチェックする。
    
            ###################################################################
            ### 関数内関数：EXCELセルデータ範囲チェック処理（0020）
            ### (1)セル[14:2]からセル[14:10]について範囲が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_range()関数 STEP 3/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                ### セル[14:2]: 水害区域面積の宅地について範囲が正しいことをチェックする。
                if ws[i].cell(row=14, column=2).value is None:
                    pass
                else:
                    if isinstance(ws[i].cell(row=14, column=2).value, int) == True or \
                        isinstance(ws[i].cell(row=14, column=2).value, float) == True:
                        if float(ws[i].cell(row=14, column=2).value) < 0:
                            ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=2, fill=fill, message_id=213)
                            ### range_warn_list.append([ws[i].title, 14, 2, constants.IPP_RAN_MSG[213][0], constants.IPP_RAN_MSG[213][1], constants.IPP_RAN_MSG[213][2], constants.IPP_RAN_MSG[213][3], constants.IPP_RAN_MSG[213][4]])
                            add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=2, fill=fill, message_id=13, message=constants.IPP_RAN_MSG)
                            range_warn_list.append([ws[i].title, 14, 2, constants.IPP_RAN_MSG[13][0], constants.IPP_RAN_MSG[13][1], constants.IPP_RAN_MSG[13][2], constants.IPP_RAN_MSG[13][3], constants.IPP_RAN_MSG[13][4]])
                        else:
                            ### range_info_list.append([ws[i].title, 14, 2, 213])
                            range_info_list.append([ws[i].title, 14, 2, 13])
                    
                ### セル[14:3]: 水害区域面積の農地について範囲が正しいことをチェックする。
                if ws[i].cell(row=14, column=3).value is None:
                    pass
                else:
                    if isinstance(ws[i].cell(row=14, column=3).value, int) == True or \
                        isinstance(ws[i].cell(row=14, column=3).value, float) == True:
                        if float(ws[i].cell(row=14, column=3).value) < 0:
                            ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=3, fill=fill, message_id=214)
                            ### range_warn_list.append([ws[i].title, 14, 3, constants.IPP_RAN_MSG[214][0], constants.IPP_RAN_MSG[214][1], constants.IPP_RAN_MSG[214][2], constants.IPP_RAN_MSG[214][3], constants.IPP_RAN_MSG[214][4]])
                            add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=3, fill=fill, message_id=14, message=constants.IPP_RAN_MSG)
                            range_warn_list.append([ws[i].title, 14, 3, constants.IPP_RAN_MSG[14][0], constants.IPP_RAN_MSG[14][1], constants.IPP_RAN_MSG[14][2], constants.IPP_RAN_MSG[14][3], constants.IPP_RAN_MSG[14][4]])
                        else:
                            ### range_info_list.append([ws[i].title, 14, 3, 214])
                            range_info_list.append([ws[i].title, 14, 3, 14])
        
                ### セル[14:4]: 水害区域面積の地下について範囲が正しいことをチェックする。
                if ws[i].cell(row=14, column=4).value is None:
                    pass
                else:
                    if isinstance(ws[i].cell(row=14, column=4).value, int) == True or \
                        isinstance(ws[i].cell(row=14, column=4).value, float) == True:
                        if float(ws[i].cell(row=14, column=4).value) < 0:
                            ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=4, fill=fill, message_id=215)
                            ### range_warn_list.append([ws[i].title, 14, 4, constants.IPP_RAN_MSG[215][0], constants.IPP_RAN_MSG[215][1], constants.IPP_RAN_MSG[215][2], constants.IPP_RAN_MSG[215][3], constants.IPP_RAN_MSG[215][4]])
                            add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=4, fill=fill, message_id=15, message=constants.IPP_RAN_MSG)
                            range_warn_list.append([ws[i].title, 14, 4, constants.IPP_RAN_MSG[15][0], constants.IPP_RAN_MSG[15][1], constants.IPP_RAN_MSG[15][2], constants.IPP_RAN_MSG[15][3], constants.IPP_RAN_MSG[15][4]])
                        else:
                            ### range_info_list.append([ws[i].title, 14, 4, 215])
                            range_info_list.append([ws[i].title, 14, 4, 15])
                    
                ### セル[14:6]: 工種について範囲が正しいことをチェックする。
                ### セル[14:8]: 農作物被害額について範囲が正しいことをチェックする。
                if ws[i].cell(row=14, column=8).value is None:
                    pass
                else:
                    if isinstance(ws[i].cell(row=14, column=8).value, int) == True or \
                        isinstance(ws[i].cell(row=14, column=8).value, float) == True:
                        if float(ws[i].cell(row=14, column=8).value) < 0:
                            ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=8, fill=fill, message_id=217)
                            ### range_warn_list.append([ws[i].title, 14, 8, constants.IPP_RAN_MSG[217][0], constants.IPP_RAN_MSG[217][1], constants.IPP_RAN_MSG[217][2], constants.IPP_RAN_MSG[217][3], constants.IPP_RAN_MSG[217][4]])
                            add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=8, fill=fill, message_id=17, message=constants.IPP_RAN_MSG)
                            range_warn_list.append([ws[i].title, 14, 8, constants.IPP_RAN_MSG[17][0], constants.IPP_RAN_MSG[17][1], constants.IPP_RAN_MSG[17][2], constants.IPP_RAN_MSG[17][3], constants.IPP_RAN_MSG[17][4]])
                        else:
                            ### range_info_list.append([ws[i].title, 14, 8, 217])
                            range_info_list.append([ws[i].title, 14, 8, 17])
        
                ### セル[14:10]: 異常気象コードについて範囲が正しいことをチェックする。
    
            ###################################################################
            ### 関数内関数：EXCELセルデータ範囲チェック処理（0030）
            ### (1)セル[20:2]からセル[20:27]について範囲が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_range()関数 STEP 4/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                if max_row[i] >= 20:
                    for j in range(20, max_row[i]+1):
                        ### セル[20:2]: 町丁名・大字名について範囲が正しいことをチェックする。
                        ### セル[20:3]: 名称について範囲が正しいことをチェックする。
                        ### セル[20:4]: 地上・地下被害の区分について範囲が正しいことをチェックする。
                        ### セル[20:5]: 浸水土砂被害の区分について範囲が正しいことをチェックする。
                        ### セル[20:6]: 被害建物棟数, 床下浸水について範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=6).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=6).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=6).value, float) == True:
                                if float(ws[i].cell(row=j, column=6).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=6, fill=fill, message_id=254)
                                    ### range_warn_grid.append([ws[i].title, j, 6, constants.IPP_RAN_MSG[254][0], constants.IPP_RAN_MSG[254][1], constants.IPP_RAN_MSG[254][2], constants.IPP_RAN_MSG[254][3], constants.IPP_RAN_MSG[254][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=6, fill=fill, message_id=23, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 6, constants.IPP_RAN_MSG[23][0], constants.IPP_RAN_MSG[23][1], constants.IPP_RAN_MSG[23][2], constants.IPP_RAN_MSG[23][3], constants.IPP_RAN_MSG[23][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 6, 254])
                                    range_info_grid.append([ws[i].title, j, 6, 23])
        
                        ### セル[20:7]: 被害建物棟数, 1cm〜49cmについて範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=7).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=7).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=7).value, float) == True:
                                if float(ws[i].cell(row=j, column=7).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=7, fill=fill, message_id=255)
                                    ### range_warn_grid.append([ws[i].title, j, 7, constants.IPP_RAN_MSG[255][0], constants.IPP_RAN_MSG[255][1], constants.IPP_RAN_MSG[255][2], constants.IPP_RAN_MSG[255][3], constants.IPP_RAN_MSG[255][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=7, fill=fill, message_id=24, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 7, constants.IPP_RAN_MSG[24][0], constants.IPP_RAN_MSG[24][1], constants.IPP_RAN_MSG[24][2], constants.IPP_RAN_MSG[24][3], constants.IPP_RAN_MSG[24][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 7, 255])
                                    range_info_grid.append([ws[i].title, j, 7, 24])
                        
                        ### セル[20:8]: 被害建物棟数, 50cm〜99cmについて範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=8).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=8).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=8).value, float) == True:
                                if float(ws[i].cell(row=j, column=8).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=8, fill=fill, message_id=256)
                                    ### range_warn_grid.append([ws[i].title, j, 8, constants.IPP_RAN_MSG[256][0], constants.IPP_RAN_MSG[256][1], constants.IPP_RAN_MSG[256][2], constants.IPP_RAN_MSG[256][3], constants.IPP_RAN_MSG[256][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=8, fill=fill, message_id=25, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 8, constants.IPP_RAN_MSG[25][0], constants.IPP_RAN_MSG[25][1], constants.IPP_RAN_MSG[25][2], constants.IPP_RAN_MSG[25][3], constants.IPP_RAN_MSG[25][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 8, 256])
                                    range_info_grid.append([ws[i].title, j, 8, 25])
        
                        ### セル[20:9]: 被害建物棟数, 1m以上について範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=9).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=9).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=9).value, float) == True:
                                if float(ws[i].cell(row=j, column=9).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=9, fill=fill, message_id=257)
                                    ### range_warn_grid.append([ws[i].title, j, 9, constants.IPP_RAN_MSG[257][0], constants.IPP_RAN_MSG[257][1], constants.IPP_RAN_MSG[257][2], constants.IPP_RAN_MSG[257][3], constants.IPP_RAN_MSG[257][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=9, fill=fill, message_id=26, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 9, constants.IPP_RAN_MSG[26][0], constants.IPP_RAN_MSG[26][1], constants.IPP_RAN_MSG[26][2], constants.IPP_RAN_MSG[26][3], constants.IPP_RAN_MSG[26][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 9, 257])
                                    range_info_grid.append([ws[i].title, j, 9, 26])
        
                        ### セル[20:10]: 被害建物棟数, 半壊について範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=10).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=10).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=10).value, float) == True:
                                if float(ws[i].cell(row=j, column=10).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=10, fill=fill, message_id=258)
                                    ### range_warn_grid.append([ws[i].title, j, 10, constants.IPP_RAN_MSG[258][0], constants.IPP_RAN_MSG[258][1], constants.IPP_RAN_MSG[258][2], constants.IPP_RAN_MSG[258][3], constants.IPP_RAN_MSG[258][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=10, fill=fill, message_id=27, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 10, constants.IPP_RAN_MSG[27][0], constants.IPP_RAN_MSG[27][1], constants.IPP_RAN_MSG[27][2], constants.IPP_RAN_MSG[27][3], constants.IPP_RAN_MSG[27][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 10, 258])
                                    range_info_grid.append([ws[i].title, j, 10, 27])
        
                        ### セル[20:11]: 被害建物棟数, 全壊・流失について範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=11).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=11).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=11).value, float) == True:
                                if float(ws[i].cell(row=j, column=11).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=11, fill=fill, message_id=259)
                                    ### range_warn_grid.append([ws[i].title, j, 11, constants.IPP_RAN_MSG[259][0], constants.IPP_RAN_MSG[259][1], constants.IPP_RAN_MSG[259][2], constants.IPP_RAN_MSG[259][3], constants.IPP_RAN_MSG[259][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=11, fill=fill, message_id=28, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 11, constants.IPP_RAN_MSG[28][0], constants.IPP_RAN_MSG[28][1], constants.IPP_RAN_MSG[28][2], constants.IPP_RAN_MSG[28][3], constants.IPP_RAN_MSG[28][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 11, 259])
                                    range_info_grid.append([ws[i].title, j, 11, 28])
        
                        ### セル[20:12]: 被害建物の延床面積について範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=12).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=12).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=12).value, float) == True:
                                if float(ws[i].cell(row=j, column=12).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=12, fill=fill, message_id=260)
                                    ### range_warn_grid.append([ws[i].title, j, 12, constants.IPP_RAN_MSG[260][0], constants.IPP_RAN_MSG[260][1], constants.IPP_RAN_MSG[260][2], constants.IPP_RAN_MSG[260][3], constants.IPP_RAN_MSG[260][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=12, fill=fill, message_id=29, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 12, constants.IPP_RAN_MSG[29][0], constants.IPP_RAN_MSG[29][1], constants.IPP_RAN_MSG[29][2], constants.IPP_RAN_MSG[29][3], constants.IPP_RAN_MSG[29][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 12, 260])
                                    range_info_grid.append([ws[i].title, j, 12, 29])
        
                        ### セル[20:13]: 被災世帯数について範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=13).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=13).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=13).value, float) == True:
                                if float(ws[i].cell(row=j, column=13).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=13, fill=fill, message_id=261)
                                    ### range_warn_grid.append([ws[i].title, j, 13, constants.IPP_RAN_MSG[261][0], constants.IPP_RAN_MSG[261][1], constants.IPP_RAN_MSG[261][2], constants.IPP_RAN_MSG[261][3], constants.IPP_RAN_MSG[261][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=13, fill=fill, message_id=30, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 13, constants.IPP_RAN_MSG[30][0], constants.IPP_RAN_MSG[30][1], constants.IPP_RAN_MSG[30][2], constants.IPP_RAN_MSG[30][3], constants.IPP_RAN_MSG[30][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 13, 261])
                                    range_info_grid.append([ws[i].title, j, 13, 30])
                        
                        ### セル[20:14]: 被災事業所数について範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=14).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=14).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=14).value, float) == True:
                                if float(ws[i].cell(row=j, column=14).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=262)
                                    ### range_warn_grid.append([ws[i].title, j, 14, constants.IPP_RAN_MSG[262][0], constants.IPP_RAN_MSG[262][1], constants.IPP_RAN_MSG[262][2], constants.IPP_RAN_MSG[262][3], constants.IPP_RAN_MSG[262][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=31, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 14, constants.IPP_RAN_MSG[31][0], constants.IPP_RAN_MSG[31][1], constants.IPP_RAN_MSG[31][2], constants.IPP_RAN_MSG[31][3], constants.IPP_RAN_MSG[31][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 14, 262])
                                    range_info_grid.append([ws[i].title, j, 14, 31])
        
                        ### セル[20:15]: 農家・漁家戸数, 床下浸水について範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=15).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=15).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=15).value, float) == True:
                                if float(ws[i].cell(row=j, column=15).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=15, fill=fill, message_id=263)
                                    ### range_warn_grid.append([ws[i].title, j, 15, constants.IPP_RAN_MSG[263][0], constants.IPP_RAN_MSG[263][1], constants.IPP_RAN_MSG[263][2], constants.IPP_RAN_MSG[263][3], constants.IPP_RAN_MSG[263][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=15, fill=fill, message_id=32, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 15, constants.IPP_RAN_MSG[32][0], constants.IPP_RAN_MSG[32][1], constants.IPP_RAN_MSG[32][2], constants.IPP_RAN_MSG[32][3], constants.IPP_RAN_MSG[32][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 15, 263])
                                    range_info_grid.append([ws[i].title, j, 15, 32])
        
                        ### セル[20:16]: 農家・漁家戸数, 1cm〜49cmについて範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=16).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=16).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=16).value, float) == True:
                                if float(ws[i].cell(row=j, column=16).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=16, fill=fill, message_id=264)
                                    ### range_warn_grid.append([ws[i].title, j, 16, constants.IPP_RAN_MSG[264][0], constants.IPP_RAN_MSG[264][1], constants.IPP_RAN_MSG[264][2], constants.IPP_RAN_MSG[264][3], constants.IPP_RAN_MSG[264][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=16, fill=fill, message_id=33, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 16, constants.IPP_RAN_MSG[33][0], constants.IPP_RAN_MSG[33][1], constants.IPP_RAN_MSG[33][2], constants.IPP_RAN_MSG[33][3], constants.IPP_RAN_MSG[33][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 16, 264])
                                    range_info_grid.append([ws[i].title, j, 16, 33])
        
                        ### セル[20:17]: 農家・漁家戸数, 50cm〜99cmについて範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=17).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=17).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=17).value, float) == True:
                                if float(ws[i].cell(row=j, column=17).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=17, fill=fill, message_id=265)
                                    ### range_warn_grid.append([ws[i].title, j, 17, constants.IPP_RAN_MSG[265][0], constants.IPP_RAN_MSG[265][1], constants.IPP_RAN_MSG[265][2], constants.IPP_RAN_MSG[265][3], constants.IPP_RAN_MSG[265][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=17, fill=fill, message_id=34, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 17, constants.IPP_RAN_MSG[34][0], constants.IPP_RAN_MSG[34][1], constants.IPP_RAN_MSG[34][2], constants.IPP_RAN_MSG[34][3], constants.IPP_RAN_MSG[34][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 17, 265])
                                    range_info_grid.append([ws[i].title, j, 17, 34])
        
                        ### セル[20:18]: 農家・漁家戸数, 1m以上・半壊について範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=18).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=18).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=18).value, float) == True:
                                if float(ws[i].cell(row=j, column=18).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=18, fill=fill, message_id=266)
                                    ### range_warn_grid.append([ws[i].title, j, 18, constants.IPP_RAN_MSG[266][0], constants.IPP_RAN_MSG[266][1], constants.IPP_RAN_MSG[266][2], constants.IPP_RAN_MSG[266][3], constants.IPP_RAN_MSG[266][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=18, fill=fill, message_id=35, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 18, constants.IPP_RAN_MSG[35][0], constants.IPP_RAN_MSG[35][1], constants.IPP_RAN_MSG[35][2], constants.IPP_RAN_MSG[35][3], constants.IPP_RAN_MSG[35][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 18, 266])
                                    range_info_grid.append([ws[i].title, j, 18, 35])
        
                        ### セル[20:19]: 農家・漁家戸数, 全壊・流失について範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=19).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=19).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=19).value, float) == True:
                                if float(ws[i].cell(row=j, column=19).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=19, fill=fill, message_id=267)
                                    ### range_warn_grid.append([ws[i].title, j, 19, constants.IPP_RAN_MSG[267][0], constants.IPP_RAN_MSG[267][1], constants.IPP_RAN_MSG[267][2], constants.IPP_RAN_MSG[267][3], constants.IPP_RAN_MSG[267][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=19, fill=fill, message_id=36, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 19, constants.IPP_RAN_MSG[36][0], constants.IPP_RAN_MSG[36][1], constants.IPP_RAN_MSG[36][2], constants.IPP_RAN_MSG[36][3], constants.IPP_RAN_MSG[36][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 19, 267])
                                    range_info_grid.append([ws[i].title, j, 19, 36])
        
                        ### セル[20:20]: 事業所従業者数, 床下浸水について範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=20).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=20).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=20).value, float) == True:
                                if float(ws[i].cell(row=j, column=20).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=20, fill=fill, message_id=268)
                                    ### range_warn_grid.append([ws[i].title, j, 20, constants.IPP_RAN_MSG[268][0], constants.IPP_RAN_MSG[268][1], constants.IPP_RAN_MSG[268][2], constants.IPP_RAN_MSG[268][3], constants.IPP_RAN_MSG[268][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=20, fill=fill, message_id=37, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 20, constants.IPP_RAN_MSG[37][0], constants.IPP_RAN_MSG[37][1], constants.IPP_RAN_MSG[37][2], constants.IPP_RAN_MSG[37][3], constants.IPP_RAN_MSG[37][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 20, 268])
                                    range_info_grid.append([ws[i].title, j, 20, 37])
        
                        ### セル[20:21]: 事業所従業者数, 1cm〜49cmについて範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=21).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=21).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=21).value, float) == True:
                                if float(ws[i].cell(row=j, column=21).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=21, fill=fill, message_id=269)
                                    ### range_warn_grid.append([ws[i].title, j, 21, constants.IPP_RAN_MSG[269][0], constants.IPP_RAN_MSG[269][1], constants.IPP_RAN_MSG[269][2], constants.IPP_RAN_MSG[269][3], constants.IPP_RAN_MSG[269][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=21, fill=fill, message_id=38, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 21, constants.IPP_RAN_MSG[38][0], constants.IPP_RAN_MSG[38][1], constants.IPP_RAN_MSG[38][2], constants.IPP_RAN_MSG[38][3], constants.IPP_RAN_MSG[38][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 21, 269])
                                    range_info_grid.append([ws[i].title, j, 21, 38])
        
                        ### セル[20:22]: 事業所従業者数, 50cm〜99cmについて範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=22).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=22).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=22).value, float) == True:
                                if float(ws[i].cell(row=j, column=22).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=22, fill=fill, message_id=270)
                                    ### range_warn_grid.append([ws[i].title, j, 22, constants.IPP_RAN_MSG[270][0], constants.IPP_RAN_MSG[270][1], constants.IPP_RAN_MSG[270][2], constants.IPP_RAN_MSG[270][3], constants.IPP_RAN_MSG[270][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=22, fill=fill, message_id=39, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 22, constants.IPP_RAN_MSG[39][0], constants.IPP_RAN_MSG[39][1], constants.IPP_RAN_MSG[39][2], constants.IPP_RAN_MSG[39][3], constants.IPP_RAN_MSG[39][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 22, 270])
                                    range_info_grid.append([ws[i].title, j, 22, 39])
        
                        ### セル[20:23]: 事業所従業者数, 1m以上・半壊について範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=23).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=23).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=23).value, float) == True:
                                if float(ws[i].cell(row=j, column=23).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=23, fill=fill, message_id=271)
                                    ### range_warn_grid.append([ws[i].title, j, 23, constants.IPP_RAN_MSG[271][0], constants.IPP_RAN_MSG[271][1], constants.IPP_RAN_MSG[271][2], constants.IPP_RAN_MSG[271][3], constants.IPP_RAN_MSG[271][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=23, fill=fill, message_id=40, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 23, constants.IPP_RAN_MSG[40][0], constants.IPP_RAN_MSG[40][1], constants.IPP_RAN_MSG[40][2], constants.IPP_RAN_MSG[40][3], constants.IPP_RAN_MSG[40][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 23, 271])
                                    range_info_grid.append([ws[i].title, j, 23, 40])
        
                        ### セル[20:24]: 事業所従業者数, 全壊・流失について範囲が正しいことをチェックする。
                        if ws[i].cell(row=j, column=24).value is None:
                            pass
                        else:
                            if isinstance(ws[i].cell(row=j, column=24).value, int) == True or \
                                isinstance(ws[i].cell(row=j, column=24).value, float) == True:
                                if float(ws[i].cell(row=j, column=24).value) < 0:
                                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=24, fill=fill, message_id=272)
                                    ### range_warn_grid.append([ws[i].title, j, 24, constants.IPP_RAN_MSG[272][0], constants.IPP_RAN_MSG[272][1], constants.IPP_RAN_MSG[272][2], constants.IPP_RAN_MSG[272][3], constants.IPP_RAN_MSG[272][4]])
                                    add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=24, fill=fill, message_id=41, message=constants.IPP_RAN_MSG)
                                    range_warn_grid.append([ws[i].title, j, 24, constants.IPP_RAN_MSG[41][0], constants.IPP_RAN_MSG[41][1], constants.IPP_RAN_MSG[41][2], constants.IPP_RAN_MSG[41][3], constants.IPP_RAN_MSG[41][4]])
                                else:
                                    ### range_info_grid.append([ws[i].title, j, 24, 272])
                                    range_info_grid.append([ws[i].title, j, 24, 41])
        
                        ### セル[20:25]: 事業所の産業区分について範囲が正しいことをチェックする。
                        ### セル[20:26]: 地下空間の利用形態について範囲が正しいことをチェックする。
                        ### セル[20:27]: 備考について範囲が正しいことをチェックする。
            return True
        except:
            return False
    
    ###########################################################################
    ### 関数内関数：EXCELセルデータ相関チェック処理
    ###########################################################################
    def check_correlate():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal correlate_warn_list
            nonlocal correlate_info_list
            nonlocal correlate_warn_grid
            nonlocal correlate_info_grid
            ### nonlocal max_row
            ###################################################################
            ### 関数内関数：EXCELセルデータ相関チェック処理（0000）
            ### (1)セル[7:2]からセル[7:9]について他項目との相関関係が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_correlate()関数 STEP 1/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                ### セル[7:2]: 都道府県が何かの値のときに、相関する市区町村名は正しく選択されているか。
                ### セル[7:3]: 市区町村が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[7:4]: 水害発生月日 vs セル[7:5]: 水害終了月日
                if ws[i].cell(row=7, column=4).value is None or \
                    ws[i].cell(row=7, column=5).value is None:
                    pass
                else:
                    if isdate(ws[i].cell(row=7, column=4).value) == False or \
                        isdate(ws[i].cell(row=7, column=5).value) == False:
                        pass
                    else:
                        ### 水害発生月日 > 水害終了月日である。
                        if datetime.strptime(ws[i].cell(row=7, column=4).value, '%Y/%m/%d') > datetime.strptime(ws[i].cell(row=7, column=5).value, '%Y/%m/%d'): 
                            ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=4, fill=fill, message_id=300)
                            ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=5, fill=fill, message_id=300)
                            ### correlate_warn_list.append([ws[i].title, 7, 4, constants.IPP_COR_MSG[300][0], constants.IPP_COR_MSG[300][1], constants.IPP_COR_MSG[300][2], constants.IPP_COR_MSG[300][3], constants.IPP_COR_MSG[300][4]])
                            ### correlate_warn_list.append([ws[i].title, 7, 5, constants.IPP_COR_MSG[300][0], constants.IPP_COR_MSG[300][1], constants.IPP_COR_MSG[300][2], constants.IPP_COR_MSG[300][3], constants.IPP_COR_MSG[300][4]])
                            add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=4, fill=fill, message_id=0, message=constants.IPP_COR_MSG)
                            add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=5, fill=fill, message_id=0, message=constants.IPP_COR_MSG)
                            correlate_warn_list.append([ws[i].title, 7, 4, constants.IPP_COR_MSG[0][0], constants.IPP_COR_MSG[0][1], constants.IPP_COR_MSG[0][2], constants.IPP_COR_MSG[0][3], constants.IPP_COR_MSG[0][4]])
                            correlate_warn_list.append([ws[i].title, 7, 5, constants.IPP_COR_MSG[0][0], constants.IPP_COR_MSG[0][1], constants.IPP_COR_MSG[0][2], constants.IPP_COR_MSG[0][3], constants.IPP_COR_MSG[0][4]])
                        else:
                            ### correlate_info_list.append([ws[i].title, 7, 4, 300])
                            ### correlate_info_list.append([ws[i].title, 7, 5, 300])
                            correlate_info_list.append([ws[i].title, 7, 4, 0])
                            correlate_info_list.append([ws[i].title, 7, 5, 0])
        
                ### セル[7:5]: 水害終了月日が何かの値のときに、相関する他項目は正しく選択されているか。 参照 セル[7:4]: 水害発生月日 vs セル[7:5]: 水害終了月日
                ### セル[7:6]: 水害原因1 vs セル[14:6]: 工種
                if ws[i].cell(row=7, column=6).value is None or \
                    ws[i].cell(row=14, column=6).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=7, column=6).value)[-1].isdecimal() == False or \
                        split_name_code(ws[i].cell(row=14, column=6).value)[-1].isdecimal() == False:
                        pass
                    else:
                        ### 水害原因が「10:破堤」「20:有堤部溢水」「30:無堤部溢水」「40:内水」の場合、相関する工種は、「1:河川」である。
                        if split_name_code(ws[i].cell(row=7, column=6).value)[-1] in [10, 20, 30, 40]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 1:
                                ### correlate_info_list.append([ws[i].title, 7, 6, 301])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 301])
                                correlate_info_list.append([ws[i].title, 7, 6, 1])
                                correlate_info_list.append([ws[i].title, 14, 6, 1])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=301)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=301)
                                ### correlate_warn_list.append([ws[i].title, 7, 6, constants.IPP_COR_MSG[301][0], constants.IPP_COR_MSG[301][1], constants.IPP_COR_MSG[301][2], constants.IPP_COR_MSG[301][3], constants.IPP_COR_MSG[301][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[301][0], constants.IPP_COR_MSG[301][1], constants.IPP_COR_MSG[301][2], constants.IPP_COR_MSG[301][3], constants.IPP_COR_MSG[301][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=1, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=1, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 6, constants.IPP_COR_MSG[1][0], constants.IPP_COR_MSG[1][1], constants.IPP_COR_MSG[1][2], constants.IPP_COR_MSG[1][3], constants.IPP_COR_MSG[1][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[1][0], constants.IPP_COR_MSG[1][1], constants.IPP_COR_MSG[1][2], constants.IPP_COR_MSG[1][3], constants.IPP_COR_MSG[1][4]])
                                
                        ### 水害原因が「50:窪地内水」「80:地すべり」「90:急傾斜地崩壊」の場合、相関する工種は、「3:河川海岸以外」である。
                        elif split_name_code(ws[i].cell(row=7, column=6).value)[-1] in [50, 80, 90]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 3:
                                ### correlate_info_list.append([ws[i].title, 7, 6, 302])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 302])
                                correlate_info_list.append([ws[i].title, 7, 6, 2])
                                correlate_info_list.append([ws[i].title, 14, 6, 2])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=302)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=302)
                                ### correlate_warn_list.append([ws[i].title, 7, 6, constants.IPP_COR_MSG[302][0], constants.IPP_COR_MSG[302][1], constants.IPP_COR_MSG[302][2], constants.IPP_COR_MSG[302][3], constants.IPP_COR_MSG[302][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[302][0], constants.IPP_COR_MSG[302][1], constants.IPP_COR_MSG[302][2], constants.IPP_COR_MSG[302][3], constants.IPP_COR_MSG[302][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=2, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=2, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 6, constants.IPP_COR_MSG[2][0], constants.IPP_COR_MSG[2][1], constants.IPP_COR_MSG[2][2], constants.IPP_COR_MSG[2][3], constants.IPP_COR_MSG[2][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[2][0], constants.IPP_COR_MSG[2][1], constants.IPP_COR_MSG[2][2], constants.IPP_COR_MSG[2][3], constants.IPP_COR_MSG[2][4]])
                                
                        ### 水害原因が「93:波浪」の場合、相関する工種は、「2:海岸」である。
                        elif split_name_code(ws[i].cell(row=7, column=6).value)[-1] in [93]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 2:
                                ### correlate_info_list.append([ws[i].title, 7, 6, 303])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 303])
                                correlate_info_list.append([ws[i].title, 7, 6, 3])
                                correlate_info_list.append([ws[i].title, 14, 6, 3])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=303)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=303)
                                ### correlate_warn_list.append([ws[i].title, 7, 6, constants.IPP_COR_MSG[303][0], constants.IPP_COR_MSG[303][1], constants.IPP_COR_MSG[303][2], constants.IPP_COR_MSG[303][3], constants.IPP_COR_MSG[303][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[303][0], constants.IPP_COR_MSG[303][1], constants.IPP_COR_MSG[303][2], constants.IPP_COR_MSG[303][3], constants.IPP_COR_MSG[303][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=3, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=3, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 6, constants.IPP_COR_MSG[3][0], constants.IPP_COR_MSG[3][1], constants.IPP_COR_MSG[3][2], constants.IPP_COR_MSG[3][3], constants.IPP_COR_MSG[3][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[3][0], constants.IPP_COR_MSG[3][1], constants.IPP_COR_MSG[3][2], constants.IPP_COR_MSG[3][3], constants.IPP_COR_MSG[3][4]])
                                
                        ### 水害原因が「60:洗堀・流出」「91:高潮」「92:津波」の場合、相関する工種は、「1:河川」「2:海岸」である。
                        elif split_name_code(ws[i].cell(row=7, column=6).value)[-1] in [60, 91, 92]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 1 or \
                                split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 2:
                                ### correlate_info_list.append([ws[i].title, 7, 6, 304])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 304])
                                correlate_info_list.append([ws[i].title, 7, 6, 4])
                                correlate_info_list.append([ws[i].title, 14, 6, 4])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=304)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=304)
                                ### correlate_warn_list.append([ws[i].title, 7, 6, constants.IPP_COR_MSG[304][0], constants.IPP_COR_MSG[304][1], constants.IPP_COR_MSG[304][2], constants.IPP_COR_MSG[304][3], constants.IPP_COR_MSG[304][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[304][0], constants.IPP_COR_MSG[304][1], constants.IPP_COR_MSG[304][2], constants.IPP_COR_MSG[304][3], constants.IPP_COR_MSG[304][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=4, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=4, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 6, constants.IPP_COR_MSG[4][0], constants.IPP_COR_MSG[4][1], constants.IPP_COR_MSG[4][2], constants.IPP_COR_MSG[4][3], constants.IPP_COR_MSG[4][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[4][0], constants.IPP_COR_MSG[4][1], constants.IPP_COR_MSG[4][2], constants.IPP_COR_MSG[4][3], constants.IPP_COR_MSG[4][4]])
                                
                        ### 水害原因が「70:土石流」の場合、相関する工種は、「1:河川」「3:河川海岸以外」である。
                        elif split_name_code(ws[i].cell(row=7, column=6).value)[-1] in [70]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 1 or \
                                split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 3:
                                ### correlate_info_list.append([ws[i].title, 7, 6, 305])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 305])
                                correlate_info_list.append([ws[i].title, 7, 6, 5])
                                correlate_info_list.append([ws[i].title, 14, 6, 5])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=305)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=305)
                                ### correlate_warn_list.append([ws[i].title, 7, 6, constants.IPP_COR_MSG[305][0], constants.IPP_COR_MSG[305][1], constants.IPP_COR_MSG[305][2], constants.IPP_COR_MSG[305][3], constants.IPP_COR_MSG[305][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[305][0], constants.IPP_COR_MSG[305][1], constants.IPP_COR_MSG[305][2], constants.IPP_COR_MSG[305][3], constants.IPP_COR_MSG[305][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=5, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=5, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 6, constants.IPP_COR_MSG[5][0], constants.IPP_COR_MSG[5][1], constants.IPP_COR_MSG[5][2], constants.IPP_COR_MSG[5][3], constants.IPP_COR_MSG[5][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[5][0], constants.IPP_COR_MSG[5][1], constants.IPP_COR_MSG[5][2], constants.IPP_COR_MSG[5][3], constants.IPP_COR_MSG[5][4]])
                        else:
                            pass
        
                ### セル[7:7]: 水害原因2 vs セル[14:6]: 工種
                if ws[i].cell(row=7, column=7).value is None or \
                    ws[i].cell(row=14, column=6).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=7, column=7).value)[-1].isdecimal() == False or \
                        split_name_code(ws[i].cell(row=14, column=6).value)[-1].isdecimal() == False:
                        pass
                    else:
                        ### 水害原因が「10:破堤」「20:有堤部溢水」「30:無堤部溢水」「40:内水」の場合、相関する工種は、「1:河川」である。
                        if split_name_code(ws[i].cell(row=7, column=7).value)[-1] in [10, 20, 30, 40]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 1:
                                ### correlate_info_list.append([ws[i].title, 7, 7, 306])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 306])
                                correlate_info_list.append([ws[i].title, 7, 7, 6])
                                correlate_info_list.append([ws[i].title, 14, 6, 6])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=306)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=306)
                                ### correlate_warn_list.append([ws[i].title, 7, 7, constants.IPP_COR_MSG[306][0], constants.IPP_COR_MSG[306][1], constants.IPP_COR_MSG[306][2], constants.IPP_COR_MSG[306][3], constants.IPP_COR_MSG[306][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[306][0], constants.IPP_COR_MSG[306][1], constants.IPP_COR_MSG[306][2], constants.IPP_COR_MSG[306][3], constants.IPP_COR_MSG[306][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=6, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=6, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 7, constants.IPP_COR_MSG[6][0], constants.IPP_COR_MSG[6][1], constants.IPP_COR_MSG[6][2], constants.IPP_COR_MSG[6][3], constants.IPP_COR_MSG[6][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[6][0], constants.IPP_COR_MSG[6][1], constants.IPP_COR_MSG[6][2], constants.IPP_COR_MSG[6][3], constants.IPP_COR_MSG[6][4]])
                                
                        ### 水害原因が「50:窪地内水」「80:地すべり」「90:急傾斜地崩壊」の場合、相関する工種は、「3:河川海岸以外」である。
                        elif split_name_code(ws[i].cell(row=7, column=7).value)[-1] in [50, 80, 90]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 3:
                                ### correlate_info_list.append([ws[i].title, 7, 7, 307])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 307])
                                correlate_info_list.append([ws[i].title, 7, 7, 7])
                                correlate_info_list.append([ws[i].title, 14, 6, 7])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=307)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=307)
                                ### correlate_warn_list.append([ws[i].title, 7, 7, constants.IPP_COR_MSG[307][0], constants.IPP_COR_MSG[307][1], constants.IPP_COR_MSG[307][2], constants.IPP_COR_MSG[307][3], constants.IPP_COR_MSG[307][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[307][0], constants.IPP_COR_MSG[307][1], constants.IPP_COR_MSG[307][2], constants.IPP_COR_MSG[307][3], constants.IPP_COR_MSG[307][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=7, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=7, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 7, constants.IPP_COR_MSG[7][0], constants.IPP_COR_MSG[7][1], constants.IPP_COR_MSG[7][2], constants.IPP_COR_MSG[7][3], constants.IPP_COR_MSG[7][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[7][0], constants.IPP_COR_MSG[7][1], constants.IPP_COR_MSG[7][2], constants.IPP_COR_MSG[7][3], constants.IPP_COR_MSG[7][4]])
                                
                        ### 水害原因が「93:波浪」の場合、相関する工種は、「2:海岸」である。
                        elif split_name_code(ws[i].cell(row=7, column=7).value)[-1] in [93]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 2:
                                ### correlate_info_list.append([ws[i].title, 7, 7, 308])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 308])
                                correlate_info_list.append([ws[i].title, 7, 7, 8])
                                correlate_info_list.append([ws[i].title, 14, 6, 8])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=308)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=308)
                                ### correlate_warn_list.append([ws[i].title, 7, 7, constants.IPP_COR_MSG[308][0], constants.IPP_COR_MSG[308][1], constants.IPP_COR_MSG[308][2], constants.IPP_COR_MSG[308][3], constants.IPP_COR_MSG[308][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[308][0], constants.IPP_COR_MSG[308][1], constants.IPP_COR_MSG[308][2], constants.IPP_COR_MSG[308][3], constants.IPP_COR_MSG[308][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=8, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=8, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 7, constants.IPP_COR_MSG[8][0], constants.IPP_COR_MSG[8][1], constants.IPP_COR_MSG[8][2], constants.IPP_COR_MSG[308][3], constants.IPP_COR_MSG[8][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[8][0], constants.IPP_COR_MSG[8][1], constants.IPP_COR_MSG[8][2], constants.IPP_COR_MSG[308][3], constants.IPP_COR_MSG[8][4]])
                                
                        ### 水害原因が「60:洗堀・流出」「91:高潮」「92:津波」の場合、相関する工種は、「1:河川」「2:海岸」である。
                        elif split_name_code(ws[i].cell(row=7, column=7).value)[-1] in [60, 91, 92]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 1 or \
                                split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 2:
                                ### correlate_info_list.append([ws[i].title, 7, 7, 309])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 309])
                                correlate_info_list.append([ws[i].title, 7, 7, 9])
                                correlate_info_list.append([ws[i].title, 14, 6, 9])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=309)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=309)
                                ### correlate_warn_list.append([ws[i].title, 7, 7, constants.IPP_COR_MSG[309][0], constants.IPP_COR_MSG[309][1], constants.IPP_COR_MSG[309][2], constants.IPP_COR_MSG[309][3], constants.IPP_COR_MSG[309][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[309][0], constants.IPP_COR_MSG[309][1], constants.IPP_COR_MSG[309][2], constants.IPP_COR_MSG[309][3], constants.IPP_COR_MSG[309][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=9, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=9, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 7, constants.IPP_COR_MSG[9][0], constants.IPP_COR_MSG[9][1], constants.IPP_COR_MSG[9][2], constants.IPP_COR_MSG[9][3], constants.IPP_COR_MSG[9][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[9][0], constants.IPP_COR_MSG[9][1], constants.IPP_COR_MSG[9][2], constants.IPP_COR_MSG[9][3], constants.IPP_COR_MSG[9][4]])
                                
                        ### 水害原因が「70:土石流」の場合、相関する工種は、「1:河川」「3:河川海岸以外」である。
                        elif split_name_code(ws[i].cell(row=7, column=7).value)[-1] in [70]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 1 or \
                                split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 3:
                                ### correlate_info_list.append([ws[i].title, 7, 7, 310])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 310])
                                correlate_info_list.append([ws[i].title, 7, 7, 10])
                                correlate_info_list.append([ws[i].title, 14, 6, 10])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=310)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=310)
                                ### correlate_warn_list.append([ws[i].title, 7, 7, constants.IPP_COR_MSG[310][0], constants.IPP_COR_MSG[310][1], constants.IPP_COR_MSG[310][2], constants.IPP_COR_MSG[310][3], constants.IPP_COR_MSG[310][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[310][0], constants.IPP_COR_MSG[310][1], constants.IPP_COR_MSG[310][2], constants.IPP_COR_MSG[310][3], constants.IPP_COR_MSG[310][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=10, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=10, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 7, constants.IPP_COR_MSG[10][0], constants.IPP_COR_MSG[10][1], constants.IPP_COR_MSG[10][2], constants.IPP_COR_MSG[10][3], constants.IPP_COR_MSG[10][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[10][0], constants.IPP_COR_MSG[10][1], constants.IPP_COR_MSG[10][2], constants.IPP_COR_MSG[10][3], constants.IPP_COR_MSG[10][4]])
                        else:
                            pass
        
                ### セル[7:8]: 水害原因3 vs セル[14:6]: 工種
                if ws[i].cell(row=7, column=8).value is None or \
                    ws[i].cell(row=14, column=6).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=7, column=8).value)[-1].isdecimal() == False or \
                        split_name_code(ws[i].cell(row=14, column=6).value)[-1].isdecimal() == False:
                        pass
                    else:
                        ### 水害原因が「10:破堤」「20:有堤部溢水」「30:無堤部溢水」「40:内水」の場合、相関する工種は、「1:河川」である。
                        if split_name_code(ws[i].cell(row=7, column=8).value)[-1] in [10, 20, 30, 40]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 1:
                                ### correlate_info_list.append([ws[i].title, 7, 8, 311])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 311])
                                correlate_info_list.append([ws[i].title, 7, 8, 11])
                                correlate_info_list.append([ws[i].title, 14, 6, 11])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=311)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=311)
                                ### correlate_warn_list.append([ws[i].title, 7, 8, constants.IPP_COR_MSG[311][0], constants.IPP_COR_MSG[311][1], constants.IPP_COR_MSG[311][2], constants.IPP_COR_MSG[311][3], constants.IPP_COR_MSG[311][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[311][0], constants.IPP_COR_MSG[311][1], constants.IPP_COR_MSG[311][2], constants.IPP_COR_MSG[311][3], constants.IPP_COR_MSG[311][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=11, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=11, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 8, constants.IPP_COR_MSG[11][0], constants.IPP_COR_MSG[11][1], constants.IPP_COR_MSG[11][2], constants.IPP_COR_MSG[11][3], constants.IPP_COR_MSG[11][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[11][0], constants.IPP_COR_MSG[11][1], constants.IPP_COR_MSG[11][2], constants.IPP_COR_MSG[11][3], constants.IPP_COR_MSG[11][4]])
                                
                        ### 水害原因が「50:窪地内水」「80:地すべり」「90:急傾斜地崩壊」の場合、相関する工種は、「3:河川海岸以外」である。
                        elif split_name_code(ws[i].cell(row=7, column=8).value)[-1] in [50, 80, 90]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 3:
                                ### correlate_info_list.append([ws[i].title, 7, 8, 312])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 312])
                                correlate_info_list.append([ws[i].title, 7, 8, 12])
                                correlate_info_list.append([ws[i].title, 14, 6, 12])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=312)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=312)
                                ### correlate_warn_list.append([ws[i].title, 7, 8, constants.IPP_COR_MSG[312][0], constants.IPP_COR_MSG[312][1], constants.IPP_COR_MSG[312][2], constants.IPP_COR_MSG[312][3], constants.IPP_COR_MSG[312][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[312][0], constants.IPP_COR_MSG[312][1], constants.IPP_COR_MSG[312][2], constants.IPP_COR_MSG[312][3], constants.IPP_COR_MSG[312][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=12, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=12, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 8, constants.IPP_COR_MSG[12][0], constants.IPP_COR_MSG[12][1], constants.IPP_COR_MSG[12][2], constants.IPP_COR_MSG[12][3], constants.IPP_COR_MSG[12][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[12][0], constants.IPP_COR_MSG[12][1], constants.IPP_COR_MSG[12][2], constants.IPP_COR_MSG[12][3], constants.IPP_COR_MSG[12][4]])
                                
                        ### 水害原因が「93:波浪」の場合、相関する工種は、「2:海岸」である。
                        elif split_name_code(ws[i].cell(row=7, column=8).value)[-1] in [93]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 2:
                                ### correlate_info_list.append([ws[i].title, 7, 8, 313])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 313])
                                correlate_info_list.append([ws[i].title, 7, 8, 13])
                                correlate_info_list.append([ws[i].title, 14, 6, 13])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=313)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=313)
                                ### correlate_warn_list.append([ws[i].title, 7, 8, constants.IPP_COR_MSG[313][0], constants.IPP_COR_MSG[313][1], constants.IPP_COR_MSG[313][2], constants.IPP_COR_MSG[313][3], constants.IPP_COR_MSG[313][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[313][0], constants.IPP_COR_MSG[313][1], constants.IPP_COR_MSG[313][2], constants.IPP_COR_MSG[313][3], constants.IPP_COR_MSG[313][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=13, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=13, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 8, constants.IPP_COR_MSG[13][0], constants.IPP_COR_MSG[13][1], constants.IPP_COR_MSG[13][2], constants.IPP_COR_MSG[13][3], constants.IPP_COR_MSG[13][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[13][0], constants.IPP_COR_MSG[13][1], constants.IPP_COR_MSG[13][2], constants.IPP_COR_MSG[13][3], constants.IPP_COR_MSG[13][4]])
                                
                        ### 水害原因が「60:洗堀・流出」「91:高潮」「92:津波」の場合、相関する工種は、「1:河川」「2:海岸」である。
                        elif split_name_code(ws[i].cell(row=7, column=8).value)[-1] in [60, 91, 92]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 1 or \
                                split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 2:
                                ### correlate_info_list.append([ws[i].title, 7, 8, 314])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 314])
                                correlate_info_list.append([ws[i].title, 7, 8, 14])
                                correlate_info_list.append([ws[i].title, 14, 6, 14])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=314)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=314)
                                ### correlate_warn_list.append([ws[i].title, 7, 8, constants.IPP_COR_MSG[314][0], constants.IPP_COR_MSG[314][1], constants.IPP_COR_MSG[314][2], constants.IPP_COR_MSG[314][3], constants.IPP_COR_MSG[314][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[314][0], constants.IPP_COR_MSG[314][1], constants.IPP_COR_MSG[314][2], constants.IPP_COR_MSG[314][3], constants.IPP_COR_MSG[314][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=14, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=14, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 8, constants.IPP_COR_MSG[14][0], constants.IPP_COR_MSG[14][1], constants.IPP_COR_MSG[14][2], constants.IPP_COR_MSG[14][3], constants.IPP_COR_MSG[14][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[14][0], constants.IPP_COR_MSG[14][1], constants.IPP_COR_MSG[14][2], constants.IPP_COR_MSG[14][3], constants.IPP_COR_MSG[14][4]])
                                
                        ### 水害原因が「70:土石流」の場合、相関する工種は、「1:河川」「3:河川海岸以外」である。
                        elif split_name_code(ws[i].cell(row=7, column=8).value)[-1] in [70]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 1 or \
                                split_name_code(ws[i].cell(row=14, column=6).value)[-1] == 3:
                                ### correlate_info_list.append([ws[i].title, 7, 8, 315])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 315])
                                correlate_info_list.append([ws[i].title, 7, 8, 15])
                                correlate_info_list.append([ws[i].title, 14, 6, 15])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=315)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=315)
                                ### correlate_warn_list.append([ws[i].title, 7, 8, constants.IPP_COR_MSG[315][0], constants.IPP_COR_MSG[315][1], constants.IPP_COR_MSG[315][2], constants.IPP_COR_MSG[315][3], constants.IPP_COR_MSG[315][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[315][0], constants.IPP_COR_MSG[315][1], constants.IPP_COR_MSG[315][2], constants.IPP_COR_MSG[315][3], constants.IPP_COR_MSG[315][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=15, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=15, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 7, 8, constants.IPP_COR_MSG[15][0], constants.IPP_COR_MSG[15][1], constants.IPP_COR_MSG[15][2], constants.IPP_COR_MSG[15][3], constants.IPP_COR_MSG[15][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[15][0], constants.IPP_COR_MSG[15][1], constants.IPP_COR_MSG[15][2], constants.IPP_COR_MSG[15][3], constants.IPP_COR_MSG[15][4]])
                        else:
                            pass
        
                ### セル[7:9]: 水害区域番号が何かの値のときに、相関する他項目は正しく選択されているか。
        
            ###################################################################
            ### 関数内関数：EXCELセルデータ相関チェック処理（0010）
            ### (1)セル[10:2]からセル[10:6]について他項目との相関関係が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_correlate()関数 STEP 2/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                ### セル[10:2]: 水系・沿岸名が何かの値のときに、相関する水系種別は正しく選択されているか。
                ### if ws[i].cell(row=10, column=2).value is None:
                ###     result_correlate_list.append([ws[i].title, 10, 2, constants.MESSAGE[][0], constants.MESSAGE[][1], constants.MESSAGE[][2], constants.MESSAGE[][3], constants.MESSAGE[][4]])
                ### セル[10:2]: 水系・沿岸名が何かの値のときに、相関する工種は正しく選択されているか。
                ### if ws[i].cell(row=10, column=2).value is None or \
                ###     ws[i].cell(row=14, column=6).value is None:
                ###     pass
                ### else:
                ###     if split_name_code(ws[i].cell(row=10, column=2).value)[-1].isdecimal() == False or \
                ###         split_name_code(ws[i].cell(row=14, column=6).value)[-1].isdecimal() == False:
                ###         pass
                ###     else:
                ###         ### 水系・沿岸名が「水系」のときに、相関する工種は、「1:河川」である。
                ###         if split_name_code(ws[i].cell(row=10, column=2).value)[-1] == :
                ###             if split_name_code(ws[i].cell(row=14, column=6).value)[-1] in [1]:
                ###                 correlate_info_list.append([ws[i].title, 14, 6, ])
                ###             else:
                ###                 add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=)
                ###                 correlate_warn_list.append([ws[i].title, 14, 6, ])
                ###         ### 水系・沿岸名が「沿岸」のときに、相関する工種は、「2:海岸」である。
                ###         elif split_name_code(ws[i].cell(row=10, column=2).value)[-1] == :
                ###             if split_name_code(ws[i].cell(row=14, column=6).value)[-1] in [2]:
                ###                 correlate_info_list.append([ws[i].title, 14, 6, ])
                ###             else:
                ###                 add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=)
                ###                 correlate_warn_list.append([ws[i].title, 14, 6, ])
                ###         ### 水系・沿岸名が「河川海岸以外」のときに、相関する工種は、「3:河川海岸以外」である。
                ###         elif split_name_code(ws[i].cell(row=10, column=2).value)[-1] == :
                ###             if split_name_code(ws[i].cell(row=14, column=6).value)[-1] in [3]:
                ###                 correlate_info_list.append([ws[i].title, 14, 6, ])
                ###             else:
                ###                 add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=)
                ###                 correlate_warn_list.append([ws[i].title, 14, 6, ])
                ###         else:
                ###             pass
                ### セル[10:3]: 水系種別 vs セル[10:5]: 河川種別
                if ws[i].cell(row=10, column=3).value is None or \
                    ws[i].cell(row=10, column=5).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=10, column=3).value)[-1].isdecimal() == False or \
                        split_name_code(ws[i].cell(row=10, column=5).value)[-1].isdecimal() == False:
                        pass
                    else:
                        ### 水系種別が「1:一級」のときに、相関する河川種別は、「1:直轄」「2:指定」「4:準用」「5:普通」である。
                        if split_name_code(ws[i].cell(row=10, column=3).value)[-1] == 1:
                            if split_name_code(ws[i].cell(row=10, column=5).value)[-1] in [1, 2, 4, 5]:
                                ### correlate_info_list.append([ws[i].title, 10, 3, 320])
                                ### correlate_info_list.append([ws[i].title, 10, 5, 320])
                                correlate_info_list.append([ws[i].title, 10, 3, 16])
                                correlate_info_list.append([ws[i].title, 10, 5, 16])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=320)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=320)
                                ### correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[320][0], constants.IPP_COR_MSG[320][1], constants.IPP_COR_MSG[320][2], constants.IPP_COR_MSG[320][3], constants.IPP_COR_MSG[320][4]])
                                ### correlate_warn_list.append([ws[i].title, 10, 5, constants.IPP_COR_MSG[320][0], constants.IPP_COR_MSG[320][1], constants.IPP_COR_MSG[320][2], constants.IPP_COR_MSG[320][3], constants.IPP_COR_MSG[320][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=16, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=16, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[16][0], constants.IPP_COR_MSG[16][1], constants.IPP_COR_MSG[16][2], constants.IPP_COR_MSG[16][3], constants.IPP_COR_MSG[16][4]])
                                correlate_warn_list.append([ws[i].title, 10, 5, constants.IPP_COR_MSG[16][0], constants.IPP_COR_MSG[16][1], constants.IPP_COR_MSG[16][2], constants.IPP_COR_MSG[16][3], constants.IPP_COR_MSG[16][4]])
    
                        ### 水系種別が「2:二級」のときに、相関する河川種別は、「3:二級」「4:準用」「5:普通」である。
                        elif split_name_code(ws[i].cell(row=10, column=3).value)[-1] == 2:
                            if split_name_code(ws[i].cell(row=10, column=5).value)[-1] in [3, 4, 5]:
                                ### correlate_info_list.append([ws[i].title, 10, 3, 321])
                                ### correlate_info_list.append([ws[i].title, 10, 5, 321])
                                correlate_info_list.append([ws[i].title, 10, 3, 17])
                                correlate_info_list.append([ws[i].title, 10, 5, 17])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=321)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=321)
                                ### correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[321][0], constants.IPP_COR_MSG[321][1], constants.IPP_COR_MSG[321][2], constants.IPP_COR_MSG[321][3], constants.IPP_COR_MSG[321][4]])
                                ### correlate_warn_list.append([ws[i].title, 10, 5, constants.IPP_COR_MSG[321][0], constants.IPP_COR_MSG[321][1], constants.IPP_COR_MSG[321][2], constants.IPP_COR_MSG[321][3], constants.IPP_COR_MSG[321][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=17, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=17, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[17][0], constants.IPP_COR_MSG[17][1], constants.IPP_COR_MSG[17][2], constants.IPP_COR_MSG[17][3], constants.IPP_COR_MSG[17][4]])
                                correlate_warn_list.append([ws[i].title, 10, 5, constants.IPP_COR_MSG[17][0], constants.IPP_COR_MSG[17][1], constants.IPP_COR_MSG[17][2], constants.IPP_COR_MSG[17][3], constants.IPP_COR_MSG[17][4]])
    
                        ### 水系種別が「3:準用」のときに、相関する河川種別は、「4:準用」「5:普通」である。
                        elif split_name_code(ws[i].cell(row=10, column=3).value)[-1] == 3:
                            if split_name_code(ws[i].cell(row=10, column=5).value)[-1] in [4, 5]:
                                ### correlate_info_list.append([ws[i].title, 10, 3, 322])
                                ### correlate_info_list.append([ws[i].title, 10, 5, 322])
                                correlate_info_list.append([ws[i].title, 10, 3, 18])
                                correlate_info_list.append([ws[i].title, 10, 5, 18])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=322)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=322)
                                ### correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[322][0], constants.IPP_COR_MSG[322][1], constants.IPP_COR_MSG[322][2], constants.IPP_COR_MSG[322][3], constants.IPP_COR_MSG[322][4]])
                                ### correlate_warn_list.append([ws[i].title, 10, 5, constants.IPP_COR_MSG[322][0], constants.IPP_COR_MSG[322][1], constants.IPP_COR_MSG[322][2], constants.IPP_COR_MSG[322][3], constants.IPP_COR_MSG[322][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=18, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=18, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[18][0], constants.IPP_COR_MSG[18][1], constants.IPP_COR_MSG[18][2], constants.IPP_COR_MSG[18][3], constants.IPP_COR_MSG[18][4]])
                                correlate_warn_list.append([ws[i].title, 10, 5, constants.IPP_COR_MSG[18][0], constants.IPP_COR_MSG[18][1], constants.IPP_COR_MSG[18][2], constants.IPP_COR_MSG[18][3], constants.IPP_COR_MSG[18][4]])
    
                        ### 水系種別が「4:普通」のときに、相関する河川種別は、「5:普通」である。
                        elif split_name_code(ws[i].cell(row=10, column=3).value)[-1] == 4:
                            if split_name_code(ws[i].cell(row=10, column=5).value)[-1] in [5]:
                                ### correlate_info_list.append([ws[i].title, 10, 3, 323])
                                ### correlate_info_list.append([ws[i].title, 10, 5, 323])
                                correlate_info_list.append([ws[i].title, 10, 3, 19])
                                correlate_info_list.append([ws[i].title, 10, 5, 19])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=323)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=323)
                                ### correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[323][0], constants.IPP_COR_MSG[323][1], constants.IPP_COR_MSG[323][2], constants.IPP_COR_MSG[323][3], constants.IPP_COR_MSG[323][4]])
                                ### correlate_warn_list.append([ws[i].title, 10, 5, constants.IPP_COR_MSG[323][0], constants.IPP_COR_MSG[323][1], constants.IPP_COR_MSG[323][2], constants.IPP_COR_MSG[323][3], constants.IPP_COR_MSG[323][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=19, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=19, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[19][0], constants.IPP_COR_MSG[19][1], constants.IPP_COR_MSG[19][2], constants.IPP_COR_MSG[19][3], constants.IPP_COR_MSG[19][4]])
                                correlate_warn_list.append([ws[i].title, 10, 5, constants.IPP_COR_MSG[19][0], constants.IPP_COR_MSG[19][1], constants.IPP_COR_MSG[19][2], constants.IPP_COR_MSG[19][3], constants.IPP_COR_MSG[19][4]])
    
                        ### 水系種別が「5:沿岸」のときに、相関する河川種別は、「6:海岸」である。
                        elif split_name_code(ws[i].cell(row=10, column=3).value)[-1] == 5:
                            if split_name_code(ws[i].cell(row=10, column=5).value)[-1] in [6]:
                                ### correlate_info_list.append([ws[i].title, 10, 3, 324])
                                ### correlate_info_list.append([ws[i].title, 10, 5, 324])
                                correlate_info_list.append([ws[i].title, 10, 3, 20])
                                correlate_info_list.append([ws[i].title, 10, 5, 20])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=324)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=324)
                                ### correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[324][0], constants.IPP_COR_MSG[324][1], constants.IPP_COR_MSG[324][2], constants.IPP_COR_MSG[324][3], constants.IPP_COR_MSG[324][4]])
                                ### correlate_warn_list.append([ws[i].title, 10, 5, constants.IPP_COR_MSG[324][0], constants.IPP_COR_MSG[324][1], constants.IPP_COR_MSG[324][2], constants.IPP_COR_MSG[324][3], constants.IPP_COR_MSG[324][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=20, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=20, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[20][0], constants.IPP_COR_MSG[20][1], constants.IPP_COR_MSG[20][2], constants.IPP_COR_MSG[20][3], constants.IPP_COR_MSG[20][4]])
                                correlate_warn_list.append([ws[i].title, 10, 5, constants.IPP_COR_MSG[20][0], constants.IPP_COR_MSG[20][1], constants.IPP_COR_MSG[20][2], constants.IPP_COR_MSG[20][3], constants.IPP_COR_MSG[20][4]])
    
                        ### 水系種別が「6:河川海岸以外」のときに、相関する河川種別は、「7:河川海岸以外」である。
                        elif split_name_code(ws[i].cell(row=10, column=3).value)[-1] == 6:
                            if split_name_code(ws[i].cell(row=10, column=5).value)[-1] in [7]:
                                ### correlate_info_list.append([ws[i].title, 10, 3, 325])
                                ### correlate_info_list.append([ws[i].title, 10, 5, 325])
                                correlate_info_list.append([ws[i].title, 10, 3, 21])
                                correlate_info_list.append([ws[i].title, 10, 5, 21])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=325)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=325)
                                ### correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[325][0], constants.IPP_COR_MSG[325][1], constants.IPP_COR_MSG[325][2], constants.IPP_COR_MSG[325][3], constants.IPP_COR_MSG[325][4]])
                                ### correlate_warn_list.append([ws[i].title, 10, 5, constants.IPP_COR_MSG[325][0], constants.IPP_COR_MSG[325][1], constants.IPP_COR_MSG[325][2], constants.IPP_COR_MSG[325][3], constants.IPP_COR_MSG[325][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=21, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=21, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[21][0], constants.IPP_COR_MSG[21][1], constants.IPP_COR_MSG[21][2], constants.IPP_COR_MSG[21][3], constants.IPP_COR_MSG[21][4]])
                                correlate_warn_list.append([ws[i].title, 10, 5, constants.IPP_COR_MSG[21][0], constants.IPP_COR_MSG[21][1], constants.IPP_COR_MSG[21][2], constants.IPP_COR_MSG[21][3], constants.IPP_COR_MSG[21][4]])
                        else:
                            pass
    
                ### セル[10:3]: 水系種別 vs セル[14:6]: 工種
                if ws[i].cell(row=10, column=3).value is None or \
                    ws[i].cell(row=14, column=6).value is None:
                    pass
                else:
                    if split_name_code(ws[i].cell(row=10, column=3).value)[-1].isdecimal() == False or \
                        split_name_code(ws[i].cell(row=14, column=6).value)[-1].isdecimal() == False:
                        pass
                    else:
                        ### 水系種別が「1:一級」「2:二級」「3:準用」「4:普通」のときに、相関する工種は、「1:河川」である。
                        if split_name_code(ws[i].cell(row=10, column=3).value)[-1] in [1, 2, 3, 4]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] in [1]:
                                ### correlate_info_list.append([ws[i].title, 10, 3, 326])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 326])
                                correlate_info_list.append([ws[i].title, 10, 3, 22])
                                correlate_info_list.append([ws[i].title, 14, 6, 22])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=326)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=326)
                                ### correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[326][0], constants.IPP_COR_MSG[326][1], constants.IPP_COR_MSG[326][2], constants.IPP_COR_MSG[326][3], constants.IPP_COR_MSG[326][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[326][0], constants.IPP_COR_MSG[326][1], constants.IPP_COR_MSG[326][2], constants.IPP_COR_MSG[326][3], constants.IPP_COR_MSG[326][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=22, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=22, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[22][0], constants.IPP_COR_MSG[22][1], constants.IPP_COR_MSG[22][2], constants.IPP_COR_MSG[22][3], constants.IPP_COR_MSG[22][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[22][0], constants.IPP_COR_MSG[22][1], constants.IPP_COR_MSG[22][2], constants.IPP_COR_MSG[22][3], constants.IPP_COR_MSG[22][4]])
                    
                        ### 水系種別が「5:沿岸」のときに、相関する工種は、「2:海岸」である。
                        elif split_name_code(ws[i].cell(row=10, column=3).value)[-1] in [5]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] in [2]:
                                ### correlate_info_list.append([ws[i].title, 10, 3, 327])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 327])
                                correlate_info_list.append([ws[i].title, 10, 3, 23])
                                correlate_info_list.append([ws[i].title, 14, 6, 23])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=327)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=327)
                                ### correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[327][0], constants.IPP_COR_MSG[327][1], constants.IPP_COR_MSG[327][2], constants.IPP_COR_MSG[327][3], constants.IPP_COR_MSG[327][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[327][0], constants.IPP_COR_MSG[327][1], constants.IPP_COR_MSG[327][2], constants.IPP_COR_MSG[327][3], constants.IPP_COR_MSG[327][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=23, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=23, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[23][0], constants.IPP_COR_MSG[23][1], constants.IPP_COR_MSG[23][2], constants.IPP_COR_MSG[23][3], constants.IPP_COR_MSG[23][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[23][0], constants.IPP_COR_MSG[23][1], constants.IPP_COR_MSG[23][2], constants.IPP_COR_MSG[23][3], constants.IPP_COR_MSG[23][4]])
                                
                        ### 水系種別が「6:河川海岸以外」のときに、相関する工種は、「3:河川海岸以外」である。
                        elif split_name_code(ws[i].cell(row=10, column=3).value)[-1] in [6]:
                            if split_name_code(ws[i].cell(row=14, column=6).value)[-1] in [6]:
                                ### correlate_info_list.append([ws[i].title, 10, 3, 328])
                                ### correlate_info_list.append([ws[i].title, 14, 6, 328])
                                correlate_info_list.append([ws[i].title, 10, 3, 24])
                                correlate_info_list.append([ws[i].title, 14, 6, 24])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=328)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=328)
                                ### correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[328][0], constants.IPP_COR_MSG[328][1], constants.IPP_COR_MSG[328][2], constants.IPP_COR_MSG[328][3], constants.IPP_COR_MSG[328][4]])
                                ### correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[328][0], constants.IPP_COR_MSG[328][1], constants.IPP_COR_MSG[328][2], constants.IPP_COR_MSG[328][3], constants.IPP_COR_MSG[328][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=24, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=6, fill=fill, message_id=24, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, 10, 3, constants.IPP_COR_MSG[24][0], constants.IPP_COR_MSG[24][1], constants.IPP_COR_MSG[24][2], constants.IPP_COR_MSG[24][3], constants.IPP_COR_MSG[24][4]])
                                correlate_warn_list.append([ws[i].title, 14, 6, constants.IPP_COR_MSG[24][0], constants.IPP_COR_MSG[24][1], constants.IPP_COR_MSG[24][2], constants.IPP_COR_MSG[24][3], constants.IPP_COR_MSG[24][4]])
                        else:
                            pass
    
                ### セル[10:4]: 河川・海岸名が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[10:5]: 河川種別が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[10:6]: 地盤勾配区分が何かの値のときに、相関する他項目は正しく選択されているか。
        
            ###################################################################
            ### 関数内関数：EXCELセルデータ相関チェック処理（0020）
            ### (1)セル[14:2]からセル[14:10]について他項目との相関関係が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_correlate()関数 STEP 3/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                ### セル[14:3]: 水害区域面積の農地 vs セル[14:8]: 農作物被害額
                ### セル[14:3]: 水害区域面積の農地がNoneのとき、農作物被害額はNoneが正しい。
                if ws[i].cell(row=14, column=3).value is None:
                    if ws[i].cell(row=14, column=8).value is None:
                        ### correlate_info_list.append([ws[i].title, 14, 3, 340])
                        ### correlate_info_list.append([ws[i].title, 14, 8, 340])
                        correlate_info_list.append([ws[i].title, 14, 3, 25])
                        correlate_info_list.append([ws[i].title, 14, 8, 25])
                    else:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=3, fill=fill, message_id=340)
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=8, fill=fill, message_id=340)
                        ### correlate_warn_list.append([ws[i].title, 14, 3, constants.IPP_COR_MSG[340][0], constants.IPP_COR_MSG[340][1], constants.IPP_COR_MSG[340][2], constants.IPP_COR_MSG[340][3], constants.IPP_COR_MSG[340][4]])
                        ### correlate_warn_list.append([ws[i].title, 14, 8, constants.IPP_COR_MSG[340][0], constants.IPP_COR_MSG[340][1], constants.IPP_COR_MSG[340][2], constants.IPP_COR_MSG[340][3], constants.IPP_COR_MSG[340][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=3, fill=fill, message_id=25, message=constants.IPP_COR_MSG)
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=8, fill=fill, message_id=25, message=constants.IPP_COR_MSG)
                        correlate_warn_list.append([ws[i].title, 14, 3, constants.IPP_COR_MSG[25][0], constants.IPP_COR_MSG[25][1], constants.IPP_COR_MSG[25][2], constants.IPP_COR_MSG[25][3], constants.IPP_COR_MSG[25][4]])
                        correlate_warn_list.append([ws[i].title, 14, 8, constants.IPP_COR_MSG[25][0], constants.IPP_COR_MSG[25][1], constants.IPP_COR_MSG[25][2], constants.IPP_COR_MSG[25][3], constants.IPP_COR_MSG[25][4]])
                else:
                    if ws[i].cell(row=14, column=8).value is None:
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=3, fill=fill, message_id=341)
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=8, fill=fill, message_id=341)
                        ### correlate_warn_list.append([ws[i].title, 14, 3, constants.IPP_COR_MSG[341][0], constants.IPP_COR_MSG[341][1], constants.IPP_COR_MSG[341][2], constants.IPP_COR_MSG[341][3], constants.IPP_COR_MSG[341][4]])
                        ### correlate_warn_list.append([ws[i].title, 14, 8, constants.IPP_COR_MSG[341][0], constants.IPP_COR_MSG[341][1], constants.IPP_COR_MSG[341][2], constants.IPP_COR_MSG[341][3], constants.IPP_COR_MSG[341][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=3, fill=fill, message_id=26, message=constants.IPP_COR_MSG)
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=8, fill=fill, message_id=26, message=constants.IPP_COR_MSG)
                        correlate_warn_list.append([ws[i].title, 14, 3, constants.IPP_COR_MSG[26][0], constants.IPP_COR_MSG[26][1], constants.IPP_COR_MSG[26][2], constants.IPP_COR_MSG[26][3], constants.IPP_COR_MSG[26][4]])
                        correlate_warn_list.append([ws[i].title, 14, 8, constants.IPP_COR_MSG[26][0], constants.IPP_COR_MSG[26][1], constants.IPP_COR_MSG[26][2], constants.IPP_COR_MSG[26][3], constants.IPP_COR_MSG[26][4]])
                    else:
                        ### correlate_info_list.append([ws[i].title, 14, 3, 341])
                        ### correlate_info_list.append([ws[i].title, 14, 8, 341])
                        correlate_info_list.append([ws[i].title, 14, 3, 26])
                        correlate_info_list.append([ws[i].title, 14, 8, 26])
    
                ### セル[14:2]: 水害区域面積の宅地が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[14:3]: 水害区域面積の農地が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[14:4]: 水害区域面積の地下が何かの値のときに、相関する他項目は正しく選択されているか。
                ### 水害区域面積の宅地、農地、地下のいずれかに入力されているか。
                if ws[i].cell(row=14, column=2).value is None and \
                    ws[i].cell(row=14, column=3).value is None and \
                    ws[i].cell(row=14, column=4).value is None:
                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=2, fill=fill, message_id=342)
                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=3, fill=fill, message_id=342)
                    ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=4, fill=fill, message_id=342)
                    ### correlate_warn_list.append([ws[i].title, 14, 2, constants.IPP_COR_MSG[342][0], constants.IPP_COR_MSG[342][1], constants.IPP_COR_MSG[342][2], constants.IPP_COR_MSG[342][3], constants.IPP_COR_MSG[342][4]])
                    ### correlate_warn_list.append([ws[i].title, 14, 3, constants.IPP_COR_MSG[342][0], constants.IPP_COR_MSG[342][1], constants.IPP_COR_MSG[342][2], constants.IPP_COR_MSG[342][3], constants.IPP_COR_MSG[342][4]])
                    ### correlate_warn_list.append([ws[i].title, 14, 4, constants.IPP_COR_MSG[342][0], constants.IPP_COR_MSG[342][1], constants.IPP_COR_MSG[342][2], constants.IPP_COR_MSG[342][3], constants.IPP_COR_MSG[342][4]])
                    add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=2, fill=fill, message_id=27, message=constants.IPP_COR_MSG)
                    add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=3, fill=fill, message_id=27, message=constants.IPP_COR_MSG)
                    add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=4, fill=fill, message_id=27, message=constants.IPP_COR_MSG)
                    correlate_warn_list.append([ws[i].title, 14, 2, constants.IPP_COR_MSG[27][0], constants.IPP_COR_MSG[27][1], constants.IPP_COR_MSG[27][2], constants.IPP_COR_MSG[27][3], constants.IPP_COR_MSG[27][4]])
                    correlate_warn_list.append([ws[i].title, 14, 3, constants.IPP_COR_MSG[27][0], constants.IPP_COR_MSG[27][1], constants.IPP_COR_MSG[27][2], constants.IPP_COR_MSG[27][3], constants.IPP_COR_MSG[27][4]])
                    correlate_warn_list.append([ws[i].title, 14, 4, constants.IPP_COR_MSG[27][0], constants.IPP_COR_MSG[27][1], constants.IPP_COR_MSG[27][2], constants.IPP_COR_MSG[27][3], constants.IPP_COR_MSG[27][4]])
                else:
                    ### correlate_info_list.append([ws[i].title, 14, 2, 342])
                    ### correlate_info_list.append([ws[i].title, 14, 3, 342])
                    ### correlate_info_list.append([ws[i].title, 14, 4, 342])
                    correlate_info_list.append([ws[i].title, 14, 2, 27])
                    correlate_info_list.append([ws[i].title, 14, 3, 27])
                    correlate_info_list.append([ws[i].title, 14, 4, 27])
                
                ### セル[14:6]: 工種が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[14:8]: 農作物被害額が何かの値のときに、相関する他項目は正しく選択されているか。
                ### セル[14:10]: 異常気象が何かの値のときに、相関する他項目は正しく選択されているか。
        
            ###################################################################
            ### 関数内関数：EXCELセルデータ相関チェック処理（0030）
            ### (1)セル[20:2]からセル[20:27]について他項目との相関関係が正しいことをチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_correlate()関数 STEP 4/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                if max_row[i] >= 20:
                    for j in range(20, max_row[i]+1):
                        ### セル[20:2]: 町丁名・大字名が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:3]: 名称が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:4]: 地上・地下被害の区分 vs セル[14:2]: 水害区域面積の宅地、またはセル[14:3]: 水害区域面積の農地
                        if ws[i].cell(row=j, column=4).value is None:
                            pass
                        else:
                            if split_name_code(ws[i].cell(row=j, column=4).value)[-1].isdecimal() == False:
                                pass
                            else:
                                ### 地上・地下被害の区分が「地上のみ:1」のときに、相関する水害区域面積の宅地または水害区域面積の農地が入力されているか。
                                if split_name_code(ws[i].cell(row=j, column=4).value)[-1] in [1]:
                                    if ws[i].cell(row=14, column=2).value is None and \
                                        ws[i].cell(row=14, column=3).value is None:
                                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=360)
                                        ### correlate_warn_list.append([ws[i].title, j, 4, constants.IPP_COR_MSG[360][0], constants.IPP_COR_MSG[360][1], constants.IPP_COR_MSG[360][2], constants.IPP_COR_MSG[360][3], constants.IPP_COR_MSG[360][4]])
                                        add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=28, message=constants.IPP_COR_MSG)
                                        correlate_warn_list.append([ws[i].title, j, 4, constants.IPP_COR_MSG[28][0], constants.IPP_COR_MSG[28][1], constants.IPP_COR_MSG[28][2], constants.IPP_COR_MSG[28][3], constants.IPP_COR_MSG[28][4]])
                                    else:
                                        ### correlate_info_list.append([ws[i].title, j, 4, 360])
                                        correlate_info_list.append([ws[i].title, j, 4, 28])
    
                                ### 地上・地下被害の区分が「地上部分:2」のときに、相関する水害区域面積の宅地または水害区域面積の農地が入力されているか。
                                elif split_name_code(ws[i].cell(row=j, column=4).value)[-1] in [2]:
                                    if ws[i].cell(row=14, column=2).value is None and \
                                        ws[i].cell(row=14, column=3).value is None:
                                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=361)
                                        ### correlate_warn_list.append([ws[i].title, j, 4, constants.IPP_COR_MSG[361][0], constants.IPP_COR_MSG[361][1], constants.IPP_COR_MSG[361][2], constants.IPP_COR_MSG[361][3], constants.IPP_COR_MSG[361][4]])
                                        add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=29, message=constants.IPP_COR_MSG)
                                        correlate_warn_list.append([ws[i].title, j, 4, constants.IPP_COR_MSG[29][0], constants.IPP_COR_MSG[29][1], constants.IPP_COR_MSG[29][2], constants.IPP_COR_MSG[29][3], constants.IPP_COR_MSG[29][4]])
                                    else:
                                        ### correlate_info_list.append([ws[i].title, j, 4, 361])
                                        correlate_info_list.append([ws[i].title, j, 4, 29])
    
                                ### 地上・地下被害の区分が「地下部分:3」のときに、相関する水害区域面積の地下が入力されているか。
                                elif split_name_code(ws[i].cell(row=j, column=4).value)[-1] in [3]:
                                    if ws[i].cell(row=14, column=4).value is None:
                                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=362)
                                        ### correlate_warn_list.append([ws[i].title, j, 4, constants.IPP_COR_MSG[362][0], constants.IPP_COR_MSG[362][1], constants.IPP_COR_MSG[362][2], constants.IPP_COR_MSG[362][3], constants.IPP_COR_MSG[362][4]])
                                        add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=30, message=constants.IPP_COR_MSG)
                                        correlate_warn_list.append([ws[i].title, j, 4, constants.IPP_COR_MSG[30][0], constants.IPP_COR_MSG[30][1], constants.IPP_COR_MSG[30][2], constants.IPP_COR_MSG[30][3], constants.IPP_COR_MSG[30][4]])
                                    else:
                                        ### correlate_info_list.append([ws[i].title, j, 4, 362])
                                        correlate_info_list.append([ws[i].title, j, 4, 30])
    
                                ### 地上・地下被害の区分が「地下のみ:4」のときに、相関する水害区域面積の地下が入力されているか。
                                elif split_name_code(ws[i].cell(row=j, column=4).value)[-1] in [4]:
                                    if ws[i].cell(row=14, column=4).value is None:
                                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=363)
                                        ### correlate_warn_list.append([ws[i].title, j, 4, constants.IPP_COR_MSG[363][0], constants.IPP_COR_MSG[363][1], constants.IPP_COR_MSG[363][2], constants.IPP_COR_MSG[363][3], constants.IPP_COR_MSG[363][4]])
                                        add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=31, message=constants.IPP_COR_MSG)
                                        correlate_warn_list.append([ws[i].title, j, 4, constants.IPP_COR_MSG[31][0], constants.IPP_COR_MSG[31][1], constants.IPP_COR_MSG[31][2], constants.IPP_COR_MSG[31][3], constants.IPP_COR_MSG[31][4]])
                                    else:
                                        ### correlate_info_list.append([ws[i].title, j, 4, 363])
                                        correlate_info_list.append([ws[i].title, j, 4, 31])
                                else:
                                    pass
    
                        ### セル[20:4]: 地上・地下被害の区分 vs セル[20:26]: 地下空間の利用形態
                        if ws[i].cell(row=j, column=4).value is None:
                            pass
                        else:
                            if split_name_code(ws[i].cell(row=j, column=4).value)[-1].isdecimal() == False:
                                pass
                            else:
                                ### 地上・地下被害の区分が「1:」「2:」の場合、相関する地下空間の利用形態は、何らかの値が入力される。
                                if split_name_code(ws[i].cell(row=j, column=4).value)[-1] in [1, 2]:
                                    if ws[i].cell(row=j, column=27).value is None:
                                        ### correlate_info_list.append([ws[i].title, j, 4, 364])
                                        ### correlate_info_list.append([ws[i].title, j, 27, 364])
                                        correlate_info_list.append([ws[i].title, j, 4, 32])
                                        correlate_info_list.append([ws[i].title, j, 27, 32])
                                    else:
                                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=364)
                                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=27, fill=fill, message_id=364)
                                        ### correlate_warn_list.append([ws[i].title, j, 4, constants.IPP_COR_MSG[364][0], constants.IPP_COR_MSG[364][1], constants.IPP_COR_MSG[364][2], constants.IPP_COR_MSG[364][3], constants.IPP_COR_MSG[364][4]])
                                        ### correlate_warn_list.append([ws[i].title, j, 27, constants.IPP_COR_MSG[364][0], constants.IPP_COR_MSG[364][1], constants.IPP_COR_MSG[364][2], constants.IPP_COR_MSG[364][3], constants.IPP_COR_MSG[364][4]])
                                        add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=32, message=constants.IPP_COR_MSG)
                                        add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=27, fill=fill, message_id=32, message=constants.IPP_COR_MSG)
                                        correlate_warn_list.append([ws[i].title, j, 4, constants.IPP_COR_MSG[32][0], constants.IPP_COR_MSG[32][1], constants.IPP_COR_MSG[32][2], constants.IPP_COR_MSG[32][3], constants.IPP_COR_MSG[32][4]])
                                        correlate_warn_list.append([ws[i].title, j, 27, constants.IPP_COR_MSG[32][0], constants.IPP_COR_MSG[32][1], constants.IPP_COR_MSG[32][2], constants.IPP_COR_MSG[32][3], constants.IPP_COR_MSG[32][4]])
    
                                elif split_name_code(ws[i].cell(row=j, column=4).value)[-1] in [3, 4]:
                                    if ws[i].cell(row=j, column=27).value is None:
                                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=365)
                                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=27, fill=fill, message_id=365)
                                        ### correlate_warn_list.append([ws[i].title, j, 4, constants.IPP_COR_MSG[365][0], constants.IPP_COR_MSG[365][1], constants.IPP_COR_MSG[365][2], constants.IPP_COR_MSG[365][3], constants.IPP_COR_MSG[365][4]])
                                        ### correlate_warn_list.append([ws[i].title, j, 27, constants.IPP_COR_MSG[365][0], constants.IPP_COR_MSG[365][1], constants.IPP_COR_MSG[365][2], constants.IPP_COR_MSG[365][3], constants.IPP_COR_MSG[365][4]])
                                        add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=33, message=constants.IPP_COR_MSG)
                                        add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=27, fill=fill, message_id=33, message=constants.IPP_COR_MSG)
                                        correlate_warn_list.append([ws[i].title, j, 4, constants.IPP_COR_MSG[33][0], constants.IPP_COR_MSG[33][1], constants.IPP_COR_MSG[33][2], constants.IPP_COR_MSG[33][3], constants.IPP_COR_MSG[33][4]])
                                        correlate_warn_list.append([ws[i].title, j, 27, constants.IPP_COR_MSG[33][0], constants.IPP_COR_MSG[33][1], constants.IPP_COR_MSG[33][2], constants.IPP_COR_MSG[33][3], constants.IPP_COR_MSG[33][4]])
                                    else:
                                        ### correlate_info_list.append([ws[i].title, j, 4, 365])
                                        ### correlate_info_list.append([ws[i].title, j, 27, 365])
                                        correlate_info_list.append([ws[i].title, j, 4, 33])
                                        correlate_info_list.append([ws[i].title, j, 27, 33])
                                else:
                                    pass
                            
                        ### セル[20:5]: 浸水土砂被害の区分が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:6]: 被害建物棟数, 床下浸水 vs セル[20:12]: 延床面積
                        ### セル[20:7]: 被害建物棟数, 1cm〜49cm vs セル[20:12]: 延床面積
                        ### セル[20:8]: 被害建物棟数, 50cm〜99cm vs セル[20:12]: 延床面積
                        ### セル[20:9]: 被害建物棟数, 1m以上 vs セル[20:12]: 延床面積
                        ### セル[20:10]: 被害建物棟数, 半壊 vs セル[20:12]: 延床面積
                        ### セル[20:11]: 被害建物棟数, 全壊・流失 vs セル[20:12]: 延床面積
                        if ws[i].cell(row=j, column=6).value is None and \
                            ws[i].cell(row=j, column=7).value is None and \
                            ws[i].cell(row=j, column=8).value is None and \
                            ws[i].cell(row=j, column=9).value is None and \
                            ws[i].cell(row=j, column=10).value is None and \
                            ws[i].cell(row=j, column=11).value is None:
                            if ws[i].cell(row=j, column=12).value is None:
                                ### correlate_info_list.append([ws[i].title, j, 6, 366])
                                ### correlate_info_list.append([ws[i].title, j, 7, 366])
                                ### correlate_info_list.append([ws[i].title, j, 8, 366])
                                ### correlate_info_list.append([ws[i].title, j, 9, 366])
                                ### correlate_info_list.append([ws[i].title, j, 10, 366])
                                ### correlate_info_list.append([ws[i].title, j, 11, 366])
                                ### correlate_info_list.append([ws[i].title, j, 12, 366])
                                correlate_info_list.append([ws[i].title, j, 6, 34])
                                correlate_info_list.append([ws[i].title, j, 7, 34])
                                correlate_info_list.append([ws[i].title, j, 8, 34])
                                correlate_info_list.append([ws[i].title, j, 9, 34])
                                correlate_info_list.append([ws[i].title, j, 10, 34])
                                correlate_info_list.append([ws[i].title, j, 11, 34])
                                correlate_info_list.append([ws[i].title, j, 12, 34])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=6, fill=fill, message_id=366)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=7, fill=fill, message_id=366)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=8, fill=fill, message_id=366)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=9, fill=fill, message_id=366)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=10, fill=fill, message_id=366)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=11, fill=fill, message_id=366)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=12, fill=fill, message_id=366)
                                ### correlate_warn_list.append([ws[i].title, j, 6, constants.IPP_COR_MSG[366][0], constants.IPP_COR_MSG[366][1], constants.IPP_COR_MSG[366][2], constants.IPP_COR_MSG[366][3], constants.IPP_COR_MSG[366][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 7, constants.IPP_COR_MSG[366][0], constants.IPP_COR_MSG[366][1], constants.IPP_COR_MSG[366][2], constants.IPP_COR_MSG[366][3], constants.IPP_COR_MSG[366][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 8, constants.IPP_COR_MSG[366][0], constants.IPP_COR_MSG[366][1], constants.IPP_COR_MSG[366][2], constants.IPP_COR_MSG[366][3], constants.IPP_COR_MSG[366][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 9, constants.IPP_COR_MSG[366][0], constants.IPP_COR_MSG[366][1], constants.IPP_COR_MSG[366][2], constants.IPP_COR_MSG[366][3], constants.IPP_COR_MSG[366][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 10, constants.IPP_COR_MSG[366][0], constants.IPP_COR_MSG[366][1], constants.IPP_COR_MSG[366][2], constants.IPP_COR_MSG[366][3], constants.IPP_COR_MSG[366][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 11, constants.IPP_COR_MSG[366][0], constants.IPP_COR_MSG[366][1], constants.IPP_COR_MSG[366][2], constants.IPP_COR_MSG[366][3], constants.IPP_COR_MSG[366][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 12, constants.IPP_COR_MSG[366][0], constants.IPP_COR_MSG[366][1], constants.IPP_COR_MSG[366][2], constants.IPP_COR_MSG[366][3], constants.IPP_COR_MSG[366][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=6, fill=fill, message_id=34, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=7, fill=fill, message_id=34, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=8, fill=fill, message_id=34, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=9, fill=fill, message_id=34, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=10, fill=fill, message_id=34, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=11, fill=fill, message_id=34, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=12, fill=fill, message_id=34, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, j, 6, constants.IPP_COR_MSG[34][0], constants.IPP_COR_MSG[34][1], constants.IPP_COR_MSG[34][2], constants.IPP_COR_MSG[34][3], constants.IPP_COR_MSG[34][4]])
                                correlate_warn_list.append([ws[i].title, j, 7, constants.IPP_COR_MSG[34][0], constants.IPP_COR_MSG[34][1], constants.IPP_COR_MSG[34][2], constants.IPP_COR_MSG[34][3], constants.IPP_COR_MSG[34][4]])
                                correlate_warn_list.append([ws[i].title, j, 8, constants.IPP_COR_MSG[34][0], constants.IPP_COR_MSG[34][1], constants.IPP_COR_MSG[34][2], constants.IPP_COR_MSG[34][3], constants.IPP_COR_MSG[34][4]])
                                correlate_warn_list.append([ws[i].title, j, 9, constants.IPP_COR_MSG[34][0], constants.IPP_COR_MSG[34][1], constants.IPP_COR_MSG[34][2], constants.IPP_COR_MSG[34][3], constants.IPP_COR_MSG[34][4]])
                                correlate_warn_list.append([ws[i].title, j, 10, constants.IPP_COR_MSG[34][0], constants.IPP_COR_MSG[34][1], constants.IPP_COR_MSG[34][2], constants.IPP_COR_MSG[34][3], constants.IPP_COR_MSG[34][4]])
                                correlate_warn_list.append([ws[i].title, j, 11, constants.IPP_COR_MSG[34][0], constants.IPP_COR_MSG[34][1], constants.IPP_COR_MSG[34][2], constants.IPP_COR_MSG[34][3], constants.IPP_COR_MSG[34][4]])
                                correlate_warn_list.append([ws[i].title, j, 12, constants.IPP_COR_MSG[34][0], constants.IPP_COR_MSG[34][1], constants.IPP_COR_MSG[34][2], constants.IPP_COR_MSG[34][3], constants.IPP_COR_MSG[34][4]])
                        else:
                            if ws[i].cell(row=j, column=12).value is None:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=6, fill=fill, message_id=367)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=7, fill=fill, message_id=367)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=8, fill=fill, message_id=367)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=9, fill=fill, message_id=367)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=10, fill=fill, message_id=367)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=11, fill=fill, message_id=367)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=12, fill=fill, message_id=367)
                                ### correlate_warn_list.append([ws[i].title, j, 6, constants.IPP_COR_MSG[367][0], constants.IPP_COR_MSG[367][1], constants.IPP_COR_MSG[367][2], constants.IPP_COR_MSG[367][3], constants.IPP_COR_MSG[367][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 7, constants.IPP_COR_MSG[367][0], constants.IPP_COR_MSG[367][1], constants.IPP_COR_MSG[367][2], constants.IPP_COR_MSG[367][3], constants.IPP_COR_MSG[367][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 8, constants.IPP_COR_MSG[367][0], constants.IPP_COR_MSG[367][1], constants.IPP_COR_MSG[367][2], constants.IPP_COR_MSG[367][3], constants.IPP_COR_MSG[367][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 9, constants.IPP_COR_MSG[367][0], constants.IPP_COR_MSG[367][1], constants.IPP_COR_MSG[367][2], constants.IPP_COR_MSG[367][3], constants.IPP_COR_MSG[367][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 10, constants.IPP_COR_MSG[367][0], constants.IPP_COR_MSG[367][1], constants.IPP_COR_MSG[367][2], constants.IPP_COR_MSG[367][3], constants.IPP_COR_MSG[367][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 11, constants.IPP_COR_MSG[367][0], constants.IPP_COR_MSG[367][1], constants.IPP_COR_MSG[367][2], constants.IPP_COR_MSG[367][3], constants.IPP_COR_MSG[367][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 12, constants.IPP_COR_MSG[367][0], constants.IPP_COR_MSG[367][1], constants.IPP_COR_MSG[367][2], constants.IPP_COR_MSG[367][3], constants.IPP_COR_MSG[367][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=6, fill=fill, message_id=35, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=7, fill=fill, message_id=35, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=8, fill=fill, message_id=35, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=9, fill=fill, message_id=35, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=10, fill=fill, message_id=35, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=11, fill=fill, message_id=35, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=12, fill=fill, message_id=35, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, j, 6, constants.IPP_COR_MSG[35][0], constants.IPP_COR_MSG[35][1], constants.IPP_COR_MSG[35][2], constants.IPP_COR_MSG[35][3], constants.IPP_COR_MSG[35][4]])
                                correlate_warn_list.append([ws[i].title, j, 7, constants.IPP_COR_MSG[35][0], constants.IPP_COR_MSG[35][1], constants.IPP_COR_MSG[35][2], constants.IPP_COR_MSG[35][3], constants.IPP_COR_MSG[35][4]])
                                correlate_warn_list.append([ws[i].title, j, 8, constants.IPP_COR_MSG[35][0], constants.IPP_COR_MSG[35][1], constants.IPP_COR_MSG[35][2], constants.IPP_COR_MSG[35][3], constants.IPP_COR_MSG[35][4]])
                                correlate_warn_list.append([ws[i].title, j, 9, constants.IPP_COR_MSG[35][0], constants.IPP_COR_MSG[35][1], constants.IPP_COR_MSG[35][2], constants.IPP_COR_MSG[35][3], constants.IPP_COR_MSG[35][4]])
                                correlate_warn_list.append([ws[i].title, j, 10, constants.IPP_COR_MSG[35][0], constants.IPP_COR_MSG[35][1], constants.IPP_COR_MSG[35][2], constants.IPP_COR_MSG[35][3], constants.IPP_COR_MSG[35][4]])
                                correlate_warn_list.append([ws[i].title, j, 11, constants.IPP_COR_MSG[35][0], constants.IPP_COR_MSG[35][1], constants.IPP_COR_MSG[35][2], constants.IPP_COR_MSG[35][3], constants.IPP_COR_MSG[35][4]])
                                correlate_warn_list.append([ws[i].title, j, 12, constants.IPP_COR_MSG[35][0], constants.IPP_COR_MSG[35][1], constants.IPP_COR_MSG[35][2], constants.IPP_COR_MSG[35][3], constants.IPP_COR_MSG[35][4]])
                            else:
                                ### correlate_info_list.append([ws[i].title, j, 6, 367])
                                ### correlate_info_list.append([ws[i].title, j, 7, 367])
                                ### correlate_info_list.append([ws[i].title, j, 8, 367])
                                ### correlate_info_list.append([ws[i].title, j, 9, 367])
                                ### correlate_info_list.append([ws[i].title, j, 10, 367])
                                ### correlate_info_list.append([ws[i].title, j, 11, 367])
                                ### correlate_info_list.append([ws[i].title, j, 12, 367])
                                correlate_info_list.append([ws[i].title, j, 6, 35])
                                correlate_info_list.append([ws[i].title, j, 7, 35])
                                correlate_info_list.append([ws[i].title, j, 8, 35])
                                correlate_info_list.append([ws[i].title, j, 9, 35])
                                correlate_info_list.append([ws[i].title, j, 10, 35])
                                correlate_info_list.append([ws[i].title, j, 11, 35])
                                correlate_info_list.append([ws[i].title, j, 12, 35])
                            
                        ### セル[20:12]: 被害建物の延床面積が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:13]: 被災世帯数が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:14]: 被災事業所数 vs セル[20:25]: 事業所の産業区分
                        if ws[i].cell(row=j, column=14).value is None:
                            if ws[i].cell(row=j, column=25).value is None:
                                ### correlate_info_list.append([ws[i].title, j, 14, 368])
                                ### correlate_info_list.append([ws[i].title, j, 25, 368])
                                correlate_info_list.append([ws[i].title, j, 14, 36])
                                correlate_info_list.append([ws[i].title, j, 25, 36])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=368)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=25, fill=fill, message_id=368)
                                ### correlate_warn_list.append([ws[i].title, j, 14, constants.IPP_COR_MSG[368][0], constants.IPP_COR_MSG[368][1], constants.IPP_COR_MSG[368][2], constants.IPP_COR_MSG[368][3], constants.IPP_COR_MSG[368][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 25, constants.IPP_COR_MSG[368][0], constants.IPP_COR_MSG[368][1], constants.IPP_COR_MSG[368][2], constants.IPP_COR_MSG[368][3], constants.IPP_COR_MSG][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=36, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=25, fill=fill, message_id=36, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, j, 14, constants.IPP_COR_MSG[36][0], constants.IPP_COR_MSG[36][1], constants.IPP_COR_MSG[36][2], constants.IPP_COR_MSG[36][3], constants.IPP_COR_MSG[36][4]])
                                correlate_warn_list.append([ws[i].title, j, 25, constants.IPP_COR_MSG[36][0], constants.IPP_COR_MSG[36][1], constants.IPP_COR_MSG[36][2], constants.IPP_COR_MSG[36][3], constants.IPP_COR_MSG[36][4]])
                        else:
                            if ws[i].cell(row=j, column=25).value is None:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=369)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=25, fill=fill, message_id=369)
                                ### correlate_warn_list.append([ws[i].title, j, 14, constants.IPP_COR_MSG[369][0], constants.IPP_COR_MSG[369][1], constants.IPP_COR_MSG[369][2], constants.IPP_COR_MSG[369][3], constants.IPP_COR_MSG[369][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 25, constants.IPP_COR_MSG[369][0], constants.IPP_COR_MSG[369][1], constants.IPP_COR_MSG[369][2], constants.IPP_COR_MSG[369][3], constants.IPP_COR_MSG[369][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=37, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=25, fill=fill, message_id=37, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, j, 14, constants.IPP_COR_MSG[37][0], constants.IPP_COR_MSG[37][1], constants.IPP_COR_MSG[37][2], constants.IPP_COR_MSG[37][3], constants.IPP_COR_MSG[37][4]])
                                correlate_warn_list.append([ws[i].title, j, 25, constants.IPP_COR_MSG[37][0], constants.IPP_COR_MSG[37][1], constants.IPP_COR_MSG[37][2], constants.IPP_COR_MSG[37][3], constants.IPP_COR_MSG[37][4]])
                            else:
                                ### correlate_info_list.append([ws[i].title, j, 14, 369])
                                ### correlate_info_list.append([ws[i].title, j, 25, 369])
                                correlate_info_list.append([ws[i].title, j, 14, 37])
                                correlate_info_list.append([ws[i].title, j, 25, 37])
    
                        ### セル[20:14]: 被災事業所数 vs セル[20:20]: 事業所従業者数, 床下浸水
                        ### セル[20:14]: 被災事業所数 vs セル[20:21]: 事業所従業者数, 1cm〜49cm
                        ### セル[20:14]: 被災事業所数 vs セル[20:22]: 事業所従業者数, 50cm〜99cm
                        ### セル[20:14]: 被災事業所数 vs セル[20:23]: 事業所従業者数, 1m以上・半壊
                        ### セル[20:14]: 被災事業所数 vs セル[20:24]: 事業所従業者数, 全壊・流失
                        if ws[i].cell(row=j, column=14).value is None:
                            if ws[i].cell(row=j, column=20).value is None and \
                                ws[i].cell(row=j, column=21).value is None and \
                                ws[i].cell(row=j, column=22).value is None and \
                                ws[i].cell(row=j, column=23).value is None and \
                                ws[i].cell(row=j, column=24).value is None:
                                ### correlate_info_list.append([ws[i].title, j, 14, 370])
                                ### correlate_info_list.append([ws[i].title, j, 20, 370])
                                ### correlate_info_list.append([ws[i].title, j, 21, 370])
                                ### correlate_info_list.append([ws[i].title, j, 22, 370])
                                ### correlate_info_list.append([ws[i].title, j, 23, 370])
                                ### correlate_info_list.append([ws[i].title, j, 24, 370])
                                correlate_info_list.append([ws[i].title, j, 14, 38])
                                correlate_info_list.append([ws[i].title, j, 20, 38])
                                correlate_info_list.append([ws[i].title, j, 21, 38])
                                correlate_info_list.append([ws[i].title, j, 22, 38])
                                correlate_info_list.append([ws[i].title, j, 23, 38])
                                correlate_info_list.append([ws[i].title, j, 24, 38])
                            else:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=370)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=20, fill=fill, message_id=370)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=21, fill=fill, message_id=370)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=22, fill=fill, message_id=370)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=23, fill=fill, message_id=370)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=24, fill=fill, message_id=370)
                                ### correlate_warn_list.append([ws[i].title, j, 14, constants.IPP_COR_MSG[370][0], constants.IPP_COR_MSG[370][1], constants.IPP_COR_MSG[370][2], constants.IPP_COR_MSG[370][3], constants.IPP_COR_MSG[370][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 20, constants.IPP_COR_MSG[370][0], constants.IPP_COR_MSG[370][1], constants.IPP_COR_MSG[370][2], constants.IPP_COR_MSG[370][3], constants.IPP_COR_MSG[370][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 21, constants.IPP_COR_MSG[370][0], constants.IPP_COR_MSG[370][1], constants.IPP_COR_MSG[370][2], constants.IPP_COR_MSG[370][3], constants.IPP_COR_MSG[370][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 22, constants.IPP_COR_MSG[370][0], constants.IPP_COR_MSG[370][1], constants.IPP_COR_MSG[370][2], constants.IPP_COR_MSG[370][3], constants.IPP_COR_MSG[370][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 23, constants.IPP_COR_MSG[370][0], constants.IPP_COR_MSG[370][1], constants.IPP_COR_MSG[370][2], constants.IPP_COR_MSG[370][3], constants.IPP_COR_MSG[370][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 24, constants.IPP_COR_MSG[370][0], constants.IPP_COR_MSG[370][1], constants.IPP_COR_MSG[370][2], constants.IPP_COR_MSG[370][3], constants.IPP_COR_MSG[370][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=38, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=20, fill=fill, message_id=38, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=21, fill=fill, message_id=38, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=22, fill=fill, message_id=38, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=23, fill=fill, message_id=38, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=24, fill=fill, message_id=38, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, j, 14, constants.IPP_COR_MSG[38][0], constants.IPP_COR_MSG[38][1], constants.IPP_COR_MSG[38][2], constants.IPP_COR_MSG[38][3], constants.IPP_COR_MSG[38][4]])
                                correlate_warn_list.append([ws[i].title, j, 20, constants.IPP_COR_MSG[38][0], constants.IPP_COR_MSG[38][1], constants.IPP_COR_MSG[38][2], constants.IPP_COR_MSG[38][3], constants.IPP_COR_MSG[38][4]])
                                correlate_warn_list.append([ws[i].title, j, 21, constants.IPP_COR_MSG[38][0], constants.IPP_COR_MSG[38][1], constants.IPP_COR_MSG[38][2], constants.IPP_COR_MSG[38][3], constants.IPP_COR_MSG[38][4]])
                                correlate_warn_list.append([ws[i].title, j, 22, constants.IPP_COR_MSG[38][0], constants.IPP_COR_MSG[38][1], constants.IPP_COR_MSG[38][2], constants.IPP_COR_MSG[38][3], constants.IPP_COR_MSG[38][4]])
                                correlate_warn_list.append([ws[i].title, j, 23, constants.IPP_COR_MSG[38][0], constants.IPP_COR_MSG[38][1], constants.IPP_COR_MSG[38][2], constants.IPP_COR_MSG[38][3], constants.IPP_COR_MSG[38][4]])
                                correlate_warn_list.append([ws[i].title, j, 24, constants.IPP_COR_MSG[38][0], constants.IPP_COR_MSG[38][1], constants.IPP_COR_MSG[38][2], constants.IPP_COR_MSG[38][3], constants.IPP_COR_MSG[38][4]])
                        else:
                            if ws[i].cell(row=j, column=20).value is None and \
                                ws[i].cell(row=j, column=21).value is None and \
                                ws[i].cell(row=j, column=22).value is None and \
                                ws[i].cell(row=j, column=23).value is None and \
                                ws[i].cell(row=j, column=24).value is None:
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=371)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=20, fill=fill, message_id=371)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=21, fill=fill, message_id=371)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=22, fill=fill, message_id=371)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=23, fill=fill, message_id=371)
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=24, fill=fill, message_id=371)
                                ### correlate_warn_list.append([ws[i].title, j, 14, constants.IPP_COR_MSG[371][0], constants.IPP_COR_MSG[371][1], constants.IPP_COR_MSG[371][2], constants.IPP_COR_MSG[371][3], constants.IPP_COR_MSG[371][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 20, constants.IPP_COR_MSG[371][0], constants.IPP_COR_MSG[371][1], constants.IPP_COR_MSG[371][2], constants.IPP_COR_MSG[371][3], constants.IPP_COR_MSG[371][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 21, constants.IPP_COR_MSG[371][0], constants.IPP_COR_MSG[371][1], constants.IPP_COR_MSG[371][2], constants.IPP_COR_MSG[371][3], constants.IPP_COR_MSG[371][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 22, constants.IPP_COR_MSG[371][0], constants.IPP_COR_MSG[371][1], constants.IPP_COR_MSG[371][2], constants.IPP_COR_MSG[371][3], constants.IPP_COR_MSG[371][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 23, constants.IPP_COR_MSG[371][0], constants.IPP_COR_MSG[371][1], constants.IPP_COR_MSG[371][2], constants.IPP_COR_MSG[371][3], constants.IPP_COR_MSG[371][4]])
                                ### correlate_warn_list.append([ws[i].title, j, 24, constants.IPP_COR_MSG[371][0], constants.IPP_COR_MSG[371][1], constants.IPP_COR_MSG[371][2], constants.IPP_COR_MSG[371][3], constants.IPP_COR_MSG[371][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=14, fill=fill, message_id=39, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=20, fill=fill, message_id=39, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=21, fill=fill, message_id=39, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=22, fill=fill, message_id=39, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=23, fill=fill, message_id=39, message=constants.IPP_COR_MSG)
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=24, fill=fill, message_id=39, message=constants.IPP_COR_MSG)
                                correlate_warn_list.append([ws[i].title, j, 14, constants.IPP_COR_MSG[39][0], constants.IPP_COR_MSG[39][1], constants.IPP_COR_MSG[39][2], constants.IPP_COR_MSG[39][3], constants.IPP_COR_MSG[39][4]])
                                correlate_warn_list.append([ws[i].title, j, 20, constants.IPP_COR_MSG[39][0], constants.IPP_COR_MSG[39][1], constants.IPP_COR_MSG[39][2], constants.IPP_COR_MSG[39][3], constants.IPP_COR_MSG[39][4]])
                                correlate_warn_list.append([ws[i].title, j, 21, constants.IPP_COR_MSG[39][0], constants.IPP_COR_MSG[39][1], constants.IPP_COR_MSG[39][2], constants.IPP_COR_MSG[39][3], constants.IPP_COR_MSG[39][4]])
                                correlate_warn_list.append([ws[i].title, j, 22, constants.IPP_COR_MSG[39][0], constants.IPP_COR_MSG[39][1], constants.IPP_COR_MSG[39][2], constants.IPP_COR_MSG[39][3], constants.IPP_COR_MSG[39][4]])
                                correlate_warn_list.append([ws[i].title, j, 23, constants.IPP_COR_MSG[39][0], constants.IPP_COR_MSG[39][1], constants.IPP_COR_MSG[39][2], constants.IPP_COR_MSG[39][3], constants.IPP_COR_MSG[39][4]])
                                correlate_warn_list.append([ws[i].title, j, 24, constants.IPP_COR_MSG[39][0], constants.IPP_COR_MSG[39][1], constants.IPP_COR_MSG[39][2], constants.IPP_COR_MSG[39][3], constants.IPP_COR_MSG[39][4]])
                            else:
                                ### correlate_info_list.append([ws[i].title, j, 14, 371])
                                ### correlate_info_list.append([ws[i].title, j, 20, 371])
                                ### correlate_info_list.append([ws[i].title, j, 21, 371])
                                ### correlate_info_list.append([ws[i].title, j, 22, 371])
                                ### correlate_info_list.append([ws[i].title, j, 23, 371])
                                ### correlate_info_list.append([ws[i].title, j, 24, 371])
                                correlate_info_list.append([ws[i].title, j, 14, 39])
                                correlate_info_list.append([ws[i].title, j, 20, 39])
                                correlate_info_list.append([ws[i].title, j, 21, 39])
                                correlate_info_list.append([ws[i].title, j, 22, 39])
                                correlate_info_list.append([ws[i].title, j, 23, 39])
                                correlate_info_list.append([ws[i].title, j, 24, 39])
                            
                        ### セル[20:15]: 農家・漁家戸数, 床下浸水が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:16]: 農家・漁家戸数, 1cm〜49cmが何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:17]: 農家・漁家戸数, 50cm〜99cmが何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:18]: 農家・漁家戸数, 1m以上・半壊が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:19]: 農家・漁家戸数, 全壊・流失が何かの値のときに、相関する他項目は正しく選択されているか。
                        ### セル[20:20]: 事業所従業者数, 床下浸水が何かの値のときに、相関する他項目は正しく選択されているか。 参照 セル[20:14]: 被災事業所数 vs セル[20:20]: 事業所従業者数
                        ### セル[20:21]: 事業所従業者数, 1cm〜49cmが何かの値のときに、相関する他項目は正しく選択されているか。 参照 セル[20:14]: 被災事業所数 vs セル[20:20]: 事業所従業者数
                        ### セル[20:22]: 事業所従業者数, 50cm〜99cmが何かの値のときに、相関する他項目は正しく選択されているか。 参照 セル[20:14]: 被災事業所数 vs セル[20:20]: 事業所従業者数
                        ### セル[20:23]: 事業所従業者数, 1m以上・半壊が何かの値のときに、相関する他項目は正しく選択されているか。 参照 セル[20:14]: 被災事業所数 vs セル[20:20]: 事業所従業者数
                        ### セル[20:24]: 事業所従業者数, 全壊・流失が何かの値のときに、相関する他項目は正しく選択されているか。 参照 セル[20:14]: 被災事業所数 vs セル[20:20]: 事業所従業者数
                        ### セル[20:25]: 事業所の産業区分が何かの値のときに、相関する他項目は正しく選択されているか。 参照  
                        ### セル[20:26]: 地下空間の利用形態が何かの値のときに、相関する他項目は正しく選択されているか。 参照 
                        ### セル[20:27]: 備考が何かの値のときに、相関する他項目は正しく選択されているか。
            return True
        except:
            return False
    
    ###########################################################################
    ### 関数内関数：EXCELセルデータ突合チェック処理
    ###########################################################################
    def check_compare():
        try:
            nonlocal ws
            nonlocal ws_result
            ### nonlocal fill
            nonlocal compare_warn_list
            nonlocal compare_info_list
            nonlocal compare_warn_grid
            nonlocal compare_info_grid
            ### nonlocal max_row
            ### nonlocal ken_code_list
            ### nonlocal ken_name_list
            ### nonlocal ken_name_code_list
            ### nonlocal city_code_list
            ### nonlocal city_name_list
            ### nonlocal city_name_code_list
            ### nonlocal cause_code_list
            ### nonlocal cause_name_list
            ### nonlocal cause_name_code_list
            ### nonlocal area_id_list
            ### nonlocal area_name_list
            ### nonlocal area_name_id_list
            ### nonlocal suikei_code_list
            ### nonlocal suikei_name_list
            ### nonlocal suikei_name_code_list
            ### nonlocal suikei_type_code_list
            ### nonlocal suikei_type_name_list
            ### nonlocal suikei_type_name_code_list
            ### nonlocal kasen_code_list
            ### nonlocal kasen_name_list
            ### nonlocal kasen_name_code_list
            ### nonlocal kasen_type_code_list
            ### nonlocal kasen_type_name_list
            ### nonlocal kasen_type_name_code_list
            ### nonlocal gradient_code_list
            ### nonlocal gradient_name_list
            ### nonlocal gradient_name_code_list
            ### nonlocal kasen_kaigan_code_list
            ### nonlocal kasen_kaigan_name_list
            ### nonlocal kasen_kaigan_name_code_list
            ### nonlocal weather_id_list
            ### nonlocal weather_name_list
            ### nonlocal weather_name_id_list
            ### nonlocal building_code_list
            ### nonlocal building_name_list
            ### nonlocal building_name_code_list
            ### nonlocal underground_code_list
            ### nonlocal underground_name_list
            ### nonlocal underground_name_code_list
            ### nonlocal flood_sediment_code_list
            ### nonlocal flood_sediment_name_list
            ### nonlocal flood_sediment_name_code_list
            ### nonlocal industry_code_list
            ### nonlocal industry_name_list
            ### nonlocal industry_name_code_list
            ### nonlocal usage_code_list
            ### nonlocal usage_name_list
            ### nonlocal usage_name_code_list
            ###################################################################
            ### 関数内関数：EXCELセルデータ突合チェック処理（0000）
            ### (1)セル[7:2]からセル[7:9]についてデータベースに登録されている値と突合せチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_compare()関数 STEP 1/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                ### セル[7:2]: 都道府県についてデータベースに登録されている値と突合せチェックする。
                if ws[i].cell(row=7, column=2).value is None:
                    pass
                else:
                    if ws[i].cell(row=7, column=2).value not in list(ken_code_list) and \
                        ws[i].cell(row=7, column=2).value not in list(ken_name_list) and \
                        ws[i].cell(row=7, column=2).value not in list(ken_name_code_list):
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=2, fill=fill, message_id=400)
                        ### compare_warn_list.append([ws[i].title, 7, 2, constants.IPP_COM_MSG[400][0], constants.IPP_COM_MSG[400][1], constants.IPP_COM_MSG[400][2], constants.IPP_COM_MSG[400][3], constants.IPP_COM_MSG[400][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=2, fill=fill, message_id=0, message=constants.IPP_COM_MSG)
                        compare_warn_list.append([ws[i].title, 7, 2, constants.IPP_COM_MSG[0][0], constants.IPP_COM_MSG[0][1], constants.IPP_COM_MSG[0][2], constants.IPP_COM_MSG[0][3], constants.IPP_COM_MSG[0][4]])
                    else:
                        ### compare_info_list.append([ws[i].title, 7, 2, 400])
                        compare_info_list.append([ws[i].title, 7, 2, 0])
                    
                ### セル[7:3]: 市区町村についてデータベースに登録されている値と突合せチェックする。
                if ws[i].cell(row=7, column=3).value is None:
                    pass
                else:
                    if ws[i].cell(row=7, column=3).value not in list(city_code_list) and \
                        ws[i].cell(row=7, column=3).value not in list(city_name_list) and \
                        ws[i].cell(row=7, column=3).value not in list(city_name_code_list):
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=3, fill=fill, message_id=401)
                        ### compare_warn_list.append([ws[i].title, 7, 3, constants.IPP_COM_MSG[401][0], constants.IPP_COM_MSG[401][1], constants.IPP_COM_MSG[401][2], constants.IPP_COM_MSG[401][3], constants.IPP_COM_MSG[401][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=3, fill=fill, message_id=1, message=constants.IPP_COM_MSG)
                        compare_warn_list.append([ws[i].title, 7, 3, constants.IPP_COM_MSG[1][0], constants.IPP_COM_MSG[1][1], constants.IPP_COM_MSG[1][2], constants.IPP_COM_MSG[1][3], constants.IPP_COM_MSG[1][4]])
                    else:
                        ### compare_info_list.append([ws[i].title, 7, 3, 401])
                        compare_info_list.append([ws[i].title, 7, 3, 1])
                    
                ### セル[7:4]: 水害発生月日についてデータベースに登録されている値と突合せチェックする。
                ### セル[7:5]: 水害終了月日についてデータベースに登録されている値と突合せチェックする。
                ### セル[7:6]: 水害原因1についてデータベースに登録されている値と突合せチェックする。
                if ws[i].cell(row=7, column=6).value is None:
                    pass
                else:
                    if ws[i].cell(row=7, column=6).value not in list(cause_code_list) and \
                        ws[i].cell(row=7, column=6).value not in list(cause_name_list) and \
                        ws[i].cell(row=7, column=6).value not in list(cause_name_code_list):
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=404)
                        ### compare_warn_list.append([ws[i].title, 7, 6, constants.IPP_COM_MSG[404][0], constants.IPP_COM_MSG[404][1], constants.IPP_COM_MSG[404][2], constants.IPP_COM_MSG[404][3], constants.IPP_COM_MSG[404][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=6, fill=fill, message_id=4, message=constants.IPP_COM_MSG)
                        compare_warn_list.append([ws[i].title, 7, 6, constants.IPP_COM_MSG[4][0], constants.IPP_COM_MSG[4][1], constants.IPP_COM_MSG[4][2], constants.IPP_COM_MSG[4][3], constants.IPP_COM_MSG[4][4]])
                    else:
                        ### compare_info_list.append([ws[i].title, 7, 6, 404])
                        compare_info_list.append([ws[i].title, 7, 6, 4])
                    
                ### セル[7:7]: 水害原因2についてデータベースに登録されている値と突合せチェックする。
                if ws[i].cell(row=7, column=7).value is None:
                    pass
                else:
                    if ws[i].cell(row=7, column=7).value not in list(cause_code_list) and \
                        ws[i].cell(row=7, column=7).value not in list(cause_name_list) and \
                        ws[i].cell(row=7, column=7).value not in list(cause_name_code_list):
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=405)
                        ### compare_warn_list.append([ws[i].title, 7, 7, constants.IPP_COM_MSG[405][0], constants.IPP_COM_MSG[405][1], constants.IPP_COM_MSG[405][2], constants.IPP_COM_MSG[405][3], constants.IPP_COM_MSG[405][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=7, fill=fill, message_id=5, message=constants.IPP_COM_MSG)
                        compare_warn_list.append([ws[i].title, 7, 7, constants.IPP_COM_MSG[5][0], constants.IPP_COM_MSG[5][1], constants.IPP_COM_MSG[5][2], constants.IPP_COM_MSG[5][3], constants.IPP_COM_MSG[5][4]])
                    else:
                        ### compare_info_list.append([ws[i].title, 7, 7, 405])
                        compare_info_list.append([ws[i].title, 7, 7, 5])
                    
                ### セル[7:8]: 水害原因3についてデータベースに登録されている値と突合せチェックする。
                if ws[i].cell(row=7, column=8).value is None:
                    pass
                else:
                    if ws[i].cell(row=7, column=8).value not in list(cause_code_list) and \
                        ws[i].cell(row=7, column=8).value not in list(cause_name_list) and \
                        ws[i].cell(row=7, column=8).value not in list(cause_name_code_list):
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=406)
                        ### compare_warn_list.append([ws[i].title, 7, 8, constants.IPP_COM_MSG[406][0], constants.IPP_COM_MSG[406][1], constants.IPP_COM_MSG[406][2], constants.IPP_COM_MSG[406][3], constants.IPP_COM_MSG[406][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=8, fill=fill, message_id=6, message=constants.IPP_COM_MSG)
                        compare_warn_list.append([ws[i].title, 7, 8, constants.IPP_COM_MSG[6][0], constants.IPP_COM_MSG[6][1], constants.IPP_COM_MSG[6][2], constants.IPP_COM_MSG[6][3], constants.IPP_COM_MSG[6][4]])
                    else:
                        ### compare_info_list.append([ws[i].title, 7, 8, 406])
                        compare_info_list.append([ws[i].title, 7, 8, 6])
                    
                ### セル[7:9]: 水害区域番号についてデータベースに登録されている値と突合せチェックする。 ### COMMENT OUT 2023/11/14
                ### if ws[i].cell(row=7, column=9).value is None:
                ###     pass
                ### else:
                ###     if ws[i].cell(row=7, column=9).value not in list(area_id_list) and \
                ###         ws[i].cell(row=7, column=9).value not in list(area_name_list) and \
                ###         ws[i].cell(row=7, column=9).value not in list(area_name_id_list):
                ###         ### add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=9, fill=fill, message_id=407)
                ###         ### compare_warn_list.append([ws[i].title, 7, 9, constants.IPP_COM_MSG[407][0], constants.IPP_COM_MSG[407][1], constants.IPP_COM_MSG[407][2], constants.IPP_COM_MSG[407][3], constants.IPP_COM_MSG[407][4]])
                ###         add_comment(ws=ws[i], ws_result=ws_result[i], row=7, column=9, fill=fill, message_id=7, message=constants.IPP_COM_MSG)
                ###         compare_warn_list.append([ws[i].title, 7, 9, constants.IPP_COM_MSG[7][0], constants.IPP_COM_MSG[7][1], constants.IPP_COM_MSG[7][2], constants.IPP_COM_MSG[7][3], constants.IPP_COM_MSG[7][4]])
                ###     else:
                ###         ### compare_info_list.append([ws[i].title, 7, 9, 407])
                ###         compare_info_list.append([ws[i].title, 7, 9, 7])
        
            ###################################################################
            ### 関数内関数：EXCELセルデータ突合チェック処理（0010）
            ### (1)セル[10:2]からセル[10:6]についてデータベースに登録されている値と突合せチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ### TO-DO: if == ''はダミーの処理である。突合せチェック処理を記述する。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_compare()関数 STEP 2/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                ### セル[10:2]: 水系・沿岸名についてデータベースに登録されている値と突合せチェックする。
                if ws[i].cell(row=10, column=2).value is None:
                    pass
                else:
                    if ws[i].cell(row=10, column=2).value not in list(suikei_code_list) and \
                        ws[i].cell(row=10, column=2).value not in list(suikei_name_list) and \
                        ws[i].cell(row=10, column=2).value not in list(suikei_name_code_list):
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=2, fill=fill, message_id=408)
                        ### compare_warn_list.append([ws[i].title, 10, 2, constants.IPP_COM_MSG[408][0], constants.IPP_COM_MSG[408][1], constants.IPP_COM_MSG[408][2], constants.IPP_COM_MSG[408][3], constants.IPP_COM_MSG[408][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=2, fill=fill, message_id=8, message=constants.IPP_COM_MSG)
                        compare_warn_list.append([ws[i].title, 10, 2, constants.IPP_COM_MSG[8][0], constants.IPP_COM_MSG[8][1], constants.IPP_COM_MSG[8][2], constants.IPP_COM_MSG[8][3], constants.IPP_COM_MSG[8][4]])
                    else:
                        ### compare_info_list.append([ws[i].title, 10, 2, 408])
                        compare_info_list.append([ws[i].title, 10, 2, 8])
                    
                ### セル[10:3]: 水系種別についてデータベースに登録されている値と突合せチェックする。
                if ws[i].cell(row=10, column=3).value is None:
                    pass
                else:
                    if ws[i].cell(row=10, column=3).value not in list(suikei_type_code_list) and \
                        ws[i].cell(row=10, column=3).value not in list(suikei_type_name_list) and \
                        ws[i].cell(row=10, column=3).value not in list(suikei_type_name_code_list):
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=409)
                        ### compare_warn_list.append([ws[i].title, 10, 3, constants.IPP_COM_MSG[409][0], constants.IPP_COM_MSG[409][1], constants.IPP_COM_MSG[409][2], constants.IPP_COM_MSG[409][3], constants.IPP_COM_MSG[409][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=3, fill=fill, message_id=9, message=constants.IPP_COM_MSG)
                        compare_warn_list.append([ws[i].title, 10, 3, constants.IPP_COM_MSG[9][0], constants.IPP_COM_MSG[9][1], constants.IPP_COM_MSG[9][2], constants.IPP_COM_MSG[9][3], constants.IPP_COM_MSG[9][4]])
                    else:
                        ### compare_info_list.append([ws[i].title, 10, 3, 409])
                        compare_info_list.append([ws[i].title, 10, 3, 9])
                    
                ### セル[10:4]: 河川・海岸名についてデータベースに登録されている値と突合せチェックする。
                if ws[i].cell(row=10, column=4).value is None:
                    pass
                else:
                    if ws[i].cell(row=10, column=4).value not in list(kasen_code_list) and \
                        ws[i].cell(row=10, column=4).value not in list(kasen_name_list) and \
                        ws[i].cell(row=10, column=4).value not in list(kasen_name_code_list):
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=4, fill=fill, message_id=410)
                        ### compare_warn_list.append([ws[i].title, 10, 4, constants.IPP_COM_MSG[410][0], constants.IPP_COM_MSG[410][1], constants.IPP_COM_MSG[410][2], constants.IPP_COM_MSG[410][3], constants.IPP_COM_MSG[410][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=4, fill=fill, message_id=10, message=constants.IPP_COM_MSG)
                        compare_warn_list.append([ws[i].title, 10, 4, constants.IPP_COM_MSG[10][0], constants.IPP_COM_MSG[10][1], constants.IPP_COM_MSG[10][2], constants.IPP_COM_MSG[10][3], constants.IPP_COM_MSG[10][4]])
                    else:
                        ### compare_info_list.append([ws[i].title, 10, 4, 410])
                        compare_info_list.append([ws[i].title, 10, 4, 10])
                    
                ### セルE10[10:5]: 河川種別についてデータベースに登録されている値と突合せチェックする。
                if ws[i].cell(row=10, column=5).value is None:
                    pass
                else:
                    if ws[i].cell(row=10, column=5).value not in list(kasen_type_code_list) and \
                        ws[i].cell(row=10, column=5).value not in list(kasen_type_name_list) and \
                        ws[i].cell(row=10, column=5).value not in list(kasen_type_name_code_list):
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=411)
                        ### compare_warn_list.append([ws[i].title, 10, 5, constants.IPP_COM_MSG[411][0], constants.IPP_COM_MSG[411][1], constants.IPP_COM_MSG[411][2], constants.IPP_COM_MSG[411][3], constants.IPP_COM_MSG[411][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=5, fill=fill, message_id=11, message=constants.IPP_COM_MSG)
                        compare_warn_list.append([ws[i].title, 10, 5, constants.IPP_COM_MSG[11][0], constants.IPP_COM_MSG[11][1], constants.IPP_COM_MSG[11][2], constants.IPP_COM_MSG[11][3], constants.IPP_COM_MSG[11][4]])
                    else:
                        ### compare_info_list.append([ws[i].title, 10, 5, 411])
                        compare_info_list.append([ws[i].title, 10, 5, 11])
                    
                ### セル[10:6]: 地盤勾配区分についてデータベースに登録されている値と突合せチェックする。
                if ws[i].cell(row=10, column=6).value is None:
                    pass
                else:
                    if ws[i].cell(row=10, column=6).value not in list(gradient_code_list) and \
                        ws[i].cell(row=10, column=6).value not in list(gradient_name_list) and \
                        ws[i].cell(row=10, column=6).value not in list(gradient_name_code_list):
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=6, fill=fill, message_id=412)
                        ### compare_warn_list.append([ws[i].title, 10, 6, constants.IPP_COM_MSG[412][0], constants.IPP_COM_MSG[412][1], constants.IPP_COM_MSG[412][2], constants.IPP_COM_MSG[412][3], constants.IPP_COM_MSG[412][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=10, column=6, fill=fill, message_id=12, message=constants.IPP_COM_MSG)
                        compare_warn_list.append([ws[i].title, 10, 6, constants.IPP_COM_MSG[12][0], constants.IPP_COM_MSG[12][1], constants.IPP_COM_MSG[12][2], constants.IPP_COM_MSG[12][3], constants.IPP_COM_MSG[12][4]])
                    else:
                        ### compare_info_list.append([ws[i].title, 10, 6, 412])
                        compare_info_list.append([ws[i].title, 10, 6, 12])
        
            ###################################################################
            ### 関数内関数：EXCELセルデータ突合チェック処理（0020）
            ### (1)セル[14:2]からセル[14:10]についてデータベースに登録されている値と突合せチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_compare()関数 STEP 3/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                ### セル[14:2]: 水害区域面積の宅地についてデータベースに登録されている値と突合せチェックする。
                ### セル[14:3]: 水害区域面積の農地についてデータベースに登録されている値と突合せチェックする。
                ### セル[14:4]: 水害区域面積の地下についてデータベースに登録されている値と突合せチェックする。
                ### セル[14:6]: 工種についてデータベースに登録されている値と突合せチェックする。
                if ws[i].cell(row=14, column=6).value is None:
                    pass
                else:
                    if ws[i].cell(row=14, column=6).value not in list(kasen_kaigan_code_list) and \
                        ws[i].cell(row=14, column=6).value not in list(kasen_kaigan_name_list) and \
                        ws[i].cell(row=14, column=6).value not in list(kasen_kaigan_name_code_list):
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=2, fill=fill, message_id=416)
                        ### compare_warn_list.append([ws[i].title, 14, 6, constants.IPP_COM_MSG[416][0], constants.IPP_COM_MSG[416][1], constants.IPP_COM_MSG[416][2], constants.IPP_COM_MSG[416][3], constants.IPP_COM_MSG[416][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=2, fill=fill, message_id=16, message=constants.IPP_COM_MSG)
                        compare_warn_list.append([ws[i].title, 14, 6, constants.IPP_COM_MSG[16][0], constants.IPP_COM_MSG[16][1], constants.IPP_COM_MSG[16][2], constants.IPP_COM_MSG[16][3], constants.IPP_COM_MSG[16][4]])
                    else:
                        ### compare_info_list.append([ws[i].title, 14, 6, 416])
                        compare_info_list.append([ws[i].title, 14, 6, 16])
                    
                ### セル[14:8]: 農作物被害額についてデータベースに登録されている値と突合せチェックする。
                ### セル[14:10]: 異常気象コードについてデータベースに登録されている値と突合せチェックする。
                if ws[i].cell(row=14, column=10).value is None:
                    pass
                else:
                    if ws[i].cell(row=14, column=10).value not in list(weather_id_list) and \
                        ws[i].cell(row=14, column=10).value not in list(weather_name_list) and \
                        ws[i].cell(row=14, column=10).value not in list(weather_name_id_list):
                        ### add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=10, fill=fill, message_id=418)
                        ### compare_warn_list.append([ws[i].title, 14, 10, constants.IPP_COM_MSG[418][0], constants.IPP_COM_MSG[418][1], constants.IPP_COM_MSG[418][2], constants.IPP_COM_MSG[418][3], constants.IPP_COM_MSG[418][4]])
                        add_comment(ws=ws[i], ws_result=ws_result[i], row=14, column=10, fill=fill, message_id=18, message=constants.IPP_COM_MSG)
                        compare_warn_list.append([ws[i].title, 14, 10, constants.IPP_COM_MSG[18][0], constants.IPP_COM_MSG[18][1], constants.IPP_COM_MSG[18][2], constants.IPP_COM_MSG[18][3], constants.IPP_COM_MSG[18][4]])
                    else:
                        ### compare_info_list.append([ws[i].title, 14, 10, 418])
                        compare_info_list.append([ws[i].title, 14, 10, 18])
        
            ###################################################################
            ### 関数内関数：EXCELセルデータ突合チェック処理（0030）
            ### (1)セル[20:2]からセル[20:27]についてデータベースに登録されている値と突合せチェックする。
            ### (2)チェック結果リストにセルの行、列とメッセージを追加する。
            ### (3)IPPANワークシートとRESULTワークシートのセルに背景赤色の塗りつぶしをセットする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan.check_compare()関数 STEP 4/4.', 'DEBUG')
            for i, _ in enumerate(ws):
                if max_row[i] >= 20:
                    for j in range(20, max_row[i]+1):
                        ### セル[20:2]: 町丁名・大字名についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:3]: 名称についてデータベースに登録されている値と突合せチェックする。
                        if ws[i].cell(row=j, column=4).value is None:
                            pass
                        else:
                            if ws[i].cell(row=j, column=3).value not in list(building_code_list) and \
                                ws[i].cell(row=j, column=3).value not in list(building_name_list) and \
                                ws[i].cell(row=j, column=3).value not in list(building_name_code_list):
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=3, fill=fill, message_id=451)
                                ### compare_warn_grid.append([ws[i].title, j, 3, constants.IPP_COM_MSG[451][0], constants.IPP_COM_MSG[451][1], constants.IPP_COM_MSG[451][2], constants.IPP_COM_MSG[451][3], constants.IPP_COM_MSG[451][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=3, fill=fill, message_id=20, message=constants.IPP_COM_MSG)
                                compare_warn_grid.append([ws[i].title, j, 3, constants.IPP_COM_MSG[20][0], constants.IPP_COM_MSG[20][1], constants.IPP_COM_MSG[20][2], constants.IPP_COM_MSG[20][3], constants.IPP_COM_MSG[20][4]])
                            else:
                                ### compare_info_grid.append([ws[i].title, j, 3, 451])
                                compare_info_grid.append([ws[i].title, j, 3, 20])
                            
                        ### セル[20:4]: 地上・地下被害の区分についてデータベースに登録されている値と突合せチェックする。
                        if ws[i].cell(row=j, column=4).value is None:
                            pass
                        else:
                            if ws[i].cell(row=j, column=4).value not in list(underground_code_list) and \
                                ws[i].cell(row=j, column=4).value not in list(underground_name_list) and \
                                ws[i].cell(row=j, column=4).value not in list(underground_name_code_list):
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=452)
                                ### compare_warn_grid.append([ws[i].title, j, 4, constants.IPP_COM_MSG[452][0], constants.IPP_COM_MSG[452][1], constants.IPP_COM_MSG[452][2], constants.IPP_COM_MSG[452][3], constants.IPP_COM_MSG[452][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=4, fill=fill, message_id=21, message=constants.IPP_COM_MSG)
                                compare_warn_grid.append([ws[i].title, j, 4, constants.IPP_COM_MSG[21][0], constants.IPP_COM_MSG[21][1], constants.IPP_COM_MSG[21][2], constants.IPP_COM_MSG[21][3], constants.IPP_COM_MSG[21][4]])
                            else:
                                ### compare_info_grid.append([ws[i].title, j, 4, 452])
                                compare_info_grid.append([ws[i].title, j, 4, 21])
                            
                        ### セル[20:5]: 浸水土砂被害の区分についてデータベースに登録されている値と突合せチェックする。
                        if ws[i].cell(row=j, column=5).value is None:
                            pass
                        else:
                            if ws[i].cell(row=j, column=5).value not in list(flood_sediment_code_list) and \
                                ws[i].cell(row=j, column=5).value not in list(flood_sediment_name_list) and \
                                ws[i].cell(row=j, column=5).value not in list(flood_sediment_name_code_list):
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=5, fill=fill, message_id=453)
                                ### compare_warn_grid.append([ws[i].title, j, 5, constants.IPP_COM_MSG[453][0], constants.IPP_COM_MSG[453][1], constants.IPP_COM_MSG[453][2], constants.IPP_COM_MSG[453][3], constants.IPP_COM_MSG[453][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=5, fill=fill, message_id=22, message=constants.IPP_COM_MSG)
                                compare_warn_grid.append([ws[i].title, j, 5, constants.IPP_COM_MSG[22][0], constants.IPP_COM_MSG[22][1], constants.IPP_COM_MSG[22][2], constants.IPP_COM_MSG[22][3], constants.IPP_COM_MSG[22][4]])
                            else:
                                ### compare_info_grid.append([ws[i].title, j, 5, 453])
                                compare_info_grid.append([ws[i].title, j, 5, 22])
                            
                        ### セル[20:6]: 被害建物棟数, 床下浸水についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:7]: 被害建物棟数, 1cm〜49cmについてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:8]: 被害建物棟数, 50cm〜99cmについてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:9]: 被害建物棟数, 1m以上についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:10]: 被害建物棟数, 半壊についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:11]: 被害建物棟数, 全壊・流失についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:12]: 被害建物の延床面積についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:13]: 被災世帯数についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:14]: 被災事業所数についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:15]: 農家・漁家戸数, 床下浸水についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:16]: 農家・漁家戸数, 1cm〜49cmについてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:17]: 農家・漁家戸数, 50cm〜99cmについてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:18]: 農家・漁家戸数, 1m以上・半壊についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:19]: 農家・漁家戸数, 全壊・流失についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:20]: 事業所従業者数, 床下浸水についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:21]: 事業所従業者数, 1cm〜49cmについてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:22]: 事業所従業者数, 50cm〜99cmについてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:23]: 事業所従業者数, 1m以上・半壊についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:24]: 事業所従業者数, 全壊・流失についてデータベースに登録されている値と突合せチェックする。
                        ### セル[20:25]: 事業所の産業区分についてデータベースに登録されている値と突合せチェックする。
                        if ws[i].cell(row=j, column=25).value is None:
                            pass
                        else:
                            if ws[i].cell(row=j, column=25).value not in list(industry_code_list) and \
                                ws[i].cell(row=j, column=25).value not in list(industry_name_list) and \
                                ws[i].cell(row=j, column=25).value not in list(industry_name_code_list):
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=25, fill=fill, message_id=473)
                                ### compare_warn_grid.append([ws[i].title, j, 25, constants.IPP_COM_MSG[473][0], constants.IPP_COM_MSG[473][1], constants.IPP_COM_MSG[473][2], constants.IPP_COM_MSG[473][3], constants.IPP_COM_MSG[473][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=25, fill=fill, message_id=42, message=constants.IPP_COM_MSG)
                                compare_warn_grid.append([ws[i].title, j, 25, constants.IPP_COM_MSG[42][0], constants.IPP_COM_MSG[42][1], constants.IPP_COM_MSG[42][2], constants.IPP_COM_MSG[42][3], constants.IPP_COM_MSG[42][4]])
                            else:
                                ### compare_info_grid.append([ws[i].title, j, 25, 473])
                                compare_info_grid.append([ws[i].title, j, 25, 42])
                            
                        ### セル[20:26]: 地下空間の利用形態についてデータベースに登録されている値と突合せチェックする。
                        if ws[i].cell(row=j, column=26).value is None:
                            pass
                        else:
                            if ws[i].cell(row=j, column=26).value not in list(usage_code_list) and \
                                ws[i].cell(row=j, column=26).value not in list(usage_name_list) and \
                                ws[i].cell(row=j, column=26).value not in list(usage_name_code_list):
                                ### add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=26, fill=fill, message_id=474)
                                ### compare_warn_grid.append([ws[i].title, j, 26, constants.IPP_COM_MSG[474][0], constants.IPP_COM_MSG[474][1], constants.IPP_COM_MSG[474][2], constants.IPP_COM_MSG[474][3], constants.IPP_COM_MSG[474][4]])
                                add_comment(ws=ws[i], ws_result=ws_result[i], row=j, column=26, fill=fill, message_id=43, message=constants.IPP_COM_MSG)
                                compare_warn_grid.append([ws[i].title, j, 26, constants.IPP_COM_MSG[43][0], constants.IPP_COM_MSG[43][1], constants.IPP_COM_MSG[43][2], constants.IPP_COM_MSG[43][3], constants.IPP_COM_MSG[43][4]])
                            else:
                                ### compare_info_grid.append([ws[i].title, j, 26, 474])
                                compare_info_grid.append([ws[i].title, j, 26, 43])
                            
                        ### セル[20:27]: 備考についてデータベースに登録されている値と突合せチェックする。
            return True
        
        except:
            return False
    
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0110City.browser_post_ippan()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 1/30.', 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 2/30.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_CITY
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 3/30.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0110City.browser_post_ippan()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
        
        if user_proxy_list[0].city_code == False:
            print_log('[WARN] P0110City.browser_post_ippan()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
        
        #######################################################################
        ### 局所変数セット処理(0030)
        ### チェック用の局所変数を初期化する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 4/30.', 'DEBUG')
        ### 必須チェック用の局所変数を初期化する。
        require_info_list = []
        require_warn_list = []
        require_info_grid = []
        require_warn_grid = []

        ### 形式チェック用の局所変数を初期化する。
        format_info_list = []
        format_warn_list = []
        format_info_grid = []
        format_warn_grid = []

        ### 範囲チェック用の局所変数を初期化する。
        range_info_list = []
        range_warn_list = []
        range_info_grid = []
        range_warn_grid = []

        ### 相関チェック用の局所変数を初期化する。
        correlate_info_list = []
        correlate_warn_list = []
        correlate_info_grid = []
        correlate_warn_grid = []

        ### 突合せチェック用の局所変数を初期化する。
        compare_info_list = []
        compare_warn_list = []
        compare_info_grid = []
        compare_warn_grid = []
    
        #######################################################################
        ### 局所変数セット処理(0040)
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 5/30.', 'DEBUG')
        form = UploadIppanForm(request.POST, request.FILES)
            
        #######################################################################
        ### フォーム検証処理(0050)
        ### (1)フォームが正しい場合、処理を継続する。
        ### (2)フォームが正しくない場合、ERROR画面を表示して関数を抜ける。
        ### ※ネストを浅くするため。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 6/30.', 'DEBUG')
        if form.is_valid() == False:
            print_log('[WARN] P0110City.browser_post_ippan()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
    
        #######################################################################
        ### EXCEL入出力処理(1000)
        ### (1)局所変数に値をセットする。
        ### (2)アップロードされた一般資産調査員調査票ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 7/30.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_Ym = datetime.now(JST).strftime('%Y%m')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        
        upload_file_object = request.FILES['file']
        upload_file_name, upload_file_ext = os.path.splitext(request.FILES['file'].name)
        upload_file_name = upload_file_name + '_' + datetime_now_YmdHMS + '.xlsx'
        ### upload_file_path = 'static/repository/' + datetime_now_Ym + '/' + upload_file_name
        upload_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + user_proxy_list[0].city_code + '/' + upload_file_name

        output_file_name, output_file_ext = os.path.splitext(request.FILES['file'].name)
        output_file_name = output_file_name + '_' + datetime_now_YmdHMS + '_output' + '.xlsx'
        ### output_file_path = 'static/repository/' + datetime_now_Ym + '/' + output_file_name
        output_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + user_proxy_list[0].city_code + '/' + output_file_name

        print_log('[DEBUG] P0110City.browser_post_ippan()関数 upload_file_object={}'.format(upload_file_object), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 upload_file_path={}'.format(upload_file_path), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 upload_file_name={}'.format(upload_file_name), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 output_file_path={}'.format(output_file_path), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 output_file_name={}'.format(output_file_name), 'DEBUG')
        
        with open(upload_file_path, 'wb+') as destination:
            for chunk in upload_file_object.chunks():
                destination.write(chunk)
                
        upload_file_size = os.path.getsize(upload_file_path)/1024 ## KB
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 upload_file_size={} KB'.format(upload_file_size), '[DEBUG]')
                
        #######################################################################
        ### EXCEL入出力処理(1010)
        ### (1)アップロードされた一般資産調査員調査票ファイルのワークブックを読み込む。
        ### (2)IPPANワークシートをコピーして、チェック結果を格納するCHECK_RESULTワークシートを追加する。
        ### (3)追加したワークシートを2シート目に移動する。
        ### (4)ワークシートの最大行数を局所変数のmax_rowにセットする。
        ### (5)背景赤色の塗りつぶしを局所変数のfillにセットする。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 8/30.', 'DEBUG')
        wb = openpyxl.load_workbook(upload_file_path)
        ws = []
        ws_result = []
        ws_title = []
        for ws_temp in wb.worksheets:
            if 'IPPAN' in ws_temp.title:
                ws.append(ws_temp)
                ws_result.append(wb.copy_worksheet(ws_temp))
                ws_result[-1].title = 'RESULT' + ws_temp.title
                ws_title.append(ws_temp.title)

        for ws_temp in wb.worksheets:
            if 'RESULT' in ws_temp.title:
                wb.move_sheet(ws_temp.title, offset=-wb.index(ws_temp))
                wb.move_sheet(ws_temp.title, offset=1)

        for ws_temp in wb.worksheets:
            ws_temp.sheet_view.tabSelected = None
            
        wb.active = 1

        #######################################################################
        ### EXCEL入出力処理(1020)
        ### (1)EXCELシート毎に最大行を探索する。
        ### (2)局所変数のmax_rowリストに追加する。
        ### ※max_row_tempの初期値の19は、町丁名・大字名、名称等のキャプション部分のEXCEL行番号である。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 9/30.', 'DEBUG')
        max_row = []
        for ws_temp in ws:
            ### EXCELシート毎に最大行を探索する。
            max_row_temp = 19
            for i in range(ws_temp.max_row+1, 19, -1):
                if ws_temp.cell(row=i, column=2).value is None:
                    pass
                else:
                    max_row_temp = i
                    break
            ### 局所変数のmax_rowリストに追加する。
            max_row.append(max_row_temp)

        #######################################################################
        ### EXCEL入出力処理(1030)
        ### EXCELセルの背景赤色を局所変数のfillに設定する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 10/30.', 'DEBUG')
        fill = openpyxl.styles.PatternFill(patternType='solid', fgColor='FF0000', bgColor='FF0000')

        #######################################################################
        ### DBアクセス処理(2000)
        ### (1)DBから突合せチェック用のデータを取得する。
        ### (2)突合せチェック用のリストを生成する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 11/30.', 'DEBUG')
        ### DBから突合せチェック用のデータを取得する。
        ken_list = KEN.objects.raw("""SELECT * FROM KEN ORDER BY CAST(KEN_CODE AS INTEGER)""")
        city_list = CITY.objects.raw("""SELECT * FROM CITY ORDER BY CAST(CITY_CODE AS INTEGER)""")
        cause_list = CAUSE.objects.raw("""SELECT * FROM CAUSE ORDER BY CAST(CAUSE_CODE AS INTEGER)""")
        area_list = AREA.objects.raw("""SELECT * FROM AREA ORDER BY CAST(AREA_ID AS INTEGER)""")
        suikei_list = SUIKEI.objects.raw("""SELECT * FROM SUIKEI ORDER BY CAST(SUIKEI_CODE AS INTEGER)""")
        suikei_type_list = SUIKEI_TYPE.objects.raw("""SELECT * FROM SUIKEI_TYPE ORDER BY CAST(SUIKEI_TYPE_CODE AS INTEGER)""")
        kasen_list = KASEN.objects.raw("""SELECT * FROM KASEN ORDER BY CAST(KASEN_CODE AS INTEGER)""")
        kasen_type_list = KASEN_TYPE.objects.raw("""SELECT * FROM KASEN_TYPE ORDER BY CAST(KASEN_TYPE_CODE AS INTEGER)""")
        gradient_list = GRADIENT.objects.raw("""SELECT * FROM GRADIENT ORDER BY CAST(GRADIENT_CODE AS INTEGER)""")
        kasen_kaigan_list = KASEN_KAIGAN.objects.raw("""SELECT * FROM KASEN_KAIGAN ORDER BY CAST(KASEN_KAIGAN_CODE AS INTEGER)""")
        weather_list = WEATHER.objects.raw("""SELECT * FROM WEATHER ORDER BY CAST(WEATHER_ID AS INTEGER)""")
        building_list = BUILDING.objects.raw("""SELECT * FROM BUILDING ORDER BY CAST(BUILDING_CODE AS INTEGER)""")
        underground_list = UNDERGROUND.objects.raw("""SELECT * FROM UNDERGROUND ORDER BY CAST(UNDERGROUND_CODE AS INTEGER)""")
        flood_sediment_list = FLOOD_SEDIMENT.objects.raw("""SELECT * FROM FLOOD_SEDIMENT ORDER BY CAST(FLOOD_SEDIMENT_CODE AS INTEGER)""")
        industry_list = INDUSTRY.objects.raw("""SELECT * FROM INDUSTRY ORDER BY CAST(INDUSTRY_CODE AS INTEGER)""")
        usage_list = USAGE.objects.raw("""SELECT * FROM USAGE ORDER BY CAST(USAGE_CODE AS INTEGER)""")
        
        ### 突合せチェック用のリストを生成する。
        ken_code_list = [ken.ken_code for ken in ken_list]
        ken_name_list = [ken.ken_name for ken in ken_list]
        ken_name_code_list = [str(ken.ken_name) + ":" + str(ken.ken_code) for ken in ken_list]
        city_code_list = [city.city_code for city in city_list]
        city_name_list = [city.city_name for city in city_list]
        city_name_code_list = [str(city.city_name) + ":" + str(city.city_code) for city in city_list]
        cause_code_list = [cause.cause_code for cause in cause_list]
        cause_name_list = [cause.cause_name for cause in cause_list]
        cause_name_code_list = [str(cause.cause_name) + ":" + str(cause.cause_code) for cause in cause_list]
        area_id_list = [area.area_id for area in area_list]
        area_name_list = [area.area_name for area in area_list]
        area_name_id_list = [str(area.area_name) + ":" + str(area.area_id) for area in area_list]
        suikei_code_list = [suikei.suikei_code for suikei in suikei_list]
        suikei_name_list = [suikei.suikei_name for suikei in suikei_list]
        suikei_name_code_list = [str(suikei.suikei_name) + ":" + str(suikei.suikei_code) for suikei in suikei_list]
        suikei_type_code_list = [suikei_type.suikei_type_code for suikei_type in suikei_type_list]
        suikei_type_name_list = [suikei_type.suikei_type_name for suikei_type in suikei_type_list]
        suikei_type_name_code_list = [str(suikei_type.suikei_type_name) + ":" + str(suikei_type.suikei_type_code) for suikei_type in suikei_type_list]
        kasen_code_list = [kasen.kasen_code for kasen in kasen_list]
        kasen_name_list = [kasen.kasen_name for kasen in kasen_list]
        kasen_name_code_list = [str(kasen.kasen_name) + ":" + str(kasen.kasen_code) for kasen in kasen_list]
        kasen_type_code_list = [kasen_type.kasen_type_code for kasen_type in kasen_type_list]
        kasen_type_name_list = [kasen_type.kasen_type_name for kasen_type in kasen_type_list]
        kasen_type_name_code_list = [str(kasen_type.kasen_type_name) + ":" + str(kasen_type.kasen_type_code) for kasen_type in kasen_type_list]
        gradient_code_list = [gradient.gradient_code for gradient in gradient_list]
        gradient_name_list = [gradient.gradient_name for gradient in gradient_list]
        gradient_name_code_list = [str(gradient.gradient_name) + ":" + str(gradient.gradient_code) for gradient in gradient_list]
        kasen_kaigan_code_list = [kasen_kaigan.kasen_kaigan_code for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_list = [kasen_kaigan.kasen_kaigan_name for kasen_kaigan in kasen_kaigan_list]
        kasen_kaigan_name_code_list = [str(kasen_kaigan.kasen_kaigan_name) + ":" + str(kasen_kaigan.kasen_kaigan_code) for kasen_kaigan in kasen_kaigan_list]
        weather_id_list = [weather.weather_id for weather in weather_list]
        weather_name_list = [weather.weather_name for weather in weather_list]
        weather_name_id_list = [str(weather.weather_name) + ":" + str(weather.weather_id) for weather in weather_list]
        building_code_list = [building.building_code for building in building_list]
        building_name_list = [building.building_name for building in building_list]
        building_name_code_list = [str(building.building_name) + ":" + str(building.building_code) for building in building_list]
        underground_code_list = [underground.underground_code for underground in underground_list]
        underground_name_list = [underground.underground_name for underground in underground_list]
        underground_name_code_list = [str(underground.underground_name) + ":" + str(underground.underground_code) for underground in underground_list]
        flood_sediment_code_list = [flood_sediment.flood_sediment_code for flood_sediment in flood_sediment_list]
        flood_sediment_name_list = [flood_sediment.flood_sediment_name for flood_sediment in flood_sediment_list]
        flood_sediment_name_code_list = [str(flood_sediment.flood_sediment_name) + ":" + str(flood_sediment.flood_sediment_code) for flood_sediment in flood_sediment_list]
        industry_code_list = [industry.industry_code for industry in industry_list]
        industry_name_list = [industry.industry_name for industry in industry_list]
        industry_name_code_list = [str(industry.industry_name) + ":" + str(industry.industry_code) for industry in industry_list]
        usage_code_list = [usage.usage_code for usage in usage_list]
        usage_name_list = [usage.usage_name for usage in usage_list]
        usage_name_code_list = [str(usage.usage_name) + ":" + str(usage.usage_code) for usage in usage_list]

        #######################################################################
        ### 必須、形式、範囲、相関、突合せチェック処理(2010)
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 12/30.', 'DEBUG')
        bool_return = check_require()
        if bool_return == False:
            print_log('[ERROR] check_require()関数が異常終了しました。', 'WARN')
            raise Exception
            
        bool_return = check_format()
        if bool_return == False:
            print_log('[ERROR] check_format()関数が異常終了しました。', 'WARN')
            raise Exception

        bool_return = check_range()
        if bool_return == False:
            print_log('[ERROR] check_range()関数が異常終了しました。', 'WARN')
            raise Exception

        bool_return = check_correlate()
        if bool_return == False:
            print_log('[ERROR] check_correlate()関数が異常終了しました。', 'WARN')
            raise Exception

        bool_return = check_compare()
        if bool_return == False:
            print_log('[ERROR] check_compare()関数が異常終了しました。', 'WARN')
            raise Exception

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(3000)
        ### チェック結果ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 13/30.', 'DEBUG')
        wb.save(output_file_path)

        #######################################################################
        ### ファイル入出力処理、ログ出力処理(3010)
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 14/30.', 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 max_row={}'.format(max_row), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(require_warn_list)={}'.format(len(require_warn_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(format_warn_list)={}'.format(len(format_warn_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(range_warn_list)={}'.format(len(range_warn_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(correlate_warn_list)={}'.format(len(correlate_warn_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(compare_warn_list)={}'.format(len(compare_warn_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(require_info_list)={}'.format(len(require_info_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(format_info_list)={}'.format(len(format_info_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(range_info_list)={}'.format(len(range_info_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(correlate_info_list)={}'.format(len(correlate_info_list)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 len(compare_info_list)={}'.format(len(compare_info_list)), 'DEBUG')
        
        #######################################################################
        ### ファイル入出力処理、ログ出力処理(3020)
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 15/30.', 'DEBUG')
        info_str = ''
        warn_str = ''
        if len(require_info_list) > 0:
            for i in range(len(require_info_list)):
                info_str = info_str + \
                    str(require_info_list[i][0]) + ',' + \
                    str(require_info_list[i][1]) + ',' + \
                    str(require_info_list[i][2]) + ',' + \
                    str(constants.IPP_REQ_MSG[require_info_list[i][3]][0]) + ',' + \
                    str(constants.IPP_REQ_MSG[require_info_list[i][3]][1]) + ',' + \
                    str(constants.IPP_REQ_MSG[require_info_list[i][3]][2]) + '\n'        
        
        if len(format_info_list) > 0:
            for i in range(len(format_info_list)):
                info_str = info_str + \
                    str(format_info_list[i][0]) + ',' + \
                    str(format_info_list[i][1]) + ',' + \
                    str(format_info_list[i][2]) + ',' + \
                    str(constants.IPP_FOR_MSG[format_info_list[i][3]][0]) + ',' + \
                    str(constants.IPP_FOR_MSG[format_info_list[i][3]][1]) + ',' + \
                    str(constants.IPP_FOR_MSG[format_info_list[i][3]][2]) + '\n'        

        if len(range_info_list) > 0:
            for i in range(len(range_info_list)):
                info_str = info_str + \
                    str(range_info_list[i][0]) + ',' + \
                    str(range_info_list[i][1]) + ',' + \
                    str(range_info_list[i][2]) + ',' + \
                    str(constants.IPP_RAN_MSG[range_info_list[i][3]][0]) + ',' + \
                    str(constants.IPP_RAN_MSG[range_info_list[i][3]][1]) + ',' + \
                    str(constants.IPP_RAN_MSG[range_info_list[i][3]][2]) + '\n'        

        if len(correlate_info_list) > 0:
            for i in range(len(correlate_info_list)):
                info_str = info_str + \
                    str(correlate_info_list[i][0]) + ',' + \
                    str(correlate_info_list[i][1]) + ',' + \
                    str(correlate_info_list[i][2]) + ',' + \
                    str(constants.IPP_COR_MSG[correlate_info_list[i][3]][0]) + ',' + \
                    str(constants.IPP_COR_MSG[correlate_info_list[i][3]][1]) + ',' + \
                    str(constants.IPP_COR_MSG[correlate_info_list[i][3]][2]) + '\n'        

        if len(compare_info_list) > 0:
            for i in range(len(compare_info_list)):
                info_str = info_str + \
                    str(compare_info_list[i][0]) + ',' + \
                    str(compare_info_list[i][1]) + ',' + \
                    str(compare_info_list[i][2]) + ',' + \
                    str(constants.IPP_COM_MSG[compare_info_list[i][3]][0]) + ',' + \
                    str(constants.IPP_COM_MSG[compare_info_list[i][3]][1]) + ',' + \
                    str(constants.IPP_COM_MSG[compare_info_list[i][3]][2]) + '\n'        

        if len(require_warn_list) > 0:
            for i in range(len(require_warn_list)):
                warn_str = warn_str + \
                    str(require_warn_list[i][0]) + ',' + \
                    str(require_warn_list[i][1]) + ',' + \
                    str(require_warn_list[i][2]) + ',' + \
                    str(constants.IPP_REQ_MSG[require_warn_list[i][3]][0]) + ',' + \
                    str(constants.IPP_REQ_MSG[require_warn_list[i][3]][1]) + ',' + \
                    str(constants.IPP_REQ_MSG[require_warn_list[i][3]][2]) + '\n'        
        
        if len(format_warn_list) > 0:
            for i in range(len(format_warn_list)):
                warn_str = warn_str + \
                    str(format_warn_list[i][0]) + ',' + \
                    str(format_warn_list[i][1]) + ',' + \
                    str(format_warn_list[i][2]) + ',' + \
                    str(constants.IPP_FOR_MSG[format_warn_list[i][3]][0]) + ',' + \
                    str(constants.IPP_FOR_MSG[format_warn_list[i][3]][1]) + ',' + \
                    str(constants.IPP_FOR_MSG[format_warn_list[i][3]][2]) + '\n'        

        if len(range_warn_list) > 0:
            for i in range(len(range_warn_list)):
                warn_str = warn_str + \
                    str(range_warn_list[i][0]) + ',' + \
                    str(range_warn_list[i][1]) + ',' + \
                    str(range_warn_list[i][2]) + ',' + \
                    str(constants.IPP_RAN_MSG[range_warn_list[i][3]][0]) + ',' + \
                    str(constants.IPP_RAN_MSG[range_warn_list[i][3]][1]) + ',' + \
                    str(constants.IPP_RAN_MSG[range_warn_list[i][3]][2]) + '\n'        

        if len(correlate_warn_list) > 0:
            for i in range(len(correlate_warn_list)):
                warn_str = warn_str + \
                    str(correlate_warn_list[i][0]) + ',' + \
                    str(correlate_warn_list[i][1]) + ',' + \
                    str(correlate_warn_list[i][2]) + ',' + \
                    str(constants.IPP_COR_MSG[correlate_warn_list[i][3]][0]) + ',' + \
                    str(constants.IPP_COR_MSG[correlate_warn_list[i][3]][1]) + ',' + \
                    str(constants.IPP_COR_MSG[correlate_warn_list[i][3]][2]) + '\n'        

        if len(compare_warn_list) > 0:
            for i in range(len(compare_warn_list)):
                warn_str = warn_str + \
                    str(compare_warn_list[i][0]) + ',' + \
                    str(compare_warn_list[i][1]) + ',' + \
                    str(compare_warn_list[i][2]) + ',' + \
                    str(constants.IPP_COM_MSG[compare_warn_list[i][3]][0]) + ',' + \
                    str(constants.IPP_COM_MSG[compare_warn_list[i][3]][1]) + ',' + \
                    str(constants.IPP_COM_MSG[compare_warn_list[i][3]][2]) + '\n'        

        #######################################################################
        ### DBアクセス処理(4000)
        ### ※入力チェックでエラーが発見された場合に処理する。
        ### ※ネストを浅くするために、処理対象外の場合、終了させる。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 16/30.', 'DEBUG')
        if len(require_warn_list) > 0 or len(require_warn_grid) > 0 or \
            len(format_warn_list) > 0 or len(format_warn_grid) > 0 or \
            len(range_warn_list) > 0 or len(range_warn_grid) > 0 or \
            len(correlate_warn_list) > 0 or len(correlate_warn_grid) > 0 or \
            len(compare_warn_list) > 0 or len(compare_warn_grid) > 0:

            connection_cursor = connection.cursor()
            try:
                connection_cursor.execute("""BEGIN""")
                
                ###############################################################
                ### DBアクセス処理(4010)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の市区町村のIPPAN_HEADERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ###############################################################
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 17/30.', 'DEBUG')
                params = dict({
                    'CITY_CODE': split_name_code(ws[0].cell(row=7, column=3).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE IPPAN_HEADER SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE ippan_header_id IN (
                    SELECT 
                        ippan_header_id 
                    FROM IPPAN_HEADER 
                    WHERE 
                        city_code=%(CITY_CODE)s AND 
                        deleted_at IS NULL)""", params)
        
                ###############################################################
                ### DBアクセス処理(4020)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の市区町村のIPPANのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ###############################################################
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 18/30.', 'DEBUG')
                params = dict({
                    'CITY_CODE': split_name_code(ws[0].cell(row=7, column=3).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE IPPAN SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE ippan_id IN (
                    SELECT 
                        ippan_id 
                    FROM IPPAN_VIEW 
                    WHERE 
                        city_code=%(CITY_CODE)s AND 
                        deleted_at IS NULL)""", params)
    
                ###############################################################
                ### DBアクセス処理(4030)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の市区町村のIPPAN_SUMMARYのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ###############################################################
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 19/30.', 'DEBUG')
                params = dict({
                    'CITY_CODE': split_name_code(ws[0].cell(row=7, column=3).value)[-1]
                })
                connection_cursor.execute("""
                    UPDATE IPPAN_SUMMARY SET 
                        deleted_at=CURRENT_TIMESTAMP 
                    WHERE ippan_id IN (
                    SELECT 
                        ippan_id 
                    FROM IPPAN_SUMMARY_VIEW 
                    WHERE 
                        city_code=%(CITY_CODE)s AND 
                        deleted_at IS NULL)""", params)
    
                ###############################################################
                ### DBアクセス処理(4040)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※既存の市区町村のIPPAN_TRIGGERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
                ###############################################################
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 20/30.', 'DEBUG')
                func_params = dict({
                    'connection_cursor': connection_cursor, 
                    'ken_code': None, 
                    'city_code': split_name_code(ws[0].cell(row=7, column=3).value)[-1], 
                    'action_code': _IPP_ACT_01
                })
                bool_return = delete_message(metadata=func_params)
                if bool_return == False:
                    print_log('[ERROR] delete_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
                ###############################################################
                ### DBアクセス処理(4050)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※トリガーテーブルにIPP_ACT_01トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 21/30.', 'DEBUG')
                func_params = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': None, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[0].cell(row=7, column=2).value)[-1]), 
                    'city_code': convert_empty_to_none(split_name_code(ws[0].cell(row=7, column=3).value)[-1]), 
                    'action_code': _IPP_ACT_01, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': get_info_log(), 
                    'warn_log': get_warn_log(), 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=func_params)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
                ###############################################################
                ### DBアクセス処理(4060)
                ### ※入力チェックで警告が発見された場合に処理する。
                ### ※トリガーテーブルにIPP_ACT_02トリガーを実行済、失敗として登録する。
                ###############################################################
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 22/30.', 'DEBUG')
                func_params = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': None, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[0].cell(row=7, column=2).value)[-1]), 
                    'city_code': convert_empty_to_none(split_name_code(ws[0].cell(row=7, column=3).value)[-1]), 
                    'action_code': _IPP_ACT_02, 
                    'status_code': _FAILURE, 
                    'info_count': 0, 
                    'warn_count': len(ws), 
                    'info_log': info_str, 
                    'warn_log': warn_str, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name, 
                })
                bool_return = publish_consume_message(metadata=func_params)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                    
                connection_cursor.execute("""COMMIT""")
                
            except:
                print_log('[ERROR] P0110City.browser_post_ippan()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
                print_log('[ERROR] P0110City.browser_post_ippan()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
                connection_cursor.execute("""ROLLBACK""")
            finally:
                connection_cursor.close()
                
            ###################################################################
            ### レスポンスセット処理(4070)
            ### ※入力チェックで警告が発見された場合に処理する。
            ### ※テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 23/30.', 'DEBUG')
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'browser_post_ippan_warn': 'browser_post_ippan_warn',
                'require_warn_grid': require_warn_grid, 
                'require_warn_list': require_warn_list, 
                'format_warn_grid': format_warn_grid,
                'format_warn_list': format_warn_list,
                'range_warn_grid': range_warn_grid,
                'range_warn_list': range_warn_list,
                'correlate_warn_grid': correlate_warn_grid,
                'correlate_warn_list': correlate_warn_list,
                'compare_warn_grid': compare_warn_grid,
                'compare_warn_list': compare_warn_list,
                'output_file_path': output_file_path, 
            }
            print_log('[WARN] P0110City.browser_post_ippan()関数が警告終了しました。', 'INFO')
            return False, HttpResponse(template.render(context, request))

        #######################################################################
        ### DBアクセス処理(5000)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        ### ※入力データ_ヘッダ部分テーブルにデータを登録する。
        ### ※入力データ_一覧票部分テーブルにデータを登録する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 24/30.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""")
            
            ###################################################################
            ### DBアクセス処理(5010)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の市区町村のIPPAN_HEADERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 25/30.', 'DEBUG')
            params = dict({
                'CITY_CODE': split_name_code(ws[0].cell(row=7, column=3).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE IPPAN_HEADER SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE ippan_header_id IN (
                SELECT 
                    ippan_header_id 
                FROM IPPAN_HEADER 
                WHERE 
                    city_code=%(CITY_CODE)s AND 
                    deleted_at IS NULL)""", params)
    
            ###################################################################
            ### DBアクセス処理(5020)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の市区町村のIPPANのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 26/30.', 'DEBUG')
            params = dict({
                'CITY_CODE': split_name_code(ws[0].cell(row=7, column=3).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE IPPAN SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE ippan_id IN (
                SELECT 
                    ippan_id 
                FROM IPPAN_VIEW 
                WHERE 
                    city_code=%(CITY_CODE)s AND 
                    deleted_at IS NULL)""", params)

            ###################################################################
            ### DBアクセス処理(5030)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の市区町村のIPPAN_SUMMARYのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 27/30.', 'DEBUG')
            params = dict({
                'CITY_CODE': split_name_code(ws[0].cell(row=7, column=3).value)[-1]
            })
            connection_cursor.execute("""
                UPDATE IPPAN_SUMMARY SET 
                    deleted_at=CURRENT_TIMESTAMP 
                WHERE ippan_id IN (
                SELECT 
                    ippan_id 
                FROM IPPAN_SUMMARY_VIEW 
                WHERE 
                    city_code=%(CITY_CODE)s AND 
                    deleted_at IS NULL)""", params)

            ###################################################################
            ### DBアクセス処理(5040)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※既存の市区町村のIPPAN_TRIGGERのDELETED_ATにCURRENT_TIMESTAMPをセットして、削除済とする。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 28/30.', 'DEBUG')
            func_params = dict({
                'connection_cursor': connection_cursor, 
                'ken_code': None, 
                'city_code': split_name_code(ws[0].cell(row=7, column=3).value)[-1], 
                'action_code': _IPP_ACT_01
            })
            bool_return = delete_message(metadata=func_params)
            if bool_return == False:
                print_log('[ERROR] delete_message()関数が異常終了しました。', 'ERROR')
                raise Exception

            ###################################################################
            ### DBアクセス処理(5050)
            ### ※入力チェックで警告が発見されなかった場合に処理する。
            ### ※ippan_header_id__max で正しい。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 29/30.', 'DEBUG')
            for i, _ in enumerate(ws):
                ippan_header_id = IPPAN_HEADER.objects.all().aggregate(Max('ippan_header_id'))['ippan_header_id__max']
                if ippan_header_id is None:
                    ippan_header_id = 1
                else:
                    ippan_header_id += 1
                    
                ###############################################################
                ### DBアクセス処理(5060)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※一般資産調査員調査票_ヘッダ部分テーブルにデータを登録する。
                ###############################################################
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 29_1/30.', 'DEBUG')
                params = dict({
                    'IPPAN_HEADER_ID': ippan_header_id, 
                    'IPPAN_HEADER_NAME': ws_title[i], 
                    'KEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=2).value)[-1]), 
                    'CITY_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=3).value)[-1]), 
                    'BEGIN_DATE': convert_empty_to_none(ws[i].cell(row=7, column=4).value), 
                    'END_DATE': convert_empty_to_none(ws[i].cell(row=7, column=5).value), 
                    'CAUSE_1_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=6).value)[-1]), 
                    'CAUSE_2_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=7).value)[-1]), 
                    'CAUSE_3_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=8).value)[-1]), 
                    'AREA_ID': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=9).value)[-1]), 
                    'SUIKEI_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=10, column=2).value)[-1]), 
                    'KASEN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=10, column=4).value)[-1]), 
                    'GRADIENT_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=10, column=6).value)[-1]), 
                    'RESIDENTIAL_AREA': convert_empty_to_none(ws[i].cell(row=14, column=2).value), 
                    'AGRICULTURAL_AREA': convert_empty_to_none(ws[i].cell(row=14, column=3).value), 
                    'UNDERGROUND_AREA': convert_empty_to_none(ws[i].cell(row=14, column=4).value), 
                    'KASEN_KAIGAN_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=14, column=6).value)[-1]), 
                    'CROP_DAMAGE': convert_empty_to_none(ws[i].cell(row=14, column=8).value), 
                    'WEATHER_ID': convert_empty_to_none(split_name_code(ws[i].cell(row=14, column=10).value)[-1]), 
                    'DELETED_AT': None, 
                    'UPLOAD_FILE_PATH': upload_file_path, 
                    'UPLOAD_FILE_NAME': upload_file_name, 
                    'UPLOAD_FILE_SIZE': upload_file_size,  ### ADD 2023/03/03
                    'SUMMARY_FILE_PATH': None, 
                    'SUMMARY_FILE_NAME': None
                })
                connection_cursor.execute("""
                    INSERT INTO IPPAN_HEADER (
                        ippan_header_id, ippan_header_name, ken_code, city_code, begin_date, end_date, 
                        cause_1_code, cause_2_code, cause_3_code, area_id, suikei_code, 
                        kasen_code, gradient_code, residential_area, agricultural_area, underground_area, 
                        kasen_kaigan_code, crop_damage, weather_id, committed_at, deleted_at, upload_file_path, 
                        upload_file_name, upload_file_size, summary_file_path, summary_file_name 
                    ) VALUES (
                        %(IPPAN_HEADER_ID)s, 
                        %(IPPAN_HEADER_NAME)s, 
                        %(KEN_CODE)s, 
                        %(CITY_CODE)s, 
                        TO_DATE(%(BEGIN_DATE)s, 'yyyy/mm/dd'), 
                        TO_DATE(%(END_DATE)s, 'yyyy/mm/dd'), 
                        %(CAUSE_1_CODE)s, 
                        %(CAUSE_2_CODE)s, 
                        %(CAUSE_3_CODE)s, 
                        %(AREA_ID)s, 
                        %(SUIKEI_CODE)s, 
                        %(KASEN_CODE)s, 
                        %(GRADIENT_CODE)s, 
                        %(RESIDENTIAL_AREA)s, 
                        %(AGRICULTURAL_AREA)s, 
                        %(UNDERGROUND_AREA)s, 
                        %(KASEN_KAIGAN_CODE)s, 
                        %(CROP_DAMAGE)s, 
                        %(WEATHER_ID)s, 
                        CURRENT_TIMESTAMP,  -- committed_at 
                        %(DELETED_AT)s, 
                        %(UPLOAD_FILE_PATH)s, 
                        %(UPLOAD_FILE_NAME)s, 
                        %(UPLOAD_FILE_SIZE)s, 
                        %(SUMMARY_FILE_PATH)s, 
                        %(SUMMARY_FILE_NAME)s)""", params)
                    
                ###############################################################
                ### DBアクセス処理(5070)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※一般資産調査員調査票_一覧表部分テーブルにデータを登録する。
                ###############################################################
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 29_2/30.', 'DEBUG')
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 max_row[i]={}'.format(max_row[i]), 'DEBUG')
                if max_row[i] >= 20:
                    for j in range(20, max_row[i]+1):
                        print_log('[DEBUG] P0110City.browser_post_ippan()関数 j={}'.format(j), 'DEBUG')
                        params = dict({
                            'IPPAN_NAME': convert_empty_to_none(ws[i].cell(row=j, column=2).value), 
                            'IPPAN_HEADER_ID': ippan_header_id, 
                            'BUILDING_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=3).value)[-1]), 
                            'UNDERGROUND_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=4).value)[-1]), 
                            'FLOOD_SEDIMENT_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=5).value)[-1]), 
                            'BUILDING_LV00': convert_empty_to_none(ws[i].cell(row=j, column=6).value), 
                            'BUILDING_LV01_49': convert_empty_to_none(ws[i].cell(row=j, column=7).value), 
                            'BUILDING_LV50_99': convert_empty_to_none(ws[i].cell(row=j, column=8).value), 
                            'BUILDING_LV100': convert_empty_to_none(ws[i].cell(row=j, column=9).value), 
                            'BUILDING_HALF': convert_empty_to_none(ws[i].cell(row=j, column=10).value), 
                            'BUILDING_FULL': convert_empty_to_none(ws[i].cell(row=j, column=11).value), 
                            'FLOOR_AREA': convert_empty_to_none(ws[i].cell(row=j, column=12).value), 
                            'FAMILY': convert_empty_to_none(ws[i].cell(row=j, column=13).value), 
                            'OFFICE': convert_empty_to_none(ws[i].cell(row=j, column=14).value), 
                            'FARMER_FISHER_LV00': convert_empty_to_none(ws[i].cell(row=j, column=15).value), 
                            'FARMER_FISHER_LV01_49': convert_empty_to_none(ws[i].cell(row=j, column=16).value), 
                            'FARMER_FISHER_LV50_99': convert_empty_to_none(ws[i].cell(row=j, column=17).value), 
                            'FARMER_FISHER_LV100': convert_empty_to_none(ws[i].cell(row=j, column=18).value), 
                            'FARMER_FISHER_FULL': convert_empty_to_none(ws[i].cell(row=j, column=19).value), 
                            'EMPLOYEE_LV00': convert_empty_to_none(ws[i].cell(row=j, column=20).value), 
                            'EMPLOYEE_LV01_49': convert_empty_to_none(ws[i].cell(row=j, column=21).value), 
                            'EMPLOYEE_LV50_99': convert_empty_to_none(ws[i].cell(row=j, column=22).value), 
                            'EMPLOYEE_LV100': convert_empty_to_none(ws[i].cell(row=j, column=23).value), 
                            'EMPLOYEE_FULL': convert_empty_to_none(ws[i].cell(row=j, column=24).value), 
                            'INDUSTRY_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=25).value)[-1]), 
                            'USAGE_CODE': convert_empty_to_none(split_name_code(ws[i].cell(row=j, column=26).value)[-1]), 
                            'COMMENT': convert_empty_to_none(ws[i].cell(row=j, column=27).value), 
                            'DELETED_AT': None
                        })
                        connection_cursor.execute(""" 
                            INSERT INTO IPPAN (
                                ippan_id, ippan_name, ippan_header_id, 
                                building_code, underground_code, flood_sediment_code, 
                                building_lv00, building_lv01_49, building_lv50_99, building_lv100, building_half, building_full, 
                                floor_area, family, office, 
                                farmer_fisher_lv00, farmer_fisher_lv01_49, farmer_fisher_lv50_99, farmer_fisher_lv100, farmer_fisher_full, 
                                employee_lv00, employee_lv01_49, employee_lv50_99, employee_lv100, employee_full, 
                                industry_code, usage_code, comment, 
                                committed_at, deleted_at 
                            ) VALUES (
                                (SELECT CASE WHEN (MAX(ippan_id+1)) IS NULL THEN CAST(0 AS INTEGER) ELSE CAST(MAX(ippan_id+1) AS INTEGER) END AS ippan_id FROM IPPAN), -- ippan_id 
                                %(IPPAN_NAME)s, 
                                %(IPPAN_HEADER_ID)s, 
                                %(BUILDING_CODE)s, 
                                %(UNDERGROUND_CODE)s, 
                                %(FLOOD_SEDIMENT_CODE)s, 
                                %(BUILDING_LV00)s, 
                                %(BUILDING_LV01_49)s, 
                                %(BUILDING_LV50_99)s, 
                                %(BUILDING_LV100)s, 
                                %(BUILDING_HALF)s, 
                                %(BUILDING_FULL)s, 
                                %(FLOOR_AREA)s, 
                                %(FAMILY)s, 
                                %(OFFICE)s, 
                                %(FARMER_FISHER_LV00)s, 
                                %(FARMER_FISHER_LV01_49)s, 
                                %(FARMER_FISHER_LV50_99)s, 
                                %(FARMER_FISHER_LV100)s, 
                                %(FARMER_FISHER_FULL)s, 
                                %(EMPLOYEE_LV00)s, 
                                %(EMPLOYEE_LV01_49)s, 
                                %(EMPLOYEE_LV50_99)s, 
                                %(EMPLOYEE_LV100)s, 
                                %(EMPLOYEE_FULL)s, 
                                %(INDUSTRY_CODE)s, 
                                %(USAGE_CODE)s, 
                                %(COMMENT)s, 
                                CURRENT_TIMESTAMP, -- committed_at 
                                %(DELETED_AT)s) """, params)

                ###############################################################
                ### DBアクセス処理(5080)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにIPP_ACT_01トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 29_3/30.', 'DEBUG')
                func_params = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': ippan_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[0].cell(row=7, column=2).value)[-1]), 
                    'city_code': convert_empty_to_none(split_name_code(ws[0].cell(row=7, column=3).value)[-1]), 
                    'action_code': _IPP_ACT_01, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': get_info_log(), 
                    'warn_log': get_warn_log(), 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=func_params)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception

                ###############################################################
                ### DBアクセス処理(5090)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにIPP_ACT_02トリガーを実行済、成功として登録する。
                ###############################################################
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 29_4/30.', 'DEBUG')
                func_params = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': ippan_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=2).value)[-1]), 
                    'city_code': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=3).value)[-1]), 
                    'action_code': _IPP_ACT_02, 
                    'status_code': _SUCCESS, 
                    'info_count': 1, 
                    'warn_count': 0, 
                    'info_log': info_str, 
                    'warn_log': warn_str, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_consume_message(metadata=func_params)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
            
                ###############################################################
                ### DBアクセス処理(5100)
                ### ※入力チェックで警告が発見されなかった場合に処理する。
                ### ※トリガーテーブルにIPP_ACT_03トリガーを未実行＝次回実行対象として登録する。
                ###############################################################
                print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 29_5/30.', 'DEBUG')
                func_params = dict({
                    'connection_cursor': connection_cursor, 
                    'header_id': ippan_header_id, 
                    'ken_code': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=2).value)[-1]), 
                    'city_code': convert_empty_to_none(split_name_code(ws[i].cell(row=7, column=3).value)[-1]), 
                    'action_code': _IPP_ACT_03, 
                    'status_code': _RUNNING, 
                    'download_file_path': None, 
                    'download_file_name': None, 
                    'upload_file_path': upload_file_path, 
                    'upload_file_name': upload_file_name
                })
                bool_return = publish_message(metadata=func_params)
                if bool_return == False:
                    print_log('[ERROR] publish_consume_message()関数が異常終了しました。', 'ERROR')
                    raise Exception
                
            connection_cursor.execute("""COMMIT""")
            
        except:
            print_log('[ERROR] P0110City.browser_post_ippan()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0110City.browser_post_ippan()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0110City.browser_post_ippan()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
            
        finally:
            connection_cursor.close()
        
        #######################################################################
        ### レスポンスセット処理(5110)
        ### ※入力チェックで警告が発見されなかった場合に処理する。
        ### ※テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_ippan()関数 STEP 30/30.', 'DEBUG')
        template = loader.get_template('P0110City/browser/browser.html')
        context = {
            'browser_post_ippan_info': 'browser_post_ippan_info',
            'require_info_grid': require_info_grid, 
            'require_info_list': require_info_list, 
            'format_info_grid': format_info_grid,
            'format_info_list': format_info_list,
            'range_info_grid': range_info_grid,
            'range_info_list': range_info_list,
            'correlate_info_grid': correlate_info_grid,
            'correlate_info_list': correlate_info_list,
            'compare_info_grid': compare_info_grid,
            'compare_info_list': compare_info_list,
        }
        print_log('[INFO] P0110City.browser_post_ippan()関数が正常終了しました。', 'INFO')
        return True, HttpResponse(template.render(context, request))
        
    except:
        print_log('[ERROR] P0110City.browser_post_ippan()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.browser_post_ippan()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.browser_post_ippan()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0110City/browser/browser.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))
    
###############################################################################
### 市区町村用ブラウザ
###############################################################################
def browser_post_area(request):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0110City.browser_post_area()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0110City.browser_post_area()関数 STEP 1/13.', 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_area()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_area()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_area()関数 STEP 2/13.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_CITY
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_area()関数 STEP 3/13.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0110City.browser_post_area()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
        
        if user_proxy_list[0].city_code == False:
            print_log('[WARN] P0110City.browser_post_area()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))

        #######################################################################
        ### 局所変数セット処理(0030)
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_area()関数 STEP 4/13.', 'DEBUG')
        form = UploadAreaForm(request.POST, request.FILES)
            
        #######################################################################
        ### フォーム検証処理(0040)
        ### (1)フォームが正しい場合、処理を継続する。
        ### (2)フォームが正しくない場合、ERROR画面を表示して関数を抜ける。
        ### ※ネストを浅くするため。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_area()関数 STEP 5/13.', 'DEBUG')
        if form.is_valid() == False:
            print_log('[WARN] P0110City.browser_post_area()関数が警告終了しました。', 'WARN')
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
    
        #######################################################################
        ### 水害区域図入出力処理(1000)
        ### (1)局所変数に値をセットする。
        ### (2)アップロードされた水害区域図ファイルを保存する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_area()関数 STEP 6/13.', 'DEBUG')
        JST = timezone(timedelta(hours=9), 'JST')
        datetime_now_Ym = datetime.now(JST).strftime('%Y%m')
        datetime_now_YmdHMS = datetime.now(JST).strftime('%Y%m%d%H%M%S')
        
        upload_file_object = request.FILES['file']
        upload_file_name, upload_file_ext = os.path.splitext(request.FILES['file'].name)
        upload_file_name = upload_file_name + '_' + datetime_now_YmdHMS + '.pdf'
        upload_file_path = 'static/upload/' + user_proxy_list[0].ken_code + '/' + user_proxy_list[0].city_code + '/' + upload_file_name
        
        print_log('[DEBUG] P0110City.browser_post_area()関数 upload_file_object={}'.format(upload_file_object), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_area()関数 upload_file_path={}'.format(upload_file_path), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_area()関数 upload_file_name={}'.format(upload_file_name), 'DEBUG')

        with open(upload_file_path, 'wb+') as destination:
            for chunk in upload_file_object.chunks():
                destination.write(chunk)

        upload_file_size = os.path.getsize(upload_file_path)/1024 ## KB
        print_log('[DEBUG] P0110City.browser_post_area()関数 upload_file_size={} KB'.format(upload_file_size), '[DEBUG]')

        #######################################################################
        ### ポストデータ検証処理(1010)
        ### ポストされたデータをチェックして、局所変数に値をセットする。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_area()関数 STEP 7/13.', 'DEBUG')
        area_id = request.POST.get('area_id')
        area_name = request.POST.get('area_name')
        print_log('[DEBUG] P0110City.browser_post_area()関数 area_id={}'.format(area_id), 'DEBUG')
        print_log('[DEBUG] P0110City.browser_post_area()関数 area_name={}'.format(area_name), 'DEBUG')

        #######################################################################
        ### DBアクセス処理(2000)
        ### 水害区域テーブルのデータを削除済に更新する。
        ### 水害区域テーブルにデータを登録する。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_area()関数 STEP 8/13.', 'DEBUG')
        connection_cursor = connection.cursor()
        try:
            connection_cursor.execute("""BEGIN""");
            
            ###################################################################
            ### DBアクセス処理(2010)
            ### 水害区域テーブルのデータを削除済に更新する。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_area()関数 STEP 9/13.', 'DEBUG')
            params = dict({
                'AREA_ID': int(area_id)
            })
            connection_cursor.execute("""
                DELETE 
                FROM AREA 
                WHERE 
                    area_id=%(AREA_ID)s""", params)
            
            ###################################################################
            ### DBアクセス処理(2020)
            ### 水害区域テーブルにデータを登録する。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_area()関数 STEP 10/13.', 'DEBUG')
            params = dict({
                'AREA_ID': int(area_id), 
                'AREA_NAME': area_name, 
                'KEN_CODE': user_proxy_list[0].ken_code, 
                'CITY_CODE': user_proxy_list[0].city_code, 
                'DELETED_AT': None, 
                'UPLOAD_FILE_PATH': upload_file_path, 
                'UPLOAD_FILE_NAME': upload_file_name, 
                'UPLOAD_FILE_SIZE': upload_file_size
            })
            connection_cursor.execute("""
                INSERT INTO AREA (
                    area_id, area_name, ken_code, city_code, committed_at, deleted_at, upload_file_path, upload_file_name, upload_file_size 
                ) VALUES (
                    %(AREA_ID)s, 
                    %(AREA_NAME)s, 
                    %(KEN_CODE)s, 
                    %(CITY_CODE)s, 
                    CURRENT_TIMESTAMP, 
                    %(DELETED_AT)s, 
                    %(UPLOAD_FILE_PATH)s, 
                    %(UPLOAD_FILE_NAME)s, 
                    %(UPLOAD_FILE_SIZE)s)""", params)
    
            ###################################################################
            ### DBアクセス処理(2030)
            ### トリガーテーブルにB01水害区域図アップロードトリガーを実行済、成功として登録する。
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_area()関数 STEP 11/13.', 'DEBUG')
            func_params = dict({
                'connection_cursor': connection_cursor, 
                'header_id': None, 
                'ken_code': user_proxy_list[0].ken_code, 
                'city_code': user_proxy_list[0].city_code, 
                'action_code': _ARE_ACT_01, 
                'status_code': _SUCCESS, 
                'info_count': 1, 
                'warn_count': 0, 
                'deleted_at': None, 
                'info_log': get_info_log(), 
                'warn_log': get_warn_log(), 
                'download_file_path': None, 
                'download_file_name': None, 
                'upload_file_path': upload_file_path, 
                'upload_file_name': upload_file_name
            })
            bool_return = publish_consume_message(metadata=func_params)
            if bool_return == False:
                print_log('[ERROR] publish_message()関数が異常終了しました。', 'WARN')
                raise Exception
            
            ###################################################################
            ### DBアクセス処理(2040)
            ### トリガーテーブルにB02水害区域図貼付けトリガーを未実行＝次回実行対象として登録する。TODO TO-DO TO_DO
            ###################################################################
            print_log('[DEBUG] P0110City.browser_post_area()関数 STEP 12/13.', 'DEBUG')
            func_params = dict({
                'connection_cursor': connection_cursor, 
                'header_id': None, 
                'ken_code': user_proxy_list[0].ken_code, 
                'city_code': user_proxy_list[0].city_code, 
                'action_code': _ARE_ACT_02, 
                'status_code': None, 
                'download_file_path': None, 
                'download_file_name': None, 
                'upload_file_path': upload_file_path, 
                'upload_file_name': upload_file_name
            })
            bool_return = publish_message(metadata=func_params)
            if bool_return == False:
                print_log('[ERROR] publish_message()関数が異常終了しました。', 'WARN')
                raise Exception
                
            connection_cursor.execute("""COMMIT""");
            
        except:
            print_log('[ERROR] P0110City.browser_post_area()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
            print_log('[ERROR] P0110City.browser_post_area()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
            print_log('[ERROR] P0110City.browser_post_area()関数が異常終了しました。', 'ERROR')
            connection_cursor.execute("""ROLLBACK""")
            template = loader.get_template('P0110City/browser/browser.html')
            context = {
                'alert_log': get_alert_log(), 
            }
            return False, HttpResponse(template.render(context, request))
            
        finally:
            connection_cursor.close()
            
        #######################################################################
        ### レスポンスセット処理(2050)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.browser_post_area()関数 STEP 13/13.', 'DEBUG')
        template = loader.get_template('P0110City/browser/browser.html')
        context = {
            'browser_post_area_info': 'browser_post_area_info',
        }
        print_log('[INFO] P0110City.browser_post_area()関数が正常終了しました。', 'INFO')
        return True, HttpResponse(template.render(context, request))
    
    except:
        print_log('[ERROR] P0110City.browser_post_area()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.browser_post_area()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.browser_post_area()関数が異常終了しました。', 'ERROR')
        template = loader.get_template('P0110City/browser/browser.html')
        context = {
            'alert_log': get_alert_log(), 
        }
        return False, HttpResponse(template.render(context, request))

###############################################################################
### 市区町村用一般資産調査員調査票EXCELダウンロード
### 市区町村用一般資産調査員調査票CSVダウンロード
### 市区町村用一般資産集計結果EXCELダウンロード
### 市区町村用一般資産集計結果CSVダウンロード
### 市区町村用水害区域図PDFダウンロード
### 市区町村用水害区域図KMLダウンロード
###############################################################################
def download_header_id(request, header_id, file_type):
    try:
        #######################################################################
        ### 引数チェック処理(0000)
        ### ブラウザからのリクエストと引数をチェックする。
        #######################################################################
        reset_log()
        print_log('[INFO] P0110City.download_header_id()関数が開始しました。', 'INFO')
        print_log('[DEBUG] P0110City.download_header_id()関数 STEP 1/5.', 'DEBUG')
        print_log('[DEBUG] P0110City.download_header_id()関数 str(request.method)={}'.format(str(request.method)), 'DEBUG')
        print_log('[DEBUG] P0110City.download_header_id()関数 str(request.user)={}'.format(str(request.user)), 'DEBUG')
        print_log('[DEBUG] P0110City.download_header_id()関数 header_id={}'.format(header_id), 'DEBUG')
        
        #######################################################################
        ### DBアクセス処理(0010)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.download_header_id()関数 STEP 2/5.', 'DEBUG')
        params = dict({
            'USERNAME': str(request.user), 
            'ROLE_CODE': _ROLE_CITY
        })
        user_proxy_list = USER_PROXY.objects.raw("""
            SELECT 
                P1.ID, 
                A1.USERNAME, 
                P1.ROLE_CODE, 
                P1.KEN_CODE, 
                P1.CITY_CODE 
            FROM USER_PROXY P1 
            LEFT JOIN (
                SELECT 
                    * 
                FROM AUTH_USER) A1 ON P1.USER_ID=A1.ID 
            WHERE 
                A1.USERNAME=%(USERNAME)s AND 
                P1.ROLE_CODE=%(ROLE_CODE)s""", params)
            
        print_log('{}'.format(user_proxy_list), 'DEBUG')
        print_log('{}'.format(len(user_proxy_list)), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0]), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].ken_code), 'DEBUG')
        print_log('{}'.format(user_proxy_list[0].city_code), 'DEBUG')

        #######################################################################
        ### 戻り値チェック処理(0020)
        ### 戻り値をチェックして、異常ケース、警告ケースの場合、
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.download_header_id()関数 STEP 3/5.', 'DEBUG')
        if user_proxy_list == False:
            print_log('[WARN] P0110City.download_header_id()関数が警告終了しました。', 'WARN')
            response = HttpResponseNotFound("")
            return False, response
        
        if user_proxy_list[0].city_code == False:
            print_log('[WARN] P0110City.download_header_id()関数が警告終了しました。', 'WARN')
            response = HttpResponseNotFound("")
            return False, response

        #######################################################################
        ### DBアクセス処理(0030)
        ### DBにアクセスして、データを取得する。
        #######################################################################
        print_log('[DEBUG] P0110City.download_header_id()関数 STEP 4/5.', 'DEBUG')
        func_params = dict({
            'IPPAN_HEADER_ID': header_id, 
            'AREA_ID': header_id, 
            'FILE_TYPE': file_type
        })
        if file_type == _IPP_CHO_EXC:
            bool_return, file_path = get_ippan_chosa_csv_excel(request, func_params)
        elif file_type == _IPP_CHO_CSV:
            bool_return, file_path = get_ippan_chosa_csv_excel(request, func_params)
        elif file_type == _IPP_SUM_EXC:
            bool_return, file_path = get_ippan_summary_csv_excel(request, func_params)
        elif file_type == _IPP_SUM_CSV:
            bool_return, file_path = get_ippan_summary_csv_excel(request, func_params)
        elif file_type == _ARE_PDF:
            bool_return, file_path = get_area_kml_pdf(request, func_params)
        elif file_type == _ARE_KML:
            bool_return, file_path = get_area_kml_pdf(request, func_params)
            
        if bool_return == False:
            raise Exception

        #######################################################################
        ### レスポンスセット処理(0040)
        ### テンプレートとコンテキストを設定して、レスポンスをブラウザに戻す。
        #######################################################################
        print_log('[DEBUG] P0110City.download_header_id()関数 STEP 5/5.', 'DEBUG')
        print_log('[INFO] P0110City.download_header_id()関数が正常終了しました。', 'INFO')
        if file_type == _IPP_CHO_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _IPP_CHO_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _IPP_SUM_EXC:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="test.xlsx"'
        elif file_type == _IPP_SUM_CSV:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="test.csv"'
        elif file_type == _ARE_PDF:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/pdf')
            response['Content-Disposition'] = 'attachment; filename="test.pdf"'
        elif file_type == _ARE_KML:
            response = HttpResponse(content=open(file_path, 'rb').read(), content_type='application/kml')
            response['Content-Disposition'] = 'attachment; filename="test.kml"'
            
        return True, response
    
    except:
        print_log('[ERROR] P0110City.download_header_id()関数 {}'.format(sys.exc_info()[0]), 'ERROR')
        print_log('[ERROR] P0110City.download_header_id()関数 {}'.format(sys.exc_info()[1]), 'ERROR')
        print_log('[ERROR] P0110City.download_header_id()関数が異常終了しました。', 'ERROR')
        response = HttpResponseNotFound("")
        return False, response
